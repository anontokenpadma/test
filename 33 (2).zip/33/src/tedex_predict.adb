with Tedex_Echo;
with Tedex_Util;

package body Tedex_Predict with SPARK_Mode is

   function Expired (Now, Stamp, Ms : Natural) return Boolean
     --  True when Stamp is older than Ms (or the clock stepped back,
     --  which fails open toward dropping stale belief).
   is (Stamp > Now or else Now - Stamp > Ms);

   --  Append S to Buf (1-based, Len = current length). Drops the tail
   --  past the buffer cap (pathological backlog only).
   procedure Put (Buf : in out String; Len : in out Natural; S : String)
     with Pre  => Buf'First = 1 and Len <= Buf'Length
                  and S'Length <= Buf'Length
                  and Buf'Last <= 100_000 and S'Last <= 100_000,
          Post => Len <= Buf'Length
                  and Len = Len'Old
                          + Natural'Min (Buf'Length - Len'Old, S'Length),
     Global => null,
     Depends => ((Buf, Len) => (Buf, Len, S))
   is
      Room : constant Natural := Buf'Length - Len;
      Take : constant Natural := Natural'Min (Room, S'Length);
   begin
      if Take > 0 then
         Buf (Len + 1 .. Len + Take) := S (S'First .. S'First + Take - 1);
      end if;
      Len := Len + Take;
   end Put;

   function Tail_Len (Total, Drop : Natural) return Natural
     --  Length left after dropping Drop bytes (saturates at 0).
   is (if Drop >= Total then 0 else Total - Drop)
     with Post => Tail_Len'Result <= Total,
     Global => null,
     Depends => (Tail_Len'Result => (Total, Drop));

   --  Length through the first CRLF-terminated submitted line in Ps
   --  (0 when absent or overlong). Ps must be 1-based.
   function First_Line_Len (Ps : String) return Natural
     with Pre  => Ps'First = 1,
          Post => First_Line_Len'Result <= Ps'Length
                  and (First_Line_Len'Result = 0
                       or First_Line_Len'Result >= 2),
     Global => null,
     Depends => (First_Line_Len'Result => Ps)
   is
   begin
      if Ps'Length < 3 then
         return 0;
      end if;
      for I in 1 .. Ps'Length - 1 loop
         pragma Loop_Invariant (I in 1 .. Ps'Length);
         if Ps (I) = ASCII.CR and then Ps (I + 1) = ASCII.LF then
            if I + 1 > 256 then
               return 0;
            end if;
            return I + 1;
         end if;
      end loop;
      return 0;
   end First_Line_Len;

   --  Length through the first submitted line fully inside
   --  Ps (1 .. K) (0 when the match reaches no line end).
   function Match_Lines (Ps : String; K : Natural) return Natural
     with Pre  => Ps'First = 1 and K <= Ps'Length,
          Post => Match_Lines'Result <= K,
     Global => null,
     Depends => (Match_Lines'Result => (Ps, K))
   is
      Lb : Natural := 0;
   begin
      if K >= 2 then
         for J in 1 .. K - 1 loop
            pragma Loop_Invariant (Lb = 0 or Lb <= K);
            exit when Lb /= 0;
            if Ps (J) = ASCII.CR and then Ps (J + 1) = ASCII.LF then
               Lb := J + 1;
            end if;
         end loop;
      end if;
      return Lb;
   end Match_Lines;

   --  1-based offset of Needle occurring verbatim in Haystack, or 0.
   --  Both 1-based (all callers normalize). Plain scan, no contracts
   --  borrowed from anywhere.
   function Find_Occurrence (Haystack, Needle : String) return Natural
     with Pre  => Haystack'First = 1 and Needle'First = 1
                  and Needle'Length >= 1
                  and Haystack'Length <= 100_000
                  and Needle'Length <= 100_000,
          Post => Find_Occurrence'Result <= Haystack'Length + 1
                  and (if Find_Occurrence'Result /= 0 then
                         Find_Occurrence'Result >= 1
                         and Find_Occurrence'Result - 1
                               + Needle'Length <= Haystack'Length
                         and Haystack (Find_Occurrence'Result
                                       .. Find_Occurrence'Result
                                          + Needle'Length - 1)
                               = Needle),
     Global => null,
     Depends => (Find_Occurrence'Result => (Haystack, Needle))
   is
   begin
      if Needle'Length > Haystack'Length then
         return 0;
      end if;
      for H in 1 .. Haystack'Length - Needle'Length + 1 loop
         pragma Loop_Invariant (H in 1 .. Haystack'Length + 1);
         declare
            Match : Boolean := True;
         begin
            for N in 1 .. Needle'Length loop
               pragma Loop_Invariant (N in 1 .. Needle'Length + 1);
               pragma Loop_Invariant
                 (if Match then
                    Haystack (H .. H + N - 2) = Needle (1 .. N - 1));
               if Haystack (H + N - 1) /= Needle (N) then
                  Match := False;
                  exit;
               end if;
            end loop;
            if Match then
               return H;
            end if;
         end;
      end loop;
      return 0;
   end Find_Occurrence;

   --  Drop the first N belief bytes (saturating). Content after the
   --  drop is whatever the caller decides next; only the length and
   --  state validity are contracted (callers re-slice explicitly).
   procedure Drop_Pending (St : in out Echo_State; N : Natural)
     with Pre  => Valid_State (St),
          Post => Valid_State (St)
                  and St.Pend_Len = Tail_Len (St'Old.Pend_Len, N),
     Global => null,
     Depends => (St => (St, N))
   is
   begin
      if N >= St.Pend_Len then
         St.Pend_Len := 0;
      else
         St.Pend (1 .. St.Pend_Len - N) :=
           St.Pend (N + 1 .. St.Pend_Len);
         St.Pend_Len := St.Pend_Len - N;
      end if;
   end Drop_Pending;

   --  Emit one predicted run (stdin bytes First .. Last, and only
   --  when Active; stale bounds after a flush are ignored) to the
   --  display buffer and the belief (capped).
   procedure Belief_Append
     (St    : in out Echo_State;
      Chunk : String;
      Active : Boolean;
      First : Natural;
      Last  : Integer;
      Now   : Natural)
     with Pre  => Chunk'First = 1
                  and (First >= 1 and then First - 1 <= Chunk'Length)
                  and Last in 0 .. Chunk'Length
                  and Chunk'Last <= 100_000
                  and Now <= Max_Ms
                  and Valid_State (St),
          Post => Valid_State (St)
                  and St.Pend_Len <= Max_Pending,
     Global => null,
     Depends => (St => (St, Chunk, Active, First, Last, Now))
   is
      Was_Empty : constant Boolean := (St.Pend_Len = 0);
   begin
      if Active and then Last >= First then
         if St.Pend_Len < Max_Pending then
            declare
               Room : constant Natural := Max_Pending - St.Pend_Len;
               Run_Len : constant Natural := Last - First + 1;
               Take : constant Natural := Natural'Min (Room, Run_Len);
            begin
               St.Pend (St.Pend_Len + 1 .. St.Pend_Len + Take) :=
                 Chunk (First .. First + Take - 1);
               St.Pend_Len := St.Pend_Len + Take;
               if Was_Empty and St.Pend_Len > 0 then
                  St.Pend_At := Now;
               end if;
            end;
         end if;
         if St.Printables + (Last - First + 1) > 4096 then
            St.Printables := 4096;
         else
            St.Printables := St.Printables + (Last - First + 1);
         end if;
      end if;
   end Belief_Append;

   procedure Emit_Newline
     (St    : in out Echo_State;
      Now   : Natural;
      Shown : in out String;
      Out_Len : in out Natural)
     with Pre  => Shown'First = 1 and Out_Len <= Shown'Length
                  and Shown'Length >= 4
                  and Shown'Length <= 100_000
                  and Now <= Max_Ms and Valid_State (St),
          Post => Valid_State (St) and Out_Len <= Out_Len'Old + 2,
     Global => null,
     Depends => (St      => (St, Now),
                 Shown   => (Shown, Out_Len),
                 Out_Len => (Shown, Out_Len))
   is
   begin
      Put (Shown, Out_Len, [Character'Val (13), Character'Val (10)]);
      if St.Pend_Len = 0 then
         St.Pend_At := Now;
      end if;
      if St.Pend_Len < Max_Pending - 1 then
         St.Pend (St.Pend_Len + 1) := Character'Val (13);
         St.Pend (St.Pend_Len + 2) := Character'Val (10);
         St.Pend_Len := St.Pend_Len + 2;
      end if;
      St.Printables := 0;
      St.Suspended := False;
   end Emit_Newline;

   procedure Emit_Erase
     (St    : in out Echo_State;
      Now   : Natural;
      Shown : in out String;
      Out_Len : in out Natural)
     with Pre  => Shown'First = 1 and Out_Len <= Shown'Length
                  and Shown'Length >= 4
                  and Shown'Length <= 100_000
                  and Now <= Max_Ms and Valid_State (St),
          Post => Valid_State (St) and Out_Len <= Out_Len'Old + 4,
     Global => null,
     Depends => (St      => (St, Now),
                 Shown   => (Shown, Out_Len),
                 Out_Len => (Shown, Out_Len))
   is
   begin
      Put (Shown, Out_Len,
           [Character'Val (8), Character'Val (27), '[', 'K']);
      if St.Credit < 64 then
         St.Credit := St.Credit + 1;
         if St.Credit = 1 then
            St.Erase_Since := Now;
         end if;
      end if;
      if St.Printables > 0 then
         St.Printables := St.Printables - 1;
      end if;
   end Emit_Erase;

   procedure Predict_Chunk
     (St    : in out Echo_State;
      Now   : Natural;
      Chunk : String;
      Shown : out String;
      Shown_Len : out Natural;
      Trace : out Trace_Code)
   is
      Out_Len : Natural := 0;
      Run_First : Positive := 1;
      Run_On    : Boolean := False;
   begin
      Shown := [others => ' '];
      Shown_Len := 0;
      Trace := Tr_None;
      if Chunk'Length = 0 then
         --  Vacuous (callers never pass empty chunks; Do_Consume and
         --  the stdin reader both guard): keeps degenerate bounds
         --  (e.g. Last = -1) out of the prover's model.
         return;
      end if;
      if St.Fullscreen then
         St.Printables := 0;
         St.Last_CR := False;
         return;
      end if;
      if St.Suspended then
         if Tedex_Util.Has_Newline (Chunk) then
            St.Suspended := False;
         else
            for Ch of Chunk loop
               if Ch = Character'Val (3) or Ch = Character'Val (21) then
                  St.Pend_Len := 0;
                  St.Printables := 0;
                  exit;
               end if;
            end loop;
            St.Last_CR := False;
            return;
         end if;
      end if;
      for I in Chunk'Range loop
         pragma Loop_Invariant (Out_Len <= 4 * (I - Chunk'First));
         pragma Loop_Invariant (St.Pend_Len <= Max_Pending);
         pragma Loop_Invariant (St.Printables <= 4096);
         pragma Loop_Invariant (St.Credit <= 64);
         pragma Loop_Invariant (Valid_State (St));
         pragma Loop_Invariant (Run_First in 1 .. I + 1);
         pragma Loop_Invariant (Out_Len <= Shown'Length);
         if Chunk (I) = Character'Val (13)
           or Chunk (I) = Character'Val (10)
         then
            Belief_Append (St, Chunk, Run_On, Run_First, I - 1, Now);
            Run_On := False;
            if Chunk (I) = Character'Val (10) and St.Last_CR then
               St.Last_CR := False;
            else
               Emit_Newline (St, Now, Shown, Out_Len);
               St.Last_CR := (Chunk (I) = Character'Val (13));
            end if;
         elsif Chunk (I) = Character'Val (127)
           or Chunk (I) = Character'Val (8)
         then
            Belief_Append (St, Chunk, Run_On, Run_First, I - 1, Now);
            Run_On := False;
            St.Last_CR := False;
            if St.Printables > 0 and St.Credit < 64 then
               Emit_Erase (St, Now, Shown, Out_Len);
            end if;
         elsif Chunk (I) = Character'Val (3)
           or Chunk (I) = Character'Val (21)
         then
            Belief_Append (St, Chunk, Run_On, Run_First, I - 1, Now);
            Run_On := False;
            St.Last_CR := False;
            St.Pend_Len := 0;
            St.Printables := 0;
         elsif Tedex_Util.Is_Predict_Byte (Chunk (I)) then
            Put (Shown, Out_Len, Chunk (I .. I));
            if not Run_On then
               Run_On := True;
               Run_First := I;
            end if;
            St.Last_CR := False;
         else
            Belief_Append (St, Chunk, Run_On, Run_First, I - 1, Now);
            Run_On := False;
            St.Last_CR := False;
         end if;
      end loop;
      Belief_Append (St, Chunk, Run_On, Run_First, Chunk'Last, Now);
      Shown_Len := Out_Len;
   end Predict_Chunk;

   procedure Consume_Chunk
     (St    : in out Echo_State;
      Now   : Natural;
      Chunk : String;
      Shown : out String;
      Shown_Len : out Natural;
      Trace : out Trace_Code)
   is
      Seg : String (1 .. Max_Chunk + Max_Hold) := [others => ' '];
      Seg_Len : Natural := 0;
      Out_Len : Natural := 0;
   begin
      Shown := [others => ' '];
      Trace := Tr_None;
      --  Continuity: withheld tail rejoins the stream.
      if St.Hold_Len > 0 then
         Seg (1 .. St.Hold_Len) := St.Hold (1 .. St.Hold_Len);
         Seg_Len := St.Hold_Len;
         St.Hold_Len := 0;
      end if;
      Put (Seg, Seg_Len, Chunk);
      --  Fullscreen/password scans over tail history + segment.
      declare
         Scan : String (1 .. 8 + Max_Chunk + Max_Hold) :=
           [others => ' '];
         Scan_Len : Natural := 0;
      begin
         if St.Fs_Len > 0 then
            Scan (1 .. St.Fs_Len) := St.Fs (1 .. St.Fs_Len);
            Scan_Len := St.Fs_Len;
         end if;
         Put (Scan, Scan_Len, Seg (1 .. Seg_Len));
         if Tedex_Util.Low_Contains
              (Scan (1 .. Scan_Len),
               ASCII.ESC & "[?1049h")
         then
            St.Fullscreen := True;
            St.Pend_Len := 0;
            St.Printables := 0;
            St.Credit := 0;
            St.Half := 0;
         end if;
         if Tedex_Util.Low_Contains
              (Scan (1 .. Scan_Len),
               ASCII.ESC & "[?1049l")
         then
            St.Fullscreen := False;
         end if;
         if Scan_Len > 8 then
            St.Fs (1 .. 8) := Scan (Scan_Len - 7 .. Scan_Len);
            St.Fs_Len := 8;
         elsif Scan_Len > 0 then
            St.Fs (1 .. Scan_Len) := Scan (1 .. Scan_Len);
            St.Fs_Len := Scan_Len;
         else
            St.Fs_Len := 0;
         end if;
         if Tedex_Util.Low_Contains (Seg (1 .. Seg_Len), "password")
           or Tedex_Util.Low_Contains (Seg (1 .. Seg_Len), "passwd")
           or Tedex_Util.Low_Contains (Seg (1 .. Seg_Len), "passphrase")
         then
            St.Suspended := True;
         end if;
      end;
      --  Swallow predicted erase echoes.
      if St.Credit > 0 then
         if Expired (Now, St.Erase_Since, 2_000) then
            St.Credit := 0;
            St.Half := 0;
         else
            declare
               Pos : Natural := 1;
            begin
               while St.Credit > 0 and Pos <= Seg_Len loop
                  pragma Loop_Invariant (Pos in 1 .. Seg_Len + 1);
                  pragma Loop_Invariant (St.Credit <= 64);
                  pragma Loop_Invariant (Valid_State (St));
                  pragma Loop_Invariant
                    (Seg_Len <= Max_Chunk + Max_Hold);
                  declare
                     E1 : constant String :=
                       [ASCII.BS, ASCII.ESC, '[', 'K'];
                     E2 : constant String :=
                       [ASCII.BS, ' ', ASCII.BS];
                     Rest : constant Natural :=
                       Tail_Len (Seg_Len, Pos - 1);
                     Matched : Natural := 0;
                  begin
                     if St.Half = 1
                       and then not Expired (Now, St.Frag_At, 1_000)
                       and then Rest >= 3
                       and then Seg (Pos .. Pos + 2) =
                         [ASCII.ESC, '[', 'K']
                     then
                        Matched := 3;
                        St.Half := 0;
                     elsif St.Half = 2
                       and then not Expired (Now, St.Frag_At, 1_000)
                       and then Rest >= 1
                       and then Seg (Pos) = ASCII.BS
                     then
                        Matched := 1;
                        St.Half := 0;
                     else
                        St.Half := 0;
                     end if;
                     if Matched = 0 then
                        if Rest >= 4
                          and then Seg (Pos .. Pos + 3) = E1
                        then
                           Matched := 4;
                        elsif Rest >= 3
                          and then Seg (Pos .. Pos + 2) = E2
                        then
                           Matched := 3;
                        elsif Rest < 4
                          and then E1 (1 .. Rest) =
                            Seg (Pos .. Seg_Len)
                        then
                           St.Half := 1;
                           St.Frag_At := Now;
                           Pos := Seg_Len + 1;
                        elsif Rest < 3
                          and then E2 (1 .. Rest) =
                            Seg (Pos .. Seg_Len)
                        then
                           St.Half := 2;
                           St.Frag_At := Now;
                           Pos := Seg_Len + 1;
                        else
                           Pos := Seg_Len + 1;
                        end if;
                     end if;
                     if Matched > 0 then
                        Pos := Pos + Matched;
                        St.Credit := St.Credit - 1;
                        Trace := Tr_Erased;
                     end if;
                  end;
               end loop;
               if Pos > Seg_Len then
                  Shown_Len := Out_Len;
                  return;
               end if;
               Seg (1 .. Seg_Len - Pos + 1) := Seg (Pos .. Seg_Len);
               Seg_Len := Seg_Len - Pos + 1;
            end;
         end if;
      end if;
      --  Stale belief expires (no-echo consumer path).
      if St.Pend_Len > 0
        and then Expired (Now, St.Pend_At, 2_000)
      then
         St.Pend_Len := 0;
         St.Printables := 0;
         St.Credit := 0;
         St.Half := 0;
         Trace := Tr_Expired;
         Put (Shown, Out_Len, Seg (1 .. Seg_Len));
         Shown_Len := Out_Len;
         return;
      end if;
      if St.Pend_Len = 0 then
         Put (Shown, Out_Len, Seg (1 .. Seg_Len));
         Shown_Len := Out_Len;
         return;
      end if;
      --  Decision loop over strictly-shrinking tails. Seg stays
      --  1-based; Base is the de-bracketed view (offset Pre). Every
      --  continue path strictly shortens Seg (PL/SL drop >= 2 bytes);
      --  all other paths return. Out_Len only grows by decided bytes.
      declare
         Seg0 : constant Natural := Seg_Len;
      begin
         loop
            pragma Loop_Invariant (Out_Len + Seg_Len <= Seg0 + 9);
            pragma Loop_Invariant (Seg_Len <= Max_Chunk + Max_Hold);
            pragma Loop_Invariant (Out_Len <= Shown'Length);
            pragma Loop_Invariant (St.Pend_Len <= Max_Pending);
            pragma Loop_Invariant (Valid_State (St));
            pragma Loop_Invariant (St.Hold_Len <= Max_Hold);
            declare
               Pre : constant Natural :=
                 Tedex_Echo.Bracket_Pre (Seg (1 .. Seg_Len));
               Boff : constant Natural :=
                 (if Pre >= Seg_Len then Seg_Len else Pre);
               Blen : constant Natural := Seg_Len - Boff;
               B : String (1 .. Max_Chunk + Max_Hold) :=
                 [others => ' '];
               K  : Natural;
               FP : Boolean;
               FM : Boolean;
            begin
               if Seg_Len = 0 or St.Pend_Len = 0 then
                  Put (Shown, Out_Len, Seg (1 .. Seg_Len));
                  Shown_Len := Out_Len;
                  return;
               end if;
               if Pre >= Seg_Len then
                  --  Degenerate all-framing chunk: show the control
                  --  bytes (the terminal interprets them invisibly).
                  Put (Shown, Out_Len, Seg (1 .. Seg_Len));
                  Shown_Len := Out_Len;
                  return;
               end if;
               B (1 .. Blen) := Seg (Boff + 1 .. Seg_Len);
               K := Tedex_Echo.Common_Prefix
                 (St.Pend (1 .. St.Pend_Len), B (1 .. Blen));
               FP := K >= St.Pend_Len;
               FM := K >= Blen;
               if K = 0 then
                  declare
                     Ln : constant Natural :=
                       First_Line_Len (St.Pend (1 .. St.Pend_Len));
                     Hit : Natural := 0;
                  begin
                     if Ln >= 2 then
                        Hit := Find_Occurrence
                          (B (1 .. Blen), St.Pend (1 .. Ln));
                     end if;
                     if Hit = 0 then
                        --  Possible echo split: hold a matching tail
                        --  (threshold 4 keeps coincidental 1-3 byte
                        --  tails on the fast show path).
                        declare
                           Fl : Natural;
                           Best : Natural := 0;
                        begin
                           if Ln >= 5 and then Ln <= 257
                             and then Blen >= 4
                           then
                              Fl := Ln;
                              for SL in reverse 4 .. Natural'Min
                                (Fl - 1, Blen)
                              loop
                                 pragma Loop_Invariant
                                   (Best = 0
                                    or (Best >= 4
                                        and Best <= Natural'Min
                                              (Fl - 1, Blen)));
                                 exit when Best /= 0;
                                 if B (Blen - SL + 1 .. Blen)
                                   = St.Pend (1 .. SL)
                                 then
                                    Best := SL;
                                 end if;
                              end loop;
                           end if;
                           if Best >= 4 then
                              Trace := Tr_Hold;
                              St.Hold (1 .. Best) :=
                                B (Blen - Best + 1 .. Blen);
                              St.Hold_Len := Best;
                              St.Hold_At := Now;
                              Put (Shown, Out_Len, B (1 .. Blen - Best));
                              Shown_Len := Out_Len;
                              return;
                           end if;
                        end;
                        Put (Shown, Out_Len, Seg (1 .. Seg_Len));
                        Shown_Len := Out_Len;
                        return;
                     else
                        --  Show leading output (framing included),
                        --  swallow one echoed line.
                        Trace := Tr_Substring;
                        if Pre > 0 then
                           Put (Shown, Out_Len, Seg (1 .. Pre));
                        end if;
                        Put (Shown, Out_Len, B (1 .. Hit - 1));
                        Drop_Pending (St, Ln);
                        Seg (1 .. Seg_Len - Pre - (Hit - 1) - Ln)
                          := Seg (Pre + (Hit - 1) + Ln + 1 .. Seg_Len);
                        Seg_Len := Seg_Len - Pre - (Hit - 1) - Ln;
                        if St.Pend_Len /= 0 then
                           St.Pend_At := Now;
                        end if;
                     end if;
                  end;
               elsif FM and then not FP then
                  Drop_Pending (St, K);
                  if Pre > 0 then
                     Put (Shown, Out_Len, Seg (1 .. Pre));
                  end if;
                  if St.Pend_Len /= 0 then
                     St.Pend_At := Now;
                  end if;
                  Trace := Tr_Frag;
                  Shown_Len := Out_Len;
                  return;
               elsif FP then
                  if Pre > 0 then
                     Put (Shown, Out_Len, Seg (1 .. Pre));
                  end if;
                  if K < Blen then
                     Put (Shown, Out_Len, B (K + 1 .. Blen));
                  end if;
                  St.Pend_Len := 0;
                  Trace := Tr_Full;
                  Shown_Len := Out_Len;
                  return;
               else
                  --  Partial prefix: line-boundary swallow, substring
                  --  eat, or classic fail-open (in that order).
                  declare
                     Lb : constant Natural :=
                       Match_Lines (St.Pend (1 .. St.Pend_Len), K);
                  begin
                     if Lb = 0 then
                        declare
                           Ln : constant Natural :=
                             First_Line_Len
                               (St.Pend (1 .. St.Pend_Len));
                           Hit : Natural := 0;
                        begin
                           if Ln >= 2 then
                              Hit := Find_Occurrence
                                (B (1 .. Blen), St.Pend (1 .. Ln));
                           end if;
                           if Hit = 0 then
                              Trace := Tr_Fail_Open;
                              Put (Shown, Out_Len, Seg (1 .. Seg_Len));
                              St.Pend_Len := 0;
                              St.Printables := 0;
                              Shown_Len := Out_Len;
                              return;
                           end if;
                           Trace := Tr_Substring;
                           if Pre > 0 then
                              Put (Shown, Out_Len, Seg (1 .. Pre));
                           end if;
                           Put (Shown, Out_Len, B (1 .. Hit - 1));
                           Drop_Pending (St, Ln);
                           Seg (1 .. Seg_Len - Pre - (Hit - 1) - Ln)
                             := Seg (Pre + (Hit - 1) + Ln + 1
                                     .. Seg_Len);
                           Seg_Len := Seg_Len - Pre - (Hit - 1) - Ln;
                           if St.Pend_Len /= 0 then
                              St.Pend_At := Now;
                           end if;
                        end;
                     else
                        Trace := Tr_Pipeline;
                        if Pre > 0 then
                           Put (Shown, Out_Len, Seg (1 .. Pre));
                        end if;
                        Drop_Pending (St, Lb);
                        Seg (1 .. Seg_Len - Pre - Lb)
                          := Seg (Pre + Lb + 1 .. Seg_Len);
                        Seg_Len := Seg_Len - Pre - Lb;
                        if St.Pend_Len /= 0 then
                           St.Pend_At := Now;
                        end if;
                     end if;
                  end;
               end if;
            end;
         end loop;
      end;
   end Consume_Chunk;

   procedure Flush_Hold
     (St    : in out Echo_State;
      Now   : Natural;
      Shown : out String;
      Shown_Len : out Natural)
   is
   begin
      Shown := [others => ' '];
      Shown_Len := 0;
      if St.Hold_Len = 0 or Now <= St.Hold_At + 1_000 then
         return;
      end if;
      Shown (1 .. St.Hold_Len) := St.Hold (1 .. St.Hold_Len);
      Shown_Len := St.Hold_Len;
      St.Hold_Len := 0;
   end Flush_Hold;

end Tedex_Predict;
