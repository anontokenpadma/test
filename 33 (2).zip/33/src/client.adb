--  tedex client: device agent (-c) or manager dashboard (-u),
--  over raw TCP, ws:// or wss:// (WebSocket, plain or via openssl s_client).
--  Usage: ./client [-s host] [-p port] [--ws ws[s]://host[:port][/path]]
--                 -c user password [--name id] [-r] [--persist] [--uninstall]
--         ./client [-s host] [-p port] [--ws ...] -u user password
with Ada.Calendar;
with Ada.Command_Line;
with Ada.Directories;
with Ada.Environment_Variables;
with Ada.Exceptions;
with Ada.Streams;
with Ada.Streams.Stream_IO;
with Ada.Strings.Unbounded;
with Ada.Text_IO;
with GNAT.OS_Lib;
with GNAT.Sockets;
with Interfaces.C;
with Interfaces.C.Strings;

with Tedex_B64;
with Tedex_Net;
with Tedex_Predict;
with Tedex_Protocol;
with Tedex_Shell;
with Tedex_Term;
with Tedex_Tls;
with Tedex_Util;
with Tedex_Ws;

--  Boundary main, not in SPARK (sockets, TLS subprocess, pty,
--  tasking); wire framing/parsing delegated to proved SPARK units.
procedure Client with SPARK_Mode => Off is

   use GNAT.Sockets;
   use Ada.Strings.Unbounded;
   use Tedex_Net;
   use Ada.Streams;
   use type Interfaces.C.int;

   Host   : Unbounded_String := To_Unbounded_String ("127.0.0.1");
   Port   : Integer := 9999;
   Is_Dev : Boolean := False;
   User   : Unbounded_String;
   Pass   : Unbounded_String;
   Dev_Id : Unbounded_String;
   Ws_Url : Unbounded_String := Null_Unbounded_String;

   Persist      : Boolean := False;  --  --persist: retry forever
   Do_Install   : Boolean := False;  --  -r: install systemd service
   Do_Uninstall : Boolean := False;  --  --uninstall: remove it
   Name_Given   : Boolean := False;  --  --name was explicit
   Was_Removed  : Boolean := False;  --  ordered to stop by manager

   type TKind is (T_Raw, T_Ws_Sock, T_Ws_Pipe);

   type Transport is record
      Kind      : TKind := T_Raw;
      Sock      : Socket_Type := No_Socket;
      Rfd, Wfd  : Interfaces.C.int := -1;
      Pid       : Interfaces.C.int := -1;
      Ws_Host   : Unbounded_String;
      Ws_Path   : Unbounded_String;
   end record;

   T : Transport;



   Mgr_Pongs_Seen : Natural := 0;
   --  Inbound WS pong counter (client side). The manager prompt loop
   --  uses it to verify the link is really alive while idling;
   --  auto-consumed pongs would otherwise hide a silent death.

   --  DEVICES counter: proved in Tedex_Util (total function, 0 on
   --  any shape error). The historical local body was removed.

   --  Natural image without leading space: the single proved
   --  Tedex_Protocol.Nat_Image. All callers pass N <= 999_999 (ports,
   --  dims, DEVICES counts), so the precondition always holds; kept as
   --  a wrapper to avoid touching call sites.
   function Trimmed_Count (N : Natural) return String is
   begin
      return Tedex_Protocol.Nat_Image (N);
   end Trimmed_Count;

   --  Optional "SHELL_START <cols> <rows>" suffix from the server.
   --  Strict: digits only, both 1..1000, nothing else after the tag.
   --  Anything else yields 0,0 (keep the 80x24 spawn default).
   function C_Geteuid return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "geteuid";
   --  0 when running as root (system unit install instead of --user).

   function C_Get_Size (Rows, Cols : access Interfaces.C.int)
     return Interfaces.C.int
     with Import => True, Convention => C, External_Name => "term_get_size";
   --  Manager tty size via TIOCGWINSZ on fd 0 (0 ok, -1 unknown):
   --  callers fall back to 80x24 rather than propagating 0x0.

   --  Stream buffers for WS poll loops ---------------------------------
   --  Attach_Ws polled MRecv (0.01s) and Run_Shell_Ws polled MRecv
   --  (0.001s). A frame split across two TCP/TLS arrivals with a gap
   --  longer than the poll slice timed out mid-message and DISCARDED the
   --  already-read header bytes, desyncing the stream ("bad frame" ->
   --  "session ended" under continuous output). These buffers keep every
   --  byte until a full message assembles; a poll with no complete
   --  message yet returns Got=False and loses nothing.
   Pipe_Raw : Unbounded_String := Null_Unbounded_String;  --  TLS-pipe bytes
   Sock_Raw : Unbounded_String := Null_Unbounded_String;  --  WS-socket bytes
   Frag_Msg : Unbounded_String := Null_Unbounded_String;  --  fragmented msg
   Frag_On  : Boolean := False;

   procedure Clear_Streams is
   begin
      Pipe_Raw := Null_Unbounded_String;
      Sock_Raw := Null_Unbounded_String;
      Frag_Msg := Null_Unbounded_String;
      Frag_On  := False;
   end Clear_Streams;

   function Rand_Bytes (N : Positive) return String is
      use Ada.Streams.Stream_IO;
      F    : File_Type;
      Buf  : Stream_Element_Array (1 .. Stream_Element_Offset (N));
      Last : Stream_Element_Offset;
      R    : String (1 .. N);
   begin
      Open (F, In_File, "/dev/urandom");
      Read (F, Buf, Last);
      Close (F);
      for I in 1 .. N loop
         R (I) := Character'Val (Buf (Stream_Element_Offset (I)));
      end loop;
      return R;
   end Rand_Bytes;

   function Rand_Hex (Bytes : Positive) return String is
      Raw : constant String := Rand_Bytes (Bytes);
   begin
      --  Nibble split is proved in Tedex_Util.Encode_Hex (only tiny
      --  lengths occur: device suffixes); fail closed if ever abused.
      if Bytes > Tedex_Util.Max_Hex_In then
         raise Constraint_Error with "rand hex too long";
      end if;
      return Tedex_Util.Encode_Hex (Raw);
   end Rand_Hex;

   function Resolve (H : String) return Inet_Addr_Type is
   begin
      return Inet_Addr (H);
   exception
      when Socket_Error =>
         return Addresses (Get_Host_By_Name (H), 1);
   end Resolve;

   function Connect_Sock (H : String; P : Integer) return Socket_Type is
      S    : Socket_Type;
      Addr : constant Sock_Addr_Type :=
        (Family => Family_Inet,
         Addr   => Resolve (H),
         Port   => Port_Type (P));
   begin
      Create_Socket (S);
      Connect_Socket (S, Addr);
      Set_No_Delay (S);
      return S;
   end Connect_Sock;

   procedure Close_Quiet (S : Socket_Type) is
   begin
      Close_Socket (S);
   exception
      when Socket_Error => null;
   end Close_Quiet;

   --  Pipe (openssl) byte IO --------------------------------------

   procedure Pipe_Send_All (Data : String) is
      use Interfaces.C;
      Rc : Interfaces.C.int;
   begin
      if Data'Length = 0 then
         return;
      end if;
      Rc := Tedex_Tls.Fd_Write_All (T.Wfd, Data'Address,
                                    Interfaces.C.int (Data'Length));
      if Rc /= 0 then
         raise Net_Error with "closed";
      end if;
   end Pipe_Send_All;

   function Pipe_Read_Exact (N : Natural; Deadln : Ada.Calendar.Time)
     return String
   is
      use Ada.Calendar;
      use Interfaces.C;
      Buf : String (1 .. Integer'Max (N, 1));
      Got : Natural := 0;
      Tmp : aliased String (1 .. 4096);
   begin
      if N = 0 then
         return "";
      end if;
      while Got < N loop
         declare
            Left : constant Duration := Deadln - Clock;
            Ms   : Integer;
            Rc   : Interfaces.C.int;
            Want : Integer;
         begin
            if Left <= 0.0 then
               raise Net_Error with "timeout";
            end if;
            Ms := Integer (Left * 1_000.0);
            if Ms > 5_000 then
               Ms := 5_000;
            elsif Ms < 1 then
               Ms := 1;
            end if;
            Want := Integer'Min (4_096, N - Got);
            Rc := Tedex_Tls.Fd_Read_Timeout
              (T.Rfd, Tmp'Address,
               Interfaces.C.int (Want), Interfaces.C.int (Ms));
            if Rc > 0 then
               for I in 1 .. Natural (Rc) loop
                  Got := Got + 1;
                  Buf (Got) := Tmp (I);
               end loop;
            elsif Rc = 0 then
               raise Net_Error with "closed";
            elsif Rc = -3 then
               null;  --  timeout slice; re-check deadline above
            elsif Rc = -2 then
               null;  --  transient; retry
            else
               raise Net_Error with "socket error";
            end if;
         end;
      end loop;
      return Buf (1 .. N);
   end Pipe_Read_Exact;

   function Next_Mask return String is
      Raw : constant String := Rand_Bytes (4);
      M   : String (1 .. 4);
   begin
      M := Raw;
      return M;
   end Next_Mask;

   procedure Ws_Pipe_Send (Data : String; Opcode : Natural := 2) is
      Buf   : String (1 .. 14 + Tedex_Ws.Max_Frame_Payload);
      First : Integer := Data'First;
      Rest  : Integer := Data'Length;
      First_Frag : Boolean := True;
   begin
      if Rest = 0 then
         declare
            FL : Natural;
         begin
            Tedex_Ws.Encode_Client_Frame
              ("", Opcode, Next_Mask, Buf, FL, Fin => True);
            Pipe_Send_All (Buf (1 .. FL));
            return;
         end;
      end if;
      while Rest > 0 loop
         declare
            N   : constant Integer :=
              Integer'Min (Rest, Tedex_Ws.Max_Frame_Payload);
            Ch  : String (1 .. N);
            FL  : Natural;
            Op  : constant Natural :=
              (if First_Frag then Opcode else 0);
         begin
            Ch := Data (First .. First + N - 1);
            Tedex_Ws.Encode_Client_Frame
              (Ch, Op, Next_Mask, Buf, FL, Fin => (N = Rest));
            Pipe_Send_All (Buf (1 .. FL));
            First := First + N;
            Rest := Rest - N;
            First_Frag := False;
         end;
      end loop;
   end Ws_Pipe_Send;

   procedure Ws_Pipe_Recv_Message
     (Timeout : Duration := 3_600.0;
      Payload : out Unbounded_String)
   is
      use Ada.Calendar;
      Deadln  : constant Time := Clock + Timeout;
      Msg     : Unbounded_String := Null_Unbounded_String;
      Started : Boolean := False;
   begin
      Payload := Null_Unbounded_String;
      loop
         declare
            Hdr2 : constant String := Pipe_Read_Exact (2, Deadln);
            L7   : constant Natural :=
              Character'Pos (Hdr2 (Hdr2'Last)) mod 128;
            Ext  : constant Natural :=
              (if L7 < 126 then 0 elsif L7 = 126 then 2 else 8);
            Need : constant Natural := 2 + Ext;  --  server frames: no mask
            Rest : constant String := Pipe_Read_Exact (Need - 2, Deadln);
            Full : constant String := Hdr2 & Rest;
            H    : Tedex_Ws.Frame_Header;
            Ok   : Boolean;
         begin
            Tedex_Ws.Decode_Header (Full, H, Ok, Require_Mask => False);
            if not Ok then
               raise Net_Error with "bad frame";
            end if;
            declare
               Pay : constant String := Pipe_Read_Exact (H.Pay_Len, Deadln);
            begin
               case H.Opcode is
                  when 8 =>
                     begin
                        Ws_Pipe_Send ("", 8);
                     exception
                        when Net_Error => null;
                     end;
                     raise Net_Error with "closed";
                  when 9 =>
                     Ws_Pipe_Send (Pay, 10);
                  when 10 =>
                     if Mgr_Pongs_Seen < Natural'Last then
                        Mgr_Pongs_Seen := Mgr_Pongs_Seen + 1;
                     end if;
                  when 0 =>
                     if not Started then
                        raise Net_Error with "unexpected continuation";
                     end if;
                     if Length (Msg) > Tedex_Ws.Msg_Cap - Pay'Length then
                        raise Net_Error with "message too big";
                     end if;
                     Append (Msg, Pay);
                     if H.Fin then
                        Payload := Msg;
                        return;
                     end if;
                  when 1 | 2 =>
                     if Started then
                        raise Net_Error with "interleaved message";
                     end if;
                     Started := True;
                     Msg := To_Unbounded_String (Pay);
                     if H.Fin then
                        Payload := Msg;
                        return;
                     end if;
                  when others =>
                     raise Net_Error with "bad opcode";
               end case;
            end;
         end;
      end loop;
   end Ws_Pipe_Recv_Message;

   function Ws_Pipe_Recv_Line (Timeout : Duration := 3_600.0) return String is
      P : Unbounded_String;
   begin
      Ws_Pipe_Recv_Message (Timeout, P);
      return To_String (P);
   end Ws_Pipe_Recv_Line;

   --  Case folding and blank stripping live in proved Tedex_Util now
   --  (single copy); the two historical locals were removed.

   procedure Validate_Handshake (Resp, Want : String) is
   begin
      --  Length guard: the byte loop stops past 8192, so fail closed
      --  (same verdict as a rejected handshake) instead of violating
      --  the proved bound.
      if Resp'Length > Tedex_Util.Max_Trim then
         raise Net_Error with "handshake rejected";
      end if;
      --  101/accept-key validation is proved in Tedex_Util (same
      --  verdicts, same messages as the inline version).
      declare
         Act : Tedex_Util.Hs_Action;
      begin
         Tedex_Util.Hs_Verdict
           (Tedex_Util.Check_Handshake (Resp, Want), Act);
         case Act is
            when Tedex_Util.Act_Accept =>
               null;
            when Tedex_Util.Act_Reject_Status =>
               raise Net_Error with "handshake rejected";
            when Tedex_Util.Act_Reject_Key =>
               raise Net_Error with "bad accept key";
         end case;
      end;
   end Validate_Handshake;

   --  End-of-headers marker: proved Tedex_Util.Tail_Blank (total
   --  function on String); callers convert from Unbounded_String.

   procedure Ws_Pipe_Handshake (Host, Path, Key : String) is
      use Ada.Calendar;
      Deadln : constant Time := Clock + 20.0;
      Req : constant String :=
        "GET " & Path & " HTTP/1.1" & ASCII.CR & ASCII.LF
        & "Host: " & Host & ASCII.CR & ASCII.LF
        & "Upgrade: websocket" & ASCII.CR & ASCII.LF
        & "Connection: Upgrade" & ASCII.CR & ASCII.LF
        & "Sec-WebSocket-Key: " & Key & ASCII.CR & ASCII.LF
        & "Sec-WebSocket-Version: 13" & ASCII.CR & ASCII.LF
        & ASCII.CR & ASCII.LF;
      Resp : Unbounded_String := Null_Unbounded_String;
      Want : constant String := Tedex_Ws.Accept_Key (Key);
   begin
      Pipe_Send_All (Req);
      --  Byte at a time: stop exactly at the blank line so nothing
      --  past it is swallowed (a fixed 1024 chunk would hang here when
      --  the response is shorter than the chunk).
      loop
         exit when Length (Resp) > 8_192;
         declare
            B : constant String := Pipe_Read_Exact (1, Deadln);
         begin
            Append (Resp, B);
            exit when Tedex_Util.Tail_Blank (To_String (Resp));
         end;
      end loop;
      Validate_Handshake (To_String (Resp), Want);
   end Ws_Pipe_Handshake;

   --  Transport dispatch ------------------------------------------

   --  ws[s]:// URL parsing is proved in Tedex_Util (same
   --  accept/reject behavior; overlong inputs are fail-closed there).
   --  Thin wrapper keeps the historical Unbounded_String shape.
   procedure Parse_Ws_Url (Url    : String;
                           Secure : out Boolean;
                           WHost  : out Unbounded_String;
                           WPort  : out Integer;
                           WPath  : out Unbounded_String) is
      HBuf : String (1 .. Tedex_Util.Max_Host);
      HLen : Natural := 0;
      PBuf : String (1 .. Tedex_Util.Max_Path);
      PLen : Natural := 0;
      Port : Natural := 0;
      Ok   : Boolean := False;
      U    : String (1 .. Tedex_Util.Max_Url);
      ULen : Natural := 0;
   begin
      Secure := False;
      WHost := Null_Unbounded_String;
      WPort := 80;
      WPath := To_Unbounded_String ("/tedex");
      Tedex_Util.Ws_Url_Head (Url, U, ULen, Ok);
      if not Ok then
         raise Constraint_Error with "bad ws url";
      end if;
      Tedex_Util.Parse_Ws_Url (U (1 .. ULen), Secure,
                               HBuf, HLen, Port, PBuf, PLen, Ok);
      if not Ok then
         raise Constraint_Error with "bad ws url";
      end if;
      WHost := To_Unbounded_String (HBuf (1 .. HLen));
      WPort := Integer (Port);
      WPath := To_Unbounded_String (PBuf (1 .. PLen));
   exception
      when Constraint_Error =>
         raise Constraint_Error with "bad ws url";
   end Parse_Ws_Url;

   function Ws_Key return String is
      Raw : constant String (1 .. 16) := Rand_Bytes (16);
   begin
      return Tedex_B64.Encode (Raw);
   end Ws_Key;

   procedure Transport_Connect is
      use Interfaces.C;
   begin
      Clear_Streams;
      if Length (Ws_Url) = 0 then
         T := (Kind => T_Raw, Sock => Connect_Sock (To_String (Host), Port),
               Rfd => -1, Wfd => -1, Pid => -1,
               Ws_Host => Null_Unbounded_String,
               Ws_Path => Null_Unbounded_String);
         return;
      end if;
      declare
         Secure : Boolean;
         Hst    : Unbounded_String;
         Prt    : Integer;
         Pth    : Unbounded_String;
         Key    : constant String := Ws_Key;
      begin
         Parse_Ws_Url (To_String (Ws_Url), Secure, Hst, Prt, Pth);
         if not Secure then
            declare
               S : constant Socket_Type :=
                 Connect_Sock (To_String (Hst), Prt);
            begin
               Ws_Client_Handshake (S, To_String (Hst), To_String (Pth), Key);
               T := (Kind => T_Ws_Sock, Sock => S,
                     Rfd => -1, Wfd => -1, Pid => -1,
                     Ws_Host => Hst, Ws_Path => Pth);
            end;
         else
            declare
               Hp   : Interfaces.C.Strings.chars_ptr :=
                 Interfaces.C.Strings.New_String (To_String (Hst));
               R, W, P : aliased Interfaces.C.int;
               Rc   : Interfaces.C.int;
            begin
               Rc := Tedex_Tls.Tls_Open
                 (Hp, Interfaces.C.int (Prt),
                  R'Access, W'Access, P'Access);
               Interfaces.C.Strings.Free (Hp);
               if Rc /= 0 then
                  raise Net_Error with "tls connect failed";
               end if;
               T := (Kind => T_Ws_Pipe, Sock => T.Sock,
                     Rfd => R, Wfd => W, Pid => P,
                     Ws_Host => Hst, Ws_Path => Pth);
               Ws_Pipe_Handshake (To_String (Hst), To_String (Pth), Key);
            end;
         end if;
      end;
   end Transport_Connect;

   procedure TClose is
      use Interfaces.C;
      Dummy : Interfaces.C.int;
      pragma Unreferenced (Dummy);
   begin
      case T.Kind is
         when T_Raw | T_Ws_Sock =>
            Close_Quiet (T.Sock);
         when T_Ws_Pipe =>
            --  Kill the openssl child first: a lingering s_client
            --  holds the TLS session open, so the server would never
            --  see EOF (attach hang + "device busy" ghosts on wss).
            Dummy := Tedex_Tls.Tls_Kill (T.Pid);
            Dummy := Tedex_Tls.Tls_Close_Fd (T.Wfd);
            Dummy := Tedex_Tls.Tls_Close_Fd (T.Rfd);
            Dummy := Tedex_Tls.Tls_Reap (T.Pid);
      end case;
      T.Pid := -1;
      Clear_Streams;
   end TClose;

   procedure MSend (Data : String) is
   begin
      case T.Kind is
         when T_Raw =>
            Send_Line (T.Sock, Data);
         when T_Ws_Sock =>
            Ws_Send_Line (T.Sock, Data, Masked => True);
         when T_Ws_Pipe =>
            Ws_Pipe_Send (Data, 2);
      end case;
   end MSend;

   function MRecv (Timeout : Duration := 3_600.0) return String is
   begin
      case T.Kind is
         when T_Raw =>
            return Recv_Line (T.Sock, Timeout);
         when T_Ws_Sock =>
            declare
               Line_US : Unbounded_String;
            begin
               Ws_Recv_Line (T.Sock, Timeout, True, False, Line_US);
               return To_String (Line_US);
            end;
         when T_Ws_Pipe =>
            return Ws_Pipe_Recv_Line (Timeout);
      end case;
   end MRecv;

   Dbg_File : Ada.Text_IO.File_Type;
   Dbg_Open : Boolean := False;

   function Hex_Of (Data : String) return String is
      H : constant String := "0123456789abcdef";
      R : String (1 .. Data'Length * 2);
   begin
      for I in Data'Range loop
         R (2 * (I - Data'First) + 1) :=
           H (Character'Pos (Data (I)) / 16 + 1);
         R (2 * (I - Data'First) + 2) :=
           H (Character'Pos (Data (I)) mod 16 + 1);
      end loop;
      return R;
   end Hex_Of;

   --  Byte-level trace for forensics (opt-in only). Logs what this side
   --  sends to / receives from the network with a timestamp; never alters
   --  bytes and never fails the session. Enable with TEDEX_DEBUG_IO=1,
   --  file via TEDEX_DEBUG_LOG (default /tmp/tedex_io.log).
   procedure Dbg_Put (Dir : String; Data : String) is
      use Ada.Text_IO;
      On : constant Boolean :=
        (Ada.Environment_Variables.Value ("TEDEX_DEBUG_IO", "0") = "1");
   begin
      if not On then
         return;
      end if;
      if not Dbg_Open then
         declare
            Path : constant String :=
              Ada.Environment_Variables.Value
                ("TEDEX_DEBUG_LOG", "/tmp/tedex_io.log");
         begin
            Open (Dbg_File, Append_File, Path);
         exception
            when others =>
               begin
                  Create (Dbg_File, Append_File, Path);
               exception
                  when others =>
                     return;
               end;
         end;
         Dbg_Open := True;
      end if;
      Put_Line (Dbg_File,
        Duration'Image (Ada.Calendar.Seconds (Ada.Calendar.Clock))
        & " " & Dir & Integer'Image (Data'Length) & ":" & Hex_Of (Data));
      Flush (Dbg_File);
   exception
      when others =>
         null;
   end Dbg_Put;

   procedure MSend_Frame (Data : String) is
   begin
      case T.Kind is
         when T_Ws_Sock =>
            Ws_Send (T.Sock, Data, 2, Masked => True);
         when T_Ws_Pipe =>
            Ws_Pipe_Send (Data, 2);
         when T_Raw =>
            raise Program_Error with "no framing on raw transport";
      end case;
   end MSend_Frame;

   procedure MSend_Ping is
   begin
      case T.Kind is
         when T_Ws_Sock =>
            Ws_Send (T.Sock, "", 9, Masked => True);
         when T_Ws_Pipe =>
            Ws_Pipe_Send ("", 9);
         when T_Raw =>
            null;
      end case;
   end MSend_Ping;

   --  Receive with keepalive: on idle timeout, ping (WS) and keep waiting.
   --  Fatal errors propagate as Net_Error.
   function MRecv_Or_Ping (Timeout : Duration) return String is
      use Ada.Calendar;
      Deadln : constant Time := Clock + Timeout;
   begin
      loop
         declare
            Left : constant Duration := Deadln - Clock;
         begin
            if Left <= 0.0 then
               raise Net_Error with "timeout";
            end if;
            if T.Kind = T_Raw then
               return MRecv (Left);
            else
               return MRecv (Duration'Min (Left, 30.0));
            end if;
         exception
            when E : Net_Error =>
               if Ada.Exceptions.Exception_Message (E) /= "timeout" then
                  raise;
               end if;
               exit when (Deadln - Clock) <= 0.0;
               MSend_Ping;
         end;
      end loop;
      raise Net_Error with "timeout";  --  unreachable
   end MRecv_Or_Ping;

   procedure MClose_Send is
   begin
      case T.Kind is
         when T_Ws_Sock =>
            begin
               Ws_Send (T.Sock, "", 8, Masked => True);
            exception
               when Net_Error => null;
            end;
         when T_Ws_Pipe =>
            begin
               Ws_Pipe_Send ("", 8);
            exception
               when Net_Error => null;
            end;
         when T_Raw =>
            null;
      end case;
   end MClose_Send;


   --  Shell + attach over message transports ----------------------

   --  Shell over message transports ----------------------

   function Raw_Recv_Chunk (Sock    : Socket_Type;
                            Timeout : Duration) return String is
      Chunk  : Ada.Streams.Stream_Element_Array (1 .. 32_768);
      Last   : Ada.Streams.Stream_Element_Offset;
   begin
      if not Wait_Readable (Sock, Timeout) then
         raise Net_Error with "timeout";
      end if;
      Receive_Socket (Sock, Chunk, Last);
      if Last < Chunk'First then
         raise Net_Error with "closed";
      end if;
      declare
         S : String (1 .. Natural (Last - Chunk'First + 1));
      begin
         for I in S'Range loop
            S (I) := Character'Val
              (Chunk (Chunk'First + Ada.Streams.Stream_Element_Offset (I - 1)));
         end loop;
         return S;
      end;
   exception
      when Socket_Error =>
         raise Net_Error with "socket error";
   end Raw_Recv_Chunk;

   procedure Pipe_Fill (Timeout : Duration) is
      use Interfaces.C;
      Tmp : aliased String (1 .. 4_096);
      Ms  : Integer := 0;
      Rc  : Interfaces.C.int;
   begin
      if Timeout > 0.0 then
         Ms := Integer (Timeout * 1_000.0);
         if Ms > 5_000 then
            Ms := 5_000;
         elsif Ms < 0 then
            Ms := 0;
         end if;
      end if;
      Rc := Tedex_Tls.Fd_Read_Timeout
        (T.Rfd, Tmp'Address, Tmp'Length, Interfaces.C.int (Ms));
      if Rc > 0 then
         Append (Pipe_Raw, Tmp (1 .. Natural (Rc)));
      elsif Rc = 0 then
         raise Net_Error with "closed";
      elsif Rc = -3 or Rc = -2 then
         null;  --  no data yet; bytes (if any) stay buffered
      else
         raise Net_Error with "socket error";
      end if;
   end Pipe_Fill;

   procedure Sock_Fill (Timeout : Duration) is
      Chunk : Stream_Element_Array (1 .. 32_768);
      Last  : Stream_Element_Offset;
   begin
      if not Wait_Readable (T.Sock, Timeout) then
         return;
      end if;
      Receive_Socket (T.Sock, Chunk, Last);
      if Last < Chunk'First then
         raise Net_Error with "closed";
      end if;
      declare
         S : String (1 .. Natural (Last - Chunk'First + 1));
      begin
         for I in S'Range loop
            S (I) := Character'Val
              (Chunk (Chunk'First + Stream_Element_Offset (I - 1)));
         end loop;
         Append (Sock_Raw, S);
      end;
   exception
      when Socket_Error =>
         raise Net_Error with "socket error";
   end Sock_Fill;

   --  Buffered WS frame reader: peek, validate, then consume ----------
   --  Bytes are NEVER removed from the buffer until a full frame
   --  (header + payload) is present, so a poll timeout mid-frame loses
   --  nothing and the next poll simply resumes filling.
   procedure Ws_Recv_NB (Is_Pipe : Boolean;
                         Timeout : Duration;
                         Payload : out Unbounded_String;
                         Got_It  : out Boolean)
   is
      use Ada.Calendar;
      Deadln : constant Time := Clock + Timeout;

      procedure Ensure (N : Natural; Enough : out Boolean) is
      begin
         loop
            if (if Is_Pipe then Length (Pipe_Raw) >= N
                else Length (Sock_Raw) >= N)
            then
               Enough := True;
               return;
            end if;
            exit when Clock >= Deadln;
            if Is_Pipe then
               Pipe_Fill (Deadln - Clock);
            else
               Sock_Fill (Deadln - Clock);
            end if;
         end loop;
         Enough := (if Is_Pipe then Length (Pipe_Raw) >= N
                    else Length (Sock_Raw) >= N);
      end Ensure;

      function Peek (Low, High : Positive) return String is
      begin
         if Is_Pipe then
            return Slice (Pipe_Raw, Low, High);
         else
            return Slice (Sock_Raw, Low, High);
         end if;
      end Peek;

      procedure Drop (N : Natural) is
      begin
         if Is_Pipe then
            if Length (Pipe_Raw) <= N then
               Pipe_Raw := Null_Unbounded_String;
            else
               Pipe_Raw := To_Unbounded_String
                 (Slice (Pipe_Raw, N + 1, Length (Pipe_Raw)));
            end if;
         else
            if Length (Sock_Raw) <= N then
               Sock_Raw := Null_Unbounded_String;
            else
               Sock_Raw := To_Unbounded_String
                 (Slice (Sock_Raw, N + 1, Length (Sock_Raw)));
            end if;
         end if;
      end Drop;

   begin
      Payload := Null_Unbounded_String;
      Got_It  := False;
      loop
         declare
            Ech : Boolean;
         begin
            Ensure (2, Ech);
            if not Ech then
               return;  --  no header yet; everything kept
            end if;
            declare
               H0   : constant String := Peek (1, 2);
               L7   : constant Natural := Character'Pos (H0 (2)) mod 128;
               Ext  : constant Natural :=
                 (if L7 < 126 then 0 elsif L7 = 126 then 2 else 8);
               Need : constant Natural := 2 + Ext;
            begin
               Ensure (Need, Ech);
               if not Ech then
                  return;  --  partial header kept
               end if;
               declare
                  Hdr : constant String (1 .. Need) := Peek (1, Need);
                  H   : Tedex_Ws.Frame_Header;
                  Ok  : Boolean;
               begin
                  Tedex_Ws.Decode_Header
                    (Hdr, H, Ok, Require_Mask => False);
                  if not Ok then
                     raise Net_Error with "bad frame";
                  end if;
                  Ensure (Need + H.Pay_Len, Ech);
                  if not Ech then
                     return;  --  partial frame kept
                  end if;
                  declare
                     Pay : Unbounded_String := Null_Unbounded_String;
                  begin
                     if H.Pay_Len > 0 then
                        Pay := To_Unbounded_String
                          (Peek (Need + 1, Need + H.Pay_Len));
                     end if;
                     Drop (Need + H.Pay_Len);
                     case H.Opcode is
                        when 8 =>
                           begin
                              if Is_Pipe then
                                 Ws_Pipe_Send ("", 8);
                              else
                                 Ws_Send (T.Sock, "", 8, Masked => True);
                              end if;
                           exception
                              when Net_Error => null;
                           end;
                           raise Net_Error with "closed";
                        when 9 =>
                           if Is_Pipe then
                              Ws_Pipe_Send (To_String (Pay), 10);
                           else
                              Ws_Send (T.Sock, To_String (Pay), 10,
                                       Masked => True);
                           end if;
                        when 10 =>
                           if Mgr_Pongs_Seen < Natural'Last then
                              Mgr_Pongs_Seen := Mgr_Pongs_Seen + 1;
                           end if;
                        when 0 =>
                           if not Frag_On then
                              raise Net_Error with "unexpected continuation";
                           end if;
                           if Length (Frag_Msg)
                             > Tedex_Ws.Msg_Cap - Length (Pay)
                           then
                              raise Net_Error with "message too big";
                           end if;
                           Append (Frag_Msg, Pay);
                           if H.Fin then
                              Payload := Frag_Msg;
                              Got_It  := True;
                              Frag_Msg := Null_Unbounded_String;
                              Frag_On  := False;
                              return;
                           end if;
                        when 1 | 2 =>
                           if Frag_On then
                              raise Net_Error with "interleaved message";
                           end if;
                           Frag_On  := True;
                           Frag_Msg := Pay;
                           if H.Fin then
                              Payload := Frag_Msg;
                              Got_It  := True;
                              Frag_Msg := Null_Unbounded_String;
                              Frag_On  := False;
                              return;
                           end if;
                        when others =>
                           raise Net_Error with "bad opcode";
                     end case;
                  end;
               end;
            end;
         end;
      end loop;
   end Ws_Recv_NB;

   procedure Run_Shell_Ws (Clean : out Boolean;
                           Cols  : Natural := 0;
                           Rows  : Natural := 0) is
      H        : Tedex_Shell.Handle;
   begin
      Clean := False;
      Tedex_Shell.Spawn (H);
      Tedex_Shell.Set_Size (H, Cols, Rows);
      --  NOTE: rc-file TMOUT is neutralized inside the spawn itself
      --  (~/.tedex_rc, see tlswrap.c): nothing is typed into the
      --  shell here, so the session stays byte-clean and the pty
      --  termios is never touched while bash initializes.
      loop
         begin
            declare
               P   : Unbounded_String;
               Got : Boolean;
            begin
               Ws_Recv_NB ((T.Kind = T_Ws_Pipe), 0.001, P, Got);
               if Got then
                  Dbg_Put ("D", To_String (P));
                  Tedex_Shell.Send (H, To_String (P));
               end if;
            end;
         exception
            when E : Net_Error =>
               if Ada.Exceptions.Exception_Message (E) /= "timeout" then
                  Tedex_Shell.Close (H);
                  return;  --  transport broke: not clean
               end if;
            when Tedex_Shell.Shell_Error =>
               Tedex_Shell.Close (H);
               return;  --  transport ok but shell path broken: not clean
         end;
         begin
            declare
               Poll_US : Unbounded_String;
            begin
               Tedex_Shell.Poll (H, 1, Poll_US);
               declare
                  Outgoing : constant String := To_String (Poll_US);
               begin
               if Outgoing /= "" then
                  MSend_Frame (Outgoing);
                  loop
                     declare
                        Extra_US : Unbounded_String;
                     begin
                        Tedex_Shell.Poll (H, 0, Extra_US);
                        declare
                           Extra : constant String := To_String (Extra_US);
                        begin
                        exit when Extra = "";
                        MSend_Frame (Extra);
                        end;
                     end;
                  end loop;
               end if;
               end;
            end;
         exception
            when Tedex_Shell.Shell_Error =>
               exit;  --  shell exited (drained): clean
            when Net_Error =>
               Tedex_Shell.Close (H);
               return;  --  transport broke mid-send: not clean
         end;
      end loop;
      Tedex_Shell.Close (H);
      Clean := True;
   end Run_Shell_Ws;

   procedure Run_Shell_Raw (Clean : out Boolean;
                            Cols  : Natural := 0;
                            Rows  : Natural := 0) is
      H        : Tedex_Shell.Handle;
   begin
      Clean := False;
      Tedex_Shell.Spawn (H);
      Tedex_Shell.Set_Size (H, Cols, Rows);
      --  Same as Run_Shell_Ws: TMOUT is handled inside the spawn.
      loop
         begin
            declare
               Incoming : constant String := Raw_Recv_Chunk (T.Sock, 0.001);
            begin
               Dbg_Put ("D", Incoming); Tedex_Shell.Send (H, Incoming);
            end;
         exception
            when E : Net_Error =>
               if Ada.Exceptions.Exception_Message (E) /= "timeout" then
                  Tedex_Shell.Close (H);
                  return;
               end if;
            when Tedex_Shell.Shell_Error =>
               Tedex_Shell.Close (H);
               return;
         end;
         begin
            declare
               Poll_US : Unbounded_String;
            begin
               Tedex_Shell.Poll (H, 1, Poll_US);
               declare
                  Outgoing : constant String := To_String (Poll_US);
               begin
               if Outgoing /= "" then
                  Tedex_Net.Send_Data (T.Sock, Outgoing);
                  loop
                     declare
                        Extra_US : Unbounded_String;
                     begin
                        Tedex_Shell.Poll (H, 0, Extra_US);
                        declare
                           Extra : constant String := To_String (Extra_US);
                        begin
                        exit when Extra = "";
                        Tedex_Net.Send_Data (T.Sock, Extra);
                        end;
                     end;
                  end loop;
               end if;
               end;
            end;
         exception
            when Tedex_Shell.Shell_Error =>
               exit;
            when Net_Error =>
               Tedex_Shell.Close (H);
               return;
         end;
      end loop;
      Tedex_Shell.Close (H);
      Clean := True;
   end Run_Shell_Raw;

   procedure Attach_Ws is
      use Ada.Calendar;
      use Interfaces.C;
      Out_Buf  : aliased String (1 .. 4_096);
      Dummy    : Interfaces.C.int;
      Last_Traffic : Time := Clock;
      Stdin_Eof    : Boolean := False;
      --  Predictive local echo (Mosh-style, opt-out TEDEX_NO_PREDICT=1):
      --  instant display of printable keystrokes, Enter newlines and
      --  backspace erases + suppression of their remote pty echoes.
      --  ESC/other control never predicted (vim/arrows safe); prediction
      --  auto-suspends on password prompts (see Tedex_Predict).
      --  Pending expires after 2s (no-echo mode), cap 1024. Backspace is
      --  predicted only while Line_Printables > 0 (chars we KNOW sit on
      --  the current unsubmitted line); erase echoes are swallowed via
      --  Erase_Credit (readline BS+ESC[K or kernel BS+space+BS), so
      --  Pending itself is never touched by erases.
      --  Predictive-echo decision state lives in the proved
      --  Tedex_Predict unit (SPARK); here only transport, terminal,
      --  clock conversion and debug mapping remain.
      Pst : Tedex_Predict.Echo_State;
      Disp_P : String (1 .. 4 * Tedex_Predict.Max_Stdin) :=
        [others => ' '];
      Disp_C : String (1 .. Tedex_Predict.Max_Chunk
                          + Tedex_Predict.Max_Hold + 16) :=
        [others => ' '];
      Attach_Start : constant Time := Clock;
      Predict_On : constant Boolean :=
        (Ada.Environment_Variables.Value ("TEDEX_NO_PREDICT", "0") /= "1");
      function Now_Ms return Natural is
         Elapsed : constant Duration := Clock - Attach_Start;
      begin
         if Elapsed < 0.0 or else Elapsed > 1_900_000.0 then
            return (if Elapsed < 0.0 then 0
                    else Tedex_Predict.Max_Ms);
         end if;
         return Natural (Elapsed * 1_000.0);
      end Now_Ms;
      procedure Map_Trace (Tr : Tedex_Predict.Trace_Code) is
      begin
         case Tr is
            when Tedex_Predict.Tr_Fail_Open => Dbg_Put ("FO", "decided");
            when Tedex_Predict.Tr_Pipeline  => Dbg_Put ("PL", "decided");
            when Tedex_Predict.Tr_Substring => Dbg_Put ("SL", "decided");
            when Tedex_Predict.Tr_Hold      => Dbg_Put ("EH", "held");
            when Tedex_Predict.Tr_Expired   => Dbg_Put ("EXP", "expired");
            when others => null;
         end case;
      end Map_Trace;
      procedure Do_Predict (Chunk : String) is
         N : Natural := 0;
         Tr : Tedex_Predict.Trace_Code := Tedex_Predict.Tr_None;
      begin
         if not Predict_On then
            return;
         end if;
         Tedex_Predict.Predict_Chunk
           (Pst, Now_Ms, Chunk, Disp_P, N, Tr);
         Map_Trace (Tr);
         if N > 0 then
            Dummy := Tedex_Tls.Fd_Write_All
              (1, Disp_P (1 .. N)'Address, Interfaces.C.int (N));
         end if;
      end Do_Predict;
      procedure Do_Consume (S : in out Unbounded_String) is
      begin
         if not Predict_On or Length (S) = 0 then
            return;
         end if;
         declare
            Raw : constant String := To_String (S);
            Off : Natural := 0;
            Acc : Unbounded_String := Null_Unbounded_String;
         begin
            while Off < Raw'Length loop
               declare
                  This : constant Natural :=
                    Natural'Min (Tedex_Predict.Max_Chunk,
                                 Raw'Length - Off);
                  C1 : constant String (1 .. This) :=
                    Raw (Raw'First + Off .. Raw'First + Off + This - 1);
                  N : Natural := 0;
                  Tr : Tedex_Predict.Trace_Code :=
                    Tedex_Predict.Tr_None;
               begin
                  Tedex_Predict.Consume_Chunk
                    (Pst, Now_Ms, C1, Disp_C, N, Tr);
                  Map_Trace (Tr);
                  if N > 0 then
                     Append (Acc, Disp_C (1 .. N));
                  end if;
                  Off := Off + This;
               end;
            end loop;
            S := Acc;
         end;
      end Do_Consume;
      pragma Unreferenced (Dummy);
      --  Byte class for prediction lives proved in Tedex_Util
      --  (Is_Predict_Byte); ESC/DEL are never predicted.
   begin
      Tedex_Term.Term_Raw (1);
      Dummy := Tedex_Term.Term_Set_Nonblock (0, 1);
      loop
         begin
            declare
               P   : Unbounded_String;
               Got : Boolean;
            begin
               Ws_Recv_NB ((T.Kind = T_Ws_Pipe), 0.002, P, Got);
               if Got then
                  Dbg_Put ("R", To_String (P));
                  declare
                     S : Unbounded_String := P;
                  begin
                     Do_Consume (S);
                     if Length (S) > 0 then
                        declare
                           Vs : constant String := To_String (S);
                        begin
                           Dummy := Tedex_Tls.Fd_Write_All
                             (1, Vs'Address, Interfaces.C.int (Vs'Length));
                        end;
                     end if;
                     Last_Traffic := Clock;
                  end;
               end if;
            end;
         exception
            when E : Net_Error =>
               if Ada.Exceptions.Exception_Message (E) /= "timeout" then
                  exit;
               end if;
         end;
         if not Stdin_Eof then
            declare
               Rc : constant Interfaces.C.int :=
                 Tedex_Term.Term_Read_Chunk
                   (Out_Buf'Address, Out_Buf'Length);
            begin
               if Rc > 0 then
                  declare
                     Total : Natural := Natural (Rc);
                     Extra : Interfaces.C.int;
                  begin
                     for J in 1 .. 5 loop
                        exit when Total >= Out_Buf'Length;
                        Extra := Tedex_Term.Term_Read_Chunk
                          (Out_Buf (Total + 1)'Address,
                           Interfaces.C.int (Out_Buf'Length - Total));
                        exit when Extra <= 0;
                        Total := Total + Natural (Extra);
                     end loop;
                     MSend_Frame (Out_Buf (1 .. Total));
                     Dbg_Put ("S", Out_Buf (1 .. Total));
                     Do_Predict (Out_Buf (1 .. Total));
                     Last_Traffic := Clock;
                  end;
               elsif Rc = 0 then
                  --  No more input, but the session lives on: the shell
                  --  ends it (or silence below does).
                  Stdin_Eof := True;
               elsif Rc = -1 then
                  exit;
               end if;
            end;
         end if;
         if Stdin_Eof and then Clock - Last_Traffic > 30.0 then
            MClose_Send;
            exit;
         end if;
         declare
            N : Natural := 0;
            Tr : Tedex_Predict.Trace_Code := Tedex_Predict.Tr_None;
            pragma Unreferenced (Tr);
         begin
            Tedex_Predict.Flush_Hold (Pst, Now_Ms, Disp_C, N);
            if N > 0 then
               Dbg_Put ("EH", "flush");
               Dummy := Tedex_Tls.Fd_Write_All
                 (1, Disp_C (1 .. N)'Address, Interfaces.C.int (N));
            end if;
         end;
         if Clock - Last_Traffic > 25.0 then
            begin
               MSend_Ping;
               Last_Traffic := Clock;
            exception
               when Net_Error => exit;
            end;
         end if;
      end loop;
      --  Restore the terminal fully: Attach_Ws sets raw + nonblock.
      Dummy := Tedex_Term.Term_Set_Nonblock (0, 0);
      Tedex_Term.Term_Raw (0);
   end Attach_Ws;



   --  Device + manager --------------------------------------------

   procedure Device_Loop (U, P, D : String) is
      Done       : Boolean := False;
      Had_Error  : Boolean := False;
      Fail_Count : Natural := 0;
      Authed     : Boolean := False;

      --  Jittered exponential backoff: a fixed retry delay turns a
      --  fleet-wide outage into a synchronized thundering herd that
      --  re-hammers the server every 5 s. Caps at ~65 s, resets on
      --  every successful registration.
      procedure Fail (Msg : String) is
         Wait_Secs : Natural;
         Rb_Byte   : Natural := 0;
      begin
         Ada.Text_IO.Put_Line ("[" & D & "] " & Msg);
         TClose;
         if Persist then
            Fail_Count := Natural'Min (Fail_Count + 1, 6);
            begin
               declare
                  Rb : constant String := Rand_Bytes (1);
               begin
                  Rb_Byte := Character'Pos (Rb (Rb'First));
               end;
            exception
               when others => null;
            end;
            --  Proven jitter: 5..65 s (Backoff_Secs plus 0..5).
            Wait_Secs :=
              Tedex_Util.Jittered_Backoff (Fail_Count, Rb_Byte);
            delay Duration (Wait_Secs);
         else
            Had_Error := True;
            Done := True;
         end if;
      end Fail;

   begin
      while not Done loop
         begin
            Authed := False;  --  set True only by a genuine OK below
            Transport_Connect;
            MSend ("AUTH device " & U & " " & P & " " & D);
            declare
               Resp : constant String := MRecv (30.0);
            begin
               if Resp'Length < 2
                 or else Resp (Resp'First .. Resp'First + 1) /= "OK"
               then
                  if Resp'Length = 15
                    and then Resp (Resp'First .. Resp'First + 14)
                               = "ERR busy, retry"
                  then
                     --  Transient store contention server-side: back
                     --  off and retry (never treat as deprovisioning).
                     TClose;
                     Fail ("server busy, retrying...");
                  else
                     Ada.Text_IO.Put_Line ("[" & D & "] " & Resp);
                     TClose;
                     Had_Error := True;
                     Done := True;  --  auth refused: never retry
                  end if;
               else
                  Authed := True;  --  genuine OK: proceed to shell wait
               end if;
            end;
            --  NOTE: a transient busy-retry must NOT fall through
            --  here (it would print a phantom "registered" and then
            --  read a closed socket): only a genuine OK sets Authed.
            if Authed and then not Done then
               Fail_Count := 0;  --  healthy again: restart backoff
               Ada.Text_IO.Put_Line ("[" & D & "] registered as " & U);
            declare
               Shell_Clean : Boolean := False;
               DCols, DRows : Natural := 0;
            begin
               loop
                  begin
                     declare
                        L : constant String := MRecv_Or_Ping (3_600.0);
                     begin
                        begin
                           if Ada.Environment_Variables.Value
                             ("TEDEX_DEBUG_KEYS") = "1"
                           then
                              Ada.Text_IO.Put_Line ("[dev] cmd: " & L);
                              Ada.Text_IO.Flush (Ada.Text_IO.Standard_Output);
                           end if;
                        exception
                           when Constraint_Error => null;
                        end;
                        if L = "PING" then
                           MSend ("PONG");
                        elsif L = "REMOVED" then
                           --  Manager removed us: stop (and uninstall in
                           --  main). Never retry, even with --persist.
                           --  Same name may register again later: nothing
                           --  is banned, only this machine stops itself.
                           Ada.Text_IO.Put_Line
                             ("[" & D & "] removed by manager"
                              & " -- uninstalling...");
                           Was_Removed := True;
                           exit;
                        elsif L'Length >= 11
                          and then L (L'First .. L'First + 10) = "SHELL_START"
                        then
                           Tedex_Protocol.Parse_Start_Dims (L, DCols, DRows);
                           if T.Kind = T_Raw then
                              Run_Shell_Raw (Shell_Clean, DCols, DRows);
                           else
                              Run_Shell_Ws (Shell_Clean, DCols, DRows);
                           end if;
                           exit;
                        end if;
                     end;
                  exception
                     when E : Net_Error =>
                        if Ada.Exceptions.Exception_Message (E) /= "timeout"
                        then
                           raise;
                        end if;
                        --  Hourly budget elapsed with no shell: stay online,
                        --  keep waiting on a fresh budget.
                  end;
               end loop;
               TClose;
               if Was_Removed then
                  Done := True;
               elsif not Shell_Clean then
                  --  Should not happen (shell paths set Clean), stay safe.
                  Fail ("session ended");
               else
                  --  Clean shell exit (user typed "exit" - or the shell
                  --  died on its own, e.g. TMOUT auto-logout): log it so
                  --  a mystery manager-side "session ended" is traceable.
                  Ada.Text_IO.Put_Line
                    ("[" & D & "] shell exited, re-registering"
                     & " (if unexpected, check TMOUT/exit in shell rc)");
               end if;
               --  Clean shell end: loop right back to re-register with no
               --  delay, so the device is (almost) never seen offline.
               end;
            end if;
         exception
            when Socket_Error | Host_Error | Constraint_Error =>
               Fail ("connect failed, " & (if Persist then "retry..."
                                          else "offline"));
            when Net_Error =>
               Fail ("disconnected, " & (if Persist then "retry..."
                                        else "offline"));
            when Tedex_Shell.Shell_Error =>
               Fail ("shell failed, " & (if Persist then "retry..."
                                        else "offline"));
         end;
      end loop;
      if Had_Error and then not Persist then
         GNAT.OS_Lib.OS_Exit (1);
      end if;
   end Device_Loop;

   procedure Login_Manager (U, P : String) is
   begin
      Transport_Connect;
      MSend ("AUTH manager " & U & " " & P & " -");
      declare
         Resp : constant String := MRecv (30.0);
      begin
         if Resp'Length < 2 or else Resp (Resp'First .. Resp'First + 1) /= "OK" then
            TClose;
            raise Program_Error with Resp;
         end if;
      end;
   end Login_Manager;


   procedure Manager_Loop (U, P : String) is
      use Ada.Text_IO;

      --  Blank stripping and case folding live proved in Tedex_Util
      --  now (Trim_Blanks/To_Lower); the two historical locals and the
      --  Unbounded_String splitter below were removed.

      function Get_Cmd return String is
         Buf : aliased String (1 .. 1024);
         N   : constant Interfaces.C.int :=
           Tedex_Term.C_Read_Line (Buf'Address, Buf'Length);
      begin
         if N <= 0 then
            return "";
         end if;
         declare
            S : constant String := Buf (1 .. Natural (N));
         begin
            if S'Length > 0 and then S (S'Last) = ASCII.LF then
               if S'Length > 1 and then S (S'Last - 1) = ASCII.CR then
                  return S (S'First .. S'Last - 2);
               end if;
               return S (S'First .. S'Last - 1);
            end if;
            return S;
         end;
      end Get_Cmd;

      --  Prompt input with keepalive: while the manager idles at the
      --  prompt, ping the server every 25 s (an idle-looking link is
      --  otherwise reaped by middleboxes) and verify inbound pongs, so
      --  a silently dead link reports "connection lost" here instead of
      --  ambushing the next command. Raw transports have no WS framing
      --  or pong events: plain blocking read there.
      function Get_Cmd_Alive return String is
         use Ada.Calendar;
         Last_Ping : Time := Clock;
         Last_Pipe : Natural := Mgr_Pongs_Seen;
         Last_Net  : Natural := 0;
         Silent    : Natural := 0;
      begin
         Tedex_Net.Ws_Pong_Count (Last_Net);
         if T.Kind = T_Raw then
            return Get_Cmd;
         end if;
         loop
            declare
               R : constant Interfaces.C.int :=
                 Tedex_Tls.Fd_Wait_Read (0, 1_000);
            begin
               if R = 1 then
                  return Get_Cmd;
               elsif R = -1 then
                  return Get_Cmd;  --  broken stdin poll: legacy path
               end if;
            end;
            if Clock - Last_Ping >= 25.0 then
               begin
                  declare
                     Drop : constant String := MRecv_Or_Ping (2.0);
                     pragma Unreferenced (Drop);
                  begin
                     --  Unexpected inbound traffic still proves
                     --  the link is alive; its content has no
                     --  outstanding command at the prompt.
                     Last_Pipe := Mgr_Pongs_Seen;
                     Tedex_Net.Ws_Pong_Count (Last_Net);
                     Silent := 0;
                  end;
               exception
                  when E : Net_Error =>
                     if Ada.Exceptions.Exception_Message (E) /= "timeout" then
                        raise;
                     end if;
               end;
               MSend_Ping;
               --  Either transport's pongs (pipe for wss://, socket
               --  frames for ws://) reset the silence count.
               declare
                  Cur_Net : Natural;
               begin
                  Tedex_Net.Ws_Pong_Count (Cur_Net);
                  if Mgr_Pongs_Seen /= Last_Pipe
                    or Cur_Net /= Last_Net
                  then
                     Last_Pipe := Mgr_Pongs_Seen;
                  Tedex_Net.Ws_Pong_Count (Last_Net);
                  Silent := 0;
               else
                     Silent := Silent + 1;
                  end if;
               end;
               if Silent >= 4 then
                  raise Net_Error with "link dead (server silent)";
               end if;
               Last_Ping := Clock;
            end if;
         end loop;
      end Get_Cmd_Alive;

      --  Manager verb splitting is proved in Tedex_Util (lowercased
      --  verb, stripped arg). Thin wrapper keeps Unbounded_Strings.
      procedure Split_Verb (Cmd : String; V, A : out Unbounded_String) is
         Verb_B : String (1 .. Tedex_Util.Max_Cmd);
         Arg_B  : String (1 .. Tedex_Util.Max_Cmd);
         Verb_Len, Arg_Len : Natural := 0;
         Line : constant String := Tedex_Util.Trim_Blanks (Cmd);
      begin
         Tedex_Util.Split_Verb (Line, Verb_B, Verb_Len, Arg_B, Arg_Len);
         V := To_Unbounded_String (Verb_B (1 .. Verb_Len));
         A := To_Unbounded_String (Arg_B (1 .. Arg_Len));
      end Split_Verb;

      procedure Do_List is
         --  Parse "U/L online=O offline=F never-connected=V" (server
         --  quota header). Strict shape; Ok=False prints the raw head.
         procedure Parse_List_Header (T : String;
                                      U, L, O, F, V : out Natural;
                                      Ok : out Boolean) is
            function All_Digits (S : String) return Boolean is
            begin
               if S'Length = 0 or else S'Length > 6 then
                  return False;
               end if;
               for C of S loop
                  if C not in '0' .. '9' then
                     return False;
                  end if;
               end loop;
               return True;
            end All_Digits;
            Bl : array (1 .. 3) of Natural := [others => 0];
            Nb : Natural := 0;
         begin
            U := 0; L := 0; O := 0; F := 0; V := 0; Ok := False;
            for I in T'Range loop
               if T (I) = ' ' then
                  if Nb = 3 then
                     return;
                  end if;
                  Nb := Nb + 1;
                  Bl (Nb) := I;
               end if;
            end loop;
            if Nb /= 3 then
               return;
            end if;
            declare
               F1 : constant String := T (T'First .. Bl (1) - 1);
               F2 : constant String := T (Bl (1) + 1 .. Bl (2) - 1);
               F3 : constant String := T (Bl (2) + 1 .. Bl (3) - 1);
               F4 : constant String := T (Bl (3) + 1 .. T'Last);
               Sl : Natural := 0;
            begin
               for I in F1'Range loop
                  if F1 (I) = '/' then
                     if Sl /= 0 then
                        return;
                     end if;
                     Sl := I;
                  elsif F1 (I) not in '0' .. '9' then
                     return;
                  end if;
               end loop;
               if Sl = 0 or else Sl = F1'First or else Sl = F1'Last then
                  return;
               end if;
               if not All_Digits (F1 (F1'First .. Sl - 1))
                 or else not All_Digits (F1 (Sl + 1 .. F1'Last))
                 or else F2'Length <= 7
                 or else F2 (F2'First .. F2'First + 6) /= "online="
                 or else not All_Digits (F2 (F2'First + 7 .. F2'Last))
                 or else F3'Length <= 8
                 or else F3 (F3'First .. F3'First + 7) /= "offline="
                 or else not All_Digits (F3 (F3'First + 8 .. F3'Last))
                 or else F4'Length <= 16
                 or else F4 (F4'First .. F4'First + 15)
                        /= "never-connected="
                 or else not All_Digits (F4 (F4'First + 16 .. F4'Last))
               then
                  return;
               end if;
               U := Tedex_Util.Parse_Count (F1 (F1'First .. Sl - 1));
               L := Tedex_Util.Parse_Count (F1 (Sl + 1 .. F1'Last));
               O := Tedex_Util.Parse_Count (F2 (F2'First + 7 .. F2'Last));
               F := Tedex_Util.Parse_Count (F3 (F3'First + 8 .. F3'Last));
               V := Tedex_Util.Parse_Count (F4 (F4'First + 16 .. F4'Last));
               Ok := True;
            end;
         end Parse_List_Header;
      begin
         MSend ("LIST");
         declare
            Head : constant String := MRecv_Or_Ping (30.0);
            U, L, O, F, V : Natural := 0;
            HOk : Boolean := False;
         begin
         if Head'Length >= 8
           and then Head (Head'First .. Head'First + 7) = "DEVICES "
         then
            Parse_List_Header (Head (Head'First + 8 .. Head'Last),
                               U, L, O, F, V, HOk);
         end if;
         if not HOk then
            Put_Line (Head);
            U := 0;
         end if;
         if U = 0 then
            Put_Line ("no devices known");
         else
            Put_Line (Trimmed_Count (U) & "/" & Trimmed_Count (L)
                      & " device(s): online=" & Trimmed_Count (O)
                      & " offline=" & Trimmed_Count (F)
                      & " never-connected=" & Trimmed_Count (V));
         end if;
         loop
            declare
               L : constant String := MRecv_Or_Ping (30.0);
            begin
               exit when L = "END";
               if L'Length > 7
                 and then L (L'First .. L'First + 6) = "DEVICE "
               then
                  if L'First = 1
                    and then L'Length <= Tedex_Protocol.Max_Line
                  then
                     --  Proved parser: identical shaping to the inline
                     --  scanner it replaces (see Parse_Device_Line).
                     declare
                        P_Id   : String (1 .. Tedex_Protocol.Max_Line) :=
                          [others => ' '];
                        P_Len  : Natural := 0;
                        P_St   : Tedex_Protocol.Device_Status :=
                          Tedex_Protocol.Status_Offline;
                        P_Info : String (1 .. Tedex_Protocol.Max_Line) :=
                          [others => ' '];
                        P_ILen : Natural := 0;
                        P_Ok   : Boolean := False;
                     begin
                        Tedex_Protocol.Parse_Device_Line
                          (L, P_Id, P_Len, P_St, P_Info, P_ILen, P_Ok);
                        if P_Ok then
                           Put_Line ("  - " & P_Id (1 .. P_Len)
                                     & " ["
                                     & Tedex_Protocol.Status_Image (P_St)
                                     & "] " & P_Info (1 .. P_ILen));
                        else
                           Put_Line ("  - "
                                     & L (L'First + 7 .. L'Last));
                        end if;
                     end;
                  else
                  declare
                     Rest : constant String :=
                       L (L'First + 7 .. L'Last);
                     Sp1  : Integer := Rest'First;
                  begin
                     while Sp1 <= Rest'Last and then Rest (Sp1) /= ' ' loop
                        Sp1 := Sp1 + 1;
                     end loop;
                     if Sp1 > Rest'Last then
                        Put_Line ("  - " & Rest);
                     else
                        declare
                           Id : constant String :=
                             Rest (Rest'First .. Sp1 - 1);
                           R2 : constant String :=
                             Rest (Sp1 + 1 .. Rest'Last);
                           Sp2 : Integer := R2'First;
                        begin
                           while Sp2 <= R2'Last and then R2 (Sp2) /= ' ' loop
                              Sp2 := Sp2 + 1;
                           end loop;
                           if Sp2 > R2'Last then
                              Put_Line ("  - " & Rest);
                           else
                              declare
                                 St : constant String :=
                                   R2 (R2'First .. Sp2 - 1);
                                 Info : constant String :=
                                   R2 (Sp2 + 1 .. R2'Last);
                              begin
                                 if St = "online" or St = "busy"
                                   or St = "offline"
                                   or St = "never-connected"
                                 then
                                    Put_Line ("  - " & Id
                                              & " [" & St & "] " & Info);
                                 else
                                    Put_Line ("  - " & Rest);
                                 end if;
                              end;
                           end if;
                        end;
                     end if;
                  end;
                  end if;
               else
                  Put_Line (L);
               end if;
            end;
         end loop;
         end;
      end Do_List;

      procedure Do_Attach (Id : String) is
         Rws, Cws : aliased Interfaces.C.int := 0;
         WCols, WRows : Natural := 0;
      begin
         if Id'Length = 0 then
            Put_Line ("usage: attach <device_id>");
            return;
         end if;
         --  Report our terminal size first so the device pty matches it
         --  (tmux/full-screen need real dims; long lines wrap at the
         --  right column). Unknown/not-a-tty falls back to 80x24 rather
         --  than 0x0. Old servers answer ERR: ATTACH still proceeds.
         if C_Get_Size (Rws'Access, Cws'Access) = 0
           and then Rws >= 1 and then Rws <= 1000
           and then Cws >= 1 and then Cws <= 1000
         then
            WRows := Natural (Rws);
            WCols := Natural (Cws);
         else
            WRows := 24;
            WCols := 80;
         end if;
         MSend ("RESIZE " & Id & " "
                & Trimmed_Count (WCols) & " " & Trimmed_Count (WRows));
         declare
            RResp : constant String := MRecv_Or_Ping (30.0);
            pragma Unreferenced (RResp);
         begin
            null;  --  "OK resized", or ERR from a pre-resize server
         end;
         MSend ("ATTACH " & Id);
         declare
            Resp : constant String := MRecv_Or_Ping (60.0);
         begin
            Put_Line (Resp);
            if Resp'Length >= 8
              and then Resp (Resp'First .. Resp'First + 7) = "ATTACHED"
            then
               Flush (Standard_Output);
               begin
                  if T.Kind = T_Raw then
                     declare
                        Dummy : Interfaces.C.int :=
                          Tedex_Term.Attach
                            (Interfaces.C.int (To_C (T.Sock)));
                        pragma Unreferenced (Dummy);
                     begin
                        null;
                     end;
                  else
                     Attach_Ws;
                  end if;
               exception
                  when Net_Error | Socket_Error | Host_Error =>
                     --  A hiccup inside one attach must not kill the
                     --  manager session: report and drop back to the
                     --  prompt; the relay below re-establishes it.
                     Put_Line ("attach ended (link error)"
                               & " — back at prompt");
               end;
               TClose;
               Put_Line ("session ended — reconnecting...");
               Login_Manager (U, P);
            end if;
         end;
      end Do_Attach;

      Exited : Boolean := False;

      --  One logged-in command session. Returns normally on explicit
      --  exit (Exited set); transport errors propagate to the bounded
      --  reconnect loop below.
      procedure Session is
      begin
         loop
         Put (U & "@tedex> ");
         Flush (Standard_Output);
         declare
            Verb : Unbounded_String;
            Arg  : Unbounded_String;
         begin
            Split_Verb (Get_Cmd_Alive, Verb, Arg);
            if Length (Verb) = 0
              or else To_String (Verb) = "exit"
              or else To_String (Verb) = "quit"
            then
               begin
                  MSend ("QUIT");
               exception
                  when Net_Error => null;
               end;
               TClose;
               Exited := True;
               return;
            elsif To_String (Verb) = "help" then
               Put_Line ("list | attach <device_id> | remove <device_id> | "
                         & "create-key <user> <device_id> | exit");
            elsif To_String (Verb) = "list" then
               Do_List;
            elsif To_String (Verb) = "attach" then
               Do_Attach (To_String (Arg));
            elsif To_String (Verb) = "remove" then
               declare
                  Id : constant String := To_String (Arg);
               begin
                  if Id'Length = 0 then
                     Put_Line ("usage: remove <device_id>");
                  else
                     MSend ("REMOVE " & Id);
                     declare
                        Resp : constant String := MRecv_Or_Ping (30.0);
                     begin
                        Put_Line (Resp);
                     end;
                  end if;
               end;
            elsif To_String (Verb) = "create-key" then
               declare
                  Rest : constant String := To_String (Arg);
               begin
                  if Rest'Length = 0 then
                     Put_Line ("usage: create-key <user> <device_id>");
                  else
                     --  Two args ride verbatim; the server splits and
                     --  validates (user must be your own login).
                     MSend ("CREATE-KEY " & Rest);
                     declare
                        R1 : constant String := MRecv_Or_Ping (30.0);
                     begin
                        Put_Line (R1);
                        --  Success is two lines (OK + the key itself);
                        --  errors are one line. The second read MUST
                        --  live inside this branch: declarative reads
                        --  elaborate unconditionally, so a second read
                        --  in the declarative part would hang the shell
                        --  on every one-line ERR reply.
                        if R1'Length >= 2
                          and then R1 (R1'First .. R1'First + 1) = "OK"
                        then
                           declare
                              R2 : constant String :=
                                MRecv_Or_Ping (30.0);
                           begin
                              Put_Line (R2);
                           end;
                        end if;
                     end;
                  end if;
               end;
            else
               Put_Line ("unknown: list | attach <device_id> | remove <device_id> | "
                         & "create-key <user> <device_id> | exit");
            end if;
         end;
      end loop;
      end Session;
   begin
      --  Bounded reconnect: ride out transient drops (middlebox idle
      --  kills, hiccups) until the user quits; real deaths still end
      --  with the same "connection lost" as before (3 tries, 2+4+6 s).
      for Attempt in 1 .. 4 loop
         begin
            Login_Manager (U, P);
            if Attempt = 1 then
               Put_Line ("manager " & U & " — type help");
            else
               Put_Line ("reconnected");
            end if;
            Session;
            exit;
         exception
            when Net_Error | Socket_Error | Host_Error =>
               begin
                  TClose;
               exception
                  when others => null;
               end;
               exit when Exited;
               if Attempt = 4 then
                  Put_Line ("connection lost");
               else
                  Put_Line ("connection lost — reconnecting...");
                  delay Duration (Attempt * 2);
               end if;
            when Program_Error =>
               begin
                  TClose;
               exception
                  when others => null;
               end;
               Put_Line ("login failed");
               exit;
         end;
      end loop;
   end Manager_Loop;

   --  Proved construction ("tedex-" & Dev & ".service"); every
   --  caller already enforces Safe_Dev_Name, so the precondition holds.
   function Unit_Name_Of (Dev : String) return String is
   begin
      return Tedex_Util.Service_Unit_Name (Dev);
   end Unit_Name_Of;

   function Unit_Dir return String is
   begin
      return Ada.Directories.Compose
        (Ada.Directories.Compose
           (Ada.Directories.Compose
              (Ada.Environment_Variables.Value ("HOME"), ".config"),
            "systemd"),
         "user");
   end Unit_Dir;

   function Safe_Dev_Name (Dev : String) return Boolean is
   begin
      return Tedex_Protocol.Valid_Token (Dev);
   end Safe_Dev_Name;

   function Which (Name : String) return String is
   begin
      if Ada.Directories.Exists ("/usr/bin/" & Name) then
         return "/usr/bin/" & Name;
      elsif Ada.Directories.Exists ("/bin/" & Name) then
         return "/bin/" & Name;
      elsif Ada.Directories.Exists ("/usr/local/bin/" & Name) then
         return "/usr/local/bin/" & Name;
      else
         return "";
      end if;
   end Which;

   function Run_Cmd (Prog : String; A1, A2, A3, A4 : String := "")
     return Integer
   is
      use GNAT.OS_Lib;
      Args : Argument_List (1 .. 4);
      Last : Natural := 0;
      Code : Integer := -1;

      procedure Push (A : String) is
      begin
         if A /= "" then
            Last := Last + 1;
            Args (Last) := new String'(A);
         end if;
      end Push;
   begin
      Push (A1);
      Push (A2);
      Push (A3);
      Push (A4);
      if Prog /= "" then
         if Last = 0 then
            declare
               Empty : Argument_List (1 .. 0);
            begin
               Code := Spawn (Prog, Empty);
            end;
         else
            Code := Spawn (Prog, Args (1 .. Last));
         end if;
      end if;
      for I in 1 .. Last loop
         Free (Args (I));
      end loop;
      return Code;
   exception
      when others =>
         return -1;
   end Run_Cmd;

   procedure Write_Unit_File (UDir, Want_By : String) is
      use Ada.Text_IO;
      Dev  : constant String := To_String (Dev_Id);
      Self : constant String :=
        Ada.Directories.Full_Name (Ada.Command_Line.Command_Name);
      Unit : constant String := Unit_Name_Of (Dev);
      F    : File_Type;
   begin
      Ada.Directories.Create_Path (UDir);
      Create (F, Out_File, Ada.Directories.Compose (UDir, Unit));
      Put_Line (F, "[Unit]");
      Put_Line (F, "Description=tedex device " & Dev);
      Put_Line (F, "After=network-online.target");
      Put_Line (F, "Wants=network-online.target");
      Put_Line (F, "");
      Put_Line (F, "[Service]");
      Put_Line (F, "Environment=TERM=xterm-256color");
      Put_Line (F, "ExecStart=" & Self
                & " -s " & To_String (Host)
                & " -p " & Trimmed_Count (Port)
                & (if Length (Ws_Url) > 0
                   then " --ws " & To_String (Ws_Url) else "")
                & " -c " & To_String (User) & " " & To_String (Pass)
                & " --name " & Dev & " --persist");
      Put_Line (F, "Restart=always");
      Put_Line (F, "RestartSec=5");
      Put_Line (F, "");
      Put_Line (F, "[Install]");
      Put_Line (F, "WantedBy=" & Want_By);
      Close (F);
      declare
         Chmod : constant String := Which ("chmod");
         Rc    : Integer;
         pragma Unreferenced (Rc);
      begin
         if Chmod = "" then
            Put_Line (Standard_Error, "ERR: chmod not found");
            return;
         end if;
         Rc := Run_Cmd (Chmod, "600",
                        Ada.Directories.Compose (UDir, Unit), "");
      end;
   end Write_Unit_File;

   procedure Do_Install_Service is
      use Ada.Text_IO;
      Dev  : constant String := To_String (Dev_Id);
      Home : constant String :=
        Ada.Environment_Variables.Value ("HOME", "");
      Unit : constant String := Unit_Name_Of (Dev);
      Dst  : constant String :=
        (if Length (Ws_Url) > 0 then To_String (Ws_Url)
         else To_String (Host) & ":" & Trimmed_Count (Port));
   begin
      if not Safe_Dev_Name (Dev) then
         Put_Line (Standard_Error,
           "ERR: --name must be 1..64 chars [alnum _ - .] for -r");
         return;
      end if;
      if C_Geteuid = 0 then
         --  Root: system unit (no user bus needed, runs at boot).
         Write_Unit_File ("/etc/systemd/system", "multi-user.target");
         declare
            Ctl : constant String := Which ("systemctl");
         begin
            if Ctl = "" then
               Put_Line (Standard_Error,
                 "ERR: systemctl not found; unit file kept at "
                 & "/etc/systemd/system/" & Unit);
               return;
            end if;
            if Run_Cmd (Ctl, "daemon-reload", "", "") /= 0 then
               Put_Line (Standard_Error,
                 "ERR: systemctl daemon-reload failed (no systemd? "
                 & "use --persist with container restart policy instead; "
                 & "unit file kept)");
               return;
            end if;
            if Run_Cmd (Ctl, "enable", Unit, "") /= 0 then
               Put_Line (Standard_Error, "ERR: systemctl enable failed");
               return;
            end if;
            if Run_Cmd (Ctl, "start", Unit, "") /= 0 then
               Put_Line (Standard_Error, "ERR: systemctl start failed");
               return;
            end if;
         end;
         Put_Line ("installed system unit " & Unit & " for " & Dst);
         Put_Line ("note: runs at boot as root; unit file holds "
                   & "the account password (mode 600).");
         return;
      end if;
      if Home = "" then
         Put_Line (Standard_Error, "ERR: HOME not set");
         return;
      end if;
      Write_Unit_File (Unit_Dir, "default.target");
      declare
         Ctl : constant String := Which ("systemctl");
      begin
         if Ctl = "" then
            Put_Line (Standard_Error,
              "ERR: systemctl not found; unit file kept at "
              & Ada.Directories.Compose (Unit_Dir, Unit));
            return;
         end if;
         if Run_Cmd (Ctl, "--user", "daemon-reload", "") /= 0 then
            Put_Line (Standard_Error,
              "ERR: systemctl --user failed (no user bus; if root use "
              & "is intended this should have taken the system path; "
              & "unit file kept)");
            return;
         end if;
         if Run_Cmd (Ctl, "--user", "enable", Unit) /= 0 then
            Put_Line (Standard_Error, "ERR: systemctl enable failed");
            return;
         end if;
         if Run_Cmd (Ctl, "--user", "start", Unit) /= 0 then
            Put_Line (Standard_Error, "ERR: systemctl start failed");
            return;
         end if;
      end;
      Put_Line ("installed " & Unit & " for " & Dst);
      Put_Line ("note: 'loginctl enable-linger "
                & Ada.Environment_Variables.Value ("USER", "$USER")
                & "' keeps it running after logout;");
      Put_Line ("note: unit file holds the account password (mode 600).");
   exception
      when others =>
         Put_Line (Standard_Error, "ERR: install failed");
   end Do_Install_Service;

   procedure Do_Uninstall_Service is
      use Ada.Text_IO;
      Dev : constant String := To_String (Dev_Id);
      Home : constant String :=
        Ada.Environment_Variables.Value ("HOME", "");
      Unit : constant String := Unit_Name_Of (Dev);
      P    : Unbounded_String;
      Run_Cmd_Discard : Integer;
      pragma Unreferenced (Run_Cmd_Discard);
   begin
      if not Safe_Dev_Name (Dev) then
         Put_Line (Standard_Error, "ERR: need --name <id> of the service");
         return;
      end if;
      if C_Geteuid = 0 then
         Run_Cmd_Discard := Run_Cmd (Which ("systemctl"), "stop", Unit, "");
         Run_Cmd_Discard := Run_Cmd (Which ("systemctl"), "disable", Unit, "");
         P := To_Unbounded_String
           (Ada.Directories.Compose ("/etc/systemd/system", Unit));
      else
         if Home = "" then
            Put_Line (Standard_Error, "ERR: HOME not set");
            return;
         end if;
         Run_Cmd_Discard := Run_Cmd (Which ("systemctl"), "--user", "stop", Unit);
         Run_Cmd_Discard :=
           Run_Cmd (Which ("systemctl"), "--user", "disable", Unit);
         P := To_Unbounded_String
           (Ada.Directories.Compose (Unit_Dir, Unit));
      end if;
      if Ada.Directories.Exists (To_String (P)) then
         Ada.Directories.Delete_File (To_String (P));
         Put_Line ("removed " & Unit);
      else
         Put_Line ("no unit file " & Unit);
      end if;
   exception
      when others =>
         Put_Line (Standard_Error, "ERR: uninstall failed");
   end Do_Uninstall_Service;

   procedure Do_Self_Uninstall is
      --  Self-removal after the server ordered removal ("REMOVED").
      --  Fixed: Restart=always restarts on clean exit even when disabled,
      --  so disable alone is NOT enough (old comment was wrong). Order is
      --  disable -> delete file -> daemon-reload (after delete, else unit
      --  stays loaded as 'bad') -> stop last. Stop SIGTERMs ourselves but
      --  work is already done; systemd then marks inactive and cancels
      --  the restart job. Root uses system units, others use --user.
      use Ada.Text_IO;
      Dev  : constant String := To_String (Dev_Id);
      P    : Unbounded_String;
      Rc   : Integer;
      Ctl  : constant String := Which ("systemctl");
      pragma Unreferenced (Rc);
   begin
      if Dev = "" or else not Safe_Dev_Name (Dev) then
         return;
      end if;
      if Ctl = "" then
         return;
      end if;
      if C_Geteuid = 0 then
         P := To_Unbounded_String
           (Ada.Directories.Compose
              ("/etc/systemd/system", Unit_Name_Of (Dev)));
         Rc := Run_Cmd (Ctl, "disable", Unit_Name_Of (Dev));
         if Ada.Directories.Exists (To_String (P)) then
            begin
               Ada.Directories.Delete_File (To_String (P));
            exception
               when others => null;
            end;
         end if;
         Rc := Run_Cmd (Ctl, "daemon-reload", "", "");
         Put_Line ("removed " & Unit_Name_Of (Dev)
                   & " (device removed by manager)");
         Rc := Run_Cmd (Ctl, "stop", Unit_Name_Of (Dev));
      else
         P := To_Unbounded_String
           (Ada.Directories.Compose (Unit_Dir, Unit_Name_Of (Dev)));
         Rc := Run_Cmd (Ctl, "--user", "disable", Unit_Name_Of (Dev));
         if Ada.Directories.Exists (To_String (P)) then
            begin
               Ada.Directories.Delete_File (To_String (P));
            exception
               when others => null;
            end;
         end if;
         Rc := Run_Cmd (Ctl, "--user", "daemon-reload", "", "");
         Put_Line ("removed " & Unit_Name_Of (Dev)
                   & " (device removed by manager)");
         Rc := Run_Cmd (Ctl, "--user", "stop", Unit_Name_Of (Dev));
      end if;
   exception
      when others => null;
   end Do_Self_Uninstall;

begin
   Ignore_Sigpipe;
   declare
      use Ada.Command_Line;
      I : Natural := 1;
      Got_Mode : Boolean := False;
   begin
      while I <= Argument_Count loop
         declare
            A : constant String := Argument (I);
         begin
            if A = "-s" and then I < Argument_Count then
               Host := To_Unbounded_String (Argument (I + 1));
               I := I + 2;
            elsif A = "-p" and then I < Argument_Count then
               Port := Integer'Value (Argument (I + 1));
               I := I + 2;
            elsif A = "--ws" and then I < Argument_Count then
               Ws_Url := To_Unbounded_String (Argument (I + 1));
               I := I + 2;
            elsif A = "-u" and then I + 1 <= Argument_Count then
               Is_Dev := False;
               User := To_Unbounded_String (Argument (I + 1));
               Pass := To_Unbounded_String (Argument (I + 2));
               Got_Mode := True;
               I := I + 3;
            elsif A = "-c" and then I + 1 <= Argument_Count then
               Is_Dev := True;
               User := To_Unbounded_String (Argument (I + 1));
               Pass := To_Unbounded_String (Argument (I + 2));
               Got_Mode := True;
               I := I + 3;
            elsif A = "--name" and then I < Argument_Count then
               Dev_Id := To_Unbounded_String (Argument (I + 1));
               Name_Given := True;
               I := I + 2;
            elsif A = "-r" then
               Do_Install := True;
               I := I + 1;
            elsif A = "--persist" then
               Persist := True;
               I := I + 1;
            elsif A = "--uninstall" then
               Do_Uninstall := True;
               I := I + 1;
            else
               Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,
                 "usage: client [-s host] [-p port] [--ws ws[s]://host[:port][/path]]"
                 & " -u|-c user password-or-key [--name id] [-r] [--persist] [--uninstall]");
               return;
            end if;
         end;
      end loop;
      if not Got_Mode and not Do_Uninstall then
         Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,
           "usage: client [-s host] [-p port] [--ws ws[s]://host[:port][/path]]"
           & " -u|-c user password-or-key [--name id] [-r] [--persist] [--uninstall]");
         return;
      end if;
   exception
      when Constraint_Error =>
         Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error, "bad argument");
         return;
   end;
   if Port not in 1 .. 65_535 then
      Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error, "bad port");
      return;
   end if;
   if Do_Uninstall then
      if not Name_Given then
         Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,
           "uninstall needs --name <device id>");
         return;
      end if;
      Do_Uninstall_Service;
      return;
   end if;
   if Do_Install then
      if not Is_Dev then
         Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,
           "-r needs device mode (-c user password --name id)");
         return;
      end if;
      if not Name_Given then
         Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,
           "-r needs an explicit --name <device id>");
         return;
      end if;
      Do_Install_Service;
      return;
   end if;
   if Is_Dev then
      if Length (Dev_Id) = 0 then
         Dev_Id := To_Unbounded_String ("dev-" & Rand_Hex (2));
      end if;
      Device_Loop (To_String (User), To_String (Pass), To_String (Dev_Id));
      if Was_Removed then
         Do_Self_Uninstall;
         GNAT.OS_Lib.OS_Exit (0);
      end if;
   else
      Manager_Loop (To_String (User), To_String (Pass));
   end if;
end Client;
