--  Predictive-echo decision core (SPARK_Mode On): pure Benson-style
--  consume/predict over fixed 1-based buffers. All wall-clock, terminal
--  IO, environment and transport stays in the client glue, which feeds
--  this unit normalized inputs (First = 1) and millisecond timestamps
--  (saturating, so Natural arithmetic cannot overflow).
--
--  This is the extracted, provable form of the Attach_Ws echo glue:
--  same decisions (verified by burst parity), stated contracts.

package Tedex_Predict with SPARK_Mode is

   Max_Pending : constant := 1024;
   --  Cap of the unacknowledged belief (mirrors the client glue).
   --  Appends past this cap truncate (pathological backlog only:
   --  thousands of unacked bytes on a dead link).

   Max_Chunk : constant := 32_768;
   --  Largest single decision input; the client slices bigger reads.

   Max_Hold : constant := 256;
   --  Withheld echo-tail cap (first belief lines are short by design).

   Max_Stdin : constant := 4096;
   --  Largest stdin slice per Predict_Chunk call (matches the client
   --  read buffer); one newline displays as CRLF, so display output
   --  can at most double the input.

   Max_Ms : constant := 2_000_000_000;
   --  Timestamp ceiling (~23 days); the client saturates Clock here.

   subtype Pend_Range is Natural range 0 .. Max_Pending;
   subtype Hold_Range is Natural range 0 .. Max_Hold;

   type Trace_Code is
     (Tr_None, Tr_Frag, Tr_Full, Tr_Pipeline, Tr_Substring, Tr_Hold,
      Tr_Flushed_Hold, Tr_Fail_Open, Tr_Erased, Tr_Expired);
   --  Observable decision for the client debug log (replaces Dbg strings
   --  inside proved code).

   type Echo_State is record
      Pend       : String (1 .. Max_Pending) := [others => ' '];
      Pend_Len   : Pend_Range := 0;
      Pend_At    : Natural := 0;
      Credit     : Natural range 0 .. 64 := 0;
      Half       : Natural range 0 .. 2 := 0;
      Frag_At    : Natural := 0;
      Erase_Since : Natural := 0;
      Printables : Natural range 0 .. 4096 := 0;
      Suspended  : Boolean := False;
      Fullscreen : Boolean := False;
      Fs         : String (1 .. 8) := [others => ' '];
      Fs_Len     : Natural range 0 .. 8 := 0;
      Last_CR    : Boolean := False;
      Hold       : String (1 .. Max_Hold) := [others => ' '];
      Hold_Len   : Hold_Range := 0;
      Hold_At    : Natural := 0;
   end record;

   function Valid_State (St : Echo_State) return Boolean is
     (St.Pend_At <= Max_Ms and St.Frag_At <= Max_Ms
      and St.Erase_Since <= Max_Ms and St.Hold_At <= Max_Ms);
   --  Timestamp sanity (client feeds saturated ms).

   --  Feed one stdin chunk (First = 1): updates belief/erase state and
   --  returns the bytes to display locally (possibly empty). Never
   --  raises on valid inputs.
   procedure Predict_Chunk
     (St    : in out Echo_State;
      Now   : Natural;
      Chunk : String;
      Shown : out String;
      Shown_Len : out Natural;
      Trace : out Trace_Code)
   with Pre  => Chunk'First = 1 and Chunk'Length <= Max_Stdin
                and Shown'First = 1 and Shown'Length >= 4 * Max_Stdin
                and Shown'Length <= 100_000
                and Now <= Max_Ms and Valid_State (St),
        Post => Shown_Len <= 4 * Chunk'Length
                and Valid_State (St),
        Global => null,
        Depends => (St        => (St, Now, Chunk),
                    Shown     => (St, Now, Chunk, Shown),
                    Shown_Len => (St, Now, Chunk, Shown),
                    Trace     => null);

   --  Feed one network chunk (First = 1): consumes echoes, returns the
   --  bytes to display (possibly empty). Hold continuity: a withheld
   --  tail from the previous call is prepended internally. Never raises
   --  on valid inputs.
   procedure Consume_Chunk
     (St    : in out Echo_State;
      Now   : Natural;
      Chunk : String;
      Shown : out String;
      Shown_Len : out Natural;
      Trace : out Trace_Code)
   with Pre  => Chunk'First = 1
                and Chunk'Length <= Max_Chunk
                and Shown'First = 1
                and Shown'Length >= Chunk'Length + Max_Hold + 16
                and Shown'Length <= 100_000
                and Now <= Max_Ms and Valid_State (St),
        Post => Shown_Len <= Chunk'Length + Max_Hold + 16
                and Valid_State (St),
        Global => null,
        Depends => (St        => (St, Now, Chunk),
                    Shown     => (St, Now, Chunk, Shown),
                    Shown_Len => (St, Now, Chunk, Shown),
                    Trace     => (St, Now, Chunk));

   --  Surface a stale hold (no continuation arrived): returns the held
   --  bytes for display, clears the hold. Pure timeout rule: fresh
   --  holds stay held with empty output.
   procedure Flush_Hold
     (St    : in out Echo_State;
      Now   : Natural;
      Shown : out String;
      Shown_Len : out Natural)
   with Pre  => Shown'First = 1 and Shown'Length >= Max_Hold
                and Now <= Max_Ms and Valid_State (St),
        Post => Shown_Len <= St'Old.Hold_Len and Valid_State (St)
                and (if St'Old.Hold_Len = 0
                     or Now <= St'Old.Hold_At + 1_000
                     then Shown_Len = 0
                          and St.Hold_Len = St'Old.Hold_Len
                     else Shown_Len = St'Old.Hold_Len
                          and St.Hold_Len = 0
                          and Shown (Shown'First
                                     .. Shown'First + Shown_Len - 1)
                                = St'Old.Hold (1 .. St'Old.Hold_Len)),
        Global => null,
        Depends => (St        => (St, Now),
                    Shown     => (St, Now, Shown),
                    Shown_Len => (St, Now));

end Tedex_Predict;
