--  Display-side echo-suppression primitives for the manager attach
--  relay: pure, total string functions with machine-checked contracts
--  (SPARK_Mode On). The fail-open display *policy* built on top of
--  them still lives in the client glue (timing judgment, tested-only).
package Tedex_Echo with SPARK_Mode is

   --  Longest common prefix length of Pending and Msg, scanning from
   --  their first characters. Total on all inputs (empty-safe).
   function Common_Prefix (Pending, Msg : String) return Natural
     with Post =>
       Common_Prefix'Result <= Pending'Length
       and Common_Prefix'Result <= Msg'Length,
            Global => null,
            Depends => (Common_Prefix'Result => (Pending, Msg));
            --  NOTE (honest scope): content equality and maximality are
            --  NOT in this Post. Stating them needs First-relative
            --  indexing whose 32-bit overflow checks time out at level 4
            --  (4 formulations tried: quantified, slice, synced
            --  invariant, explicit strict bounds). Maximality is a
            --  candidate Coq theorem instead (nat has no overflow wall):
            --  EchoModel currently proves bounds + empty cases only.
            --  Behavioral maximality stays covered by echo_vectors
            --  Decide cases + production burst tests.

   --  Bracket framing at the head of Msg (readline redraw wrappers):
   --  8 for ESC[?2004l / ESC[?2004h, 9 when a framing CR follows,
   --  else 0. Total on all inputs.
   function Bracket_Pre (Msg : String) return Natural
     with Post =>
       (Bracket_Pre'Result = 0
        or Bracket_Pre'Result = 8
        or Bracket_Pre'Result = 9)
       and (if Bracket_Pre'Result /= 0 then Msg'Length > 8),
            Global => null,
            Depends => (Bracket_Pre'Result => Msg);

end Tedex_Echo;
