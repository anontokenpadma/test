(* VST specification of fds_wait_read (tlswrap.c:38-62) — last.txt item 2b, DONE 2026-10-11.
   Qed, 0 admit/Admitted, Print Assumptions classical-only, .vo 626K.
   Wait on two fds. Returns bitmask (1 and/or 2), 0 timeout, -2 intr, -1 err.
   Design: MIRRORS verif_fd_wait_read.v (1-fd, Qed) extended to the 2-array +
   out-bitmask tail. Ghost discipline (need.txt item 1, snapshot 22/):
   poll OVERWRITES ghost_var Tsh to EX e_new; __errno_location TAKES current
   ghost g and RETURNS the same g (ghost-only spec: WITH gn g, no buffer, no
   struct — frame inference absorbs the array); function POST carries the
   errno cell in EX o + opt_data (never dropped).
   Struct discipline (Rocq 9.2 + VST 2.17 EX+Tstruct elaboration quirk):
   EX proof POSTs use data_at_ for the poll array (concrete struct under EX
   mis-elaborates exp to mpred); poll PRE takes data_at_ and POST returns the
   CONCRETE array (sound: real poll preserves fd/events, only revents change;
   witnesses supply the true fd/ev), so revents loads evaluate and Oand
   branch conditions decide. Ternary timeout (timeout<0 ? -1 : timeout) via
   EX tt JOIN carrying the range (no disjunction needed).
   out-bitmask: fd0 check (POLLIN|POLLHUP -> out|=1, ground Int.or via or01;
   elif ERR|NVAL -> -1) then fd1 check (out|=2 via or_out2 rewrite) then final
   out==0 ? 0 : out; relations carried as POST disjunctions, discharged at the
   final return by case analysis (out0/out1 ground per leaf, lia + picks).
   Syscall model: poll/__errno_location AXIOMS. POLLIN=1, POLLHUP=16,
   POLLERR=8, POLLNVAL=32, EINTR=4. HONEST SCOPE: branch-structure + memory
   safety + return-code contract (NOT revents exact values). *)
Require Import VST.floyd.proofauto.
Require Import VST.concurrency.ghosts.
Require Import Clight.tlswrap.
Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.
Definition opt_data (sh : share) (o : option (val * Z)) : mpred :=
  match o with | None => emp | Some (p, e) => data_at sh tint (Vint (Int.repr e)) p end.
Lemma or01 : Int.or (Int.repr 0) (Int.repr 1) = Int.repr 1. Proof. reflexivity. Qed.
Lemma or_out2 : forall o, o = 0 \/ o = 1 ->
  Int.or (Int.repr o) (Int.repr 2) = Int.repr (o + 2).
Proof. intros o [->| ->]; reflexivity. Qed.
(* poll 2 fds: PRE any array, POST concrete (fd/ev preserved, revents fresh). *)
Definition poll2_spec : ident * funspec :=
  DECLARE _poll
  WITH fds : val, sh : share,
       fd1 : Z, ev1 : Z, rev1 : Z, fd2 : Z, ev2 : Z, rev2 : Z, timeout : Z,
       gn : gname, g_old : Z
  PRE [ tptr (Tstruct _pollfd noattr), tulong, tint ]
    PROP (Int.min_signed <= timeout <= Int.max_signed;
          Int.min_signed <= fd1 <= Int.max_signed;
          Int.min_signed <= fd2 <= Int.max_signed;
          writable_share sh)
    PARAMS (fds; Vlong (Int64.repr 2); Vint (Int.repr timeout))
    GLOBALS ()
    SEP (data_at_ sh (tarray (Tstruct _pollfd noattr) 2) fds;
         ghost_var Tsh g_old gn)
  POST [ tint ]
    EX s : Z, EX rev1' : Z, EX rev2' : Z, EX e_new : Z,
    PROP (Int.min_signed <= s <= Int.max_signed;
          -32768 <= rev1' <= 32767;
          -32768 <= rev2' <= 32767)
    LOCAL (temp ret_temp (Vint (Int.repr s)))
    SEP (data_at sh (tarray (Tstruct _pollfd noattr) 2)
           ((Vint (Int.repr fd1), (Vint (Int.repr ev1), Vint (Int.repr rev1'))) ::
            (Vint (Int.repr fd2), (Vint (Int.repr ev2), Vint (Int.repr rev2'))) :: nil) fds;
         ghost_var Tsh e_new gn).
(* errno_location: ghost-only (value = current ghost, by construction). *)
Definition errno_loc_spec : ident * funspec :=
  DECLARE ___errno_location
  WITH gn : gname, g : Z
  PRE [ ]
    PROP (True)
    PARAMS () GLOBALS ()
    SEP (ghost_var Tsh g gn)
  POST [ tptr tint ]
    EX p : val,
    PROP (True)
    LOCAL (temp ret_temp p)
    SEP (ghost_var Tsh g gn;
         data_at Tsh tint (Vint (Int.repr g)) p).
Definition fds_wait_read_spec : ident * funspec :=
  DECLARE _fds_wait_read
  WITH fd1 : Z, fd2 : Z, timeout : Z, gn : gname, e0 : Z
  PRE [ tint, tint, tint ]
    PROP (0 <= fd1 <= Int.max_signed;
          0 <= fd2 <= Int.max_signed;
          Int.min_signed <= timeout <= Int.max_signed)
    PARAMS (Vint (Int.repr fd1); Vint (Int.repr fd2); Vint (Int.repr timeout))
    GLOBALS ()
    SEP (ghost_var Tsh e0 gn)
  POST [ tint ]
    EX ret : Z, EX e_fin : Z, EX o : option (val * Z),
    PROP (Int.min_signed <= ret <= Int.max_signed;
          (ret = -2 \/ ret = -1 \/ ret = 0 \/ ret = 1 \/ ret = 2 \/ ret = 3))
    LOCAL (temp ret_temp (Vint (Int.repr ret)))
    SEP (ghost_var Tsh e_fin gn;
         opt_data Tsh o).
Definition t4join (ss : Z) (p1 v_p : val) (fd1 fd2 timeout r1 r2 epoll : Z) (gn : gname) : environ -> mpred :=
  EX t4 : Z, PROP ((t4 = -2 \/ t4 = -1))
  LOCAL (temp _t'4 (Vint (Int.repr t4)); temp _t'3 p1;
         temp _fd1 (Vint (Int.repr fd1)); temp _fd2 (Vint (Int.repr fd2));
         temp _timeout_ms (Vint (Int.repr timeout)); temp _out (Vint (Int.repr 0));
         temp _r (Vint (Int.repr ss)); lvar _p (tarray (Tstruct _pollfd noattr) 2) v_p)
  SEP (data_at Tsh tint (Vint (Int.repr epoll)) p1;
       data_at_ Tsh (tarray (Tstruct _pollfd noattr) 2) v_p;
       ghost_var Tsh epoll gn).
Definition out0join (ss : Z) (fd1 fd2 timeout : Z) (v_p : val) (r1 r2 epoll : Z) (gn : gname) : environ -> mpred :=
  @exp (environ -> mpred) _ _ (fun out0 : Z =>
  PROP ((out0 = 0 \/ out0 = 1))
  LOCAL (temp _fd1 (Vint (Int.repr fd1)); temp _fd2 (Vint (Int.repr fd2));
         temp _timeout_ms (Vint (Int.repr timeout)); temp _out (Vint (Int.repr out0));
         temp _r (Vint (Int.repr ss)); lvar _p (tarray (Tstruct _pollfd noattr) 2) v_p)
  SEP (data_at Tsh (tarray (Tstruct _pollfd noattr) 2)
         ((Vint (Int.repr fd1), (Vint (Int.repr 1), Vint (Int.repr r1))) ::
          (Vint (Int.repr fd2), (Vint (Int.repr 1), Vint (Int.repr r2))) :: nil) v_p;
       ghost_var Tsh epoll gn)).
Definition out1join (ss : Z) (out0 : Z) (fd1 fd2 timeout : Z) (v_p : val) (r1 r2 epoll : Z) (gn : gname) : environ -> mpred :=
  @exp (environ -> mpred) _ _ (fun out1 : Z =>
  PROP ((out1 = out0 \/ out1 = (out0 + 2)%Z))
  LOCAL (temp _fd1 (Vint (Int.repr fd1)); temp _fd2 (Vint (Int.repr fd2));
         temp _timeout_ms (Vint (Int.repr timeout)); temp _out (Vint (Int.repr out1));
         temp _r (Vint (Int.repr ss)); lvar _p (tarray (Tstruct _pollfd noattr) 2) v_p)
  SEP (data_at Tsh (tarray (Tstruct _pollfd noattr) 2)
         ((Vint (Int.repr fd1), (Vint (Int.repr 1), Vint (Int.repr r1))) ::
          (Vint (Int.repr fd2), (Vint (Int.repr 1), Vint (Int.repr r2))) :: nil) v_p;
       ghost_var Tsh epoll gn)).
Definition retjoin (ss : Z) (out1 : Z) (fd1 fd2 timeout : Z) (v_p : val) (epoll : Z) (gn : gname) : environ -> mpred :=
  EX ret : Z, PROP ((ret = 0 \/ ret = out1))
  LOCAL (temp _t'5 (Vint (Int.repr ret));
         temp _fd1 (Vint (Int.repr fd1)); temp _fd2 (Vint (Int.repr fd2));
         temp _timeout_ms (Vint (Int.repr timeout)); temp _out (Vint (Int.repr out1));
         temp _r (Vint (Int.repr ss)); lvar _p (tarray (Tstruct _pollfd noattr) 2) v_p)
  SEP (data_at_ Tsh (tarray (Tstruct _pollfd noattr) 2) v_p;
       ghost_var Tsh epoll gn).
Definition Gprog : funspecs :=
  ltac:(with_library prog [poll2_spec; errno_loc_spec; fds_wait_read_spec]).
Lemma body_fds_wait_read : semax_body Vprog Gprog f_fds_wait_read fds_wait_read_spec.
Proof.
  start_function.
  forward. forward. forward. forward. forward. forward. forward.
  (* out=0; p[0]=(fd1,1,0); p[1]=(fd2,1,0) — constant indices *)
  repeat (apply -> semax_seq_skip).
  repeat (apply seq_assoc1; try apply -> semax_seq_skip).
  forward_if (EX tt : Z, PROP (Int.min_signed <= tt <= Int.max_signed)
    LOCAL (temp _fd1 (Vint (Int.repr fd1)); temp _fd2 (Vint (Int.repr fd2));
           temp _timeout_ms (Vint (Int.repr timeout)); temp _out (Vint (Int.repr 0));
           temp _t'1 (Vint (Int.repr tt)); lvar _p (tarray (Tstruct _pollfd noattr) 2) v_p)
    SEP (data_at_ Tsh (tarray (Tstruct _pollfd noattr) 2) v_p;
         ghost_var Tsh e0 gn)).
  - forward. Exists (-1). entailer!.
  - forward. Exists timeout. entailer!.
  - Intros tt.
    forward_call (v_p, Tsh, fd1, 1, 0, fd2, 1, 0, tt, gn, e0).
    Intros v. destruct v as [[[ss r1] r2] epoll].
    change (fst (fst (fst (((ss, r1), r2), epoll)))) with ss in *.
    change (snd (fst (fst (((ss, r1), r2), epoll)))) with r1 in *.
    change (snd (fst (((ss, r1), r2), epoll))) with r2 in *.
    change (snd (((ss, r1), r2), epoll)) with epoll in *.
    forward. (* _r = poll result *)
    repeat (apply -> semax_seq_skip).
    repeat (apply seq_assoc1; try apply -> semax_seq_skip).
    forward_if.
    + (* r < 0: errno (ghost epoll returned as-is), return -2/-1 *)
      forward_call (gn, epoll).
      Intros p1.
      forward. (* _t'10 = *p1 = epoll *)
      repeat (apply -> semax_seq_skip).
      repeat (apply seq_assoc1; try apply -> semax_seq_skip).
      forward_if (t4join ss p1 v_p fd1 fd2 timeout r1 r2 epoll gn).
      * forward. Exists (-2). entailer!.
      * forward. Exists (-1). entailer!.
      * unfold t4join. Intros t4. forward. Exists t4 epoll (Some (p1, epoll)). entailer!.
    + (* r >= 0: `if (r==0) return 0;` then bitmask checks *)
      forward_if.
      * forward. Exists 0 epoll (@None (val * Z)). entailer!.
      * forward. (* _t'8 load *)
        forward_if_tac (out0join ss fd1 fd2 timeout v_p r1 r2 epoll gn).
        -- forward. try rewrite or01. Exists 1. entailer!.
        -- forward. (* _t'9 *)
           forward_if.
           ++ forward. Exists (-1) epoll (@None (val * Z)). entailer!.
           ++ forward. Exists 0. entailer!.
        -- unfold out0join. Intros out0.
           forward. (* _t'6 *)
           forward_if_tac (out1join ss out0 fd1 fd2 timeout v_p r1 r2 epoll gn).
           ++ forward.
              match goal with H : (out0 = 0 \/ out0 = 1) |- _ => rewrite (or_out2 out0 H) end.
              Exists (out0 + 2). entailer!.
           ++ forward. (* _t'7 *)
              forward_if.
              ** forward. Exists (-1) epoll (@None (val * Z)). entailer!.
              ** forward. Exists out0. entailer!.
           ++ unfold out1join. Intros out1.
              forward_if_tac (retjoin ss out1 fd1 fd2 timeout v_p epoll gn).
              ** forward. Exists 0. entailer!.
              ** forward. Exists out1. entailer!.
              ** unfold retjoin. Intros ret.
                 match goal with Hr0 : (ret = 0 \/ ret = out1) |- _ => destruct Hr0 as [HrA|HrB] end.
                 --- rewrite HrA. forward. Exists 0 epoll (@None (val * Z)). entailer!.
                 --- rewrite HrB.
                     match goal with H10 : (out1 = out0 \/ out1 = (out0 + 2)%Z) |- _ => destruct H10 as [H1A|H1B] end.
                     +++ rewrite H1A.
                         match goal with H00 : (out0 = 0 \/ out0 = 1) |- _ => destruct H00 as [H0A|H0B] end.
                         ++++ rewrite H0A. forward. Exists 0 epoll (@None (val * Z)). entailer!.
                         ++++ rewrite H0B. forward. Exists 1 epoll (@None (val * Z)). entailer!.
                     +++ rewrite H1B.
                         match goal with H00 : (out0 = 0 \/ out0 = 1) |- _ => destruct H00 as [H0A|H0B] end.
                         ++++ rewrite H0A. forward. Exists 2 epoll (@None (val * Z)). entailer!.
                         ++++ rewrite H0B. forward. Exists 3 epoll (@None (val * Z)). entailer!.
Qed.




