(* VST verification of fd_wait_read (tlswrap.c:20-35).
      int fd_wait_read (int fd, int timeout_ms)
      { struct pollfd p; int r;
        p.fd=fd; p.events=POLLIN; p.revents=0;
        r = poll(&p,1, timeout_ms<0 ? -1 : timeout_ms);
        if (r<0) return errno==EINTR ? -2 : -1;
        if (r==0) return 0;
        if (p.revents & (POLLERR|POLLNVAL)) return -1;
        return 1; }
    HONEST STATUS 2026-10-10 (need.txt item 2): Qed TRỌN VẸN (coqc EXIT 0,
    0 admit/Admitted). Reuses the fd_read_timeout pattern (verif_fd_read.v).
    Notable techniques:
    - The ternary `timeout_ms<0 ? -1 : timeout_ms` before poll is handled
      with the pty_poll idiom: a `sexp_skip/seq_assoc1` massage then a
      `forward_if (EX tt. ...)` with `data_at_` (any) for the poll struct;
      the poll PRE uses `data_at_` (any) so the arg `_t'1` (=EX tt) matches.
      The poll POST restores the concrete struct (Vint fd/ev/rev') so the
      later `p.revents` read has a concrete value. Sound: the timeout value
      passed to poll is existentially abstracted and does not appear in the
      poll POST, so the outcome is independent of it (poll is an axiom).
    - poll is an AXIOM: PRE `data_at_` (any struct), POST EX s/rev'/e_new with
      the concrete struct carrying rev' (the updated revents).
    - errno_location is an AXIOM returning a cell whose value is (per the
      value-only ghost discipline, need.txt item 1) the current ghost g.
    - Ghost discipline (need.txt item 1): poll OVERWRITES ghost e0->e_new
      (here `epoll`); errno_location TAKES the current ghost (epoll) and
      returns the same value; the returned errno cell (opt_data Some(p1,
      epoll)) is threaded to the final POST. Value-identity machine-checked
      on the errno read; address-aliasing kept as fresh-per-call over-approx.
    Constants: EINTR=4, POLLIN=1, POLLERR=8, POLLNVAL=32 (POLLERR|POLLNVAL=40).
    Syscall model: poll/errno AXIOMS. HONEST SCOPE: branch-structure +
    memory safety only (same as read_chunk/fd_read). *)
Require Import VST.floyd.proofauto.
Require Import VST.concurrency.ghosts.
Require Import Clight.tlswrap.
Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.

(* Optional errno-cell ownership (same as verif_read_chunk.v / fd_read). *)
Definition opt_data (sh : share) (o : option (val * Z)) : mpred :=
  match o with | None => emp | Some (p, e) => data_at sh tint (Vint (Int.repr e)) p end.

(* poll(&p,1,t): AXIOM. PRE `data_at_` (any poll struct) so the timeout arg
   (existentially abstracted by the ternary handling) matches; POST carries
   the concrete struct with the updated revents rev' and OVERWRITES the
   errno ghost e0 -> e_new (sound over-approx: poll may set errno). *)
Definition poll_wait_spec : ident * funspec :=
  DECLARE _poll
  WITH fds : val, sh : share, fdfd : Z, ev : Z, rev : Z, timeout : Z, gn : gname, g_old : Z
  PRE [ tptr (Tstruct _pollfd noattr), tulong, tint ]
    PROP (Int.min_signed <= timeout <= Int.max_signed;
          Int.min_signed <= fdfd <= Int.max_signed;
          writable_share sh)
    PARAMS (fds; Vlong (Int64.repr 1); Vint (Int.repr timeout))
    GLOBALS ()
    SEP (data_at_ sh (Tstruct _pollfd noattr) fds;
         ghost_var Tsh g_old gn)
  POST [ tint ]
    EX s : Z, EX rev' : Z, EX e_new : Z,
    PROP (Int.min_signed <= s <= Int.max_signed;
          -32768 <= rev' <= 32767)
    LOCAL (temp ret_temp (Vint (Int.repr s)))
    SEP (data_at sh (Tstruct _pollfd noattr)
           (Vint (Int.repr fdfd), (Vint (Int.repr ev), Vint (Int.repr rev'))) fds;
         ghost_var Tsh e_new gn).

(* errno_location(): AXIOM. Value-only ghost discipline (need.txt item 1):
   TAKES the current ghost g and RETURNs the same value (POST cell carries
   Vint (Int.repr g)); consumes and returns the same ghost. *)
Definition errno_loc_spec : ident * funspec :=
  DECLARE ___errno_location
  WITH gn : gname, g : Z
  PRE [ ] PROP (True) PARAMS () GLOBALS ()
    SEP (ghost_var Tsh g gn)
  POST [ tptr tint ]
    EX p : val, PROP (True)
    LOCAL (temp ret_temp p)
    SEP (ghost_var Tsh g gn; data_at Tsh tint (Vint (Int.repr g)) p).

Definition fd_wait_read_spec : ident * funspec :=
  DECLARE _fd_wait_read
  WITH fd : Z, timeout : Z, gn : gname, e0 : Z
  PRE [ tint, tint ]
    PROP (Int.min_signed <= fd <= Int.max_signed;
          Int.min_signed <= timeout <= Int.max_signed)
    PARAMS (Vint (Int.repr fd); Vint (Int.repr timeout))
    GLOBALS () SEP (ghost_var Tsh e0 gn)
  POST [ tint ]
    EX ret : Z, EX o1 : option (val * Z), EX e_fin : Z,
    PROP (Int.min_signed <= ret <= Int.max_signed;
          (ret = -2 \/ ret = -1 \/ ret = 0 \/ ret = 1))
    LOCAL (temp ret_temp (Vint (Int.repr ret)))
    SEP (opt_data Tsh o1; ghost_var Tsh e_fin gn).

Definition Gprog : funspecs :=
  ltac:(with_library prog [poll_wait_spec; errno_loc_spec; fd_wait_read_spec]).

Lemma body_fd_wait_read : semax_body Vprog Gprog f_fd_wait_read fd_wait_read_spec.
Proof.
  start_function.
  forward. forward. forward.   (* p.fd=fd; p.events=POLLIN; p.revents=0 *)
  (* ternary `timeout_ms<0 ? -1 : timeout_ms` then poll(..,_t'1) *)
  repeat (apply -> semax_seq_skip).
  repeat (apply seq_assoc1; try apply -> semax_seq_skip).
  forward_if (EX tt : Z, PROP (Int.min_signed <= tt <= Int.max_signed)
    LOCAL (temp _t'1 (Vint (Int.repr tt)); lvar _p (Tstruct _pollfd noattr) v_p;
           temp _fd (Vint (Int.repr fd)); temp _timeout_ms (Vint (Int.repr timeout)))
    SEP (data_at_ Tsh (Tstruct _pollfd noattr) v_p;
         ghost_var Tsh e0 gn)).
  - forward. Exists (-1). entailer!.
  - forward. Exists timeout. entailer!.
  - Intros tt.
    forward_call (v_p, Tsh, fd, 1, 0, tt, gn, e0).   (* poll: data_at_ PRE matches; POST concrete *)
    Intros v. destruct v as [[ss rev2] epoll].
    change (fst (fst ((ss, rev2), epoll))) with ss in *.
    change (snd (fst ((ss, rev2), epoll))) with rev2 in *.
    change (snd ((ss, rev2), epoll)) with epoll in *.
    repeat (apply -> semax_seq_skip).
    repeat (apply seq_assoc1; try apply -> semax_seq_skip).
    forward.                       (* _r = poll result *)
    forward_if.                    (* if (r<0) — then returns, so bare works *)
    + (* r < 0: read errno (ghost epoll returned as-is) *)
      forward_call (gn, epoll).
      Intros p1.
      forward.                     (* _t'6 = *p1 = errno value = epoll *)
      repeat (apply -> semax_seq_skip).
      repeat (apply seq_assoc1; try apply -> semax_seq_skip).
      forward_if (EX te : Z, PROP (te = -2 \/ te = -1)
        LOCAL (temp _t'4 (Vint (Int.repr te));
               temp _t'3 p1;
               temp _r (Vint (Int.repr ss));
               lvar _p (Tstruct _pollfd noattr) v_p;
               temp _fd (Vint (Int.repr fd)); temp _timeout_ms (Vint (Int.repr timeout)))
        SEP (data_at Tsh tint (Vint (Int.repr epoll)) p1;
             data_at_ Tsh (Tstruct _pollfd noattr) v_p;
             ghost_var Tsh epoll gn)).
      * forward. Exists (-2). entailer!.
      * forward. Exists (-1). entailer!.
      * Intros te. forward. Exists te (Some (p1, epoll)) epoll. entailer!.
    + (* r >= 0: `if (r==0) return 0;` then revents check *)
      forward_if.
      * forward. Exists 0 (@None (val*Z)) epoll. entailer!.
      * forward.
        forward_if.
        -- forward. Exists (-1) (@None (val*Z)) epoll. entailer!.
        -- forward. Exists 1 (@None (val*Z)) epoll. entailer!.
Qed.