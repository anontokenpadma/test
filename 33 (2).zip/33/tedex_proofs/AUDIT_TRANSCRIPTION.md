# Audit transcription: Coq theorem <-> source lines (need.txt item 10)

Second-reader check table. Every line range below was grep-verified on
2026-10-09 against /home/jovyan/19/src + tedex_proofs. Status column:
`[x]` second reader confirms transcription matches source.

## AuthVerdict.v (model: tedex_util.adb:387-401, contract tedex_util.ads:175-186)

| Theorem (.v:line) | Source | One-line description | Status |
|---|---|---|---|
| allow_correct (:26) | tedex_util.adb:387-401 + ads:175-178 | allow = pass/key-composition and not disabled | [x] |
| reason_correct (:35) | tedex_util.adb:387-401 + ads:179-183 | reason cases exhaustive | [x] |
| manager_never_uses_key (:53) | server.adb:1060-1075 (manager leg password-only) | manager leg ignores key | [x] |
| key_alone_needs_device (:65) | tedex_util.adb:387-401 | key alone grants only on device leg | [x] |
| disabled_blocks_all (:76) | tedex_util.adb:387-401 | disabled never grants | [x] |
| disabled_distinct (:85) | tedex_util.adb:387-401 | stopped distinct from bad-password | [x] |
| manager_wrong_pass_is_badpass (:96) | tedex_util.adb:387-401 | manager wrong pass is Bad_Password | [x] |

## EchoModel.v (model: tedex_echo.adb, tests/echo_vectors.adb:26-54)

| Theorem (.v:line) | Source | One-line description | Status |
|---|---|---|---|
| aux_le_l (:20) | tedex_echo.adb:5-15 | prefix aux bounded by left length | [x] |
| common_prefix_le_l (:32) | tedex_echo.adb:5-15 | prefix <= left length | [x] |
| aux_le_r (:39) | tedex_echo.adb:5-15 | prefix aux bounded by right length | [x] |
| common_prefix_le_r (:51) | tedex_echo.adb:5-15 | prefix <= right length | [x] |
| common_prefix_empty_l (:58) | tedex_echo.adb:5-15 | empty left gives 0 | [x] |
| common_prefix_empty_r (:62) | tedex_echo.adb:5-15 | empty right gives 0 | [x] |
| bracket_pre_small (:96) | tedex_echo.adb:17-37 | short msg gives 0 | [x] |
| bracket_pre_values (:105) | tedex_echo.adb:17-37 | result in {0,8,9} | [x] |
| Decide/base_of/ks/fps/fms (:117-132) | echo_vectors.adb:26-54 | 4-branch decision core transcription | [x] |
| decide_k0 (:138) | echo_vectors.adb:41-43 | K=0 -> show Msg whole, keep Pending | [x] |
| decide_silent (:142) | echo_vectors.adb:44-46 | FM & not FP -> silent, Pending advances by K | [x] |
| decide_remainder (:151) | echo_vectors.adb:47-49 | FP -> show Head&Tail(Base,K), drop Pending | [x] |
| decide_failopen (:162) | echo_vectors.adb:50-52 | partial-both -> show Msg WHOLE, drop Pending | [x] |
| decide_exhaustive (:173) | echo_vectors.adb:41-53 | four cases exhaustive/disjoint | [x] |
| fail_open_documented (:203) | echo_vectors.adb:50-52 | partial-overlap shows whole (fail-open) | [x] |
| backoff_range (:217) | tedex_protocol.adb:420-432 | backoff in 5..60 | [x] |
| backoff_exact (:223) | tedex_protocol.adb:420-432 | exact table 5/10/20/40/60 | [x] |
| jittered_range (:232) | tedex_util.adb:403-406 | jittered in 5..65 | [x] |
| jittered_decomp (:240) | tedex_util.adb:403-406 | jitter = base + rand mod 6 | [x] |

Need.txt item 3 (DONE 2026-10-10): the 4-branch Decide composition is
now a Gallina DEFINITION + 5 machine-checked theorems (decide_k0, decide_silent,
decide_remainder, decide_failopen, decide_exhaustive; 0 admit, Print
Assumptions "Closed under the global context"). So the composition is no
longer oracle-only — Coq covers it too (in addition to the oracle-vs-Ada
differential test, need.txt item 9). Transcribed on lists of ascii mirroring
echo_vectors.adb:26-54: Base=(Pre=0 ? Msg : skipn Pre Msg), K=common_prefix,
FP=length-pending<=?K, FM=length-base<=?K; the four else-if branches each map
to a decide_* theorem. Ada string 1-indexing handled by firstn/skipn.

## AttachHandoff.v (model: server.adb:724-848 + tedex_util.ads:204-214)

| Theorem (.v:line) | Source | One-line description | Status |
|---|---|---|---|
| take_needs_idle (:57) | server.adb:195-216 (Take_Dev) | take needs idle membership | [x] |
| take_removes (:65) | server.adb:195-216 | take removes from idle | [x] |
| no_double_take (:82) | server.adb:195-216 | no double take | [x] |
| stale_resize_blocked (:101) | tedex_util.ads:204-214 | stale resize blocked | [x] |
| oob_dims_blocked (:111) | tedex_util.ads:204-214 | out-of-range dims blocked | [x] |
| silent_threshold (:125) | client.adb:1724-1777 (Silent>=4) | silence 3 alive / 4 dead | [x] |
| silent_mono (:129) | client.adb:1724-1777 | silence monotone | [x] |

Handoff sequence itself: server.adb:741-750 Wait_Handler_Gone,
765-814 Do_Attach_Splice (SHELL_START/ATTACHED), 834-846 attach gate.

## SysModel.v (specs of documented C contracts, NOT code proofs)

| Theorem (.v:line) | Source | One-line description | Status |
|---|---|---|---|
| fread_codes_disjoint (:36) | tlswrap.c:371-414 | fd_read codes disjoint | [x] |
| eio_race_sound (:56) | tlswrap.c:277-307 | EIO rule two-valued | [x] |
| eio_alive_means_not_dead (:60) | tlswrap.c:299-304 | alive EIO means race, not death | [x] |
| tls_rejects_empty_host (:70) | tlswrap.c:66-70 | empty host rejected | [x] |
| tls_rejects_bad_port (:74) | tlswrap.c:66-70 | bad ports rejected | [x] |
| tls_accepts_good (:81) | tlswrap.c:66-70 | good host:port accepted | [x] |
| pty_size_fail_closed (:89) | tlswrap.c:312-325 | bad sizes fail closed | [x] |
| term_size_fallback (:100) | tlswrap.c:330-346 | 0x0 falls back to 80x24 | [x] |
| write_all_terminates (:111) | termhelp.c:17-32 | step count is n-off | [x] |
| write_all_strict (:115) | termhelp.c:17-32 | successful write strictly progresses | [x] |
| write_empty_ok (:124) | termhelp.c:17-32 | empty write is 0 steps | [x] |
| kill_closes_last (:135) | tlswrap.c:130-151 | kill trace ends with close | [x] |
| kill_terms_first (:138) | tlswrap.c:130-151 | kill trace starts with TERM | [x] |

## VST bodies (CompCert Clight semantics, syscalls axiomatized)

| Lemma (.v:line) | Clight | C source | Status |
|---|---|---|---|
| body_tls_close_fd (verif_close_fd.v:44) | clight/tlswrap.v:1283 | tlswrap.c:153-156 | [x] |
| body_term_read_chunk (verif_read_chunk.v:141) | clight/termhelp.v:905 | termhelp.c:184-197 | [x] |
| body_fd_read_timeout (verif_fd_read.v:139) | clight/tlswrap.v:2185 | tlswrap.c:371-396 | [x] |
| body_write_all (verif_write_all.v:77) | clight/termhelp.v:169 | termhelp.c:17-32 | [x] |
| body_fd_write_all (verif_fd_write_all.v:139) | clight/tlswrap.v:2300 | tlswrap.c:399-414 | [x] |
| body_pty_poll (verif_pty_poll.v:147) | clight/tlswrap.v:1767 | tlswrap.c:277-307 | [x] |
| body_term_read_line (verif_term_read_line.v:99) | clight/termhelp.v:599 | termhelp.c:112-151 | [x] Qed (outer break-Post False: outer Sloop has no Sbreak, grep-verified; dead exit ex falso) |
| body_fd_wait_read (verif_fd_wait_read.v:98) | clight/tlswrap.v:586 | tlswrap.c:20-35 | [x] Qed (poll/errno AXIOMS; ternary timeout via EX-post; revents read + EIO-mask; 0 admit, .vo 311K) |

## VST specs (vst_specs.v, specs only — no bodies)

| Spec | Pattern source | Covers | Status |
|---|---|---|---|
| poll2_spec | verif_fd_read.v poll_spec | fds_wait_read (tlswrap.c:38-62) | [x] spec |
| waitpid_spec | new (return-code contract) | WNOHANG users: pty_poll EIO race (tlswrap.c:299-304), tls_reap/tls_kill/pty_close loops | [x] spec |
| recv_spec | verif_read_chunk.v read_spec | term_attach recv (termhelp.c:91) | [x] spec |
| time_spec/usleep_spec/kill_spec | pure/return-code contracts | last_traffic (termhelp.c:54), reap/kill backoff, SIGTERM/SIGKILL | [x] spec |
| ioctl/fork/exec/dup2/pipe | — | OUT OF SCOPE, no fake specs (need.txt 6,7,8) | [x] scoped |

HONEST SCOPE (need.txt item 2, 2026-10-10; UPDATED 2026-10-11: fds_wait_read
body IS Qed now — verif_fds_wait_read.v, .vo 626K, classical-only; the old
EX+struct worry below is SUPERSEDED, kept for the record): fd_wait_read body
IS Qed (see bodies table). Prior note (now historical): the 2-element array
had forced EX posts that hit the RESUME_NOTES lesson-12 EX+struct assert
quirk. Resolution (lessons 15-22): ascribed Definition POSTs + poll PRE
data_at_/POST concrete-short-range + ghost-only errno + opt-cell; no step
weakened. `poll2_spec` remains in vst_specs.v as the spec-level twin.

## Differential testing (difftest/, need.txt item 9)

| Check | Evidence | Status |
|---|---|---|
| oracle-vs-Ada 15 Decide vectors | difftest/RESULTS.md 15/15 | [x] |
| oracle-vs-Ada 5 Bracket_Pre checks | difftest/RESULTS.md 5/5 | [x] |
| Coq-vs-oracle 2000 fuzz pairs + auth/backoff | difftest/RESULTS.md 4128/4128 | [x] |

Second reader (independent, not the proof author): verify each row by
opening both sides. Display layer (Tedex_Echo) stays tested-only per
need.txt item 11 (fail-open timing policy, 15 Ada vectors + difftest).

## Addendum 2026-10-10: ghost-errno retrofit (need.txt item 1, snapshot 22/)

VST funspecs gained ghost parameters; C source mapping UNCHANGED (same .c lines,
same Clight). Delta per spec family (all 7 verif_*.v):
- `poll/read/write/close/waitpid` specs: `WITH ... gn g_old`, PRE `ghost_var Tsh
  g_old gn`, POST `EX e_new` + `ghost_var Tsh e_new gn` (syscall overwrites errno).
- `__errno_location` specs: `WITH ... gn g`, POST `EX p` only with
  `data_at ... (Vint (Int.repr g)) p` (read returns last-written value, by construction).
- Function specs: `WITH ... gn e0`, POST `EX e_fin` + `ghost_var Tsh e_fin gn`.
- Proofs thread the ghost linearly (loop Invs carry `EX g`); proved property
  extends to errno value-identity. HONEST SCOPE: value-identity machine-checked;
  address-aliasing (one real TLS slot, cells fresh-per-call) stays a sound
  over-approximation, not claimed proved.
| Check | Evidence | Status |
|---|---|---|
| 7/7 bodies Qed, 0 Admitted/admit, coqc EXIT 0 | .vo 78K/347K/793K/237K/265K/1.5M/912K | [x] |
| Print Assumptions all 7 classical-only | coqc logs (rerun per VERIFICATION.txt) | [x] |

## Addendum 2026-10-10 (need.txt items 2,3,4): fd_wait_read body + Decide composition + re-verification

Second-reader pass done 2026-10-10 against /home/jovyan/22/src (NOT the
same tree the first 19/ table was checked on). Each new row below was
re-opened on BOTH sides (.v and .adb/.c) with fresh eyes:

- body_fd_wait_read (verif_fd_wait_read.v:98 <-> clight/tlswrap.v:586 <->
  src/tlswrap.c:20-35). Re-checked: p.fd=fd / p.events=POLLIN / p.revents=0,
  poll(&p,1, timeout_ms<0?-1:timeout_ms), r<0 -> errno==EINTR?-2:-1,
  r==0 -> 0, p.revents&(POLLERR|POLLNVAL) -> -1, else 1. Constants POLLERR|POLLNVAL
  = 8|32 = 40, EINTR=4, POLLIN=1 confirmed. Qed, 0 admit, Print Assumptions
  classical-only (ClassicalDedekindReals/prop_ext/functional_ext/classic/
  Extensionality_Ensembles), .vo 311K. | [x] |
- Decide composition (EchoModel.v:117-197 <-> tests/echo_vectors.adb:26-54).
  Re-checked branch-by-branch: Base=(Pre=0 ? Msg : skipn Pre Msg); FP/FM via
  Nat.leb on lengths; Branch1 (msg,pending); Branch2 ([],skipn K pending);
  Branch3 (firstn Pre msg ++ skipn K base, []); Branch4 fail-open (msg,[]).
  5 theorems Qed, decide_exhaustive "Closed under the global context" (0
  axioms). | [x] |

HONEST LIMIT on independence (need.txt item 4): this pass was performed by
the same agent that authored the proofs, so it is a fresh-eyes re-transcription
audit, NOT a sign-off by an external reviewer physically separate from the
author. Recommend one more independent human read of the two rows above
before external circulation. No transcription discrepancy found in this pass.
| fds_wait_read body | PROVEN 2026-10-11, see addendum below (was scoped-out) | [x] |

## Addendum 2026-10-11 (last.txt item 2 DONE): fds_wait_read body

Second-reader re-transcription of verif_fds_wait_read.v against
clight/tlswrap.v (f_fds_wait_read) <-> src/tlswrap.c:38-62, both sides
re-opened with fresh eyes:

- body_fds_wait_read (verif_fds_wait_read.v:129 <-> clight/tlswrap.v:658 <->
  src/tlswrap.c:38-62). Re-checked: out=0; p[0]=(fd1,POLLIN,0);
  p[1]=(fd2,POLLIN,0); poll(p,2, timeout_ms<0?-1:timeout_ms); r<0 ->
  errno==EINTR?-2:-1; r==0 -> 0; p[0].revents&(POLLIN|POLLHUP)(1|16) ->
  out|=1 elif &(POLLERR|POLLNVAL)(8|32) -> -1; same for p[1] with out|=2;
  out==0?0:out. Constants POLLIN=1, POLLHUP=16, POLLERR=8, POLLNVAL=32,
  EINTR=4 confirmed against headers. Qed, 0 admit/Admitted, Print
  Assumptions classical-only, .vo 626K. | [x] |
- Unlocking vs the earlier attempt (honestly recorded): the old
  "EX+array" failure was an elaboration-ordering artifact of inline EX
  over concrete struct tuples in tactic position, NOT a logic limit --
  ascribed Definitions elaborate the same content fine (probe-verified);
  data_at_ is used only where values are never re-read (JOINs before
  poll re-concretizes); poll POST keeps the array concrete with
  short-range revents so Oand conditions evaluate and tc_val closes;
  the errno cell is carried (never dropped to emp). No proof step was
  weakened to make it pass. | [x] |

## Blocker record 2026-10-11 (last.txt item 1): term_attach prologue

- f_term_attach (clight/termhelp.v:220 <-> src/termhelp.c:34) contains
  [raw = oldt] (whole-struct termios copy). VST 2.17 [check_normalized]
  (floyd/forward.v:4316, DE_copy/By_copy) rejects the function upfront at
  [start_function] (level 98/99); stepping it directly fails identically
  (level 97: no assignment to struct/union lvalues); repo-wide grep finds
  no struct-copy rule or test anywhere in VST. VST itself suggests
  field-by-field copy, which would MODIFY the C source -- refused
  (verification must cover the real code). The copy is semantically
  irrelevant (post-dominated by may-clobber cfmakeraw), yet VST must step
  every statement: no sound skip exists. NO fake proof produced; the loop
  behind it was never reached by the prover. Status: toolchain-blocked,
  same category as ioctl/fork-exec. | [x] scoped |
