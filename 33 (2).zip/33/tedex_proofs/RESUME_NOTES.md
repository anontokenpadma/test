# Tedex Rocq/VST verification — resume notes (19/: need.txt 2026-10-09; 18/ DONE giữ nguyên)

## Environment (verified working)
- Switch `rocq-9.2` (OCaml 5.2.1): Rocq 9.2.0 + CompCert 3.18 + coq-vst 2.17 + Flocq 4.2.2.
- Rebuild note: Flocq/VST MUST be built with system gcc (`CC=/usr/bin/gcc`,
  `/usr/bin` before `/opt/conda/bin` in PATH, unset LIBRARY_PATH/CPATH);
  conda `ld`+sysroot breaks Flocq `remake` with `_dl_vsym@GLIBC_PRIVATE`.
- `opam install coq-vst.2.17 -y -j4 --no-depexts` (needs `coq-released` repo
  + conda `clang` for conf-clang).

## File inventory (17/tedex_proofs; HOÀN TẤT rerun 2026-10-08 20:30 UTC all EXIT 0 warnings-only)
| File | Status |
|---|---|
| AuthVerdict.v (.vo 25K) | PROVED (7 thms, Qed) |
| EchoModel.v (.vo 28K) | PROVED (13 thms, Qed) |
| AttachHandoff.v (.vo 27K) | PROVED (7 thms, Qed) |
| SysModel.v (.vo 33K) | PROVED (13 thms, Qed) |
| vst_specs.v (.vo) | skeleton, typechecks, documentation only |
| verif_close_fd.v (.vo 72K) | PROVED end-to-end (Qed): tls_close_fd |
| verif_read_chunk.v (.vo 324K) | PROVED end-to-end (Qed, 0 admit tactic): term_read_chunk — DONE 2026-10-07, stale header fixed 2026-10-08 |
| verif_write_all.v (.vo 214K) | PROVED end-to-end (Qed, 0 admit tactic, helper+main): write_all loop — DONE 2026-10-08 20:28 UTC (was 2 admits + Admitted) |
| verif_fd_read.v (.vo 743K) | PROVED end-to-end (Qed, 0 admit tactic, helper+main): fd_read_timeout — DONE 2026-10-08 14:03 (was partial 63K) |
| verif_fd_write_all.v (.vo 243K) | PROVED end-to-end (Qed, 0 admit tactic, 2 helpers+main): fd_write_all loop — DONE 2026-10-09 (need.txt item 3) |
| verif_pty_poll.v (.vo 1.4M) | PROVED end-to-end (Qed, 0 admit tactic, helper+main): pty_poll EIO race — DONE 2026-10-09 (need.txt item 4) |
| verif_term_read_line.v (.vo 832K) | PROVED end-to-end (Qed, 0 admit tactic, helper+main): term_read_line — DONE 2026-10-10 (was PARTIAL 2 admits; outer break-Post False, sound: no Sbreak in outer Sloop) |
| vst_specs.v (.vo 54K) | SPECS (need.txt item 2): poll2/waitpid/recv/time/usleep/kill + opt_data, coqc EXIT 0; ioctl/fork/exec out of scope |
| ARCH_B_THREAT.md | Reconstructed 2026-10-07: kiến trúc + v11 Trim/Count_Attached/Last_Dropped + BUG + threat model |
| test.v / smoke.v (.vo) | coq proof test PASS + VST Require smoke PASS |
| clight/termhelp.{c,v}, tlswrap.{c,v} | clightgen -normalize exit 0 both, fresh .vo 109K/187K 2026-10-08 |
| work17/proofs/struct_ex_repro.v etc. | MINIMAL REPROS 2026-10-08 for toolchain blocker EX+struct (see below), not proofs |
| difftest/ (oracle.py, vectors.py, run_diff.py, RESULTS.md) | need.txt item 9: oracle-vs-Ada 20/20, Coq-vs-oracle 4128/4128 — DONE 2026-10-09 |
| AUDIT_TRANSCRIPTION.md | need.txt item 10: 40 Gallina + 6 VST + specs + difftest mapping — DONE 2026-10-09 |
| ../MANIFEST.sha256, ../VERIFICATION.txt | need.txt items 12/13: 129 files sha256sum -c PASS + toolchain/prover record — DONE 2026-10-09 |

## 2026-10-09 need.txt pass (19/; subagents rate-limited nên làm trực tiếp)

- Item 3 DONE: verif_fd_write_all.v Qed (0 admit, .vo 243K) — tint twin của
  write_all; riêng phần tint: Int.unsigned_repr cho tuint->tulong,
  tc-goal cho off+=(int)w (Z_mod_modulus + roundtrips), Int.lt + break
  tự khép qua entailer!.
- Item 4 DONE: verif_pty_poll.v Qed (0 admit, .vo 1.4M; Print Assumptions
  chỉ classical chuẩn) — poll s<0/s==0 + read k>0 (Ogt hyp đảo vế) +
  JOIN t6/t4 (opt) + EIO JOIN t10/o4 + waitpid_spec WNOHANG + fwd_skip cho
  Sskip-to-explicit-Post + outer k<=0 hyp tồn tại qua mọi join (không cần
  PROP tracking); o1 doubling (poll-cell/read-cell#1, paths exclusive).
- Item 9 DONE: difftime difftest/RESULTS.md (xem § File inventory + F).
- Item 2 DONE: vst_specs.v specs thật, coqc EXIT 0.
- Item 5 DONE 2026-10-10: verif_term_read_line.v Qed (0 admit, .vo 832K;
  helper+main; Print Assumptions chỉ classical chuẩn; was PARTIAL 2 admits):
  poll_wait(-1)/read1(Byte-range)/errno specs + entry + poll/read errno
  paths + k==0 + store upd_Znth + store-JOIN + đuôi \n/inner-discard/returns
  + afterloop chết (outer break-Post False, sound vì outer Sloop không có
  Sbreak — grep kiểm chứng; ex falso qua Intro_prop + contradiction).
  term_attach CHƯA LÀM (đa-ngày).
- Item 1 DONE 2026-10-10 (snapshot 22/): ghost errno retrofit value-only trên CẢ 7
  file VST (ghost_var Tsh threaded linearly; syscalls OVERWRITE sang EX e_new;
  errno_location TAKE g RETURN đúng g; loops mang EX g; waitpid-region JOINs mang
  EX ew; xem anontoken §G). 7/7 Qed, 0 Admitted/admit, Assumptions chỉ classical,
  coqc TẤT CẢ EXIT 0. .vo: 78K/347K/793K/237K/265K/1.5M/912K.
- Item 10/12 DONE: AUDIT_TRANSCRIPTION.md, MANIFEST.sha256 (PASS),
  VERIFICATION.txt.

## 2026-10-08 20:30 UTC HOÀN TẤT (write_all Qed + full rerun EXIT 0; giữ nguyên từ 18/)
- write_all (verif_write_all.v, .vo 214K, Qed helper+main, 0 admit): whole-buffer offset write spec (WITH fd,b,off,n,sh,pre; PARAMS offset_val off b + Vlong (n-off); sound via split2_data_at_Tarray_tschar, write only reads) + readable buffer-carrying errno spec + TT in Inv/continue/break/POST (absorbs unbounded EINTR cells; P|--TT, TT*TT=TT); loop entry Exists 0; loop test forward_if (break off=n via Int64.lt=false + zlt + roundtrip + lia; body via forward_call (fd,b,off,n,sh,pre) + entailer! arg matching); w<0 errno (forward_call (sh,b,n,pre) + load + forward_if e==4: continue Exists off / return -1 Exists -1, entailer! TT absorption); w==0 return -1; w>0 off+=w Exists (off+w) + Hr/Hz + lia; after-loop Intros off + forward + Exists 0.
- fd_read (verif_fd_read.v, .vo 743K, Qed helper+main, 0 admit): as before (poll s<0/s==0 + read k<0 3 sites + k>=0) + data_at_ workaround for EX+struct.
- Full rerun 2026-10-08 20:30 UTC: test/smoke/Auth/Echo/Attach/Sys/vst_specs/close_fd/read_chunk/fd_read/write_all ALL coqc EXIT 0 warnings-only (Hint norm, deprecated From Coq/Stdlib); grep confirms Qed = Auth/Echo/Attach/Sys/close_fd/read_chunk/fd_read/write_all (+helpers), Admitted = 0, admit-tactic = 0 (vst_specs skeleton 0/0 by design).

## Lessons (verified by compiling probe; 1-8 from 2026-10-07 read_chunk, 9-14 from 2026-10-08 fd_read/write_all)
1. Specs + Gprog typecheck; `with_library` accepts all specs.
2. `forward_if` (max<=0) works; then-branch CLOSED by entailer!.
3. `forward_call (0,buf,max,sh,pre)` for `_read` works (explicit witness).
4. Buffer-carrying errno spec (WITH sh,buf,max,post) beats emp-PRE (frame matches directly).
5. Bare `forward_if` fails on `Ssequence(Sifthenelse...)`; workaround: manual
   `repeat (apply -> semax_seq_skip). repeat (apply seq_assoc1; ...)`.
6. `repeat match Hlt: context[...] |- _ => rewrite Hr in Hlt` hits Hr/Hz itself —
   must match specific `Hlt: signed(ret)<signed(0)` then `rewrite Hr,Hz in Hlt`.
7. `rep_lia` fails Cannot find witness → use signed_repr_roundtrip + explicit
   Int64/Int constant reflexivity before lia.
8. VST `Exists _` needs explicit witnesses.
9. Loop with Scontinue/Sreturn → `forward_loop Inv continue:PreInc break:Post` (not `forward_while`); entry needs `Exists 0. entailer!.` (Inv EX off, not just entailer!).
10. lvar _p + poll struct in concrete Post (no EX) parses; `pose E1/P1` before `forward_if Post` mentioning them avoids e1 not found (e1/p1 from Intros+destruct persist after `forward` Sset, but Post must mention posed copies to be safe across explicit Post + entailer!).
11. `entailer!.` closes poll -2/-1/-3 with no extra splits (unlike read_chunk k>=0 which needed splits for A/\B/\C); read k>=0 still needs Hr/Hz + splits (reused verbatim from read_chunk with n/max + pre/post adjusted).
12. EX + struct `data_at`/`field_at` (Tstruct _pollfd, any share Tsh/sh, with/without lvar/opt) fails even in isolation in Rocq 9.2 + VST 2.17 here (`environ->mpred` vs `mpred` for EX body, plus `reptype` for freeze struct vs freeze tarray OK); EX without struct (tarray/tint/opt_data) and struct without EX (concrete Posts) both parse — minimal repros struct_ex_repro.v etc. in work17/proofs. fd_read k<0 worked around with `data_at_` (any) for poll struct in EX Posts (weakening concrete→any, sound: poll value irrelevant after poll).
13. write_all loop: `forward_if.` (no Post) splits loop test (body vs break) when body has Scontinue/Sreturn; write `forward_call (fd,b,off,n,sh,pre)` + `entailer!.` proves arg matching (`offset_val` + `Vlong (n-off)`) automatically; errno `forward_call (sh,b,n,pre)` (no PARAMS) needs NO `entailer!.` after (first goal is semax, not entailment); `forward. Exists off/(-1)/(off+w). entailer!.` closes continue/return via TT absorption automatically (no manual TT lemmas); `Int64.lt=false` → `unfold Int64.lt; destruct (zlt ...)` then roundtrip + lia (need `unfold min/max` before lia for roundtrip side goals); after-loop needs `Intros off.` before `forward` (PRE has EX off).
14. `n` disappears after `Exists/entailer!` (rewritten to `Zlength pre`); avoid matching `n` literally afterwards — use `?a/?b` wildcards and `Zlength pre`.
15. Ghost POST intros (2026-10-10): POST with 3 EX needs `Intros v. destruct v as [[a b] c].` + 3 `change (fst/snd ...)` (direct `Intros a b c` fails); 2 EX needs `destruct [a b]` + 2 changes; errno POST with 1 EX takes a single `Intros p` (no destruct). Every explicit `forward_if` POST SEP must carry the current `ghost_var Tsh <g> gn`; loop Inv/continue/break need `EX g` + ghost; `forward_call` witnesses gain `gn` + current ghost; final `Exists` gains the final ghost.
16. `ghost_var` is exclusive: a call must take the CURRENT ghost (e.g. read1 takes poll's `epoll`, not loop-entry `g`) — a stale ghost makes the `|-- ghost_var` side-goal unprovable (caught by printing the goal).

## Next (HOÀN TẤT anontoken scope; future work ngoài scope, trung thực)
- anontoken scope DONE: Auth/Echo/Attach/Sys + close_fd/read_chunk/fd_read/write_all all Qed, 0 Admitted.
- Ngoài scope (chưa làm, nói rõ để không ngộ nhận): tlswrap `fd_write_all` (int version, tương tự write_all nhưng chưa spec/proof), `term_attach` poll loop, `tls_open` fork/exec, `pty_spawn_bash`, `pty_poll` EIO/waitpid race, `tls_kill/pty_close` blocking wait — cần OS process model VST không có (xem SysModel.v + vst_specs.v OUT-of-scope).

## Next concrete step (HOÀN TẤT — không còn bước chứng minh nào trong scope)
- Scope anontoken DONE 2026-10-08 20:30 UTC (xem inventory + § progress trên).
- Ghi chú kỹ thuật cũ (đã giải quyết, giữ để tra cứu): fd_read k<0 EX+struct parsing bug đã workaround bằng `data_at_` (any) cho poll struct trong EX Posts; write_all unbounded EINTR đã giải quyết bằng TT (không cần EX l:list); field_at cho 3 Sassign đã xong via `forward`.

## Honest scope reminders
- Gallina models prove MODELS transcribed from Ada/C, not the binaries.
- VST specs for read/write/poll/errno/close are AXIOMS over syscalls.
- The errno reads now PROVE value-identity (need.txt item 1, DONE 2026-10-10):
  every errno read returns the last syscall-written value (ghost_var Tsh threaded
  linearly; machine-checked in all 7 VST bodies). Cells stay fresh-per-call
  (opt_data) — address-aliasing (one real TLS slot) remains a sound
  over-approximation for memory safety, honestly documented, NOT claimed proved.
  Write_all unbounded
  EINTR continues absorbed into TT (POST có TT, honestly documented in
  verif_write_all.v header); straight-line read_chunk/fd_read track exactly
  with opt_data o1/o2/o3.
- SPARK remains the authority for the Ada code.
- 2026-10-08 20:30 UTC DONE honest: Qed = Auth/Echo/Attach/Sys/close_fd/read_chunk/fd_read/write_all (+helpers); Admitted = 0; admit-tactic = 0; skeleton = vst_specs (0/0 by design); full coqc rerun all EXIT 0 warnings-only.

## 2026-10-10 pass (need.txt items 2,3,4,5,6 — after 22.zip)
- Item 2 PARTIAL: verif_fd_wait_read.v Qed (0 admit, .vo 318K, Print Assumptions
  classical-only) — tlswrap.c:20-35. Reuses fd_read pattern; the ternary
  `timeout_ms<0 ? -1 : timeout_ms` before poll uses the pty_poll idiom
  (sexp_skip/seq_assoc1 massage + forward_if EX tt with data_at_ struct;
  poll PRE data_at_ matches arg _t'1=EX tt; poll POST restores concrete
  short-range-bounded struct). Single-fd revents read + Oand(POLLERR|POLLNVAL)
  evaluable because rev' is bounded to short range.
  fds_wait_read body DONE 2026-10-11 (was honestly scoped-out; unlocked, see
  lesson 15-22 below): verif_fds_wait_read.v Qed, 0 admit/Admitted, .vo 626K,
  Print Assumptions classical-only. The old "EX+array" failure was an
  elaboration-ordering artifact of inline EX, not a logic limit.
- Item 3 DONE: EchoModel.v now models the Decide 4-branch composition
  (echo_vectors.adb:26-54) as Gallina Defs (base_of/ks/fps/fms/Decide) + 5
  theorems (decide_k0/decide_silent/decide_remainder/decide_failopen/
  decide_exhaustive). decide_exhaustive "Closed under the global context".
  EchoModel now 18 Qed (was 13). Gallina models total 45 (was 40).
- Item 4: AUDIT_TRANSCRIPTION.md addendum — fresh-eyes second-reader
  re-transcription pass on fd_wait_read + Decide vs src; no discrepancy. HONEST:
  same agent authored; external human sign-off still recommended.
- Item 5/6: vst_specs.v note (fds scope); VERIFICATION.txt + AUDIT +
  MANIFEST.sha256 regenerated (111 files, sha256sum -c PASS); .vo newer than .v;
  grep Admitted/admit = 0 outside comments; clight/*.c still == src/*.c;
  difftest rerun decide 15/15, bracket 5/5, coq-cmp 4128/4128, failures=0.
  Build: `./build.sh` -> ALL coqc EXIT 0.
- NOT started (still pending, honest): term_attach main loop (item 1,
  multi-day) — UPDATE 2026-10-11: investigated, TOOLCHAIN-BLOCKED (see
  ## 2026-10-11 pass below); loop plan retained for a future VST/source.

## 2026-10-11 pass (last.txt item 2 DONE; item 1 investigated+scoped)
- Item 2 DONE: verif_fds_wait_read.v Qed (0 admit/Admitted, .vo 626K, Print
  Assumptions classical-only) — tlswrap.c:38-62. Lessons 15-22 (all verified
  by compiling probes):
  15. EX-JOIN POSTs as ascribed Definitions dodge the Rocq 9.2 + VST 2.17
  EX+Tstruct elaboration trap (tactic-position inline EX over concrete structs
  defaults exp to mpred; the same content in a Definition elaborates; specs
  always elaborate via funspec guidance). Call as `forward_if (name args).`
  (period required on single-line calls); `unfold name. Intros x.` after
  (Intros cannot see through the Definition application).
  16. `forward_if_tac (...)` direct call behaves identically to the Notation
  when dispatch is suspect; used diagnostically (bisect Notation vs tac).
  17. Z arithmetic in Definition bodies/patterns needs explicit scope:
  `(out0 + 2)%Z`, else `+` parses as type-sum. Tactic witnesses get expected
  types from goals (write_all `off+w` fine); standalone patterns do not.
  18. Intros-extracted PROP hyps can be shadowed/consumed: use FRESH branch
  names ([HrA|HrB], [H1A|H1B], [H0A|H0B]); prefer rewrite over subst for
  grounded witnesses (subst fails when forward/Exists clears the var).
  Destruct-then-ground BEFORE entailer! (entailer! splits/consumes hyps);
  explicit per-leaf Exists for multi-valued returns (0/1/2/3 + bounds lia).
  19. poll PRE data_at_ / POST concrete (fd/ev preserved by reality, revents
  havoc'd short-range): sound over-approx pattern; short-range hyps let
  forward auto-close struct-field-load tc goals (tc_val tshort needs them;
  Int-range alone leaves `Znth` side goals that damage Delta under entailer!).
  20. errno ghost-only spec (WITH gn g, no buffer/struct): frame inference
  absorbs the array (fixes the classic emp-PRE frame stall the same way
  buffer-carrying specs do, with less text). NEVER drop cells to emp
  (`data_at |-- emp` unprovable); carry via opt_data in function POST.
  21. Array-struct field loads need short-range poll POSTs; loads from
  data_at_ give ground defaults (kills honest branch coverage — rejected);
  loads from EX-lists give opaque Znth terms (both branches live).
  22. Explicit-witness forward_call leaves trailing Sset unconsumed (bare
  forward_call eats Scall+Sset); add `forward.` (but NOT `entailer!.` after
  it unless a side goal is proven present — extra entailer! on semax errors).
- Item 1 (term_attach) BLOCKED, evidence (all reproducible):
  (a) [check_normalized] (floyd/forward.v:4316, DE_copy/By_copy) rejects
  f_term_attach upfront at [start_function] (level 98/99) for [raw = oldt].
  (b) Stepping it directly fails identically (level 97: no struct/union
  lvalue assignment); repo-wide grep: no struct-copy rule/step/test in VST.
  (c) A bypass-startup (copied start_function1 minus the one check line +
  [%logic] eta-fix so process_stackframe_of matches) was validated to run
  through sf3 — proving the ONLY hard wall is the copy step itself.
  (d) The copy is semantically irrelevant (post-dominated by may-clobber
  cfmakeraw) but VST must step every statement: no sound skip. VST-advised
  field-by-field copy requires MODIFYING termhelp.c — refused (verify real
  code; rebuild+retest+disclosure would be a product decision, not taken).
  Reusable artifacts: full attach spec set elaborates (opaque termios/signal
  at syscall-axiom status + read/recv/time/write_all-verbatim/errno-ghost/
  unified atom-passing poll); prologue verifies to the copy; validated
  startup technique above. Loop plan retained: branch-selected poll1/poll2
  (sd fixes nfds per path, no variable indexing), split2_data_at_Tarray_tschar
  (field_compat.v:527) for 4096-vs-k write_all calls, silence rule by Lia;
  honest limits (no liveness/termination/value-identity) stand.
- Item 1 deep-push 2026-10-11 (answering "code wrong vs not gotten there"):
  code is CORRECT (standard raw-mode idiom, CompCert-clean); the wall is
  prover machinery, mapped 4 levels deep, each verified by experiment:
  (a) [check_normalized] upfront ban (forward.v:4316) — bypassed by copying
  start_function1 minus the one check line (validated: runs through sf3 with
  an added [%logic] eta-fix so process_stackframe_of matches);
  (b) step ban (sc_set_load_store.v:2037 check_expression_by_value, level 97)
  — bypassed by copying store_tac minus the gatekeeper (the generic
  semax_store rule underneath is type-agnostic);
  (c) whole-struct field unification stalls (level 993): search_field_at_
  cannot unify whole-struct (nil-gfs) accesses for EITHER data_at_ or
  EX-tuple data_at (both tried); the advised v=field_address equation does
  NOT hold by computation (field_compatible_dec stuck on opaque lvar).
  (d) manual mapsto plumbing: the key bridge (data_at_ = field_compatible &&
  mapsto_, data_at_rec_lemmas.v:384) sits in a COMMENTED-OUT lemma, and its
  precondition (type_is_by_value) FAILS for structs (proven: reflexivity
  fails on Tstruct _termios) — killing the easy conversion; repo-wide grep
  finds no struct-assign lemma/step/test anywhere in VST.
  Remaining untried (costed honestly): hand-rolled field-level struct copy
  via mapsto plumbing (3-6h for ONE semantically-irrelevant statement, ~30%
  odds) + multi-day loop. Not "more of the same effort": missing machinery
  at check, step-tactic, unifier, and by_value-lemma levels. Blocker stands.
