#!/bin/bash
# Tedex full verification build — mirrors VERIFICATION.txt.
# Honors item 6: every .vo newer than .v, grep Admitted/admit = 0.
set -u
export PATH="$HOME/bin:$PATH"
eval $(opam env --switch=rocq-9.2 2>/dev/null) || { echo "opam env FAILED"; exit 2; }
cd "$(dirname "$0")"   # tedex_proofs/

fail=0
run() {
  echo ">>> coqc $*"
  if ! out=$(coqc -q "$@" 2>&1); then
    echo "$out" | tail -40
    echo "!!! coqc FAILED (exit $?) on: $*"
    fail=1
    return 1
  else
    echo "$out" | grep -i "error\|warning" | grep -vi "deprecated\|Hint Db\|hint db\|Stdlib" | head -5
  fi
  return 0
}

echo "===== GALLINA MODELS + smoke ====="
run test.v || true
run smoke.v || true
run AuthVerdict.v || true
run EchoModel.v || true
run AttachHandoff.v || true
run SysModel.v || true

echo "===== CLIGHT (needs -Q clight Clight) ====="
run -Q clight Clight clight/termhelp.v || true
run -Q clight Clight clight/tlswrap.v || true

echo "===== VST SPECS + verif_* (all need -Q clight Clight) ====="
run -Q clight Clight vst_specs.v || true
run -Q clight Clight verif_close_fd.v || true
run -Q clight Clight verif_read_chunk.v || true
run -Q clight Clight verif_write_all.v || true
run -Q clight Clight verif_fd_write_all.v || true
run -Q clight Clight verif_fd_read.v || true
run -Q clight Clight verif_pty_poll.v || true
run -Q clight Clight verif_term_read_line.v || true
run -Q clight Clight verif_fd_wait_read.v || true
run -Q clight Clight verif_fds_wait_read.v || true
# New proofs (if present) are appended below by regenerating this file.

echo "===== SUMMARY ====="
if [ "$fail" = 0 ]; then echo "ALL coqc EXIT 0"; else echo "SOME coqc FAILED"; fi

echo "===== grep Admitted / admit-tactic (item 6) ====="
echo -n "Admitted (real tactics, excl. header comments): "; grep -rn "^[[:space:]]*Admitted\." --include=*.v . | wc -l
echo -n "admit tactic (real, excl. header comments): "; grep -rn "^[[:space:]]*admit\." --include=*.v . | wc -l

exit $fail
