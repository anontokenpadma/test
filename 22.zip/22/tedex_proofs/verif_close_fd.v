(* VST verification of tls_close_fd (tlswrap.c) — GHOST RETROFIT DONE 2026-10-10
     int tls_close_fd (int fd) { return close (fd); }
   (need.txt item 1, value-only ghost discipline: Qed, coqc EXIT 0, 0 admit/Admitted;
   close overwrites ghost to EX e_new — sound over-approximation since real
   close(2) may set errno on failure.) *)

Require Import VST.floyd.proofauto.
Require Import VST.concurrency.ghosts.
Require Import Clight.tlswrap.

Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.

(* Axiom: close(2). GHOST: overwrites TLS-errno ghost to EX e_new (sound
over-approximation: real close may set errno on failure). *)
Definition close_spec : ident * funspec :=
  DECLARE _close
  WITH fd : Z, gn : gname, g_old : Z
  PRE [ tint ]
    PROP (0 <= fd <= Int.max_signed)
    PARAMS (Vint (Int.repr fd))
    GLOBALS ()
    SEP (ghost_var Tsh g_old gn)
  POST [ tint ]
    EX r : Z, EX e_new : Z,
    PROP (Int.min_signed <= r <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr r)))
    SEP (ghost_var Tsh e_new gn).

Definition tls_close_fd_spec : ident * funspec :=
  DECLARE _tls_close_fd
  WITH fd : Z, gn : gname, e0 : Z
  PRE [ tint ]
    PROP (0 <= fd <= Int.max_signed)
    PARAMS (Vint (Int.repr fd))
    GLOBALS ()
    SEP (ghost_var Tsh e0 gn)
  POST [ tint ]
    EX r : Z, EX e_fin : Z,
    PROP (Int.min_signed <= r <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr r)))
    SEP (ghost_var Tsh e_fin gn).

Definition Gprog : funspecs :=
  ltac:(with_library prog [close_spec; tls_close_fd_spec]).

Lemma body_tls_close_fd :
  semax_body Vprog Gprog f_tls_close_fd tls_close_fd_spec.
Proof.
  start_function.
  forward_call (fd, gn, e0).
  Intros v. destruct v as [r enew].
  change (fst (r, enew)) with r in *.
  change (snd (r, enew)) with enew in *.
  forward.
  Exists r enew.
  entailer!.
Qed.
