(* VST verification of term_read_chunk (termhelp.c) — GHOST RETROFIT DONE 2026-10-10
   (need.txt item 1, value-only ghost discipline: Qed, coqc EXIT 0, 0 admit/Admitted).
   Design: buffer-carrying errno spec + ghost_var Tsh (TLS errno value)
   threaded linearly through every spec. read/write syscalls OVERWRITE
   the ghost to EX e_new on all paths; each __errno_location call TAKES
   the current ghost g and RETURNS the same g (PROP e = g), so all three
   reads provably return the last-written value (need.txt item 1).
   Cells stay fresh-per-call (opt_data, as before); values are linked.
   Syscall model: read(2) + __errno_location are AXIOMS (external specs).
   EAGAIN=11, EWOULDBLOCK=11, EINTR=4 (Linux x86_64, matches Clight).
   PRE allows 0 <= max (max=0: empty buffer, returns -1 via then-branch).
   Negative max is EXCLUDED from the spec (vacuous); the Ada caller
   always passes 1024. *)

Require Import VST.floyd.proofauto.
Require Import VST.concurrency.ghosts.
Require Import Clight.termhelp.

Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.

(* Helper: Int64 signed/repr roundtrip on the in-range domain.
   Needed because VST's rep_lia fails on these goals in this version
   ("Cannot find witness" even in isolation), so we do it by hand. *)
Lemma signed_repr_roundtrip : forall z : Z,
  Int64.min_signed <= z <= Int64.max_signed ->
  Int64.signed (Int64.repr z) = z.
Proof.
  intros z [Hlo Hhi].
  assert (Hmin : Int64.min_signed = -9223372036854775808) by reflexivity.
  assert (Hmax : Int64.max_signed = 9223372036854775807) by reflexivity.
  rewrite Hmin in Hlo. rewrite Hmax in Hhi.
  rewrite Int64.signed_repr_eq.
  assert (HM : Int64.modulus = 18446744073709551616) by reflexivity.
  assert (HH : Int64.half_modulus = 9223372036854775808) by reflexivity.
  rewrite HM, HH.
  destruct (Z_lt_ge_dec z 0) as [Hneg|Hnn].
  - assert (Hm : z mod 18446744073709551616
                 = z + 18446744073709551616).
    { assert (HzM : 0 <= z + 18446744073709551616
                       < 18446744073709551616) by lia.
      assert (He : (z + 1 * 18446744073709551616) mod 18446744073709551616
                   = z mod 18446744073709551616).
      { apply Z.mod_add. lia. }
      assert (He2 : z + 1 * 18446744073709551616
                    = z + 18446744073709551616) by lia.
      rewrite He2 in He.
      rewrite <- He.
      rewrite (Z.mod_small _ _ HzM). reflexivity. }
    rewrite Hm.
    destruct (zlt (z + 18446744073709551616) 9223372036854775808)
      as [Hc|Hc].
    + exfalso. lia.
    + lia.
  - assert (Hm0 : z mod 18446744073709551616 = z).
    { apply Z.mod_small. lia. }
    rewrite Hm0.
    destruct (zlt z 9223372036854775808) as [Hc|Hc].
    + reflexivity.
    + exfalso. lia.
Qed.

(* Axiom: read(fd, buf, n). Nondeterministic POSIX behaviour.
   GHOST: overwrites the TLS-errno ghost to EX e_new on every path
   (sound over-approximation: real errno after read is either untouched
   or a fresh error — arbitrary covers both; the value is never read
   before the next syscall overwrite on any path that matters). *)
Definition read_spec : ident * funspec :=
  DECLARE _read
  WITH fd : Z, buf : val, n : Z, sh : share, pre : list val, gn : gname, g_old : Z
  PRE [ tint, tptr tvoid, tulong ]
    PROP (0 <= fd <= Int.max_signed;
          0 < n <= Int64.max_unsigned;
          Zlength pre = n;
          writable_share sh)
    PARAMS (Vint (Int.repr fd); buf; Vlong (Int64.repr n))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre buf;
         ghost_var Tsh g_old gn)
  POST [ tlong ]
    EX ret : Z, EX post : list val, EX e_new : Z,
    PROP (Int64.min_signed <= ret <= Int64.max_signed;
          ret <= n;
          Zlength post = n;
          (ret <= 0 -> post = pre))
    LOCAL (temp ret_temp (Vlong (Int64.repr ret)))
    SEP (data_at sh (tarray tschar n) post buf;
         ghost_var Tsh e_new gn).

(* Optional errno-cell ownership: None carries nothing (emp),
   Some carries the concrete cell. Lets joins/returns track the
   conditionally-acquired errno pointers with EXACT ownership
   (no dropping of owning heap, no invention). Sound: every Some is
   backed by a real data_at from a call POST; every None by emp. *)
Definition opt_data (sh : share) (o : option (val * Z)) : mpred :=
  match o with
  | None => emp
  | Some (p, e) => data_at sh tint (Vint (Int.repr e)) p
  end.

(* Axiom: __errno_location() returns a valid int pointer.
   GHOST: takes the current ghost g and returns the SAME g (PROP e = g
   is definitional — POST mentions g directly, no EX e). Hence every
   errno read provably returns the last syscall-written value
   (need.txt item 1: read value = last written value, by construction).
   Cells stay fresh-per-call (reality aliases one TLS slot; the
   over-approximation is sound for memory safety as before). *)
Definition errno_loc_spec : ident * funspec :=
  DECLARE ___errno_location
  WITH sh : share, buf : val, max : Z, post : list val, gn : gname, g : Z
  PRE [ ]
    PROP (0 <= max <= Int.max_signed;
          Zlength post = max;
          writable_share sh)
    PARAMS () GLOBALS ()
    SEP (data_at sh (tarray tschar max) post buf;
         ghost_var Tsh g gn)
  POST [ tptr tint ]
    EX p : val,
    PROP (True)
    LOCAL (temp ret_temp p)
    SEP (data_at sh (tarray tschar max) post buf;
         ghost_var Tsh g gn;
         data_at sh tint (Vint (Int.repr g)) p).

Definition term_read_chunk_spec : ident * funspec :=
  DECLARE _term_read_chunk
  WITH buf : val, max : Z, sh : share, pre : list val, gn : gname, e0 : Z
  PRE [ tptr tschar, tint ]
    PROP (0 <= max <= Int.max_signed;
          Zlength pre = max;
          writable_share sh)
    PARAMS (buf; Vint (Int.repr max))
    GLOBALS ()
    SEP (data_at sh (tarray tschar max) pre buf;
         ghost_var Tsh e0 gn)
  POST [ tint ]
    EX ret : Z, EX post : list val,
    EX o1 o2 o3 : option (val * Z), EX e_fin : Z,
    PROP (Int.min_signed <= ret <= Int.max_signed;
          Zlength post = max;
          (ret = -1 \/ ret = -2 \/ 0 <= ret <= max);
          (ret <= 0 -> post = pre))
    LOCAL (temp ret_temp (Vint (Int.repr ret)))
    SEP (data_at sh (tarray tschar max) post buf;
         opt_data sh o1; opt_data sh o2; opt_data sh o3;
         ghost_var Tsh e_fin gn).

Definition Gprog : funspecs :=
  ltac:(with_library prog [read_spec; errno_loc_spec;
                           term_read_chunk_spec]).

Lemma body_term_read_chunk :
  semax_body Vprog Gprog f_term_read_chunk term_read_chunk_spec.
Proof.
  start_function.
  forward_if.
  - (* max <= 0, hence max = 0: return -1, buffer empty, no options;
       ghost untouched (e_fin := e0) *)
    forward.
    Exists (-1) pre (@None (val * Z)) (@None (val * Z)) (@None (val * Z)) e0.
    entailer!.
  - (* max > 0: call read (ghost e0 overwritten by EX e_new) *)
    forward_call (0, buf, max, sh, pre, gn, e0).
    Intros vret. destruct vret as [[ret post] enew].
    change (fst (fst ((ret, post), enew))) with ret in *.
    change (snd (fst ((ret, post), enew))) with post in *.
    change (snd ((ret, post), enew)) with enew in *.
      (* forward_call already processed Sset _k; program is at if (k<0).
         Bare forward_if fails on this statement shape in VST 2.17, so
         normalize manually first (same rewrites forward_if'_new does). *)
      repeat (apply -> semax_seq_skip).
      repeat (apply seq_assoc1; try apply -> semax_seq_skip).
      forward_if.
      * (* k < 0: errno dispatch, call 1 of 3. Ghost enew is returned
           as-is (the loaded value IS enew by construction). *)
        forward_call (sh, buf, max, post, gn, enew).
        Intros p1.
        forward. (* _t'8 = enew *)
        (* JOIN#2: then/else both continue to IF#3.
           e1ptr common (concrete); e2 only in else (option).
           Ghost enew is common (concrete, threaded). *)
        forward_if (EX t3 : Z, EX o2 : option (val * Z),
          PROP ()
          LOCAL (temp _k (Vlong (Int64.repr ret));
                 temp _buf buf; temp _max (Vint (Int.repr max));
                 temp _t'2 p1; temp _t'8 (Vint (Int.repr enew));
                 temp _t'3 (Vint (Int.repr t3)))
          SEP (data_at sh (tarray tschar max) post buf;
               data_at sh tint (Vint (Int.repr enew)) p1;
               opt_data sh o2;
               ghost_var Tsh enew gn)).
        -- (* enew = 11 (EAGAIN): _t'3 = 1, o2 = None *)
           forward. (* Sset _t'3 *)
           Exists 1%Z (@None (val * Z)). entailer!.
        -- (* enew <> 11: call 2 (ghost still enew), then set _t'3 *)
           forward_call (sh, buf, max, post, gn, enew).
           Intros p2.
           forward. (* _t'9 = enew *)
           forward. (* _t'3 = (enew==11) *)
           Exists (if Int.eq (Int.repr enew) (Int.repr 11) then 1 else 0)
                  (Some (p2, enew)).
           entailer!.
        -- (* JOIN#2 continuation: unpack, continue at IF#3 *)
           Intros t3 o2.
           forward_if (EX t5 : Z, EX o3 : option (val * Z),
             PROP ()
             LOCAL (temp _k (Vlong (Int64.repr ret));
                    temp _buf buf; temp _max (Vint (Int.repr max));
                    temp _t'2 p1; temp _t'8 (Vint (Int.repr enew));
                    temp _t'3 (Vint (Int.repr t3));
                    temp _t'5 (Vint (Int.repr t5)))
             SEP (data_at sh (tarray tschar max) post buf;
                  data_at sh tint (Vint (Int.repr enew)) p1;
                  opt_data sh o2; opt_data sh o3;
                  ghost_var Tsh enew gn)).
           { (* _t'3 nonzero: _t'5 = 1, o3 = None *)
             forward. (* Sset _t'5 *)
             Exists 1%Z (@None (val * Z)). entailer!. }
           { (* _t'3 zero: call 3 (ghost still enew), then set _t'5 *)
             forward_call (sh, buf, max, post, gn, enew).
             Intros p3.
             forward. (* _t'7 = enew *)
             forward. (* _t'5 = (enew==4) *)
             Exists (if Int.eq (Int.repr enew) (Int.repr 4) then 1 else 0)
                    (Some (p3, enew)).
             entailer!. }
           { (* JOIN#3 continuation: unpack, continue at IF#4 *)
             Intros t5 o3.
             forward_if.
             { (* _t'5 nonzero: return -2, options as acquired *)
               forward.
               Exists (-2) post (Some (p1, enew)) o2 o3 enew.
               entailer!.
               match goal with Himp : ?r <= 0 -> post = pre |- post = pre => apply Himp end.
               assert (Hr : Int64.signed (Int64.repr ret) = ret) by (apply signed_repr_roundtrip; assumption).
               assert (Hz : Int64.signed (Int64.repr 0) = 0) by reflexivity.
               match goal with Hlt : Int64.signed (Int64.repr ret) < Int64.signed (Int64.repr 0) |- _ => rewrite Hr, Hz in Hlt; lia end. }
             { (* _t'5 zero: fall to return -1 *)
               forward.
               Exists (-1) post (Some (p1, enew)) o2 o3 enew.
               entailer!.
               match goal with Himp : ?r <= 0 -> post = pre |- post = pre => apply Himp end.
               assert (Hr : Int64.signed (Int64.repr ret) = ret) by (apply signed_repr_roundtrip; assumption).
               assert (Hz : Int64.signed (Int64.repr 0) = 0) by reflexivity.
               match goal with Hlt : Int64.signed (Int64.repr ret) < Int64.signed (Int64.repr 0) |- _ => rewrite Hr, Hz in Hlt; lia end. } }
      * (* k >= 0: return (int)k, no errno cells; ghost stays enew *)
        forward.
        Exists ret post (@None (val * Z)) (@None (val * Z)) (@None (val * Z)) enew.
        entailer!.
        assert (Hr : Int64.signed (Int64.repr ret) = ret)
          by (apply signed_repr_roundtrip; assumption).
        assert (Hz : Int64.signed (Int64.repr 0) = 0) by reflexivity.
        match goal with Hge : (Int64.signed (Int64.repr ret) >= Int64.signed (Int64.repr 0)) |- _ =>
          rewrite Hr, Hz in Hge end.
        split.
        { match goal with Hrg : (Int64.min_signed <= ret <= Int64.max_signed)
                |- (Int.min_signed <= ret <= Int.max_signed) =>
            destruct Hrg as [Hlo Hhi];
            unfold Int.min_signed, Int.max_signed, Int64.min_signed, Int64.max_signed in *; lia end. }
        { split.
          { right. right.
            match goal with Hge : (ret >= 0) |- _ =>
              match goal with Hle : (ret <= Zlength pre) |- _ =>
                split; [lia | lia] end end. }
          { match goal with Hrg : (Int64.min_signed <= ret <= Int64.max_signed) |- _ =>
              destruct Hrg as [Hlo Hhi];
              assert (Hmaxu : Int64.max_unsigned = 18446744073709551615) by reflexivity;
              assert (Hmin : Int64.min_signed = -9223372036854775808) by reflexivity;
              assert (Hmax : Int64.max_signed = 9223372036854775807) by reflexivity;
              assert (HU : 0 <= ret <= Int64.max_unsigned) by lia;
              rewrite (Int64.unsigned_repr ret HU);
              reflexivity end. } }
Qed.
