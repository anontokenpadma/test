(* VST specification of fd_read_timeout (tlswrap.c) — GHOST RETROFIT DONE 2026-10-10
   (need.txt item 1, value-only ghost discipline: Qed, coqc EXIT 0, 0 admit/Admitted).
     int fd_read_timeout(int fd, char *buf, int n, int timeout_ms)
     { poll(&p,1,timeout); s<0: EINTR->-2 else -1; s==0 -> -3;
       k=read(fd,buf,n); k<0: EINTR/EAGAIN/EWOULDBLOCK->-2 else -1;
       return k; }
   HONEST STATUS 2026-10-08: Qed TRỌN VẸN (coqc EXIT 0, 0 admit tactic,
   .vo 743K, DONE 2026-10-08; was empty Admitted 2026-10-07, partial
   poll+k>=0 2026-10-08 trưa; stale header fixed).
   Proved: poll s<0 (-2 EINTR=4 / -1 other) + s==0 (-3) + read k<0
   (3 sites EINTR=4/EAGAIN=11/EWOULDBLOCK=11 nested t5/t7, -2/-1 returns
   with Himp post=pre + Hr/Hz) + read k>=0 ((int)k with Int-bounds/
   disjunction/unsigned_repr splits) — all via entailer! + splits,
   no admits. Specs upgraded errno buffer-carrying (WITH sh,buf,n,post,
   like verif_read_chunk.v:100-114; sound: errno_location only exposes
   TLS slot, buffer untouched; was emp-PRE 2026-10-07 which kẹt frame).
   Workaround for toolchain EX+struct parsing bug (Rocq 9.2 + VST 2.17):
   EX + struct `data_at`/`field_at` (Tstruct _pollfd) in `environ->mpred`
   Post fails even in isolation (minimal repros work17/proofs/
   struct_ex_repro.v etc.; freeze struct fails reptype vs freeze tarray
   OK); here EX Posts for k<0 nested (t5/o2, t7/o3) use `data_at_` any
   (no concrete fd,1,rev2) for poll struct (weakening concrete to any,
   sound: poll value irrelevant after poll, branches depend only on
   s/ret/e/t, not poll fields; same honest scope branch-structure +
   memory safety). Poll s<0 inner + s==0 Posts use concrete `data_at`
   (no EX, so parses) with lvar _p; k>=0/final returns discharge poll
   via stackframe (concrete or any + lvar both work).
   Syscall model: poll/read/errno AXIOMS. POLLIN=1. EAGAIN=11,
   EWOULDBLOCK=11, EINTR=4. HONEST SCOPE same as read_chunk. *)
Require Import VST.floyd.proofauto.
Require Import VST.concurrency.ghosts.
Require Import Clight.tlswrap.
Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.
Definition opt_data (sh : share) (o : option (val * Z)) : mpred :=
  match o with | None => emp | Some (p, e) => data_at sh tint (Vint (Int.repr e)) p end.
Lemma signed_repr_roundtrip : forall z : Z,
  Int64.min_signed <= z <= Int64.max_signed ->
  Int64.signed (Int64.repr z) = z.
Proof.
  intros z [Hlo Hhi].
  assert (Hmin : Int64.min_signed = -9223372036854775808) by reflexivity.
  assert (Hmax : Int64.max_signed = 9223372036854775807) by reflexivity.
  rewrite Hmin in Hlo. rewrite Hmax in Hhi.
  rewrite Int64.signed_repr_eq.
  assert (HM : Int64.modulus = 18446744073709551616) by reflexivity.
  assert (HH : Int64.half_modulus = 9223372036854775808) by reflexivity.
  rewrite HM, HH.
  destruct (Z_lt_ge_dec z 0) as [Hneg|Hnn].
  - assert (Hm : z mod 18446744073709551616 = z + 18446744073709551616).
    { assert (HzM : 0 <= z + 18446744073709551616 < 18446744073709551616) by lia.
      assert (He : (z + 1 * 18446744073709551616) mod 18446744073709551616 = z mod 18446744073709551616).
      { apply Z.mod_add. lia. }
      assert (He2 : z + 1 * 18446744073709551616 = z + 18446744073709551616) by lia.
      rewrite He2 in He. rewrite <- He. rewrite (Z.mod_small _ _ HzM). reflexivity. }
    rewrite Hm.
    destruct (zlt (z + 18446744073709551616) 9223372036854775808) as [Hc|Hc].
    + exfalso. lia.
    + lia.
  - assert (Hm0 : z mod 18446744073709551616 = z).
    { apply Z.mod_small. lia. }
    rewrite Hm0.
    destruct (zlt z 9223372036854775808) as [Hc|Hc].
    + reflexivity.
    + exfalso. lia.
Qed.
Definition poll_spec : ident * funspec :=
  DECLARE _poll
  WITH fds : val, sh : share, fdfd : Z, ev : Z, rev : Z, timeout : Z, gn : gname, g_old : Z
  PRE [ tptr (Tstruct _pollfd noattr), tulong, tint ]
    PROP (0 <= timeout <= Int.max_signed;
          Int.min_signed <= fdfd <= Int.max_signed;
          writable_share sh)
    PARAMS (fds; Vlong (Int64.repr 1); Vint (Int.repr timeout))
    GLOBALS ()
    SEP (data_at sh (Tstruct _pollfd noattr)
           (Vint (Int.repr fdfd), (Vint (Int.repr ev), Vint (Int.repr rev))) fds;
         ghost_var Tsh g_old gn)
  POST [ tint ]
    EX s : Z, EX rev' : Z, EX e_new : Z,
    PROP (Int.min_signed <= s <= Int.max_signed;
          Int.min_signed <= rev' <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr s)))
    SEP (data_at sh (Tstruct _pollfd noattr)
           (Vint (Int.repr fdfd), (Vint (Int.repr ev), Vint (Int.repr rev'))) fds;
         ghost_var Tsh e_new gn).
Definition read_spec : ident * funspec :=
  DECLARE _read
  WITH fd : Z, buf : val, n : Z, sh : share, pre : list val, gn : gname, g_old : Z
  PRE [ tint, tptr tvoid, tulong ]
    PROP (0 <= fd <= Int.max_signed;
          0 < n <= Int64.max_unsigned;
          Zlength pre = n;
          writable_share sh)
    PARAMS (Vint (Int.repr fd); buf; Vlong (Int64.repr n))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre buf;
         ghost_var Tsh g_old gn)
  POST [ tlong ]
    EX ret : Z, EX post : list val, EX e_new : Z,
    PROP (Int64.min_signed <= ret <= Int64.max_signed;
          ret <= n;
          Zlength post = n;
          (ret <= 0 -> post = pre))
    LOCAL (temp ret_temp (Vlong (Int64.repr ret)))
    SEP (data_at sh (tarray tschar n) post buf;
         ghost_var Tsh e_new gn).
Definition errno_loc_spec : ident * funspec :=
  DECLARE ___errno_location
  WITH sh : share, buf : val, n : Z, post : list val, gn : gname, g : Z
  PRE [ ]
    PROP (0 <= n <= Int.max_signed; Zlength post = n; writable_share sh)
    PARAMS () GLOBALS ()
    SEP (data_at sh (tarray tschar n) post buf; ghost_var Tsh g gn)
  POST [ tptr tint ]
    EX p : val,
    PROP (True)
    LOCAL (temp ret_temp p)
    SEP (data_at sh (tarray tschar n) post buf; ghost_var Tsh g gn;
         data_at sh tint (Vint (Int.repr g)) p).
Definition fd_read_timeout_spec : ident * funspec :=
  DECLARE _fd_read_timeout
  WITH fd : Z, buf : val, n : Z, timeout : Z, sh : share, pre : list val, gn : gname, e0 : Z
  PRE [ tint, tptr tschar, tint, tint ]
    PROP (0 <= fd <= Int.max_signed;
          0 < n <= Int.max_signed;
          0 <= timeout <= Int.max_signed;
          Zlength pre = n;
          writable_share sh)
    PARAMS (Vint (Int.repr fd); buf; Vint (Int.repr n); Vint (Int.repr timeout))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre buf;
         ghost_var Tsh e0 gn)
  POST [ tint ]
    EX ret : Z, EX post : list val,
    EX o1 o2 o3 : option (val * Z), EX e_fin : Z,
    PROP (Int.min_signed <= ret <= Int.max_signed;
          Zlength post = n;
          (ret = -3 \/ ret = -2 \/ ret = -1 \/ 0 <= ret <= n);
          (ret <= 0 -> post = pre))
    LOCAL (temp ret_temp (Vint (Int.repr ret)))
    SEP (data_at sh (tarray tschar n) post buf;
         opt_data sh o1; opt_data sh o2; opt_data sh o3;
         ghost_var Tsh e_fin gn).
Definition Gprog : funspecs :=
  ltac:(with_library prog [poll_spec; read_spec; errno_loc_spec; fd_read_timeout_spec]).
Lemma body_fd_read_timeout : semax_body Vprog Gprog f_fd_read_timeout fd_read_timeout_spec.
Proof.
  start_function.
  forward. forward. forward.
  forward_call (v_p, Tsh, fd, 1, 0, timeout, gn, e0).
  Intros v. destruct v as [[ss rev2] epoll].
  change (fst (fst ((ss, rev2), epoll))) with ss in *.
  change (snd (fst ((ss, rev2), epoll))) with rev2 in *.
  change (snd ((ss, rev2), epoll)) with epoll in *.
  repeat (apply -> semax_seq_skip).
  repeat (apply seq_assoc1; try apply -> semax_seq_skip).
  forward_if.
  - (* poll s<0: errno (ghost epoll returned as-is) *)
    forward_call (sh, buf, n, pre, gn, epoll).
    Intros p1.
    forward.
    pose (E1 := epoll). pose (P1 := p1).
    forward_if (PROP ()
      LOCAL (temp _t'12 (Vint (Int.repr E1)); temp _t'2 P1;
             temp _s (Vint (Int.repr ss)); lvar _p (Tstruct _pollfd noattr) v_p;
             temp _fd (Vint (Int.repr fd)); temp _buf buf; temp _n (Vint (Int.repr n));
             temp _timeout_ms (Vint (Int.repr timeout)))
      SEP (data_at sh (tarray tschar n) pre buf;
           data_at sh tint (Vint (Int.repr E1)) P1;
           data_at Tsh (Tstruct _pollfd noattr)
             (Vint (Int.repr fd), (Vint (Int.repr 1), Vint (Int.repr rev2))) v_p;
           ghost_var Tsh epoll gn)).
    + forward. Exists (-2) pre (Some (P1, E1)) (@None (val*Z)) (@None (val*Z)) epoll. entailer!.
    + forward. entailer!.
    + forward. Exists (-1) pre (Some (P1, E1)) (@None (val*Z)) (@None (val*Z)) epoll. entailer!.
  - forward_if (PROP ()
      LOCAL (temp _s (Vint (Int.repr ss)); lvar _p (Tstruct _pollfd noattr) v_p;
             temp _fd (Vint (Int.repr fd)); temp _buf buf; temp _n (Vint (Int.repr n));
             temp _timeout_ms (Vint (Int.repr timeout)))
      SEP (data_at sh (tarray tschar n) pre buf;
           data_at Tsh (Tstruct _pollfd noattr)
             (Vint (Int.repr fd), (Vint (Int.repr 1), Vint (Int.repr rev2))) v_p;
           ghost_var Tsh epoll gn)).
    + forward. Exists (-3) pre (@None (val*Z)) (@None (val*Z)) (@None (val*Z)) epoll. entailer!.
    + forward. entailer!.
    + (* poll s>0: read (ghost epoll overwritten by EX eread) *)
      forward_call (fd, buf, n, sh, pre, gn, epoll).
      Intros vret. destruct vret as [[ret post] eread].
      change (fst (fst ((ret, post), eread))) with ret in *.
      change (snd (fst ((ret, post), eread))) with post in *.
      change (snd ((ret, post), eread)) with eread in *.
      repeat (apply -> semax_seq_skip).
      repeat (apply seq_assoc1; try apply -> semax_seq_skip).
      forward_if.
      * forward_call (sh, buf, n, post, gn, eread).
        Intros pa.
        forward.
        pose (Ea1 := eread). pose (Pa1 := pa).
        forward_if (EX ta : Z, EX oa : option (val * Z),
          PROP ()
          LOCAL (temp _k (Vlong (Int64.repr ret));
                 temp _s (Vint (Int.repr ss)); lvar _p (Tstruct _pollfd noattr) v_p;
                 temp _fd (Vint (Int.repr fd)); temp _buf buf; temp _n (Vint (Int.repr n));
                 temp _timeout_ms (Vint (Int.repr timeout));
                 temp _t'4 Pa1; temp _t'10 (Vint (Int.repr Ea1));
                 temp _t'5 (Vint (Int.repr ta)))
          SEP (data_at sh (tarray tschar n) post buf;
               data_at sh tint (Vint (Int.repr Ea1)) Pa1;
               opt_data sh oa;
               data_at_ Tsh (Tstruct _pollfd noattr) v_p;
               ghost_var Tsh eread gn)).
        -- forward.
           Exists 1%Z (@None (val*Z)). entailer!.
        -- forward_call (sh, buf, n, post, gn, eread).
           Intros pb.
           forward.
           forward.
           Exists (if Int.eq (Int.repr eread) (Int.repr 11) then 1 else 0)
                  (Some (pb, eread)).
           entailer!.
        -- Intros ta oa.
           forward_if (EX tb : Z, EX ob : option (val * Z),
             PROP ()
             LOCAL (temp _k (Vlong (Int64.repr ret));
                    temp _s (Vint (Int.repr ss)); lvar _p (Tstruct _pollfd noattr) v_p;
                    temp _fd (Vint (Int.repr fd)); temp _buf buf; temp _n (Vint (Int.repr n));
                    temp _timeout_ms (Vint (Int.repr timeout));
                    temp _t'4 Pa1; temp _t'10 (Vint (Int.repr Ea1));
                    temp _t'5 (Vint (Int.repr ta));
                    temp _t'7 (Vint (Int.repr tb)))
             SEP (data_at sh (tarray tschar n) post buf;
                  data_at sh tint (Vint (Int.repr Ea1)) Pa1;
                  opt_data sh oa; opt_data sh ob;
                  data_at_ Tsh (Tstruct _pollfd noattr) v_p;
                  ghost_var Tsh eread gn)).
           ++ forward.
              Exists 1%Z (@None (val*Z)). entailer!.
           ++ forward_call (sh, buf, n, post, gn, eread).
              Intros pc.
              forward.
              forward.
              Exists (if Int.eq (Int.repr eread) (Int.repr 11) then 1 else 0)
                     (Some (pc, eread)).
              entailer!.
           ++ Intros tb ob.
              forward_if.
              { forward.
                Exists (-2) post (Some (Pa1, Ea1)) oa ob eread.
                entailer!.
                match goal with Himp : ?r <= 0 -> post = pre |- post = pre => apply Himp end.
                assert (Hr : Int64.signed (Int64.repr ret) = ret) by (apply signed_repr_roundtrip; assumption).
                assert (Hz : Int64.signed (Int64.repr 0) = 0) by reflexivity.
                match goal with Hlt : Int64.signed (Int64.repr ret) < Int64.signed (Int64.repr 0) |- _ => rewrite Hr, Hz in Hlt; lia end. }
              { forward.
                Exists (-1) post (Some (Pa1, Ea1)) oa ob eread.
                entailer!.
                match goal with Himp : ?r <= 0 -> post = pre |- post = pre => apply Himp end.
                assert (Hr : Int64.signed (Int64.repr ret) = ret) by (apply signed_repr_roundtrip; assumption).
                assert (Hz : Int64.signed (Int64.repr 0) = 0) by reflexivity.
                match goal with Hlt : Int64.signed (Int64.repr ret) < Int64.signed (Int64.repr 0) |- _ => rewrite Hr, Hz in Hlt; lia end. }
      * forward.
        Exists ret post (@None (val*Z)) (@None (val*Z)) (@None (val*Z)) eread.
        entailer!.
        assert (Hr : Int64.signed (Int64.repr ret) = ret)
          by (apply signed_repr_roundtrip; assumption).
        assert (Hz : Int64.signed (Int64.repr 0) = 0) by reflexivity.
        match goal with Hge : (Int64.signed (Int64.repr ret) >= Int64.signed (Int64.repr 0)) |- _ =>
          rewrite Hr, Hz in Hge end.
        split.
        { match goal with Hrg : (Int64.min_signed <= ret <= Int64.max_signed)
                |- (Int.min_signed <= ret <= Int.max_signed) =>
            destruct Hrg as [Hlo Hhi];
            unfold Int.min_signed, Int.max_signed, Int64.min_signed, Int64.max_signed in *; lia end. }
        { split.
          { right. right. right.
            match goal with Hge : (ret >= 0) |- _ =>
              match goal with Hle : (ret <= Zlength pre) |- _ =>
                split; [lia | lia] end end. }
          { match goal with Hrg : (Int64.min_signed <= ret <= Int64.max_signed) |- _ =>
              destruct Hrg as [Hlo Hhi];
              assert (Hmaxu : Int64.max_unsigned = 18446744073709551615) by reflexivity;
              assert (Hmin : Int64.min_signed = -9223372036854775808) by reflexivity;
              assert (Hmax : Int64.max_signed = 9223372036854775807) by reflexivity;
              assert (HU : 0 <= ret <= Int64.max_unsigned) by lia;
              rewrite (Int64.unsigned_repr ret HU);
              reflexivity end. } }
Qed.
