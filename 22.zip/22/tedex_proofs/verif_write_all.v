(* VST specification of write_all (termhelp.c) — GHOST RETROFIT DONE 2026-10-10
   (need.txt item 1, value-only ghost discipline: Qed, coqc EXIT 0, 0 admit/Admitted).
     static int write_all(int fd, const char *b, long n)
     { long off = 0; while (off < n) {
         long w = write(fd, b+off, n-off);
         if (w < 0) { if (errno == EINTR) continue; return -1; }
         if (w == 0) return -1; off += w; } return 0; }
   HONEST STATUS 2026-10-08: Qed TRỌN VẸN (coqc EXIT 0, 0 admit tactic,
   .vo 214K, DONE 2026-10-08 20:28 UTC; was 2 admits + Admitted).
   Design: whole-buffer offset write spec (WITH fd,b,off,n,sh,pre,
   PARAMS offset_val off b + Vlong (n-off), SEP whole data_at) avoids
   explicit split2_data_at_Tarray_tschar in proof (sound: chunk [off,n)
   owned via split from whole; write only reads chunk, whole preserved)
   + buffer-carrying readable errno spec (WITH sh,buf,n,post, like
   verif_read_chunk/fd_read but readable_share for const char *b) +
   TT in invariant/continue/break/function-POST to absorb unbounded
   errno cells across EINTR continues (sound: P|--TT, TT*TT=TT;
   honest scope: branch-structure + memory safety + buffer unchanged,
   not exact errno-cell ownership like straight-line read_chunk/fd_read
   opt_data o1/o2/o3).
   Proved: loop entry Exists 0; loop test forward_if (break off=n via
   Int64.lt=false + zlt + roundtrip + lia; body via write call with
   entailer! arg matching); w<0 errno path (forward_call errno +
   load + forward_if e==4: continue Exists off / return -1 Exists -1,
   both via entailer! TT absorption, no extra splits); w==0 return -1;
   w>0 off+=w Exists (off+w) with Hr/Hz + lia for 0<=off+w<=n;
   after-loop return 0 Exists 0.
   Syscall model: write(2) + __errno_location AXIOMS. EINTR=4. *)
Require Import VST.floyd.proofauto.
Require Import VST.concurrency.ghosts.
Require Import Clight.termhelp.
Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.
Lemma signed_repr_roundtrip : forall z : Z, Int64.min_signed <= z <= Int64.max_signed -> Int64.signed (Int64.repr z) = z.
Proof.
  intros z [Hlo Hhi]. assert (Hmin : Int64.min_signed = -9223372036854775808) by reflexivity. assert (Hmax : Int64.max_signed = 9223372036854775807) by reflexivity.
  rewrite Hmin in Hlo. rewrite Hmax in Hhi. rewrite Int64.signed_repr_eq.
  assert (HM : Int64.modulus = 18446744073709551616) by reflexivity. assert (HH : Int64.half_modulus = 9223372036854775808) by reflexivity. rewrite HM, HH.
  destruct (Z_lt_ge_dec z 0) as [Hneg|Hnn].
  - assert (Hm : z mod 18446744073709551616 = z + 18446744073709551616).
    { assert (HzM : 0 <= z + 18446744073709551616 < 18446744073709551616) by lia.
      assert (He : (z + 1 * 18446744073709551616) mod 18446744073709551616 = z mod 18446744073709551616). { apply Z.mod_add. lia. }
      assert (He2 : z + 1 * 18446744073709551616 = z + 18446744073709551616) by lia. rewrite He2 in He. rewrite <- He. rewrite (Z.mod_small _ _ HzM). reflexivity. }
    rewrite Hm. destruct (zlt (z + 18446744073709551616) 9223372036854775808) as [Hc|Hc]. + exfalso. lia. + lia.
  - assert (Hm0 : z mod 18446744073709551616 = z). { apply Z.mod_small. lia. } rewrite Hm0. destruct (zlt z 9223372036854775808) as [Hc|Hc]. + reflexivity. + exfalso. lia.
Qed.
Definition write_spec : ident * funspec :=
  DECLARE _write
  WITH fd : Z, b : val, off : Z, n : Z, sh : share, pre : list val, gn : gname, g_old : Z
  PRE [ tint, tptr tvoid, tulong ]
    PROP (0 <= fd <= Int.max_signed; 0 <= off; off <= n; n <= Int64.max_signed; Zlength pre = n; readable_share sh)
    PARAMS (Vint (Int.repr fd); offset_val off b; Vlong (Int64.repr (n - off)))
    GLOBALS () SEP (data_at sh (tarray tschar n) pre b; ghost_var Tsh g_old gn)
  POST [ tlong ] EX ret : Z, EX e_new : Z,
    PROP (Int64.min_signed <= ret <= Int64.max_signed; ret <= n - off)
    LOCAL (temp ret_temp (Vlong (Int64.repr ret)))
    SEP (data_at sh (tarray tschar n) pre b; ghost_var Tsh e_new gn).
Definition errno_loc_spec : ident * funspec :=
  DECLARE ___errno_location
  WITH sh : share, buf : val, n : Z, post : list val, gn : gname, g : Z
  PRE [ ] PROP (0 <= n <= Int64.max_signed; Zlength post = n; readable_share sh)
    PARAMS () GLOBALS () SEP (data_at sh (tarray tschar n) post buf; ghost_var Tsh g gn)
  POST [ tptr tint ] EX p : val,
    PROP (True)
    LOCAL (temp ret_temp p)
    SEP (data_at sh (tarray tschar n) post buf; ghost_var Tsh g gn;
         data_at sh tint (Vint (Int.repr g)) p).
Definition write_all_spec : ident * funspec :=
  DECLARE _write_all
  WITH fd : Z, b : val, n : Z, sh : share, pre : list val, gn : gname, e0 : Z
  PRE [ tint, tptr tschar, tlong ]
    PROP (0 <= fd <= Int.max_signed; 0 <= n <= Int64.max_signed; Zlength pre = n; readable_share sh)
    PARAMS (Vint (Int.repr fd); b; Vlong (Int64.repr n))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre b;
         ghost_var Tsh e0 gn)
  POST [ tint ] EX r : Z, EX e_fin : Z,
    PROP ((r = 0 \/ r = -1); Int.min_signed <= r <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr r)))
    SEP (data_at sh (tarray tschar n) pre b;
         ghost_var Tsh e_fin gn; TT).
Definition Gprog : funspecs := ltac:(with_library prog [write_spec; errno_loc_spec; write_all_spec]).
Lemma body_write_all : semax_body Vprog Gprog f_write_all write_all_spec.
Proof.
  start_function. forward.
  forward_loop (EX off : Z, EX g : Z, PROP (0 <= off <= n)
    LOCAL (temp _fd (Vint (Int.repr fd)); temp _b b; temp _n (Vlong (Int64.repr n)); temp _off (Vlong (Int64.repr off)))
    SEP (data_at sh (tarray tschar n) pre b; TT; ghost_var Tsh g gn))
  continue: (EX off : Z, EX g : Z, PROP (0 <= off <= n)
    LOCAL (temp _fd (Vint (Int.repr fd)); temp _b b; temp _n (Vlong (Int64.repr n)); temp _off (Vlong (Int64.repr off)))
    SEP (data_at sh (tarray tschar n) pre b; TT; ghost_var Tsh g gn))
  break: (EX off : Z, EX g : Z, PROP (off = n)
    LOCAL (temp _fd (Vint (Int.repr fd)); temp _b b; temp _n (Vlong (Int64.repr n)))
    SEP (data_at sh (tarray tschar n) pre b; TT; ghost_var Tsh g gn)).
  - Exists 0 e0. entailer!.
  - Intros off g. forward_if.
    + forward_call (fd, b, off, n, sh, pre, gn, g). entailer!.
      Intros v. destruct v as [w enew].
      change (fst (w, enew)) with w in *.
      change (snd (w, enew)) with enew in *.
      repeat (apply -> semax_seq_skip). repeat (apply seq_assoc1; try apply -> semax_seq_skip). forward_if.
      * forward_call (sh, b, n, pre, gn, enew).
        Intros p1.
        forward.
        forward_if.
        -- forward. Exists off enew. entailer!.
        -- forward. Exists (-1) enew. entailer!.
      * repeat (apply -> semax_seq_skip). repeat (apply seq_assoc1; try apply -> semax_seq_skip). forward_if.
        -- forward. Exists (-1) enew. entailer!.
        -- forward. Exists (off + w) enew. entailer!.
           assert (Hr : Int64.signed (Int64.repr w) = w) by (apply signed_repr_roundtrip; assumption).
           assert (Hz : Int64.signed (Int64.repr 0) = 0) by reflexivity.
           match goal with H: Int64.signed (Int64.repr w) >= Int64.signed (Int64.repr 0) |- _ => rewrite Hr, Hz in H end.
           lia.
    + forward. Exists off g. entailer!.
      match goal with H: Int64.lt ?a ?b = false |- _ =>
        unfold Int64.lt in H;
        destruct (zlt (Int64.signed a) (Int64.signed b)) as [Hlt|Hge];
        [discriminate H|clear H]
      end.
      assert (Hr_off : Int64.signed (Int64.repr off) = off) by (apply signed_repr_roundtrip; unfold Int64.min_signed, Int64.max_signed in *; lia).
      assert (Hr_zl : Int64.signed (Int64.repr (Zlength pre)) = Zlength pre) by (apply signed_repr_roundtrip; unfold Int64.min_signed, Int64.max_signed in *; lia).
      rewrite Hr_off, Hr_zl in Hge.
      lia.
  - Intros off g. forward. Exists 0 g. entailer!.
Qed.
