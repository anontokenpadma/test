(* VST specification of fd_write_all (tlswrap.c:399-414) — GHOST RETROFIT DONE 2026-10-10
   (need.txt item 1, value-only ghost discipline: Qed, coqc EXIT 0, 0 admit/Admitted).
     int fd_write_all(int fd, const char *b, int n)
     { int off = 0; while (off < n) {
         long w = write(fd, b+off, n-off);
         if (w < 0) { if (errno == EINTR) continue; return -1; }
         if (w == 0) return -1; off += (int)w; } return 0; }
   HONEST STATUS 2026-10-09: Qed TRỌN VẸN (coqc EXIT 0, 0 admit tactic,
   .vo 242K, DONE 2026-10-09; tint twin of termhelp write_all).
   Design: same as verif_write_all.v (whole-buffer offset write spec +
   readable buffer-carrying errno spec + TT in Inv/continue/break/POST
   for unbounded EINTR cells) adapted to tint off/n: write call arg
   matching needs extra Int.unsigned_repr step (tuint->tulong
   zero-extend); Sset off needs tc side goal (int add no-overflow via
   Z_mod_modulus + int roundtrips) + Vint equation
   (Int64.unsigned_repr); loop test is Int.lt (32-bit int roundtrips).
   Syscall model: write(2) + __errno_location AXIOMS. EINTR=4.
   HONEST SCOPE same as write_all (branch-structure + memory safety +
   buffer unchanged, not errno-value identity). *)
Require Import VST.floyd.proofauto.
Require Import VST.concurrency.ghosts.
Require Import Clight.tlswrap.
Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.

Lemma int_signed_roundtrip : forall z : Z,
  Int.min_signed <= z <= Int.max_signed ->
  Int.signed (Int.repr z) = z.
Proof.
  intros z [Hlo Hhi].
  assert (Hmin : Int.min_signed = -2147483648) by reflexivity.
  assert (Hmax : Int.max_signed = 2147483647) by reflexivity.
  rewrite Hmin in Hlo. rewrite Hmax in Hhi.
  rewrite Int.signed_repr_eq.
  assert (HM : Int.modulus = 4294967296) by reflexivity.
  assert (HH : Int.half_modulus = 2147483648) by reflexivity.
  rewrite HM, HH.
  destruct (Z_lt_ge_dec z 0) as [Hneg|Hnn].
  - assert (Hm : z mod 4294967296 = z + 4294967296).
    { assert (HzM : 0 <= z + 4294967296 < 4294967296) by lia.
      assert (He : (z + 1 * 4294967296) mod 4294967296 = z mod 4294967296).
      { apply Z.mod_add. lia. }
      assert (He2 : z + 1 * 4294967296 = z + 4294967296) by lia.
      rewrite He2 in He. rewrite <- He. rewrite (Z.mod_small _ _ HzM). reflexivity. }
    rewrite Hm.
    destruct (zlt (z + 4294967296) 2147483648) as [Hc|Hc].
    + exfalso. lia.
    + lia.
  - assert (Hm0 : z mod 4294967296 = z).
    { apply Z.mod_small. lia. }
    rewrite Hm0.
    destruct (zlt z 2147483648) as [Hc|Hc].
    + reflexivity.
    + exfalso. lia.
Qed.

Lemma signed_repr_roundtrip : forall z : Z,
  Int64.min_signed <= z <= Int64.max_signed ->
  Int64.signed (Int64.repr z) = z.
Proof.
  intros z [Hlo Hhi].
  assert (Hmin : Int64.min_signed = -9223372036854775808) by reflexivity.
  assert (Hmax : Int64.max_signed = 9223372036854775807) by reflexivity.
  rewrite Hmin in Hlo. rewrite Hmax in Hhi.
  rewrite Int64.signed_repr_eq.
  assert (HM : Int64.modulus = 18446744073709551616) by reflexivity.
  assert (HH : Int64.half_modulus = 9223372036854775808) by reflexivity.
  rewrite HM, HH.
  destruct (Z_lt_ge_dec z 0) as [Hneg|Hnn].
  - assert (Hm : z mod 18446744073709551616 = z + 18446744073709551616).
    { assert (HzM : 0 <= z + 18446744073709551616 < 18446744073709551616) by lia.
      assert (He : (z + 1 * 18446744073709551616) mod 18446744073709551616 = z mod 18446744073709551616).
      { apply Z.mod_add. lia. }
      assert (He2 : z + 1 * 18446744073709551616 = z + 18446744073709551616) by lia.
      rewrite He2 in He. rewrite <- He. rewrite (Z.mod_small _ _ HzM). reflexivity. }
    rewrite Hm.
    destruct (zlt (z + 18446744073709551616) 9223372036854775808) as [Hc|Hc].
    + exfalso. lia.
    + lia.
  - assert (Hm0 : z mod 18446744073709551616 = z).
    { apply Z.mod_small. lia. }
    rewrite Hm0.
    destruct (zlt z 9223372036854775808) as [Hc|Hc].
    + reflexivity.
    + exfalso. lia.
Qed.

Definition write_spec : ident * funspec :=
  DECLARE _write
  WITH fd : Z, b : val, off : Z, n : Z, sh : share, pre : list val, gn : gname, g_old : Z
  PRE [ tint, tptr tvoid, tulong ]
    PROP (0 <= fd <= Int.max_signed;
          0 <= off; off <= n; n <= Int.max_signed;
          Zlength pre = n;
          readable_share sh)
    PARAMS (Vint (Int.repr fd); offset_val off b; Vlong (Int64.repr (n - off)))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre b; ghost_var Tsh g_old gn)
  POST [ tlong ]
    EX ret : Z, EX e_new : Z,
    PROP (Int64.min_signed <= ret <= Int64.max_signed;
          ret <= n - off)
    LOCAL (temp ret_temp (Vlong (Int64.repr ret)))
    SEP (data_at sh (tarray tschar n) pre b; ghost_var Tsh e_new gn).

Definition errno_loc_spec : ident * funspec :=
  DECLARE ___errno_location
  WITH sh : share, buf : val, n : Z, post : list val, gn : gname, g : Z
  PRE [ ]
    PROP (0 <= n <= Int.max_signed; Zlength post = n; readable_share sh)
    PARAMS () GLOBALS ()
    SEP (data_at sh (tarray tschar n) post buf; ghost_var Tsh g gn)
  POST [ tptr tint ]
    EX p : val,
    PROP (True)
    LOCAL (temp ret_temp p)
    SEP (data_at sh (tarray tschar n) post buf; ghost_var Tsh g gn;
         data_at sh tint (Vint (Int.repr g)) p).

Definition fd_write_all_spec : ident * funspec :=
  DECLARE _fd_write_all
  WITH fd : Z, b : val, n : Z, sh : share, pre : list val, gn : gname, e0 : Z
  PRE [ tint, tptr tschar, tint ]
    PROP (0 <= fd <= Int.max_signed;
          0 <= n <= Int.max_signed;
          Zlength pre = n;
          readable_share sh)
    PARAMS (Vint (Int.repr fd); b; Vint (Int.repr n))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre b;
         ghost_var Tsh e0 gn)
  POST [ tint ]
    EX r : Z, EX e_fin : Z,
    PROP ((r = 0 \/ r = -1);
          Int.min_signed <= r <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr r)))
    SEP (data_at sh (tarray tschar n) pre b;
         ghost_var Tsh e_fin gn; TT).

Definition Gprog : funspecs :=
  ltac:(with_library prog [write_spec; errno_loc_spec; fd_write_all_spec]).

Lemma body_fd_write_all :
  semax_body Vprog Gprog f_fd_write_all fd_write_all_spec.
Proof.
  start_function.
  forward.
  forward_loop (EX off : Z, EX g : Z,
    PROP (0 <= off <= n)
    LOCAL (temp _fd (Vint (Int.repr fd)); temp _b b; temp _n (Vint (Int.repr n));
           temp _off (Vint (Int.repr off)))
    SEP (data_at sh (tarray tschar n) pre b; TT; ghost_var Tsh g gn))
  continue: (EX off : Z, EX g : Z,
    PROP (0 <= off <= n)
    LOCAL (temp _fd (Vint (Int.repr fd)); temp _b b; temp _n (Vint (Int.repr n));
           temp _off (Vint (Int.repr off)))
    SEP (data_at sh (tarray tschar n) pre b; TT; ghost_var Tsh g gn))
  break: (EX off : Z, EX g : Z,
    PROP (off = n)
    LOCAL (temp _fd (Vint (Int.repr fd)); temp _b b; temp _n (Vint (Int.repr n)))
    SEP (data_at sh (tarray tschar n) pre b; TT; ghost_var Tsh g gn)).
  - Exists 0 e0. entailer!.
  - Intros off g.
    forward_if.
    + forward_call (fd, b, off, n, sh, pre, gn, g).
      entailer!.
      simpl.
      repeat f_equal.
      all: try reflexivity.
      apply Int.unsigned_repr.
      unfold Int.max_unsigned, Int.max_signed in *.
      assert (HM : Int.modulus = 4294967296) by reflexivity.
      assert (HH : Int.half_modulus = 2147483648) by reflexivity.
      rewrite HM, HH in *.
      lia.
      Intros v. destruct v as [w enew].
      change (fst (w, enew)) with w in *.
      change (snd (w, enew)) with enew in *.
      repeat (apply -> semax_seq_skip).
      repeat (apply seq_assoc1; try apply -> semax_seq_skip).
      forward_if.
      * forward_call (sh, b, n, pre, gn, enew).
        Intros p1.
        forward.
        forward_if.
        -- forward. Exists off enew. entailer!.
        -- forward. Exists (-1) enew. entailer!.
      * repeat (apply -> semax_seq_skip).
        repeat (apply seq_assoc1; try apply -> semax_seq_skip).
        forward_if.
        -- forward. Exists (-1) enew. entailer!.
        -- forward;
           [ entailer!;
             assert (Hr64 : Int64.signed (Int64.repr w) = w) by (apply signed_repr_roundtrip; assumption);
             assert (Hz64 : Int64.signed (Int64.repr 0) = 0) by reflexivity;
             match goal with H: Int64.signed (Int64.repr w) >= Int64.signed (Int64.repr 0) |- _ => rewrite Hr64, Hz64 in H end;
             assert (Hmod : Int64.Z_mod_modulus w = w) by
               (rewrite Int64.Z_mod_modulus_eq; apply Z.mod_small;
                unfold Int.max_signed in *;
                assert (HM64 : Int64.modulus = 18446744073709551616) by reflexivity;
                assert (HH32 : Int.half_modulus = 2147483648) by reflexivity;
                rewrite HM64, HH32 in *; lia);
             rewrite Hmod;
             assert (Hrw : Int.signed (Int.repr w) = w) by
               (apply int_signed_roundtrip;
                unfold Int.min_signed, Int.max_signed in *;
                assert (HH32 : Int.half_modulus = 2147483648) by reflexivity;
                rewrite HH32 in *; lia);
             rewrite Hrw;
             unfold Int.min_signed, Int.max_signed in *;
             assert (HH32 : Int.half_modulus = 2147483648) by reflexivity;
             rewrite HH32 in *; lia
           | Exists (off + w) enew; entailer!;
             assert (Hs64 : Int64.signed (Int64.repr w) = w) by (apply signed_repr_roundtrip; assumption);
             assert (Hz64b : Int64.signed (Int64.repr 0) = 0) by reflexivity;
             match goal with H: Int64.signed (Int64.repr w) >= Int64.signed (Int64.repr 0) |- _ => rewrite Hs64, Hz64b in H end;
             split; [ lia
             | assert (Huw : Int64.unsigned (Int64.repr w) = w) by
                 (apply Int64.unsigned_repr;
                  unfold Int64.max_unsigned, Int.max_signed in *;
                  assert (HM64b : Int64.modulus = 18446744073709551616) by reflexivity;
                  assert (HH32b : Int.half_modulus = 2147483648) by reflexivity;
                  rewrite HM64b, HH32b in *; lia);
               rewrite Huw; reflexivity ] ].
    + forward. Exists off g. entailer!.
  - Intros off g. forward. Exists 0 g. entailer!.
Qed.
