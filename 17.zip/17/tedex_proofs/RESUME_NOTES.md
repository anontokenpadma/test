# Tedex Rocq/VST verification — resume notes (2026-10-08 phiên tiếp trên 17/, 16.zip == 17 cũ STALE)

## Environment (verified working)
- Switch `rocq-9.2` (OCaml 5.2.1): Rocq 9.2.0 + CompCert 3.18 + coq-vst 2.17 + Flocq 4.2.2.
- Rebuild note: Flocq/VST MUST be built with system gcc (`CC=/usr/bin/gcc`,
  `/usr/bin` before `/opt/conda/bin` in PATH, unset LIBRARY_PATH/CPATH);
  conda `ld`+sysroot breaks Flocq `remake` with `_dl_vsym@GLIBC_PRIVATE`.
- `opam install coq-vst.2.17 -y -j4 --no-depexts` (needs `coq-released` repo
  + conda `clang` for conf-clang).

## File inventory (17/tedex_proofs, 16.zip == old 17 STALE; rerun 2026-10-08 all EXIT 0 warnings-only after fresh clight)
| File | Status |
|---|---|
| AuthVerdict.v (.vo) | PROVED (7 thms, Qed) |
| EchoModel.v (.vo) | PROVED (13 thms, Qed) |
| AttachHandoff.v (.vo) | PROVED (7 thms, Qed) |
| SysModel.v (.vo) | PROVED (13 thms, Qed) |
| vst_specs.v (.vo) | skeleton, typechecks, documentation only |
| verif_close_fd.v (.vo 72K) | PROVED end-to-end (Qed): tls_close_fd |
| verif_read_chunk.v (.vo 324K) | PROVED end-to-end (Qed, 0 admit tactic): term_read_chunk — DONE 2026-10-07, stale header fixed 2026-10-08 |
| verif_write_all.v (.vo 29K) | PARTIAL 2026-10-08: loop entry proved (Exists 0, forward_loop), body/after-loop admitted (2 admits + Admitted); specs unchanged, no errno spec yet |
| verif_fd_read.v (.vo 63K) | PARTIAL 2026-10-08: poll s<0 (-2/-1) + s==0 (-3) + read k>=0 proved (no admits in those branches, helper Qed), k<0 admitted (1 admit + Admitted); specs upgraded errno buffer-carrying (like read_chunk) |
| ARCH_B_THREAT.md | Reconstructed 2026-10-07: kiến trúc + v11 Trim/Count_Attached/Last_Dropped + BUG + threat model |
| test.v / smoke.v (.vo) | coq proof test PASS + VST Require smoke PASS |
| clight/termhelp.{c,v}, tlswrap.{c,v} | clightgen -normalize exit 0 both, fresh .vo 109K/187K 2026-10-08 |
| work17/proofs/struct_ex_repro.v etc. | MINIMAL REPROS 2026-10-08 for toolchain blocker EX+struct (see below), not proofs |

## 2026-10-08 progress (fd_read poll + read k>=0 proved, write_all loop entry proved; full rerun EXIT 0)
- fd_read (verif_fd_read.v 224 dòng, .vo 63K, 1 admit k<0 + Admitted, helper Qed): poll s<0 (-2 EINTR=4 / -1 other) + s==0 (-3) + read k>=0 ((int)k) proved via `forward` + `Exists` + `entailer!.` with no admits in those branches (concrete Posts with lvar _p/poll struct, no EX, so parses; `pose E1/P1` before inner poll Post; `repeat semax_seq_skip/seq_assoc1` before each `forward_if` since bare fails on Ssequence(Sif...); `forward_call (sh,buf,n,pre)` for poll errno (buffer-carrying, upgraded from emp-PRE like read_chunk) + `forward_call (fd,buf,n,sh,pre)` for read (explicit witness); k>=0 reuses read_chunk splits (Hr/Hz rewrite Hge, Int-bounds lia, right-right-right + Hle, unsigned_repr HU). k<0 dispatch (entire branch) admitted with single `admit` (1 admit + Admitted); plan reuses read_chunk JOIN#2/#3 with EX t5/o2, EX t7/o3 + opt_data + Himp + Hr/Hz for post=pre.
- write_all (verif_write_all.v 93 dòng, .vo 29K, 2 admits + Admitted): `forward_loop` (not `forward_while`, body has Scontinue/Sreturn) Inv EX off 0<=off<=n buffer + continue same + break off=n buffer; entry `Exists 0. entailer!.` proved; body (write b+off splitting + w<0/w==0/off+=w + errno EINTR continue + variant) admitted; after-loop (return 0 off==n) admitted; specs unchanged, no errno spec yet.
- read_chunk stale header fixed (was "in progress", now Qed TRỌN VẸN).
- Full rerun 2026-10-08 after fresh clight (109K/187K): test/smoke/Auth/Echo/Attach/Sys/vst_specs/close_fd/read_chunk/write_all/fd_read all coqc EXIT 0 warnings-only (Hint norm, deprecated From Coq/Stdlib); Qed files 0 admit tactic; partials as above; `grep ^Qed/^Admitted` confirms Qed = close_fd/read_chunk/Auth/Echo/Attach/Sys (+helpers), Admitted = write_all/fd_read.
- Toolchain blocker for fd_read k<0 nested (not logic, with minimal repros work17/proofs/struct_ex_repro.v = check_post.v EX+data_at struct fails, field_ex_repro.v = EX+field_at fails, freeze_struct_repro.v = freeze struct fails reptype vs freeze tarray OK in test_freeze2.v): EX + struct `data_at`/`field_at` (Tstruct _pollfd) in `environ->mpred` Post definitions fails even in isolation (`environ->mpred` vs `mpred`), while EX without struct (tarray/tint/opt_data, as in read_chunk JOIN#2/#3 and test_ex4/5) and struct without EX (concrete Posts above with lvar/poll) both parse. Future k<0 nested needs VST/Rocq fix (older Coq 8.x where struct+EX works) or workaround avoiding EX+struct (freeze/field_at that avoids EX+struct, or change C to avoid struct local — no, must verify actual C with struct).

## Lessons (verified by compiling probe; 1-8 from 2026-10-07 read_chunk, 9-14 from 2026-10-08 fd_read/write_all)
1. Specs + Gprog typecheck; `with_library` accepts all specs.
2. `forward_if` (max<=0) works; then-branch CLOSED by entailer!.
3. `forward_call (0,buf,max,sh,pre)` for `_read` works (explicit witness).
4. Buffer-carrying errno spec (WITH sh,buf,max,post) beats emp-PRE (frame matches directly).
5. Bare `forward_if` fails on `Ssequence(Sifthenelse...)`; workaround: manual
   `repeat (apply -> semax_seq_skip). repeat (apply seq_assoc1; ...)`.
6. `repeat match Hlt: context[...] |- _ => rewrite Hr in Hlt` hits Hr/Hz itself —
   must match specific `Hlt: signed(ret)<signed(0)` then `rewrite Hr,Hz in Hlt`.
7. `rep_lia` fails Cannot find witness → use signed_repr_roundtrip + explicit
   Int64/Int constant reflexivity before lia.
8. VST `Exists _` needs explicit witnesses.
9. Loop with Scontinue/Sreturn → `forward_loop Inv continue:PreInc break:Post` (not `forward_while`); entry needs `Exists 0. entailer!.` (Inv EX off, not just entailer!).
10. lvar _p + poll struct in concrete Post (no EX) parses; `pose E1/P1` before `forward_if Post` mentioning them avoids e1 not found (e1/p1 from Intros+destruct persist after `forward` Sset, but Post must mention posed copies to be safe across explicit Post + entailer!).
11. `entailer!.` closes poll -2/-1/-3 with no extra splits (unlike read_chunk k>=0 which needed splits for A/\B/\C); read k>=0 still needs Hr/Hz + splits (reused verbatim from read_chunk with n/max + pre/post adjusted).
12. EX + struct `data_at`/`field_at` (Tstruct _pollfd, any share Tsh/sh, with/without lvar/opt) fails even in isolation in Rocq 9.2 + VST 2.17 here (`environ->mpred` vs `mpred` for EX body, plus `reptype` for freeze struct vs freeze tarray OK); EX without struct (tarray/tint/opt_data) and struct without EX (concrete Posts) both parse — minimal repros struct_ex_repro.v etc. in work17/proofs.

## Next concrete step (whoever resumes; 2026-10-08 partials above)
- fd_read k<0 nested (read k<0, 3 errno sites EINTR=4/EAGAIN=11/EWOULDBLOCK=11, nested t5/t7, -2/-1 returns, no loop, bounded o1/o2/o3, same logic as read_chunk JOIN#2/#3 which already proved similar 3-site dispatch without struct): reuse read_chunk pattern with EX t5/o2 (Post LOCAL _k/_s/_p/params/_t'4/_t'10/_t'5 + SEP buffer post + e1 + opt o2 + poll) + EX t7/o3 + final `forward_if` (both return, no Post) with Himp (read ret<=0->post=pre) + Hr/Hz/lia for post=pre (as in read_chunk -2/-1 branches) + poll struct in EX Posts — BLOCKED by toolchain EX+struct parsing bug above (minimal repros); needs VST/Rocq fix (older Coq 8.x) or workaround avoiding EX+struct (freeze/field_at that avoids EX+struct — freeze struct currently fails reptype, freeze tarray works — or change C to avoid struct local — no).
- write_all loop body (off<n, write b+off (ulong)(n-off) with `offset_val` + `data_at` splitting sublist 0/off/n, w<0 (errno EINTR=4 continue via buffer-carrying readable errno spec + opt/list, else return -1) + w==0 return -1 + off+=w progress, no struct so EX parses): add readable errno spec + opt_data/list for unbounded EINTR continues across iterations (single EX o insufficient; need EX l:list with fold sepcon, or non-owning errno for loop + owning for straight-line, honestly documented) + write_all_spec POST with EX o/l (currently no opt, would leak owning e cells) + variant Z.to_nat (n-off) + splitting lemmas; after-loop (return 0 off==n) then trivial via entailer!.
- field_at for 3 Sassign already handled via `forward` (no explicit field_at needed, `forward. forward. forward.` closes struct assigns with `lvar _p` + `data_at Tsh` in PRE as printed via idtac); poll `forward_call` with implicit `Eaddrof &p` (bare `forward_call.` infers witness, no explicit Eaddrof needed as in probe1-16 dummy chain) — both already proved in t19 poll part above.

## Honest scope reminders
- Gallina models prove MODELS transcribed from Ada/C, not the binaries.
- VST specs for read/write/poll/errno/close are AXIOMS over syscalls.
- The 3-4 errno reads are specified independently (may differ); the proved
  property is branch-structure + memory safety, not errno-value identity
  (needs a ghost global invariant — future work). Write_all loop with unbounded
  EINTR continues needs EX l:list (not single EX o) or non-owning errno for loop,
  honestly documented above; current write_all_spec POST has no opt (would leak).
- SPARK remains the authority for the Ada code.
- 2026-10-08 partials honest: Qed = Auth/Echo/Attach/Sys/close_fd/read_chunk (header fixed) + fd_read helper signed_repr_roundtrip (Qed) + fd_read poll s<0/s==0 + read k>=0 (no admits in those branches, entailer! closes; k<0 admitted 1 admit) + write_all loop entry (Exists 0 proved; body/after-loop admitted 2 admits); Admitted = write_all/fd_read mains (as above); skeleton = vst_specs; toolchain blocker EX+struct minimal repros saved (not proofs).
