(* VST specification of write_all (termhelp.c):
     static int write_all(int fd, const char *b, long n)
     { long off = 0; while (off < n) {
         long w = write(fd, b+off, n-off);
         if (w < 0) { if (errno == EINTR) continue; return -1; }
         if (w == 0) return -1; off += w; } return 0; }
   HONEST STATUS 2026-10-08 (partial skeleton, was empty Admitted 2026-10-07):
   - PROVED: loop entry (off=0, 0<=0<=n) via `Exists 0. entailer!.`
     with `forward_loop` (NOT `forward_while`: body has Scontinue/Sreturn,
     VST requires `forward_loop Inv continue: PreInc break: Post`).
     Invariant EX off, 0<=off<=n, buffer (readable, unchanged); continue
     same as Inv (continue jumps to loop test); break Post off=n, buffer
     (before `return 0`). Specs unchanged (write readable + write_all,
     no errno spec yet since body admitted before errno calls, no opt_data
     in write_all_spec POST yet).
   - ADMITTED (2 admits + Admitted): loop body (write call with `b+off`
     via offset_val + `data_at` splitting sublist 0/off/n + w<0/w==0/off+=w
     + errno EINTR=4 continue pattern + variant Z.to_nat (n-off)) and
     after-loop (return 0 with off==n, buffer).
   - FUTURE (concrete next steps, same pattern as verif_read_chunk.v +
     verif_fd_read.v poll part): add buffer-carrying readable errno spec
     (WITH sh,buf,n,post, PRE data_at readable, POST data_at + e cell,
     sound: errno_location only exposes TLS slot, buffer untouched) +
     opt_data/list for unbounded errno cells across loop iterations
     (single EX o insufficient for unbounded EINTR continues; need EX l:list
     with fold sepcon, or non-owning errno spec for loop + owning for
     straight-line, honestly documented) + write_all_spec POST with
     EX o/l (currently no opt, would leak owning e cells on return -1/0).
   Syscall model: write(2) is an AXIOM (external spec). *)

Require Import VST.floyd.proofauto.
Require Import Clight.termhelp.
Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.
Definition write_spec : ident * funspec :=
  DECLARE _write
  WITH fd : Z, buf : val, n : Z, sh : share, pre : list val
  PRE [ tint, tptr tvoid, tulong ]
    PROP (0 <= fd <= Int.max_signed;
          0 <= n <= Int64.max_unsigned;
          Zlength pre = n;
          readable_share sh)
    PARAMS (Vint (Int.repr fd); buf; Vlong (Int64.repr n))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre buf)
  POST [ tlong ]
    EX ret : Z,
    PROP (Int64.min_signed <= ret <= Int64.max_signed;
          ret <= n)
    LOCAL (temp ret_temp (Vlong (Int64.repr ret)))
    SEP (data_at sh (tarray tschar n) pre buf).
Definition write_all_spec : ident * funspec :=
  DECLARE _write_all
  WITH fd : Z, b : val, n : Z, sh : share, pre : list val
  PRE [ tint, tptr tschar, tlong ]
    PROP (0 <= fd <= Int.max_signed;
          0 <= n <= Int64.max_signed;
          Zlength pre = n;
          readable_share sh)
    PARAMS (Vint (Int.repr fd); b; Vlong (Int64.repr n))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre b)
  POST [ tint ]
    EX r : Z,
    PROP ((r = 0 \/ r = -1);
          Int.min_signed <= r <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr r)))
    SEP (data_at sh (tarray tschar n) pre b).
Definition Gprog : funspecs :=
  ltac:(with_library prog [write_spec; write_all_spec]).
Lemma body_write_all :
  semax_body Vprog Gprog f_write_all write_all_spec.
Proof.
  start_function.
  forward.
  forward_loop (EX off : Z,
    PROP (0 <= off <= n)
    LOCAL (temp _fd (Vint (Int.repr fd)); temp _b b; temp _n (Vlong (Int64.repr n));
           temp _off (Vlong (Int64.repr off)))
    SEP (data_at sh (tarray tschar n) pre b))
  continue: (EX off : Z,
    PROP (0 <= off <= n)
    LOCAL (temp _fd (Vint (Int.repr fd)); temp _b b; temp _n (Vlong (Int64.repr n));
           temp _off (Vlong (Int64.repr off)))
    SEP (data_at sh (tarray tschar n) pre b))
  break: (EX off : Z,
    PROP (off = n)
    LOCAL (temp _fd (Vint (Int.repr fd)); temp _b b; temp _n (Vlong (Int64.repr n)))
    SEP (data_at sh (tarray tschar n) pre b)).
  - Exists 0. entailer!.
  - admit.
  - admit.
Admitted.
