(* VST verification of term_read_chunk (termhelp.c).
   HONEST STATUS (2026-10-07): proof in progress; file may not compile
   clean yet -- see RESUME_NOTES.md for the frontier.
   Design: buffer-carrying errno spec (frame made explicit, no emp-PRE
   frame inference) + freeze/thaw of acquired errno pointers.
   Syscall model: read(2) + __errno_location are AXIOMS (external specs).
   EAGAIN=11, EWOULDBLOCK=11, EINTR=4 (Linux x86_64, matches Clight).
   The three errno reads are specified independently (may differ);
   proved property: branch-structure correctness + memory safety.
   PRE allows 0 <= max (max=0: empty buffer, returns -1 via then-branch).
   Negative max is EXCLUDED from the spec (vacuous); the Ada caller
   always passes 1024. *)

Require Import VST.floyd.proofauto.
Require Import Clight.termhelp.

Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.

(* Helper: Int64 signed/repr roundtrip on the in-range domain.
   Needed because VST's rep_lia fails on these goals in this version
   ("Cannot find witness" even in isolation), so we do it by hand. *)
Lemma signed_repr_roundtrip : forall z : Z,
  Int64.min_signed <= z <= Int64.max_signed ->
  Int64.signed (Int64.repr z) = z.
Proof.
  intros z [Hlo Hhi].
  assert (Hmin : Int64.min_signed = -9223372036854775808) by reflexivity.
  assert (Hmax : Int64.max_signed = 9223372036854775807) by reflexivity.
  rewrite Hmin in Hlo. rewrite Hmax in Hhi.
  rewrite Int64.signed_repr_eq.
  assert (HM : Int64.modulus = 18446744073709551616) by reflexivity.
  assert (HH : Int64.half_modulus = 9223372036854775808) by reflexivity.
  rewrite HM, HH.
  destruct (Z_lt_ge_dec z 0) as [Hneg|Hnn].
  - assert (Hm : z mod 18446744073709551616
                 = z + 18446744073709551616).
    { assert (HzM : 0 <= z + 18446744073709551616
                       < 18446744073709551616) by lia.
      assert (He : (z + 1 * 18446744073709551616) mod 18446744073709551616
                   = z mod 18446744073709551616).
      { apply Z.mod_add. lia. }
      assert (He2 : z + 1 * 18446744073709551616
                    = z + 18446744073709551616) by lia.
      rewrite He2 in He.
      rewrite <- He.
      rewrite (Z.mod_small _ _ HzM). reflexivity. }
    rewrite Hm.
    destruct (zlt (z + 18446744073709551616) 9223372036854775808)
      as [Hc|Hc].
    + exfalso. lia.
    + lia.
  - assert (Hm0 : z mod 18446744073709551616 = z).
    { apply Z.mod_small. lia. }
    rewrite Hm0.
    destruct (zlt z 9223372036854775808) as [Hc|Hc].
    + reflexivity.
    + exfalso. lia.
Qed.

(* Axiom: read(fd, buf, n). Nondeterministic POSIX behaviour. *)
Definition read_spec : ident * funspec :=
  DECLARE _read
  WITH fd : Z, buf : val, n : Z, sh : share, pre : list val
  PRE [ tint, tptr tvoid, tulong ]
    PROP (0 <= fd <= Int.max_signed;
          0 < n <= Int64.max_unsigned;
          Zlength pre = n;
          writable_share sh)
    PARAMS (Vint (Int.repr fd); buf; Vlong (Int64.repr n))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre buf)
  POST [ tlong ]
    EX ret : Z, EX post : list val,
    PROP (Int64.min_signed <= ret <= Int64.max_signed;
          ret <= n;
          Zlength post = n;
          (ret <= 0 -> post = pre))
    LOCAL (temp ret_temp (Vlong (Int64.repr ret)))
    SEP (data_at sh (tarray tschar n) post buf).

(* Optional errno-cell ownership: None carries nothing (emp),
   Some carries the concrete cell. Lets joins/returns track the
   conditionally-acquired errno pointers with EXACT ownership
   (no dropping of owning heap, no invention). Sound: every Some is
   backed by a real data_at from a call POST; every None by emp. *)
Definition opt_data (sh : share) (o : option (val * Z)) : mpred :=
  match o with
  | None => emp
  | Some (p, e) => data_at sh tint (Vint (Int.repr e)) p
  end.

(* Axiom: __errno_location() returns a valid int pointer.
   The caller buffer is carried explicitly in PRE/POST (instead of an
   emp PRE) so the common (frame-free) part matches directly.
   Sites 2-3 carry extra already-acquired pointers; those are handled
   at the call via explicit sequence splitting (see proof). Sound: the
   axiom promises buffer and prior cells untouched (true of the real
   errno_location, which only exposes its TLS slot). *)
Definition errno_loc_spec : ident * funspec :=
  DECLARE ___errno_location
  WITH sh : share, buf : val, max : Z, post : list val
  PRE [ ]
    PROP (0 <= max <= Int.max_signed;
          Zlength post = max;
          writable_share sh)
    PARAMS () GLOBALS ()
    SEP (data_at sh (tarray tschar max) post buf)
  POST [ tptr tint ]
    EX p : val, EX e : Z,
    PROP (Int.min_signed <= e <= Int.max_signed)
    LOCAL (temp ret_temp p)
    SEP (data_at sh (tarray tschar max) post buf;
         data_at sh tint (Vint (Int.repr e)) p).

Definition term_read_chunk_spec : ident * funspec :=
  DECLARE _term_read_chunk
  WITH buf : val, max : Z, sh : share, pre : list val
  PRE [ tptr tschar, tint ]
    PROP (0 <= max <= Int.max_signed;
          Zlength pre = max;
          writable_share sh)
    PARAMS (buf; Vint (Int.repr max))
    GLOBALS ()
    SEP (data_at sh (tarray tschar max) pre buf)
  POST [ tint ]
    EX ret : Z, EX post : list val,
    EX o1 o2 o3 : option (val * Z),
    PROP (Int.min_signed <= ret <= Int.max_signed;
          Zlength post = max;
          (ret = -1 \/ ret = -2 \/ 0 <= ret <= max);
          (ret <= 0 -> post = pre))
    LOCAL (temp ret_temp (Vint (Int.repr ret)))
    SEP (data_at sh (tarray tschar max) post buf;
         opt_data sh o1; opt_data sh o2; opt_data sh o3).

Definition Gprog : funspecs :=
  ltac:(with_library prog [read_spec; errno_loc_spec;
                           term_read_chunk_spec]).

Lemma body_term_read_chunk :
  semax_body Vprog Gprog f_term_read_chunk term_read_chunk_spec.
Proof.
  start_function.
  forward_if.
  - (* max <= 0, hence max = 0: return -1, buffer empty, no options *)
    forward.
    Exists (-1) pre (@None (val * Z)) (@None (val * Z)) (@None (val * Z)).
    entailer!.
  - (* max > 0: call read *)
    forward_call (0, buf, max, sh, pre).
    Intros vret. destruct vret as [ret post].
    change (fst (ret, post)) with ret in *.
    change (snd (ret, post)) with post in *.
      (* forward_call already processed Sset _k; program is at if (k<0).
         Bare forward_if fails on this statement shape in VST 2.17, so
         normalize manually first (same rewrites forward_if'_new does). *)
      repeat (apply -> semax_seq_skip).
      repeat (apply seq_assoc1; try apply -> semax_seq_skip).
      forward_if.
      * (* k < 0: errno dispatch, call 1 of 3 (F := emp). *)
        forward_call (sh, buf, max, post).
        Intros v1. destruct v1 as [p1 e1].
        change (fst (p1, e1)) with p1 in *.
        change (snd (p1, e1)) with e1 in *.
        forward. (* _t'8 = e1 *)
        (* JOIN#2: then/else both continue to IF#3.
           e1ptr common (concrete); e2 only in else (option). *)
        forward_if (EX t3 : Z, EX o2 : option (val * Z),
          PROP ()
          LOCAL (temp _k (Vlong (Int64.repr ret));
                 temp _buf buf; temp _max (Vint (Int.repr max));
                 temp _t'2 p1; temp _t'8 (Vint (Int.repr e1));
                 temp _t'3 (Vint (Int.repr t3)))
          SEP (data_at sh (tarray tschar max) post buf;
               data_at sh tint (Vint (Int.repr e1)) p1;
               opt_data sh o2)).
        -- (* e1 = 11 (EAGAIN): _t'3 = 1, o2 = None *)
           forward. (* Sset _t'3 *)
           Exists 1%Z (@None (val * Z)). entailer!.
        -- (* e1 <> 11: call 2 with F := e1 cell, then set _t'3 *)
           forward_call (sh, buf, max, post).
           Intros v2. destruct v2 as [p2 e2].
           change (fst (p2, e2)) with p2 in *.
           change (snd (p2, e2)) with e2 in *.
           forward. (* _t'9 = e2 *)
           forward. (* _t'3 = (e2==11) *)
           Exists (if Int.eq (Int.repr e2) (Int.repr 11) then 1 else 0)
                  (Some (p2, e2)).
           entailer!.
        -- (* JOIN#2 continuation: unpack, continue at IF#3 *)
           Intros t3 o2.
           forward_if (EX t5 : Z, EX o3 : option (val * Z),
             PROP ()
             LOCAL (temp _k (Vlong (Int64.repr ret));
                    temp _buf buf; temp _max (Vint (Int.repr max));
                    temp _t'2 p1; temp _t'8 (Vint (Int.repr e1));
                    temp _t'3 (Vint (Int.repr t3));
                    temp _t'5 (Vint (Int.repr t5)))
             SEP (data_at sh (tarray tschar max) post buf;
                  data_at sh tint (Vint (Int.repr e1)) p1;
                  opt_data sh o2; opt_data sh o3)).
           { (* _t'3 nonzero: _t'5 = 1, o3 = None *)
             forward. (* Sset _t'5 *)
             Exists 1%Z (@None (val * Z)). entailer!. }
           { (* _t'3 zero: call 3, then set _t'5 *)
             forward_call (sh, buf, max, post).
             Intros v3. destruct v3 as [p3 e3].
             change (fst (p3, e3)) with p3 in *.
             change (snd (p3, e3)) with e3 in *.
             forward. (* _t'7 = e3 *)
             forward. (* _t'5 = (e3==4) *)
             Exists (if Int.eq (Int.repr e3) (Int.repr 4) then 1 else 0)
                    (Some (p3, e3)).
             entailer!. }
           { (* JOIN#3 continuation: unpack, continue at IF#4 *)
             Intros t5 o3.
             forward_if.
             { (* _t'5 nonzero: return -2, options as acquired *)
               forward.
               Exists (-2) post (Some (p1, e1)) o2 o3.
               entailer!.
               match goal with Himp : ?r <= 0 -> post = pre |- post = pre => apply Himp end.
               assert (Hr : Int64.signed (Int64.repr ret) = ret) by (apply signed_repr_roundtrip; assumption).
               assert (Hz : Int64.signed (Int64.repr 0) = 0) by reflexivity.
               match goal with Hlt : Int64.signed (Int64.repr ret) < Int64.signed (Int64.repr 0) |- _ => rewrite Hr, Hz in Hlt; lia end. }
             { (* _t'5 zero: fall to return -1 *)
               forward.
               Exists (-1) post (Some (p1, e1)) o2 o3.
               entailer!.
               match goal with Himp : ?r <= 0 -> post = pre |- post = pre => apply Himp end.
               assert (Hr : Int64.signed (Int64.repr ret) = ret) by (apply signed_repr_roundtrip; assumption).
               assert (Hz : Int64.signed (Int64.repr 0) = 0) by reflexivity.
               match goal with Hlt : Int64.signed (Int64.repr ret) < Int64.signed (Int64.repr 0) |- _ => rewrite Hr, Hz in Hlt; lia end. } }
      * (* k >= 0: return (int)k, no errno cells *)
        forward.
        Exists ret post (@None (val * Z)) (@None (val * Z)) (@None (val * Z)).
        entailer!.
        assert (Hr : Int64.signed (Int64.repr ret) = ret)
          by (apply signed_repr_roundtrip; assumption).
        assert (Hz : Int64.signed (Int64.repr 0) = 0) by reflexivity.
        match goal with Hge : (Int64.signed (Int64.repr ret) >= Int64.signed (Int64.repr 0)) |- _ =>
          rewrite Hr, Hz in Hge end.
        split.
        { match goal with Hrg : (Int64.min_signed <= ret <= Int64.max_signed)
                |- (Int.min_signed <= ret <= Int.max_signed) =>
            destruct Hrg as [Hlo Hhi];
            unfold Int.min_signed, Int.max_signed, Int64.min_signed, Int64.max_signed in *; lia end. }
        { split.
          { right. right.
            match goal with Hge : (ret >= 0) |- _ =>
              match goal with Hle : (ret <= Zlength pre) |- _ =>
                split; [lia | lia] end end. }
          { match goal with Hrg : (Int64.min_signed <= ret <= Int64.max_signed) |- _ =>
              destruct Hrg as [Hlo Hhi];
              assert (Hmaxu : Int64.max_unsigned = 18446744073709551615) by reflexivity;
              assert (Hmin : Int64.min_signed = -9223372036854775808) by reflexivity;
              assert (Hmax : Int64.max_signed = 9223372036854775807) by reflexivity;
              assert (HU : 0 <= ret <= Int64.max_unsigned) by lia;
              rewrite (Int64.unsigned_repr ret HU);
              reflexivity end. } }
Qed.
