# Tedex Rocq/VST verification — resume notes (2026-10-07 19:15, phiên chốt 15.zip)

## Environment (verified working)
- Switch `rocq-9.2` (OCaml 5.2.1): Rocq 9.2.0 + CompCert 3.18 + coq-vst 2.17 + Flocq 4.2.2.
- Rebuild note: Flocq/VST MUST be built with system gcc (`CC=/usr/bin/gcc`,
  `/usr/bin` before `/opt/conda/bin` in PATH, unset LIBRARY_PATH/CPATH);
  conda `ld`+sysroot breaks Flocq `remake` with `_dl_vsym@GLIBC_PRIVATE`.
- `opam install coq-vst.2.17 -y -j4 --no-depexts` (needs `coq-released` repo
  + conda `clang` for conf-clang).

## File inventory (`~/tedex_proofs/`, packaged in `/home/jovyan/15.zip`)
| File | Status |
|---|---|
| AuthVerdict.v (.vo) | PROVED (7 thms, Qed) |
| EchoModel.v (.vo) | PROVED (13 thms, Qed) |
| AttachHandoff.v (.vo) | PROVED (7 thms, Qed) |
| SysModel.v (.vo) | PROVED (13 thms, Qed) |
| vst_specs.v (.vo) | skeleton, typechecks, documentation only |
| verif_close_fd.v (.vo 72K) | PROVED end-to-end (Qed): tls_close_fd |
| verif_read_chunk.v (.vo 324K) | PROVED end-to-end (Qed, 0 admit): term_read_chunk — DONE 2026-10-07 |
| verif_write_all.v | specs typecheck (coqc EXIT 0), Lemma Admitted (loop proof pending) |
| verif_fd_read.v | specs typecheck (coqc EXIT 0), Lemma Admitted (poll/struct proof pending) |
| ARCH_B_THREAT.md | Reconstructed 2026-10-07: kiến trúc + v11 Trim/Count_Attached/Last_Dropped + BUG + threat model |
| test.v / smoke.v (.vo) | coq proof test PASS + VST Require smoke PASS |
| clight/termhelp.{c,v}, tlswrap.{c,v} | clightgen -normalize exit 0 both |

## verif_read_chunk.v — DONE 2026-10-07 (was PARTIAL in 10.zip)
Fix: nhánh -2/-1 dùng `Himp: ?r<=0->post=pre` (=H5 từ read_spec) + `signed_repr_roundtrip`
rewrite `H6: signed(ret)<signed(0)` rồi lia. Nhánh k>=0: goal thật sau entailer là
`A/\B/\C` (A: Int bounds, B: ret=-1\/-2\/0<=ret<=Zlength pre, C: unsigned_repr cast);
không phải `0<=ret<=max` standalone. Patch: assert Hr/Hz, rewrite Hge, split 3,
B via right-right + Hle, C via unsigned_repr + HU. coqc EXIT 0, grep admit = 0.

## Lessons (verified by compiling probe)
1. Specs + Gprog typecheck; `with_library` accepts all specs.
2. `forward_if` (max<=0) works; then-branch CLOSED by entailer!.
3. `forward_call (0,buf,max,sh,pre)` for `_read` works (explicit witness).
4. Buffer-carrying errno spec (WITH sh,buf,max,post) beats emp-PRE (frame matches directly).
5. Bare `forward_if` fails on `Ssequence(Sifthenelse...)`; workaround: manual
   `repeat (apply -> semax_seq_skip). repeat (apply seq_assoc1; ...)`.
6. `repeat match Hlt: context[...] |- _ => rewrite Hr in Hlt` hits Hr/Hz itself —
   must match specific `Hlt: signed(ret)<signed(0)` then `rewrite Hr,Hz in Hlt`.
7. `rep_lia` fails Cannot find witness → use signed_repr_roundtrip + explicit
   Int64/Int constant reflexivity before lia.
8. VST `Exists _` needs explicit witnesses.

## Next concrete step (whoever resumes)
- write_all loop (`forward_while`, invariant EX off, 0<=off<=n, variant Z.to_nat (n-off),
  pointer b+off via offset_val, errno EINTR=4 continue pattern).
- fd_read_timeout: field_at for 3 Sassign (Efield _fd/_events/_revents), forward_call poll
  with Eaddrof &p, then reuse read_chunk errno JOIN pattern (needs buffer-carrying
  errno_loc_spec + opt_data, current emp-PRE spec must be upgraded).

## Honest scope reminders
- Gallina models prove MODELS transcribed from Ada/C, not the binaries.
- VST specs for read/write/poll/errno/close are AXIOMS over syscalls.
- The 3 errno reads are specified independently (may differ); the proved
  property is branch-structure + memory safety, not errno-value identity
  (needs a ghost global invariant — future work).
- SPARK remains the authority for the Ada code.
