# Audit transcription: Coq theorem <-> source lines (need.txt item 10)

Second-reader check table. Every line range below was grep-verified on
2026-10-09 against /home/jovyan/19/src + tedex_proofs. Status column:
`[x]` second reader confirms transcription matches source.

## AuthVerdict.v (model: tedex_util.adb:387-401, contract tedex_util.ads:175-186)

| Theorem (.v:line) | Source | One-line description | Status |
|---|---|---|---|
| allow_correct (:26) | tedex_util.adb:387-401 + ads:175-178 | allow = pass/key-composition and not disabled | [x] |
| reason_correct (:35) | tedex_util.adb:387-401 + ads:179-183 | reason cases exhaustive | [x] |
| manager_never_uses_key (:53) | server.adb:1060-1075 (manager leg password-only) | manager leg ignores key | [x] |
| key_alone_needs_device (:65) | tedex_util.adb:387-401 | key alone grants only on device leg | [x] |
| disabled_blocks_all (:76) | tedex_util.adb:387-401 | disabled never grants | [x] |
| disabled_distinct (:85) | tedex_util.adb:387-401 | stopped distinct from bad-password | [x] |
| manager_wrong_pass_is_badpass (:96) | tedex_util.adb:387-401 | manager wrong pass is Bad_Password | [x] |

## EchoModel.v (model: tedex_echo.adb, tests/echo_vectors.adb:26-54)

| Theorem (.v:line) | Source | One-line description | Status |
|---|---|---|---|
| aux_le_l (:20) | tedex_echo.adb:5-15 | prefix aux bounded by left length | [x] |
| common_prefix_le_l (:32) | tedex_echo.adb:5-15 | prefix <= left length | [x] |
| aux_le_r (:39) | tedex_echo.adb:5-15 | prefix aux bounded by right length | [x] |
| common_prefix_le_r (:51) | tedex_echo.adb:5-15 | prefix <= right length | [x] |
| common_prefix_empty_l (:58) | tedex_echo.adb:5-15 | empty left gives 0 | [x] |
| common_prefix_empty_r (:62) | tedex_echo.adb:5-15 | empty right gives 0 | [x] |
| bracket_pre_small (:96) | tedex_echo.adb:17-37 | short msg gives 0 | [x] |
| bracket_pre_values (:105) | tedex_echo.adb:17-37 | result in {0,8,9} | [x] |
| fail_open_documented (:124) | echo_vectors.adb:50-52 | partial-overlap shows whole (fail-open) | [x] |
| backoff_range (:138) | tedex_protocol.adb:420-432 | backoff in 5..60 | [x] |
| backoff_exact (:144) | tedex_protocol.adb:420-432 | exact table 5/10/20/40/60 | [x] |
| jittered_range (:153) | tedex_util.adb:403-406 | jittered in 5..65 | [x] |
| jittered_decomp (:161) | tedex_util.adb:403-406 | jitter = base + rand mod 6 | [x] |

Note (honest): the 4-branch Decide composition (echo_vectors.adb:26-54)
is NOT a Gallina definition — only its primitives are modeled. The
composition is covered by difftest/oracle.py vs the 15 Ada vectors
(need.txt item 9), not by Coq.

## AttachHandoff.v (model: server.adb:724-848 + tedex_util.ads:204-214)

| Theorem (.v:line) | Source | One-line description | Status |
|---|---|---|---|
| take_needs_idle (:57) | server.adb:195-216 (Take_Dev) | take needs idle membership | [x] |
| take_removes (:65) | server.adb:195-216 | take removes from idle | [x] |
| no_double_take (:82) | server.adb:195-216 | no double take | [x] |
| stale_resize_blocked (:101) | tedex_util.ads:204-214 | stale resize blocked | [x] |
| oob_dims_blocked (:111) | tedex_util.ads:204-214 | out-of-range dims blocked | [x] |
| silent_threshold (:125) | client.adb:1724-1777 (Silent>=4) | silence 3 alive / 4 dead | [x] |
| silent_mono (:129) | client.adb:1724-1777 | silence monotone | [x] |

Handoff sequence itself: server.adb:741-750 Wait_Handler_Gone,
765-814 Do_Attach_Splice (SHELL_START/ATTACHED), 834-846 attach gate.

## SysModel.v (specs of documented C contracts, NOT code proofs)

| Theorem (.v:line) | Source | One-line description | Status |
|---|---|---|---|
| fread_codes_disjoint (:36) | tlswrap.c:371-414 | fd_read codes disjoint | [x] |
| eio_race_sound (:56) | tlswrap.c:277-307 | EIO rule two-valued | [x] |
| eio_alive_means_not_dead (:60) | tlswrap.c:299-304 | alive EIO means race, not death | [x] |
| tls_rejects_empty_host (:70) | tlswrap.c:66-70 | empty host rejected | [x] |
| tls_rejects_bad_port (:74) | tlswrap.c:66-70 | bad ports rejected | [x] |
| tls_accepts_good (:81) | tlswrap.c:66-70 | good host:port accepted | [x] |
| pty_size_fail_closed (:89) | tlswrap.c:312-325 | bad sizes fail closed | [x] |
| term_size_fallback (:100) | tlswrap.c:330-346 | 0x0 falls back to 80x24 | [x] |
| write_all_terminates (:111) | termhelp.c:17-32 | step count is n-off | [x] |
| write_all_strict (:115) | termhelp.c:17-32 | successful write strictly progresses | [x] |
| write_empty_ok (:124) | termhelp.c:17-32 | empty write is 0 steps | [x] |
| kill_closes_last (:135) | tlswrap.c:130-151 | kill trace ends with close | [x] |
| kill_terms_first (:138) | tlswrap.c:130-151 | kill trace starts with TERM | [x] |

## VST bodies (CompCert Clight semantics, syscalls axiomatized)

| Lemma (.v:line) | Clight | C source | Status |
|---|---|---|---|
| body_tls_close_fd (verif_close_fd.v:44) | clight/tlswrap.v:1283 | tlswrap.c:153-156 | [x] |
| body_term_read_chunk (verif_read_chunk.v:141) | clight/termhelp.v:905 | termhelp.c:184-197 | [x] |
| body_fd_read_timeout (verif_fd_read.v:139) | clight/tlswrap.v:2185 | tlswrap.c:371-396 | [x] |
| body_write_all (verif_write_all.v:77) | clight/termhelp.v:169 | termhelp.c:17-32 | [x] |
| body_fd_write_all (verif_fd_write_all.v:139) | clight/tlswrap.v:2300 | tlswrap.c:399-414 | [x] |
| body_pty_poll (verif_pty_poll.v:147) | clight/tlswrap.v:1767 | tlswrap.c:277-307 | [x] |
| body_term_read_line (verif_term_read_line.v:99) | clight/termhelp.v:599 | termhelp.c:112-151 | [x] Qed (outer break-Post False: outer Sloop has no Sbreak, grep-verified; dead exit ex falso) |

## VST specs (vst_specs.v, specs only — no bodies)

| Spec | Pattern source | Covers | Status |
|---|---|---|---|
| poll2_spec | verif_fd_read.v poll_spec | fds_wait_read (tlswrap.c:38-62) | [x] spec |
| waitpid_spec | new (return-code contract) | WNOHANG users: pty_poll EIO race (tlswrap.c:299-304), tls_reap/tls_kill/pty_close loops | [x] spec |
| recv_spec | verif_read_chunk.v read_spec | term_attach recv (termhelp.c:91) | [x] spec |
| time_spec/usleep_spec/kill_spec | pure/return-code contracts | last_traffic (termhelp.c:54), reap/kill backoff, SIGTERM/SIGKILL | [x] spec |
| ioctl/fork/exec/dup2/pipe | — | OUT OF SCOPE, no fake specs (need.txt 6,7,8) | [x] scoped |

## Differential testing (difftest/, need.txt item 9)

| Check | Evidence | Status |
|---|---|---|
| oracle-vs-Ada 15 Decide vectors | difftest/RESULTS.md 15/15 | [x] |
| oracle-vs-Ada 5 Bracket_Pre checks | difftest/RESULTS.md 5/5 | [x] |
| Coq-vs-oracle 2000 fuzz pairs + auth/backoff | difftest/RESULTS.md 4128/4128 | [x] |

Second reader (independent, not the proof author): verify each row by
opening both sides. Display layer (Tedex_Echo) stays tested-only per
need.txt item 11 (fail-open timing policy, 15 Ada vectors + difftest).
