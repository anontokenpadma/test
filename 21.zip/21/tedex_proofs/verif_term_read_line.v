(* VST specification of term_read_line (termhelp.c:112-151) — need.txt item 5.
   HONEST STATUS 2026-10-10: Qed TRỌN VẸN (coqc EXIT 0, 0 admit tactic,
   DONE 2026-10-10; was 2 admits + Admitted).
   Design: write_all loop pattern (forward_loop + TT for unbounded errno
   cells) + read_chunk JOIN idioms (t2-JOIN EX t2 relation) + poll_wait
   spec (timeout -1, data_at_) + read1 spec (single byte via &c, concrete
   byte value + Byte-range PROP) + buffer store via forward (upd_Znth
   automatic) + nested discard loop (inner forward_loop [entry|body],
   flag JOINs, break/continue) + outer break-Post False (sound: outer
   Sloop has NO Sbreak — verified by grep; dead exit proved ex falso
   via Intro_prop + contradiction).
   Syscall model: poll/read/errno AXIOMS (EINTR=4). HONEST SCOPE:
   branch-structure + memory safety + byte counts (NOT line CONTENT). *)
Require Import VST.floyd.proofauto.
Require Import Clight.termhelp.
Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.
Lemma int_signed_roundtrip : forall z : Z,
  Int.min_signed <= z <= Int.max_signed -> Int.signed (Int.repr z) = z.
Proof.
  intros z [Hlo Hhi].
  assert (Hmin : Int.min_signed = -2147483648) by reflexivity.
  assert (Hmax : Int.max_signed = 2147483647) by reflexivity.
  rewrite Hmin in Hlo. rewrite Hmax in Hhi. rewrite Int.signed_repr_eq.
  assert (HM : Int.modulus = 4294967296) by reflexivity.
  assert (HH : Int.half_modulus = 2147483648) by reflexivity. rewrite HM, HH.
  destruct (Z_lt_ge_dec z 0) as [Hneg|Hnn].
  - assert (Hm : z mod 4294967296 = z + 4294967296).
    { assert (HzM : 0 <= z + 4294967296 < 4294967296) by lia.
      assert (He : (z + 1 * 4294967296) mod 4294967296 = z mod 4294967296). { apply Z.mod_add. lia. }
      assert (He2 : z + 1 * 4294967296 = z + 4294967296) by lia. rewrite He2 in He. rewrite <- He. rewrite (Z.mod_small _ _ HzM). reflexivity. }
    rewrite Hm. destruct (zlt (z + 4294967296) 2147483648) as [Hc|Hc]. + exfalso. lia. + lia.
  - assert (Hm0 : z mod 4294967296 = z). { apply Z.mod_small. lia. } rewrite Hm0. destruct (zlt z 2147483648) as [Hc|Hc]. + reflexivity. + exfalso. lia.
Qed.
Definition poll_wait_spec : ident * funspec :=
  DECLARE _poll
  WITH fds : val, sh : share
  PRE [ tptr (Tstruct _pollfd noattr), tulong, tint ]
    PROP (writable_share sh)
    PARAMS (fds; Vlong (Int64.repr 1); Vint (Int.repr (-1)))
    GLOBALS ()
    SEP (data_at_ sh (Tstruct _pollfd noattr) fds)
  POST [ tint ]
    EX s : Z, EX rev' : Z,
    PROP (Int.min_signed <= s <= Int.max_signed;
          Int.min_signed <= rev' <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr s)))
    SEP (data_at_ sh (Tstruct _pollfd noattr) fds).
Definition read1_spec : ident * funspec :=
  DECLARE _read
  WITH fd : Z, cptr : val, sh : share, old : val
  PRE [ tint, tptr tvoid, tulong ]
    PROP (0 <= fd <= Int.max_signed; readable_share sh)
    PARAMS (Vint (Int.repr fd); cptr; Vlong (Int64.repr 1))
    GLOBALS ()
    SEP (data_at sh tschar old cptr)
  POST [ tlong ]
    EX k : Z, EX newb : Z,
    PROP (Int64.min_signed <= k <= Int64.max_signed;
          k <= 1;
          Byte.min_signed <= newb <= Byte.max_signed)
    LOCAL (temp ret_temp (Vlong (Int64.repr k)))
    SEP (data_at sh tschar (Vint (Int.repr newb)) cptr).
Definition errno_loc_spec : ident * funspec :=
  DECLARE ___errno_location
  WITH sh : share, buf : val, n : Z, post : list val
  PRE [ ]
    PROP (0 <= n <= Int.max_signed; Zlength post = n; writable_share sh)
    PARAMS () GLOBALS ()
    SEP (data_at sh (tarray tschar n) post buf)
  POST [ tptr tint ]
    EX p : val, EX e : Z,
    PROP (Int.min_signed <= e <= Int.max_signed)
    LOCAL (temp ret_temp p)
    SEP (data_at sh (tarray tschar n) post buf;
         data_at sh tint (Vint (Int.repr e)) p).
Definition term_read_line_spec : ident * funspec :=
  DECLARE _term_read_line
  WITH buf : val, max : Z, sh : share, pre : list val
  PRE [ tptr tschar, tint ]
    PROP (1 < max <= Int.max_signed;
          Zlength pre = max;
          writable_share sh)
    PARAMS (buf; Vint (Int.repr max))
    GLOBALS ()
    SEP (data_at sh (tarray tschar max) pre buf)
  POST [ tint ]
    EX ret : Z, EX post : list val,
    PROP ((ret = -1 \/ ret = 0 \/ 1 <= ret <= max - 1);
          Zlength post = max)
    LOCAL (temp ret_temp (Vint (Int.repr ret)))
    SEP (data_at sh (tarray tschar max) post buf; TT).
Definition Gprog : funspecs :=
  ltac:(with_library prog [poll_wait_spec; read1_spec; errno_loc_spec; term_read_line_spec]).
Lemma body_term_read_line :
  semax_body Vprog Gprog f_term_read_line term_read_line_spec.
Proof.
  start_function.
  forward.
  forward_if.
  - forward. Exists (-1) pre. entailer!.
  - repeat (apply -> semax_seq_skip).
    forward_loop (EX n : Z, EX post : list val, EX cb : val,
      PROP (0 <= n <= max - 1;
            Zlength post = max;
            (n = 0 -> post = pre))
      LOCAL (temp _buf buf; temp _max (Vint (Int.repr max));
             temp _n (Vint (Int.repr n));
             lvar _p (Tstruct _pollfd noattr) v_p;
             lvar _c tschar v_c)
      SEP (data_at sh (tarray tschar max) post buf; TT;
           data_at_ Tsh (Tstruct _pollfd noattr) v_p;
           data_at Tsh tschar cb v_c))
    continue: (EX n : Z, EX post : list val, EX cb : val,
      PROP (0 <= n <= max - 1;
            Zlength post = max;
            (n = 0 -> post = pre))
      LOCAL (temp _buf buf; temp _max (Vint (Int.repr max));
             temp _n (Vint (Int.repr n));
             lvar _p (Tstruct _pollfd noattr) v_p;
             lvar _c tschar v_c)
      SEP (data_at sh (tarray tschar max) post buf; TT;
           data_at_ Tsh (Tstruct _pollfd noattr) v_p;
           data_at Tsh tschar cb v_c))
    break: (EX n : Z, EX post : list val, EX cb : val,
      PROP (False)
      LOCAL (temp _buf buf; temp _max (Vint (Int.repr max));
             lvar _p (Tstruct _pollfd noattr) v_p;
             lvar _c tschar v_c)
      SEP (data_at sh (tarray tschar max) post buf; TT;
           data_at_ Tsh (Tstruct _pollfd noattr) v_p;
           data_at Tsh tschar cb v_c)).
    + Exists 0 pre Vundef. entailer!.
    + Intros n post cb.
      repeat forward.
      forward_call (v_p, Tsh).
      Intros sv. destruct sv as [ss rev2].
      change (fst (ss, rev2)) with ss in *.
      change (snd (ss, rev2)) with rev2 in *.
      repeat (apply -> semax_seq_skip).
      repeat (apply seq_assoc1; try apply -> semax_seq_skip).
      forward_if.
      * forward_call (sh, buf, max, post).
        Intros v1. destruct v1 as [p1 e1].
        change (fst (p1, e1)) with p1 in *.
        change (snd (p1, e1)) with e1 in *.
        forward.
        forward_if.
        -- forward. Exists n post cb. entailer!.
        -- repeat (apply -> semax_seq_skip).
           repeat (apply seq_assoc1; try apply -> semax_seq_skip).
           forward_if (EX t2 : Z,
             PROP ((t2 = n /\ 0 < n) \/ (t2 = -1 /\ n = 0))
             LOCAL (temp _n (Vint (Int.repr n));
                    temp _buf buf; temp _max (Vint (Int.repr max));
                    temp _t'2 (Vint (Int.repr t2));
                    lvar _p (Tstruct _pollfd noattr) v_p;
                    lvar _c tschar v_c)
             SEP (data_at sh (tarray tschar max) post buf; TT;
                  data_at_ Tsh (Tstruct _pollfd noattr) v_p;
                  data_at Tsh tschar cb v_c)).
           ++ forward. Exists n. entailer!.
           ++ forward. Exists (-1). entailer!.
           ++ Intros t2.
              forward. Exists t2 post. entailer!.
      * forward_call.
        Intros v. destruct v as [k2 b2].
        change (fst (k2, b2)) with k2 in *.
        change (snd (k2, b2)) with b2 in *.
        repeat (apply -> semax_seq_skip).
        repeat (apply seq_assoc1; try apply -> semax_seq_skip).
        forward_if.
        -- forward_call (sh, buf, max, post).
           Intros v1. destruct v1 as [p1 e1].
           change (fst (p1, e1)) with p1 in *.
           change (snd (p1, e1)) with e1 in *.
           forward.
           forward_if.
           ++ forward. Exists n post (Vint (Int.repr b2)). entailer!.
           ++ repeat (apply -> semax_seq_skip).
              repeat (apply seq_assoc1; try apply -> semax_seq_skip).
              forward_if (EX t2 : Z,
                PROP ((t2 = n /\ 0 < n) \/ (t2 = -1 /\ n = 0))
                LOCAL (temp _n (Vint (Int.repr n));
                       temp _buf buf; temp _max (Vint (Int.repr max));
                       temp _t'6 (Vint (Int.repr t2));
                       lvar _p (Tstruct _pollfd noattr) v_p;
                       lvar _c tschar v_c)
                SEP (data_at sh (tarray tschar max) post buf; TT;
                     data_at_ Tsh (Tstruct _pollfd noattr) v_p;
                     data_at Tsh tschar (Vint (Int.repr b2)) v_c)).
              ** forward. Exists n. entailer!.
              ** forward. Exists (-1). entailer!.
              ** Intros t2.
                 forward. Exists t2 post. entailer!.
        -- repeat (apply -> semax_seq_skip).
           repeat (apply seq_assoc1; try apply -> semax_seq_skip).
           forward_if.
           ++ forward. Exists n post. entailer!.
           ++ repeat (apply -> semax_seq_skip).
              repeat (apply seq_assoc1; try apply -> semax_seq_skip).
              forward_if (EX n : Z, EX post : list val,
                PROP (0 <= n <= max - 1;
                      Zlength post = max;
                      (n = 0 -> post = pre))
                LOCAL (temp _buf buf; temp _max (Vint (Int.repr max));
                       temp _n (Vint (Int.repr n));
                       lvar _p (Tstruct _pollfd noattr) v_p;
                       lvar _c tschar v_c)
                SEP (data_at sh (tarray tschar max) post buf; TT;
                     data_at_ Tsh (Tstruct _pollfd noattr) v_p;
                     data_at Tsh tschar (Vint (Int.repr b2)) v_c)).
              ** forward. forward. forward. forward.
                 Exists (n + 1) (upd_Znth n post (Vint (Int.repr b2))).
                 entailer!.
              ** forward. Exists n post. entailer!.
              ** Intros n1 post1.
                 forward.
                 forward_if.
                 { 
                   repeat (apply -> semax_seq_skip).
                   repeat (apply seq_assoc1; try apply -> semax_seq_skip).
                   forward_if (EX cbI : val,
                     PROP ()
                     LOCAL (temp _buf buf; temp _max (Vint (Int.repr max));
                            temp _n (Vint (Int.repr n1));
                            lvar _p (Tstruct _pollfd noattr) v_p;
                            lvar _c tschar v_c)
                     SEP (data_at sh (tarray tschar max) post1 buf; TT;
                          data_at_ Tsh (Tstruct _pollfd noattr) v_p;
                          data_at Tsh tschar cbI v_c)).
                   - forward_loop (EX cbI2 : val,
                       PROP ()
                       LOCAL (temp _buf buf; temp _max (Vint (Int.repr max));
                              temp _n (Vint (Int.repr n1));
                              lvar _p (Tstruct _pollfd noattr) v_p;
                              lvar _c tschar v_c)
                       SEP (data_at sh (tarray tschar max) post1 buf; TT;
                            data_at_ Tsh (Tstruct _pollfd noattr) v_p;
                            data_at Tsh tschar cbI2 v_c))
                     continue: (EX cbI2 : val,
                       PROP ()
                       LOCAL (temp _buf buf; temp _max (Vint (Int.repr max));
                              temp _n (Vint (Int.repr n1));
                              lvar _p (Tstruct _pollfd noattr) v_p;
                              lvar _c tschar v_c)
                       SEP (data_at sh (tarray tschar max) post1 buf; TT;
                            data_at_ Tsh (Tstruct _pollfd noattr) v_p;
                            data_at Tsh tschar cbI2 v_c))
                     break: (EX cbI2 : val,
                       PROP ()
                       LOCAL (temp _buf buf; temp _max (Vint (Int.repr max));
                              temp _n (Vint (Int.repr n1));
                              lvar _p (Tstruct _pollfd noattr) v_p;
                              lvar _c tschar v_c)
                       SEP (data_at sh (tarray tschar max) post1 buf; TT;
                            data_at_ Tsh (Tstruct _pollfd noattr) v_p;
                            data_at Tsh tschar cbI2 v_c)).
                     + Exists (Vint (Int.repr b2)). entailer!.
                     + Intros cbI2.
                       forward.
                       forward_call.
                       Intros v3. destruct v3 as [k3 b3].
                       change (fst (k3, b3)) with k3 in *.
                       change (snd (k3, b3)) with b3 in *.
                       repeat (apply -> semax_seq_skip).
                       repeat (apply seq_assoc1; try apply -> semax_seq_skip).
                       forward_if (EX t9 : Z,
                         PROP ()
                         LOCAL (temp _k (Vlong (Int64.repr k3));
                                temp _buf buf; temp _max (Vint (Int.repr max));
                                temp _n (Vint (Int.repr n1));
                                lvar _p (Tstruct _pollfd noattr) v_p;
                                lvar _c tschar v_c;
                                temp _t'9 (Vint (Int.repr t9)))
                         SEP (data_at sh (tarray tschar max) post1 buf; TT;
                              data_at_ Tsh (Tstruct _pollfd noattr) v_p;
                              data_at Tsh tschar (Vint (Int.repr b3)) v_c)).
                       * forward. Exists 1. entailer!.
                       * forward. forward.
                         Exists (if Int.eq (Int.repr b3) (Int.repr 10) then 1 else 0).
                         entailer!.
                       * Intros t9.
                         forward_if.
                         -- forward. Exists (Vint (Int.repr b3)). entailer!.
                         -- forward. Exists (Vint (Int.repr b3)). entailer!.
                     + Intros cbI2.
                       Exists cbI2. entailer!.
                   - fwd_skip. Exists (Vint (Int.repr b2)). entailer!.
                   - Intros cbI'.
                     forward. Exists n1 post1. entailer!.
                     }
                 { fwd_skip. Exists n1 post1 (Vint (Int.repr b2)). entailer!. }
    + Intro n0. Intro post0. Intro cb0. repeat Intro_prop. contradiction.

Qed.