(* Step 2 (SPECS, typechecked with VST — need.txt item 2, DONE 2026-10-09):
   VST/Verifiable-C specifications for the remaining C syscalls, in the
   exact style of the proved files (WITH/PRE/POST + opt_data):
   - verif_read_chunk.v: read_spec + errno_loc_spec (buffer-carrying)
   - verif_fd_read.v: poll_spec (1 fd) + read_spec + errno_loc_spec
   - verif_write_all.v / verif_fd_write_all.v: write offset-spec + errno
   This file adds, following the same patterns:
   - poll2_spec (fds_wait_read, tlswrap.c:38-62): 2-fd poll array
   - waitpid_spec (tls_reap/tls_kill/pty_close/pty_poll waitpid(WNOHANG)):
     return-code contract (0 alive / pid reaped / -1 error), status cell
     carried as data_at_ (may be clobbered — honest over-approx)
   - recv_spec (term_attach recv path, termhelp.c:91): like read_spec
   - time_spec (time(0) for last_traffic): pure, emp
   - usleep_spec (tls_reap/tls_kill/pty_close backoff): pure, emp
   - kill_spec (tls_kill/pty_close SIGTERM/SIGKILL): return-code, emp
   - opt_data (shared helper, same definition as read_chunk/fd_read)
   Specs only: no semax_body proofs here (each gets its verif_*.v file).
   HONEST SCOPE: every DECLARE is an AXIOM over the OS (same status as
   the proved files' read/write/poll/errno specs). Branch-structure +
   memory safety only, not value identity across calls (need.txt item 1).
   OUT OF SCOPE (need.txt items 6,7,8 — deliberately NO specs, no fake
   proofs; see SysModel.v + AUDIT_TRANSCRIPTION.md):
   - ioctl (pty_set_size/term_get_size, tlswrap.c:312-346): VST has no
     ioctl model; validation bounds proved in SysModel.v instead.
   - fork/exec/setsid/dup2/pipe (tls_open/pty_spawn_bash): process
     creation is beyond VST; integration tests, not proofs.
   - waitpid blocking form waitpid(pid,&st,0) (tls_kill/pty_close tail):
     signal semantics beyond VST; return-code spec only (waitpid_spec
     covers WNOHANG which is what pty_poll + reap loops need).
   Compiles with VST + tlswrap Clight (for Tstruct _pollfd). *)

Require Import VST.floyd.proofauto.
Require Import Clight.tlswrap.
Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Import Clightdefs.ClightNotations.
Local Open Scope string_scope.
Local Open Scope clight_scope.

(* Idents for termhelp-only externals (mirror Clight.termhelp). *)
Definition _recv : ident := $"recv".
Definition _time : ident := $"time".

(* Optional errno/status-cell ownership (same as verif_read_chunk.v). *)
Definition opt_data (sh : share) (o : option (val * Z)) : mpred :=
  match o with
  | None => emp
  | Some (p, e) => data_at sh tint (Vint (Int.repr e)) p
  end.

(* fds_wait_read (tlswrap.c:38-62): poll on 2 fds, bitmask out.
   Returns bitmask (1 and/or 2), 0 timeout, -2 EINTR, -1 error.
   Mirrors poll_spec (verif_fd_read.v) with a 2-element array. *)
Definition poll2_spec : ident * funspec :=
  DECLARE _poll
  WITH fds : val, sh : share,
       fd1 : Z, ev1 : Z, rev1 : Z, fd2 : Z, ev2 : Z, rev2 : Z, timeout : Z
  PRE [ tptr (Tstruct _pollfd noattr), tulong, tint ]
    PROP (0 <= timeout <= Int.max_signed;
          Int.min_signed <= fd1 <= Int.max_signed;
          Int.min_signed <= fd2 <= Int.max_signed;
          writable_share sh)
    PARAMS (fds; Vlong (Int64.repr 2); Vint (Int.repr timeout))
    GLOBALS ()
    SEP (data_at sh (tarray (Tstruct _pollfd noattr) 2)
           ((Vint (Int.repr fd1), (Vint (Int.repr ev1), Vint (Int.repr rev1))) ::
            (Vint (Int.repr fd2), (Vint (Int.repr ev2), Vint (Int.repr rev2))) :: nil) fds)
  POST [ tint ]
    EX s : Z, EX rev1' : Z, EX rev2' : Z,
    PROP (Int.min_signed <= s <= Int.max_signed;
          Int.min_signed <= rev1' <= Int.max_signed;
          Int.min_signed <= rev2' <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr s)))
    SEP (data_at sh (tarray (Tstruct _pollfd noattr) 2)
           ((Vint (Int.repr fd1), (Vint (Int.repr ev1), Vint (Int.repr rev1'))) ::
            (Vint (Int.repr fd2), (Vint (Int.repr ev2), Vint (Int.repr rev2'))) :: nil) fds).

(* waitpid(pid, &st, WNOHANG=1) as used by pty_poll (tlswrap.c:299-304),
   tls_reap (tlswrap.c:119-127), tls_kill, pty_close.
   Returns 0 (child alive), pid (reaped), or -1 (error/ECHILD).
   Status cell may be clobbered: data_at_ on both sides (honest). *)
Definition waitpid_spec : ident * funspec :=
  DECLARE _waitpid
  WITH pid : Z, stptr : val, sh : share
  PRE [ tint, tptr tint, tint ]
    PROP (0 < pid <= Int.max_signed; readable_share sh)
    PARAMS (Vint (Int.repr pid); stptr; Vint (Int.repr 1))
    GLOBALS ()
    SEP (data_at_ sh tint stptr)
  POST [ tint ]
    EX r : Z,
    PROP ((r = 0 \/ r = pid \/ r = -1);
          Int.min_signed <= r <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr r)))
    SEP (data_at_ sh tint stptr).

(* recv (term_attach relay, termhelp.c:91): like read_spec.
   Nondeterministic POSIX behaviour; buffer may change iff ret > 0. *)
Definition recv_spec : ident * funspec :=
  DECLARE _recv
  WITH fd : Z, buf : val, n : Z, sh : share, pre : list val
  PRE [ tint, tptr tvoid, tulong, tint ]
    PROP (0 <= fd <= Int.max_signed;
          0 < n <= Int64.max_unsigned;
          Zlength pre = n;
          writable_share sh)
    PARAMS (Vint (Int.repr fd); buf; Vlong (Int64.repr n); Vint (Int.repr 0))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre buf)
  POST [ tlong ]
    EX ret : Z, EX post : list val,
    PROP (Int64.min_signed <= ret <= Int64.max_signed;
          ret <= n;
          Zlength post = n;
          (ret <= 0 -> post = pre))
    LOCAL (temp ret_temp (Vlong (Int64.repr ret)))
    SEP (data_at sh (tarray tschar n) post buf).

(* time(0) (term_attach last_traffic, termhelp.c:54): pure. *)
Definition time_spec : ident * funspec :=
  DECLARE _time
  WITH tptr_arg : val
  PRE [ tptr tlong ]
    PROP (True)
    PARAMS (tptr_arg) GLOBALS () SEP (emp)
  POST [ tlong ]
    EX t : Z,
    PROP (0 <= t <= Int64.max_signed)
    LOCAL (temp ret_temp (Vlong (Int64.repr t)))
    SEP (emp).

(* usleep (tls_reap/tls_kill/pty_close backoff, 100000us): pure. *)
Definition usleep_spec : ident * funspec :=
  DECLARE _usleep
  WITH usec : Z
  PRE [ tuint ]
    PROP (0 <= usec <= Int.max_unsigned)
    PARAMS (Vint (Int.repr usec)) GLOBALS () SEP (emp)
  POST [ tint ]
    PROP (True)
    LOCAL (temp ret_temp (Vint (Int.repr 0)))
    SEP (emp).

(* kill(pid, sig) (tls_kill SIGTERM/SIGKILL, tlswrap.c:139-149,
   pty_close): return-code contract only (0 ok / -1 error), emp. *)
Definition kill_spec : ident * funspec :=
  DECLARE _kill
  WITH pid : Z, sig : Z
  PRE [ tint, tint ]
    PROP (Int.min_signed <= pid <= Int.max_signed;
          Int.min_signed <= sig <= Int.max_signed)
    PARAMS (Vint (Int.repr pid); Vint (Int.repr sig)) GLOBALS () SEP (emp)
  POST [ tint ]
    EX r : Z,
    PROP ((r = 0 \/ r = -1);
          Int.min_signed <= r <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr r)))
    SEP (emp).
