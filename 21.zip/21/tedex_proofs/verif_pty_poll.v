(* VST specification of pty_poll (tlswrap.c:277-307):
     int pty_poll(int master, int pid, char *buf, int max, int timeout_ms)
     { poll(&p,1,timeout); s<0: EINTR->0 else -2; s==0 -> 0;
       k=read(master,buf,max); k>0 -> (int)k;
       k<0: EAGAIN/EWOULDBLOCK/EINTR -> 0 (3 errno reads, JOIN);
       k<0: EIO -> waitpid(pid,&st,WNOHANG)==0 ? 0 (race) : -1;
       else -1 (incl. k==0). }
   HONEST STATUS 2026-10-09: Qed TRỌN VẸN (coqc EXIT 0, 0 admit tactic,
   DONE 2026-10-09; need.txt item 4).
   Design: fd_read poll part (bare s<0-if + explicit inner Post, lvar _p,
   concrete poll struct on straight paths) + read_chunk JOIN#2/#3
   (EX t6/o2, EX t4/o3, opt_data) + EIO JOIN (EX t10/o4) + waitpid_spec
   (WNOHANG return-code contract, data_at_ status cell) + fd_read k>0
   splits (Int-bounds/disjunction/unsigned_repr, Ogt hyp flipped sides)
   + fwd_skip for Sskip-to-explicit-Post joins + outer k<=0 hyp persisting
   through all joins for post=pre (no PROP tracking needed). 4 errno
   sites -> o1..o4 (o1 doubles as poll-cell / read-cell#1: paths
   exclusive). lvar _st + data_at_ carried in every explicit Post.
   Syscall model: poll/read/errno/waitpid AXIOMS. EAGAIN=11,
   EWOULDBLOCK=11, EINTR=4, EIO=5, WNOHANG=1. HONEST SCOPE same as
   read_chunk/fd_read (branch-structure + memory safety). *)
Require Import VST.floyd.proofauto.
Require Import Clight.tlswrap.
Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.
Definition opt_data (sh : share) (o : option (val * Z)) : mpred :=
  match o with | None => emp | Some (p, e) => data_at sh tint (Vint (Int.repr e)) p end.
Lemma signed_repr_roundtrip : forall z : Z,
  Int64.min_signed <= z <= Int64.max_signed ->
  Int64.signed (Int64.repr z) = z.
Proof.
  intros z [Hlo Hhi].
  assert (Hmin : Int64.min_signed = -9223372036854775808) by reflexivity.
  assert (Hmax : Int64.max_signed = 9223372036854775807) by reflexivity.
  rewrite Hmin in Hlo. rewrite Hmax in Hhi.
  rewrite Int64.signed_repr_eq.
  assert (HM : Int64.modulus = 18446744073709551616) by reflexivity.
  assert (HH : Int64.half_modulus = 9223372036854775808) by reflexivity.
  rewrite HM, HH.
  destruct (Z_lt_ge_dec z 0) as [Hneg|Hnn].
  - assert (Hm : z mod 18446744073709551616 = z + 18446744073709551616).
    { assert (HzM : 0 <= z + 18446744073709551616 < 18446744073709551616) by lia.
      assert (He : (z + 1 * 18446744073709551616) mod 18446744073709551616 = z mod 18446744073709551616).
      { apply Z.mod_add. lia. }
      assert (He2 : z + 1 * 18446744073709551616 = z + 18446744073709551616) by lia.
      rewrite He2 in He. rewrite <- He. rewrite (Z.mod_small _ _ HzM). reflexivity. }
    rewrite Hm.
    destruct (zlt (z + 18446744073709551616) 9223372036854775808) as [Hc|Hc].
    + exfalso. lia.
    + lia.
  - assert (Hm0 : z mod 18446744073709551616 = z).
    { apply Z.mod_small. lia. }
    rewrite Hm0.
    destruct (zlt z 9223372036854775808) as [Hc|Hc].
    + reflexivity.
    + exfalso. lia.
Qed.
Definition poll_spec : ident * funspec :=
  DECLARE _poll
  WITH fds : val, sh : share, fdfd : Z, ev : Z, rev : Z, timeout : Z
  PRE [ tptr (Tstruct _pollfd noattr), tulong, tint ]
    PROP (0 <= timeout <= Int.max_signed;
          Int.min_signed <= fdfd <= Int.max_signed;
          writable_share sh)
    PARAMS (fds; Vlong (Int64.repr 1); Vint (Int.repr timeout))
    GLOBALS ()
    SEP (data_at sh (Tstruct _pollfd noattr)
           (Vint (Int.repr fdfd), (Vint (Int.repr ev), Vint (Int.repr rev))) fds)
  POST [ tint ]
    EX s : Z, EX rev' : Z,
    PROP (Int.min_signed <= s <= Int.max_signed;
          Int.min_signed <= rev' <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr s)))
    SEP (data_at sh (Tstruct _pollfd noattr)
           (Vint (Int.repr fdfd), (Vint (Int.repr ev), Vint (Int.repr rev'))) fds).
Definition read_spec : ident * funspec :=
  DECLARE _read
  WITH fd : Z, buf : val, n : Z, sh : share, pre : list val
  PRE [ tint, tptr tvoid, tulong ]
    PROP (0 <= fd <= Int.max_signed;
          0 < n <= Int64.max_unsigned;
          Zlength pre = n;
          writable_share sh)
    PARAMS (Vint (Int.repr fd); buf; Vlong (Int64.repr n))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre buf)
  POST [ tlong ]
    EX ret : Z, EX post : list val,
    PROP (Int64.min_signed <= ret <= Int64.max_signed;
          ret <= n;
          Zlength post = n;
          (ret <= 0 -> post = pre))
    LOCAL (temp ret_temp (Vlong (Int64.repr ret)))
    SEP (data_at sh (tarray tschar n) post buf).
Definition errno_loc_spec : ident * funspec :=
  DECLARE ___errno_location
  WITH sh : share, buf : val, n : Z, post : list val
  PRE [ ]
    PROP (0 <= n <= Int.max_signed; Zlength post = n; writable_share sh)
    PARAMS () GLOBALS ()
    SEP (data_at sh (tarray tschar n) post buf)
  POST [ tptr tint ]
    EX p : val, EX e : Z,
    PROP (Int.min_signed <= e <= Int.max_signed)
    LOCAL (temp ret_temp p)
    SEP (data_at sh (tarray tschar n) post buf;
         data_at sh tint (Vint (Int.repr e)) p).
Definition waitpid_spec : ident * funspec :=
  DECLARE _waitpid
  WITH pid : Z, stptr : val, sh : share
  PRE [ tint, tptr tint, tint ]
    PROP (0 < pid <= Int.max_signed; readable_share sh)
    PARAMS (Vint (Int.repr pid); stptr; Vint (Int.repr 1))
    GLOBALS ()
    SEP (data_at_ sh tint stptr)
  POST [ tint ]
    EX r : Z,
    PROP ((r = 0 \/ r = pid \/ r = -1);
          Int.min_signed <= r <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr r)))
    SEP (data_at_ sh tint stptr).
Definition pty_poll_spec : ident * funspec :=
  DECLARE _pty_poll
  WITH master : Z, pid : Z, buf : val, max : Z, timeout : Z, sh : share, pre : list val
  PRE [ tint, tint, tptr tschar, tint, tint ]
    PROP (0 <= master <= Int.max_signed;
          0 < pid <= Int.max_signed;
          0 < max <= Int.max_signed;
          0 <= timeout <= Int.max_signed;
          Zlength pre = max;
          writable_share sh)
    PARAMS (Vint (Int.repr master); Vint (Int.repr pid); buf; Vint (Int.repr max); Vint (Int.repr timeout))
    GLOBALS ()
    SEP (data_at sh (tarray tschar max) pre buf)
  POST [ tint ]
    EX ret : Z, EX post : list val,
    EX o1 o2 o3 o4 : option (val * Z),
    PROP (Int.min_signed <= ret <= Int.max_signed;
          Zlength post = max;
          (ret = -2 \/ ret = -1 \/ ret = 0 \/ 0 <= ret <= max);
          (ret <= 0 -> post = pre))
    LOCAL (temp ret_temp (Vint (Int.repr ret)))
    SEP (data_at sh (tarray tschar max) post buf;
         opt_data sh o1; opt_data sh o2; opt_data sh o3; opt_data sh o4).
Definition Gprog : funspecs :=
  ltac:(with_library prog [poll_spec; read_spec; errno_loc_spec; waitpid_spec; pty_poll_spec]).
Lemma body_pty_poll : semax_body Vprog Gprog f_pty_poll pty_poll_spec.
Proof.
  start_function.
  forward. forward. forward.
  forward_call.
  Intros s. destruct s as [ss rev2].
  change (fst (ss, rev2)) with ss in *.
  change (snd (ss, rev2)) with rev2 in *.
  repeat (apply -> semax_seq_skip).
  repeat (apply seq_assoc1; try apply -> semax_seq_skip).
  forward_if.
  - forward_call (sh, buf, max, pre).
    Intros v1. destruct v1 as [p1 e1].
    change (fst (p1, e1)) with p1 in *.
    change (snd (p1, e1)) with e1 in *.
    forward.
    pose (E1 := e1). pose (P1 := p1).
    forward_if (PROP ()
      LOCAL (temp _t'16 (Vint (Int.repr E1)); temp _t'2 P1;
             temp _s (Vint (Int.repr ss)); lvar _p (Tstruct _pollfd noattr) v_p;
             lvar _st tint v_st;
             temp _master (Vint (Int.repr master)); temp _pid (Vint (Int.repr pid));
             temp _buf buf; temp _max (Vint (Int.repr max));
             temp _timeout_ms (Vint (Int.repr timeout)))
      SEP (data_at sh (tarray tschar max) pre buf;
           data_at sh tint (Vint (Int.repr E1)) P1;
           data_at Tsh (Tstruct _pollfd noattr)
             (Vint (Int.repr master), (Vint (Int.repr 1), Vint (Int.repr rev2))) v_p;
           data_at_ Tsh tint v_st)).
    + forward. Exists 0 pre (Some (P1, E1)) (@None (val*Z)) (@None (val*Z)) (@None (val*Z)). entailer!.
    + forward. entailer!.
    + forward. Exists (-2) pre (Some (P1, E1)) (@None (val*Z)) (@None (val*Z)) (@None (val*Z)). entailer!.
  - forward_if (PROP ()
      LOCAL (temp _s (Vint (Int.repr ss)); lvar _p (Tstruct _pollfd noattr) v_p;
             lvar _st tint v_st;
             temp _master (Vint (Int.repr master)); temp _pid (Vint (Int.repr pid));
             temp _buf buf; temp _max (Vint (Int.repr max));
             temp _timeout_ms (Vint (Int.repr timeout)))
      SEP (data_at sh (tarray tschar max) pre buf;
           data_at Tsh (Tstruct _pollfd noattr)
             (Vint (Int.repr master), (Vint (Int.repr 1), Vint (Int.repr rev2))) v_p;
           data_at_ Tsh tint v_st)).
    + forward. Exists 0 pre (@None (val*Z)) (@None (val*Z)) (@None (val*Z)) (@None (val*Z)). entailer!.
    + forward. entailer!.
    + forward_call (master, buf, max, sh, pre).
      Intros vret. destruct vret as [ret post].
      change (fst (ret, post)) with ret in *.
      change (snd (ret, post)) with post in *.
      repeat (apply -> semax_seq_skip).
      repeat (apply seq_assoc1; try apply -> semax_seq_skip).
      forward_if.
      * forward.
        Exists ret post (@None (val*Z)) (@None (val*Z)) (@None (val*Z)) (@None (val*Z)).
        entailer!.
        assert (Hr : Int64.signed (Int64.repr ret) = ret)
          by (apply signed_repr_roundtrip; assumption).
        assert (Hz : Int64.signed (Int64.repr 0) = 0) by reflexivity.
        match goal with Hlt : (Int64.signed (Int64.repr 0) < Int64.signed (Int64.repr ret)) |- _ =>
          rewrite Hr, Hz in Hlt end.
        split.
        { match goal with Hrg : (Int64.min_signed <= ret <= Int64.max_signed)
                |- (Int.min_signed <= ret <= Int.max_signed) =>
            destruct Hrg as [Hlo Hhi];
            unfold Int.min_signed, Int.max_signed, Int64.min_signed, Int64.max_signed in *; lia end. }
        { split.
          { right. right. right.
            match goal with Hlt : (0 < ret) |- _ =>
              match goal with Hle : (ret <= Zlength pre) |- _ =>
                split; [lia | lia] end end. }
          { match goal with Hrg : (Int64.min_signed <= ret <= Int64.max_signed) |- _ =>
              destruct Hrg as [Hlo Hhi];
              assert (Hmaxu : Int64.max_unsigned = 18446744073709551615) by reflexivity;
              assert (Hmin : Int64.min_signed = -9223372036854775808) by reflexivity;
              assert (Hmax : Int64.max_signed = 9223372036854775807) by reflexivity;
              assert (HU : 0 <= ret <= Int64.max_unsigned) by lia;
              rewrite (Int64.unsigned_repr ret HU);
              reflexivity end. } }
      * repeat (apply -> semax_seq_skip).
        repeat (apply seq_assoc1; try apply -> semax_seq_skip).
        forward_if (EX t4 : Z, EX o1 o2 o3 : option (val * Z),
          PROP ()
          LOCAL (temp _k (Vlong (Int64.repr ret));
                 temp _s (Vint (Int.repr ss)); lvar _p (Tstruct _pollfd noattr) v_p;
                 lvar _st tint v_st;
                 temp _master (Vint (Int.repr master)); temp _pid (Vint (Int.repr pid));
                 temp _buf buf; temp _max (Vint (Int.repr max));
                 temp _timeout_ms (Vint (Int.repr timeout));
                 temp _t'4 (Vint (Int.repr t4)))
          SEP (data_at sh (tarray tschar max) post buf;
               opt_data sh o1; opt_data sh o2; opt_data sh o3;
               data_at_ Tsh (Tstruct _pollfd noattr) v_p;
               data_at_ Tsh tint v_st)).
        -- forward_call (sh, buf, max, post).
           Intros v2. destruct v2 as [pa ea].
           change (fst (pa, ea)) with pa in *.
           change (snd (pa, ea)) with ea in *.
           forward.
           pose (Ea1 := ea). pose (Pa1 := pa).
           forward_if (EX t6 : Z, EX o2 : option (val * Z),
             PROP ()
             LOCAL (temp _k (Vlong (Int64.repr ret));
                    temp _s (Vint (Int.repr ss)); lvar _p (Tstruct _pollfd noattr) v_p;
                    lvar _st tint v_st;
                    temp _master (Vint (Int.repr master)); temp _pid (Vint (Int.repr pid));
                    temp _buf buf; temp _max (Vint (Int.repr max));
                    temp _timeout_ms (Vint (Int.repr timeout));
                    temp _t'5 Pa1; temp _t'14 (Vint (Int.repr Ea1));
                    temp _t'6 (Vint (Int.repr t6)))
             SEP (data_at sh (tarray tschar max) post buf;
                  data_at sh tint (Vint (Int.repr Ea1)) Pa1;
                  opt_data sh o2;
                  data_at_ Tsh (Tstruct _pollfd noattr) v_p;
                  data_at_ Tsh tint v_st)).
           ++ forward.
              Exists 1%Z (@None (val*Z)). entailer!.
           ++ forward_call (sh, buf, max, post).
              Intros v3. destruct v3 as [pb eb].
              change (fst (pb, eb)) with pb in *.
              change (snd (pb, eb)) with eb in *.
              forward.
              forward.
              Exists (if Int.eq (Int.repr eb) (Int.repr 11) then 1 else 0)
                     (Some (pb, eb)).
              entailer!.
           ++ Intros t6 o2.
              forward_if (EX t4 : Z, EX o3 : option (val * Z),
                PROP ()
                LOCAL (temp _k (Vlong (Int64.repr ret));
                       temp _s (Vint (Int.repr ss)); lvar _p (Tstruct _pollfd noattr) v_p;
                       lvar _st tint v_st;
                       temp _master (Vint (Int.repr master)); temp _pid (Vint (Int.repr pid));
                       temp _buf buf; temp _max (Vint (Int.repr max));
                       temp _timeout_ms (Vint (Int.repr timeout));
                       temp _t'5 Pa1; temp _t'14 (Vint (Int.repr Ea1));
                       temp _t'6 (Vint (Int.repr t6));
                       temp _t'4 (Vint (Int.repr t4)))
                SEP (data_at sh (tarray tschar max) post buf;
                     data_at sh tint (Vint (Int.repr Ea1)) Pa1;
                     opt_data sh o2; opt_data sh o3;
                     data_at_ Tsh (Tstruct _pollfd noattr) v_p;
                     data_at_ Tsh tint v_st)).
              { forward.
                Exists 1%Z (@None (val*Z)). entailer!. }
              { forward_call (sh, buf, max, post).
                Intros v4. destruct v4 as [pc ec].
                change (fst (pc, ec)) with pc in *.
                change (snd (pc, ec)) with ec in *.
                forward.
                forward.
                forward.
                Exists (if Int.eq (Int.repr ec) (Int.repr 4) then 1 else 0)
                       (Some (pc, ec)).
                entailer!. }
              { Intros t4 o3.
                Exists t4 (Some (Pa1, Ea1)) o2 o3. entailer!. }
        -- forward.
           Exists 0%Z (@None (val*Z)) (@None (val*Z)) (@None (val*Z)). entailer!.
        -- Intros t4 o1 o2 o3.
           repeat (apply -> semax_seq_skip).
           repeat (apply seq_assoc1; try apply -> semax_seq_skip).
           forward_if.
           { forward.
             Exists 0 post o1 o2 o3 (@None (val*Z)).
             entailer!.
             match goal with Himp : ?r <= 0 -> post = pre |- post = pre => apply Himp end.
             assert (Hr : Int64.signed (Int64.repr ret) = ret) by (apply signed_repr_roundtrip; assumption).
             assert (Hz : Int64.signed (Int64.repr 0) = 0) by reflexivity.
             match goal with Hge : (Int64.signed (Int64.repr 0) >= Int64.signed (Int64.repr ret)) |- _ => rewrite Hr, Hz in Hge end.
             lia. }
           { repeat (apply -> semax_seq_skip).
             repeat (apply seq_assoc1; try apply -> semax_seq_skip).
             forward_if (EX t10 : Z, EX o4 : option (val * Z),
               PROP ()
               LOCAL (temp _k (Vlong (Int64.repr ret));
                      temp _s (Vint (Int.repr ss)); lvar _p (Tstruct _pollfd noattr) v_p;
                      lvar _st tint v_st;
                      temp _master (Vint (Int.repr master)); temp _pid (Vint (Int.repr pid));
                      temp _buf buf; temp _max (Vint (Int.repr max));
                      temp _timeout_ms (Vint (Int.repr timeout));
                      temp _t'10 (Vint (Int.repr t10)))
               SEP (data_at sh (tarray tschar max) post buf;
                    opt_data sh o1; opt_data sh o2; opt_data sh o3; opt_data sh o4;
                    data_at_ Tsh (Tstruct _pollfd noattr) v_p;
                    data_at_ Tsh tint v_st)).
             - forward_call (sh, buf, max, post).
               Intros v5. destruct v5 as [pd ed].
               change (fst (pd, ed)) with pd in *.
               change (snd (pd, ed)) with ed in *.
               forward.
               forward.
               Exists (if Int.eq (Int.repr ed) (Int.repr 5) then 1 else 0)
                      (Some (pd, ed)).
               entailer!.
             - forward.
               Exists 0%Z (@None (val*Z)). entailer!.
             - Intros t10 o4.
               forward_if (PROP ()
                 LOCAL (temp _k (Vlong (Int64.repr ret));
                        temp _s (Vint (Int.repr ss)); lvar _p (Tstruct _pollfd noattr) v_p;
                        lvar _st tint v_st;
                        temp _master (Vint (Int.repr master)); temp _pid (Vint (Int.repr pid));
                        temp _buf buf; temp _max (Vint (Int.repr max));
                        temp _timeout_ms (Vint (Int.repr timeout)))
                 SEP (data_at sh (tarray tschar max) post buf;
                      opt_data sh o1; opt_data sh o2; opt_data sh o3; opt_data sh o4;
                      data_at_ Tsh (Tstruct _pollfd noattr) v_p;
                      data_at_ Tsh tint v_st)).
               + forward_call (pid, v_st, Tsh).
                 Intros r.
                 forward_if (PROP ()
                   LOCAL (temp _k (Vlong (Int64.repr ret));
                          temp _s (Vint (Int.repr ss)); lvar _p (Tstruct _pollfd noattr) v_p;
                          lvar _st tint v_st;
                          temp _master (Vint (Int.repr master)); temp _pid (Vint (Int.repr pid));
                          temp _buf buf; temp _max (Vint (Int.repr max));
                          temp _timeout_ms (Vint (Int.repr timeout)))
                   SEP (data_at sh (tarray tschar max) post buf;
                        opt_data sh o1; opt_data sh o2; opt_data sh o3; opt_data sh o4;
                        data_at_ Tsh (Tstruct _pollfd noattr) v_p;
                        data_at_ Tsh tint v_st)).
                 { forward.
                   Exists 0 post o1 o2 o3 o4.
                   entailer!.
                   match goal with Himp : ?rr <= 0 -> post = pre |- post = pre => apply Himp end.
                   assert (Hr : Int64.signed (Int64.repr ret) = ret) by (apply signed_repr_roundtrip; assumption).
                   assert (Hz : Int64.signed (Int64.repr 0) = 0) by reflexivity.
                   match goal with Hge : (Int64.signed (Int64.repr 0) >= Int64.signed (Int64.repr ret)) |- _ => rewrite Hr, Hz in Hge end.
                   lia. }
                 { fwd_skip. entailer!. }
               + fwd_skip. entailer!.
             + forward.
               Exists (-1) post o1 o2 o3 o4.
               entailer!.
               match goal with Himp : ?rr <= 0 -> post = pre |- post = pre => apply Himp end.
               assert (Hr : Int64.signed (Int64.repr ret) = ret) by (apply signed_repr_roundtrip; assumption).
               assert (Hz : Int64.signed (Int64.repr 0) = 0) by reflexivity.
               match goal with Hge : (Int64.signed (Int64.repr 0) >= Int64.signed (Int64.repr ret)) |- _ => rewrite Hr, Hz in Hge end.
               lia. }
Qed.
