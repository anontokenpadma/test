# Difftest RESULTS (need.txt item 9) — 2026-10-09

Oracle: difftest/oracle.py transcribes Ada line-for-line (Decide echo_vectors.adb:26-54, Common_Prefix/Bracket_Pre tedex_echo.adb,
Auth_Verdict tedex_util.adb:387-401, Backoff tedex_protocol.adb:420-432, Jitter tedex_util.adb:403-406).
Coq sources md5: EchoModel 2ffcd01ba5d8ee73, AuthVerdict 4e97dc753d3c225f (symlinks, identical bytes).
Commands: `coqc -q -Q . Difftest EchoModel.v AuthVerdict.v` (stage/), one `coqtop -q -Q . Difftest` batch with 4128 Evals.

- oracle-vs-Ada Decide vectors: 15/15
- oracle-vs-Ada Bracket_Pre checks: 5/5
- Coq-vs-oracle fuzz common_prefix+bracket_pre: 2000 pairs (4000 evals)
- Coq-vs-oracle auth_verdict: 16/16 combos; backoff 0..10; jittered 66
- Coq-vs-oracle total: 4128/4128 match

HONEST LIMIT: Gallina models only the primitives (common_prefix,
bracket_pre, auth_verdict, backoff); the 4-branch Decide composition
lives only in echo_vectors.adb, so Decide-vs-Coq end-to-end is NOT
covered — oracle-vs-Ada validates the transcription, Coq-vs-oracle
validates the primitives. Fail-open timing policy stays tested-only
(need.txt item 11).

## Per-check log
- [x] ada-vector Decide/exact-echo got=(b'', b'') exp=(b'', b'')
- [x] ada-vector Decide/frag-1 got=(b'', b's\r\n') exp=(b'', b's\r\n')
- [x] ada-vector Decide/frag-2 got=(b'', b'') exp=(b'', b'')
- [x] ada-vector Decide/glued got=(b'bin', b'') exp=(b'bin', b'')
- [x] ada-vector Decide/lost+found-collision got=(b'lost+found mnt', b'') exp=(b'lost+found mnt', b'')
- [x] ada-vector Decide/lib-collision got=(b'lib', b'') exp=(b'lib', b'')
- [x] ada-vector Decide/sbin-collision got=(b'sbin', b'') exp=(b'sbin', b'')
- [x] ada-vector Decide/unrelated got=(b'bin', b'abc') exp=(b'bin', b'abc')
- [x] ada-vector Decide/empty-msg got=(b'', b'abc') exp=(b'', b'abc')
- [x] ada-vector Decide/empty-pend got=(b'abc', b'') exp=(b'abc', b'')
- [x] ada-vector Decide/empty-both got=(b'', b'') exp=(b'', b'')
- [x] ada-vector Decide/bracket-echo got=(b'\x1b[?2004h', b'') exp=(b'\x1b[?2004h', b'')
- [x] ada-vector Decide/bracket-cr-echo got=(b'\x1b[?2004l\r', b'') exp=(b'\x1b[?2004l\r', b'')
- [x] ada-vector Decide/bracket-collision got=(b'\x1b[?2004l\rlost+found', b'') exp=(b'\x1b[?2004l\rlost+found', b'')
- [x] ada-vector Decide/exact-output-line got=(b'', b'') exp=(b'', b'')
- [x] ada-vector Bracket_Pre/bracket-plain got=0 exp=0
- [x] ada-vector Bracket_Pre/bracket-8 got=8 exp=8
- [x] ada-vector Bracket_Pre/bracket-9 got=9 exp=9
- [x] ada-vector Bracket_Pre/bracket-short got=0 exp=0
- [x] ada-vector Bracket_Pre/bracket-bare8 got=0 exp=0
- [x] stage md5 EchoModel.v 2ffcd01ba5d8ee73
- [x] stage md5 AuthVerdict.v 4e97dc753d3c225f
- [x] stage coqc Difftest models 
- [x] coqtop batch exit 0 
Rocq < 
Rocq < Toplevel input, characters 15-20:
> Require Import Ascii List.
>                ^^^^^
Warning: Loading Stdlib without prefix is deprecated.
Use "From Stdlib Require Ascii" or the deprecated "From Coq Require Ascii"
for compatibility with older Coq versions.
[deprecated-missing-stdlib,deprecated-since-9.0,deprecated,default]
Toplevel input, characters 21-25:
> Require Import Ascii List.
>                      ^^^^
Warning: Loading Stdlib without prefix is deprecated.
Use "From Std
- [x] coqtop result count got 4128 want 4128
- [x] Coq-vs-oracle all match 4128/4128; 
