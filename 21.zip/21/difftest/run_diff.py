"""Differential test driver: oracle-vs-Ada vectors, Coq-vs-oracle fuzz (need.txt item 9).

Usage: python3 run_diff.py [--fuzz N]   (default N=2000)
Writes RESULTS.md in this directory. Exits nonzero on any mismatch.
"""
import hashlib
import os
import random
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__)
)
PROOFS = "/home/jovyan/19/tedex_proofs"
sys.path.insert(0, HERE)
from oracle import (auth_verdict, backoff_secs, bracket_pre, common_prefix,
                    decide, jittered_backoff)
from vectors import BRACKET_CASES, DECIDE_CASES

FUZZ_N = int(sys.argv[sys.argv.index("--fuzz") + 1]) if "--fuzz" in sys.argv else 2000

results = []
failures = []


def check(name, cond, detail=""):
    results.append((name, cond, detail))
    if not cond:
        failures.append(name)


# ---------- 1. oracle vs Ada vectors ----------
n_dec_ok = 0
for name, pend, msg, exp_show, exp_pend in DECIDE_CASES:
    got = decide(pend, msg)
    ok = got == (exp_show, exp_pend)
    n_dec_ok += ok
    check(f"ada-vector Decide/{name}", ok, f"got={got!r} exp={(exp_show, exp_pend)!r}")
n_br_ok = 0
for name, inp, exp in BRACKET_CASES:
    got = bracket_pre(inp)
    ok = got == exp
    n_br_ok += ok
    check(f"ada-vector Bracket_Pre/{name}", ok, f"got={got} exp={exp}")

# ---------- 2. stage Coq sources (symlink, md5-attested) ----------
stage = os.path.join(HERE, "stage")
os.makedirs(stage, exist_ok=True)
hashes = {}
for f in ("EchoModel.v", "AuthVerdict.v"):
    src = os.path.join(PROOFS, f)
    link = os.path.join(stage, f)
    if not os.path.islink(link):
        os.symlink(src, link)
    h_src = hashlib.sha256(open(src, "rb").read()).hexdigest()
    h_tgt = hashlib.sha256(open(link, "rb").read()).hexdigest()
    hashes[f] = h_src
    check(f"stage md5 {f}", h_src == h_tgt, h_src[:16])
env = dict(os.environ)
env["PATH"] = os.path.expanduser("~/bin") + ":" + env.get("PATH", "")
opam_env = subprocess.run(["bash", "-c", "eval $(opam env --switch=rocq-9.2 2>/dev/null) && env"],
                          capture_output=True, text=True, env=env).stdout
for line in opam_env.splitlines():
    if "=" in line:
        k, _, v = line.partition("=")
        if k in ("PATH", "COQBIN", "CAML_LD_LIBRARY_PATH", "OCAMLPATH", "OPAM_SWITCH_PREFIX"):
            env[k] = v
ok_stage, stage_log = True, ""
for f in ("EchoModel.v", "AuthVerdict.v"):
    r = subprocess.run(["coqc", "-q", "-Q", ".", "Difftest", f],
                       cwd=stage, capture_output=True, text=True, env=env)
    if r.returncode != 0:
        ok_stage, stage_log = False, f + ": " + (r.stderr or "")[:500]
check("stage coqc Difftest models", ok_stage, stage_log)

# ---------- 3. build eval workload ----------
def coq_bytes(b: bytes) -> str:
    if not b:
        return "(@nil ascii)"
    return "(" + " :: ".join(f"ascii_of_nat {x}" for x in b) + " :: nil)"


evals = []          # (kind, key, expected_py)
proof_lines = ["Require Import Difftest.EchoModel Difftest.AuthVerdict.",
               "Require Import Ascii List.", "Import ListNotations."]
for name, pend, msg in [(n, p, m) for (n, p, m, _, _) in DECIDE_CASES]:
    pre = bracket_pre(msg)
    base = msg if pre == 0 else msg[pre:]
    evals.append(("cp", (name,), common_prefix(pend, base), ("common_prefix", pend, base)))
    evals.append(("bp", (name,), pre, ("bracket_pre", msg)))
for name, inp, exp in BRACKET_CASES:
    evals.append(("bp", (name,), exp, ("bracket_pre", inp)))
ALPH = [27, 91, 63, 50, 48, 52, 108, 104, 13, 10, 97, 98, 108, 115, 32]
rng = random.Random(20261009)
fuzz_pairs = []
for _ in range(FUZZ_N):
    p = bytes(rng.choice(ALPH) for _ in range(rng.randint(0, 12)))
    m = bytes(rng.choice(ALPH) for _ in range(rng.randint(0, 14)))
    fuzz_pairs.append((p, m))
    pre = bracket_pre(m)
    base = m if pre == 0 else m[pre:]
    evals.append(("cp", None, common_prefix(p, base), ("common_prefix", p, base)))
    evals.append(("bp", None, pre, ("bracket_pre", m)))
for a in (False, True):
    for b in (False, True):
        for c in (False, True):
            for d in (False, True):
                exp = auth_verdict(a, b, c, d)
                evals.append(("av", (a, b, c, d), exp, ("auth_verdict", a, b, c, d)))
for f in range(0, 11):
    evals.append(("bo", (f,), backoff_secs(f), ("backoff_secs", f)))
for f in range(0, 11):
    for rb in (0, 1, 5, 6, 7, 255):
        evals.append(("jb", (f, rb), jittered_backoff(f, rb), ("jittered_backoff", f, rb)))

for kind, key, exp, spec in evals:
    fn = spec[0]
    if fn == "common_prefix":
        _, p, m = spec
        proof_lines.append(f"Eval compute in (common_prefix {coq_bytes(p)} {coq_bytes(m)}).")
    elif fn == "bracket_pre":
        _, m = spec
        proof_lines.append(f"Eval compute in (bracket_pre {coq_bytes(m)}).")
    elif fn == "auth_verdict":
        _, a, b, c, d = spec
        proof_lines.append(
            f"Eval compute in (auth_verdict {'true' if a else 'false'} {'true' if b else 'false'} "
            f"{'true' if c else 'false'} {'true' if d else 'false'}).")
    elif fn == "backoff_secs":
        _, f = spec
        proof_lines.append(f"Eval compute in (backoff_secs {f}).")
    elif fn == "jittered_backoff":
        _, f, rb = spec
        proof_lines.append(f"Eval compute in (jittered_backoff {f} {rb}).")

# ---------- 4. run coqtop batch ----------
proc = subprocess.run(["coqtop", "-q", "-Q", ".", "Difftest"],
                      input="\n".join(proof_lines) + "\n",
                      capture_output=True, text=True, cwd=stage, env=env, timeout=600)
check("coqtop batch exit 0", proc.returncode == 0, (proc.stderr or "")[:500])
got_vals = re.findall(r"^\s*=\s*(.*?)\s*$", proc.stdout, re.M)
check("coqtop result count", len(got_vals) == len(evals),
      f"got {len(got_vals)} want {len(evals)}")

DENY = {"Deny_None": "Deny_None", "Deny_Bad_Password": "Deny_Bad_Password",
        "Deny_Stopped": "Deny_Stopped"}


def norm(kind, raw):
    raw = raw.strip()
    if kind in ("cp", "bp", "bo", "jb"):
        return int(raw)
    m = re.match(r"\(\s*(true|false)\s*,\s*(\w+)\s*\)$", raw)
    allow = m.group(1) == "true"
    return (allow, DENY[m.group(2)])


n_cmp = n_mis = 0
mis_samples = []
for (kind, key, exp, _), raw in zip(evals, got_vals):
    n_cmp += 1
    try:
        ok = norm(kind, raw) == exp
    except Exception as e:  # noqa: BLE001
        ok, raw = False, f"PARSE-FAIL {raw!r} ({e})"
    if not ok:
        n_mis += 1
        if len(mis_samples) < 10:
            mis_samples.append(f"{kind} {key}: coq={raw!r} py={exp!r}")
check("Coq-vs-oracle all match", n_mis == 0, f"{n_cmp - n_mis}/{n_cmp}; " + "; ".join(mis_samples))

# ---------- 5. RESULTS.md ----------
with open(os.path.join(HERE, "RESULTS.md"), "w") as f:
    f.write("# Difftest RESULTS (need.txt item 9) — 2026-10-09\n\n")
    f.write("Oracle: difftest/oracle.py transcribes Ada line-for-line "
            "(Decide echo_vectors.adb:26-54, Common_Prefix/Bracket_Pre tedex_echo.adb,\n"
            "Auth_Verdict tedex_util.adb:387-401, Backoff tedex_protocol.adb:420-432, "
            "Jitter tedex_util.adb:403-406).\n")
    f.write(f"Coq sources md5: EchoModel {hashes['EchoModel.v'][:16]}, "
            f"AuthVerdict {hashes['AuthVerdict.v'][:16]} (symlinks, identical bytes).\n")
    f.write(f"Commands: `coqc -q -Q . Difftest EchoModel.v AuthVerdict.v` (stage/), "
            f"one `coqtop -q -Q . Difftest` batch with {len(evals)} Evals.\n\n")
    f.write(f"- oracle-vs-Ada Decide vectors: {n_dec_ok}/{len(DECIDE_CASES)}\n")
    f.write(f"- oracle-vs-Ada Bracket_Pre checks: {n_br_ok}/{len(BRACKET_CASES)}\n")
    f.write(f"- Coq-vs-oracle fuzz common_prefix+bracket_pre: {FUZZ_N} pairs "
            f"({2 * FUZZ_N} evals)\n")
    f.write(f"- Coq-vs-oracle auth_verdict: 16/16 combos; backoff 0..10; jittered 66\n")
    f.write(f"- Coq-vs-oracle total: {n_cmp - n_mis}/{n_cmp} match\n\n")
    f.write("HONEST LIMIT: Gallina models only the primitives (common_prefix,\n"
            "bracket_pre, auth_verdict, backoff); the 4-branch Decide composition\n"
            "lives only in echo_vectors.adb, so Decide-vs-Coq end-to-end is NOT\n"
            "covered — oracle-vs-Ada validates the transcription, Coq-vs-oracle\n"
            "validates the primitives. Fail-open timing policy stays tested-only\n"
            "(need.txt item 11).\n\n")
    f.write("## Per-check log\n")
    for name, ok, detail in results:
        f.write(f"- [{'x' if ok else 'FAIL'}] {name} {detail}\n")

print(f"decide {n_dec_ok}/{len(DECIDE_CASES)}, bracket {n_br_ok}/{len(BRACKET_CASES)}, "
      f"coq-cmp {n_cmp - n_mis}/{n_cmp}, failures={len(failures)}")
sys.exit(1 if failures else 0)
