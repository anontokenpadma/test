"""Python oracle transcribing Ada sources line-for-line (need.txt item 9).

Sources (all in /home/jovyan/19/src/):
- Decide/Tail: tests/echo_vectors.adb:26-54 (+ Check data :80-138)
- Common_Prefix: tedex_echo.adb:5-15
- Bracket_Pre: tedex_echo.adb:17-37
- Auth_Verdict: tedex_util.adb:387-401
- Backoff_Secs: tedex_protocol.adb:420-432
- Jittered_Backoff: tedex_util.adb:403-406
Byte strings are Python bytes (Ada String = array of Character'Val 0..255).
"""

ESC, CR, LF = 27, 13, 10


def common_prefix(pending: bytes, msg: bytes) -> int:
    # tedex_echo.adb:5-15
    k = 0
    while k < len(pending) and k < len(msg) and pending[k] == msg[k]:
        k += 1
    return k


B1 = bytes([27]) + b"[?2004l"
B2 = bytes([27]) + b"[?2004h"


def bracket_pre(msg: bytes) -> int:
    # tedex_echo.adb:17-37
    if len(msg) > 8 and (msg[:8] == B1 or msg[:8] == B2):
        if msg[8] == 13:
            return 9
        return 8
    return 0


def decide(pending: bytes, msg: bytes):
    # echo_vectors.adb:26-54 -> (shown, new_pending)
    pre = bracket_pre(msg)
    head = msg[:pre] if pre else b""
    r0 = b"" if pre >= len(msg) else msg[pre:]
    base = msg if pre == 0 else r0
    k = common_prefix(pending, base)
    fp = k >= len(pending)
    fm = k >= len(base)
    if k == 0:
        return msg, pending
    elif fm and not fp:
        return b"", pending[k:]
    elif fp:
        return head + base[k:], b""
    else:
        return msg, b""


def auth_verdict(pass_ok: bool, is_device: bool, key_ok: bool, disabled: bool):
    # tedex_util.adb:387-401 -> (allow, reason)
    if not (pass_ok or (is_device and key_ok)):
        return False, "Deny_Bad_Password"
    elif disabled:
        return False, "Deny_Stopped"
    else:
        return True, "Deny_None"


def backoff_secs(failures: int) -> int:
    # tedex_protocol.adb:420-432
    return {1: 5, 2: 10, 3: 20, 4: 40}.get(failures, 60)


def jittered_backoff(failures: int, rand_byte: int) -> int:
    # tedex_util.adb:403-406
    return backoff_secs(failures) + (rand_byte % 6)
