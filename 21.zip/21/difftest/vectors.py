"""Ada vector data transcribed from tests/echo_vectors.adb (need.txt item 9).

ESC/CR/LF concatenation (e.g. "ls" & CR & LF) = bytes join.
Each Decide case: (name, pending, msg, exp_shown, exp_pending).
Bracket_Pre checks: (name, input, expected).
"""
from oracle import ESC, CR, LF

E = bytes([ESC])


def S(*parts) -> bytes:
    out = b""
    for p in parts:
        if isinstance(p, int):
            out += bytes([p])
        else:
            out += p.encode("latin1")
    return out


LS = S("ls", CR, LF)  # "ls" & CR & LF

DECIDE_CASES = [
    ("exact-echo", LS, LS, b"", b""),
    ("frag-1", LS, b"l", b"", S("s", CR, LF)),
    ("frag-2", S("s", CR, LF), S("s", CR, LF), b"", b""),
    ("glued", LS, LS + b"bin", b"bin", b""),
    ("lost+found-collision", LS, b"lost+found mnt", b"lost+found mnt", b""),
    ("lib-collision", LS, b"lib", b"lib", b""),
    ("sbin-collision", S("s", CR, LF), b"sbin", b"sbin", b""),
    ("unrelated", b"abc", b"bin", b"bin", b"abc"),
    ("empty-msg", b"abc", b"", b"", b"abc"),
    ("empty-pend", b"", b"abc", b"abc", b""),
    ("empty-both", b"", b"", b"", b""),
    ("bracket-echo", LS, E + b"[?2004h" + LS, E + b"[?2004h", b""),
    ("bracket-cr-echo", LS, E + b"[?2004l" + bytes([CR]) + LS,
     E + b"[?2004l" + bytes([CR]), b""),
    ("bracket-collision", LS, E + b"[?2004l" + bytes([CR]) + b"lost+found",
     E + b"[?2004l" + bytes([CR]) + b"lost+found", b""),
    ("exact-output-line", b"ls", b"ls", b"", b""),
]

BRACKET_CASES = [
    ("bracket-plain", b"plain", 0),
    ("bracket-8", E + b"[?2004lrest", 8),
    ("bracket-9", E + b"[?2004l" + bytes([CR]) + b"x", 9),
    ("bracket-short", E + b"[?2004", 0),
    ("bracket-bare8", E + b"[?2004h", 0),
]
