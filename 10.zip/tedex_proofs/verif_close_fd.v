(* VST verification of tls_close_fd (tlswrap.c):
     int tls_close_fd (int fd) { return close (fd); }
   HONEST STATUS: attempt -- tests whether emp-PRE external calls work
   in this Floyd version (diagnostic for the errno blocker). *)

Require Import VST.floyd.proofauto.
Require Import Clight.tlswrap.

Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.

(* Axiom: close(2). *)
Definition close_spec : ident * funspec :=
  DECLARE _close
  WITH fd : Z
  PRE [ tint ]
    PROP (0 <= fd <= Int.max_signed)
    PARAMS (Vint (Int.repr fd))
    GLOBALS ()
    SEP (emp)
  POST [ tint ]
    EX r : Z,
    PROP (Int.min_signed <= r <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr r)))
    SEP (emp).

Definition tls_close_fd_spec : ident * funspec :=
  DECLARE _tls_close_fd
  WITH fd : Z
  PRE [ tint ]
    PROP (0 <= fd <= Int.max_signed)
    PARAMS (Vint (Int.repr fd))
    GLOBALS ()
    SEP (emp)
  POST [ tint ]
    EX r : Z,
    PROP (Int.min_signed <= r <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr r)))
    SEP (emp).

Definition Gprog : funspecs :=
  ltac:(with_library prog [close_spec; tls_close_fd_spec]).

Lemma body_tls_close_fd :
  semax_body Vprog Gprog f_tls_close_fd tls_close_fd_spec.
Proof.
  start_function.
  forward_call (fd).
  Intros r.
  forward.
  Exists r.
  entailer!.
Qed.
