(* Step 1c: Model of the server ATTACH handoff + resize forwarding.
   Sources: server.adb Take_Dev/Mark_Attached/Mark_Gone/Wait_Handler_Gone/
   Do_Attach_Splice (724-848), Tedex_Util.Should_Forward_Resize.
   HONEST SCOPE: finite-map/state-machine model of the handoff protocol.
   Proves handoff safety properties of the MODEL; the Ada protected-object
   implementation is verified by SPARK + code review, not by these lemmas. *)

Require Import List Nat Bool Lia Arith.
Import ListNotations.

(* --- Device identity --- *)
Definition user := nat.
Definition dev := nat.
Definition sock := nat.
Definition key := (user * dev)%type.

(* Registry model: idle devices, busy (attached) devices, gone flags *)
Record registry : Type := mkReg {
  idle : list key;
  busy : list key;
  gone : list key
}.

Definition reg_empty : registry :=
  mkReg [] [] [].

Fixpoint mem (x : key) (l : list key) : bool :=
  match l with
  | [] => false
  | y :: ys => if Nat.eqb (fst x) (fst y) && Nat.eqb (snd x) (snd y)
               then true else mem x ys
  end.

Fixpoint remove_key (k : key) (l : list key) : list key :=
  match l with
  | [] => []
  | y :: ys => if Nat.eqb (fst k) (fst y) && Nat.eqb (snd k) (snd y)
               then remove_key k ys else y :: remove_key k ys
  end.

(* Take_Dev: atomically remove from idle (server.adb:193-214) *)
Definition take_dev (r : registry) (k : key) : option (registry * bool) :=
  if mem k (idle r) then
    Some (mkReg (remove_key k (idle r)) (busy r) (gone r), true)
  else None.

(* Mark_Gone by the device loop (server.adb:629-665): hands socket to splice *)
Definition mark_gone (r : registry) (k : key) : registry :=
  if mem k (gone r) then r
  else mkReg (idle r) (busy r) (k :: gone r).

(* Unmark after splice completes *)
Definition unmark (r : registry) (k : key) : registry :=
  mkReg (idle r) (remove_key k (busy r)) (remove_key k (gone r)).

(* H1: take only succeeds on idle members *)
Theorem take_needs_idle : forall r k r' ok,
  take_dev r k = Some (r', ok) -> mem k (idle r) = true.
Proof.
  intros. unfold take_dev in H.
  destruct (mem k (idle r)) eqn:E; inversion H; subst; reflexivity.
Qed.

(* H2: take removes exactly the taken key from idle *)
Theorem take_removes : forall r k r' ok,
  take_dev r k = Some (r', ok) ->
  mem k (idle r') = false.
Proof.
  intros. unfold take_dev in H.
  destruct (mem k (idle r)) eqn:E; inversion H; subst; simpl.
  (* remove_key drops every copy of k *)
  assert (R: forall l, mem k (remove_key k l) = false).
  { induction l as [|y ys IH]; simpl.
    - reflexivity.
    - destruct (Nat.eqb (fst k) (fst y) && Nat.eqb (snd k) (snd y)) eqn:F.
      + exact IH.
      + simpl. rewrite F. exact IH. }
  apply R.
Qed.

(* H3: double-take without re-register fails (no double attach) *)
Theorem no_double_take : forall r k r1,
  take_dev r k = Some (r1, true) ->
  take_dev r1 k = None.
Proof.
  intros. unfold take_dev.
  assert (M := take_removes r k r1 true H).
  rewrite M. reflexivity.
Qed.

(* --- Resize forwarding (tedex_util.ads:204-214) --- *)
Definition max_dev : nat := 64.

Definition should_forward (pend_len : nat) (same : bool)
  (cols rows : nat) : bool :=
  (Nat.leb 1 pend_len && Nat.leb pend_len max_dev) &&
  same && (Nat.leb 1 cols && Nat.leb cols 1000) &&
  (Nat.leb 1 rows && Nat.leb rows 1000).

(* A stale size for another device is never forwarded *)
Theorem stale_resize_blocked : forall pend_len cols rows,
  should_forward pend_len false cols rows = false.
Proof.
  intros. unfold should_forward.
  destruct (Nat.leb 1 pend_len && Nat.leb pend_len max_dev);
    destruct (Nat.leb 1 cols && Nat.leb cols 1000);
    destruct (Nat.leb 1 rows && Nat.leb rows 1000);
    simpl; reflexivity.
Qed.

Theorem oob_dims_blocked : forall pend_len same,
  should_forward pend_len same 0 24 = false /\
  should_forward pend_len same 80 0 = false /\
  should_forward pend_len same 1001 24 = false.
Proof.
  intros. unfold should_forward. repeat split;
    destruct (Nat.leb 1 pend_len && Nat.leb pend_len max_dev);
    destruct same; simpl; reflexivity.
Qed.

(* --- Manager liveness (client.adb Get_Cmd_Alive: Silent>=4 -> dead) --- *)
Definition silent_dead (misses : nat) : bool :=
  Nat.leb 4 misses.

Theorem silent_threshold : silent_dead 3 = false /\ silent_dead 4 = true /\
  silent_dead 100 = true.
Proof. repeat split; reflexivity. Qed.

Theorem silent_mono : forall a b, a <= b ->
  silent_dead a = true -> silent_dead b = true.
Proof.
  intros. unfold silent_dead in *.
  apply Nat.leb_le in H0.
  apply Nat.leb_le. lia.
Qed.
