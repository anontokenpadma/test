(* Step 2 (SKELETON -- NOT YET MACHINE-CHECKED):
   VST/Verifiable-C specifications for three C helpers.
   Status: specs drafted; proofs Admitted pending full coq-vst build
   (compcert+VST compiling in background at time of writing).
   Run clightgen on termhelp.c/tlswrap.c first, then fill proofs.
   HONEST SCOPE: nothing in this file is proved. It frames the exact
   verification task so the later VST session can complete it. *)

(* Target signatures (verified against source):
   termhelp.c: static int write_all(int fd, const char *b, long n);
     returns 0 on full write, -1 on error/w==0 (EINTR retried).
   termhelp.c: int term_read_chunk(char *buf, int max);
     max<=0 -> -1; read<0 with EAGAIN/EWOULDBLOCK/EINTR -> -2;
     other error -> -1; EOF -> 0; else byte count.
   tlswrap.c: int fd_read_timeout(int fd, char *buf, int n, int timeout_ms);
     poll EINTR -> -2, poll err -> -1, poll 0 -> -3;
     read EINTR/EAGAIN/EWOULDBLOCK -> -2, err -> -1, else count (0=EOF).
*)

(* --- Spec 1: write_all ---
   Pre:  readable share sh, buffer b |-> buf contents, 0 <= n <= len.
   Post: return 0 /\ buffer unchanged /\ n bytes "accepted"
     \/  return -1 /\ buffer unchanged (error/EOF-mid-write).
   Syscall model: write() is an axiom (external); spec quantifies over
   all write() behaviours matching POSIX (short writes allowed,
   EINTR must be retried -- the loop's key obligation).
   Proof obligation (hard part): loop invariant off in [0,n] +
   "bytes [0,off) already accepted"; variant n-off.
   Status: ADMITTED. *)

(* --- Spec 2: term_read_chunk ---
   Pre:  writable buffer of >= max bytes, max is int.
   Post: max<=0 -> return -1;
     else return = read() result mapped by the errno table above,
     buffer prefix [0,ret) holds input bytes when ret > 0.
   Syscall model: read(0,...) axiom; errno axiom.
   Proof obligation: branch coverage of the errno table; no overrun
   (single read, no loop -- simplest of the three).
   Status: ADMITTED. *)

(* --- Spec 3: fd_read_timeout ---
   Pre:  writable buffer >= n bytes, timeout_ms int.
   Post: return in {-3,-2,-1} per poll/read table above, or
     0 <= ret <= n with buffer prefix holding input bytes.
   Syscall model: poll() + read() axioms.
   Proof obligation: the -2/-3/-1 distinction is exact (callers in
   Ada branch on it: retry vs timeout vs fatal -- mistaking -2 for
   fatal loses data, mistaking -3 for retry spins).
   Status: ADMITTED. *)

(* --- Explicitly OUT of VST scope (axiomatized OS, see SysModel.v) ---
   term_attach poll loop, tls_open fork/exec, pty_spawn_bash,
   pty_poll EIO/waitpid race, tls_kill/pty_close blocking wait.
   These need an OS process model VST does not supply; verify only
   their validation wrappers + return-code contracts (done in SysModel.v).
*)

(* Placeholder so the file loads in plain Rocq without VST installed. *)
Require Import String.
Definition vst_step2_status : string := "skeleton-admitted".
