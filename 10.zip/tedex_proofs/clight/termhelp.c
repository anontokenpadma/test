/* tedex terminal attach relay: stdin/stdout <-> socket, raw mode on tty */
#define _DEFAULT_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <sys/socket.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

void tedex_ignore_sigpipe (void)
{
   signal (SIGPIPE, SIG_IGN);
}

static int write_all (int fd, const char *b, long n)
{
   long off = 0;
   while (off < n) {
      long w = write (fd, b + off, (unsigned long) (n - off));
      if (w < 0) {
         if (errno == EINTR)
            continue;
         return -1;
      }
      if (w == 0)
         return -1;
      off += w;
   }
   return 0;
}

int term_attach (int sockfd)
{
   struct termios oldt;
   int istty = isatty (0);

   if (istty) {
      if (tcgetattr (0, &oldt) == 0) {
         struct termios raw = oldt;
         cfmakeraw (&raw);
         tcsetattr (0, TCSANOW, &raw);
      } else {
         istty = 0;
      }
   }
   signal (SIGPIPE, SIG_IGN);

   {
      char buf[4096];
      int stdin_done = 0;
      int maxfd = sockfd > 1 ? sockfd : 1;
      time_t last_traffic = time (0);

      (void) maxfd;
      for (;;) {
         struct pollfd p[2];
         int nfds = 0;
         if (!stdin_done) {
            p[nfds].fd = 0;
            p[nfds].events = POLLIN;
            p[nfds].revents = 0;
            nfds++;
         }
         p[nfds].fd = sockfd;
         p[nfds].events = POLLIN;
         p[nfds].revents = 0;
         nfds++;
         {
            int n = poll (p, (nfds_t) nfds, 1000);
            if (n < 0) {
               if (errno == EINTR)
                  continue;
               break;
            }
         }
         if (!stdin_done && (p[0].revents & POLLIN)) {
            long k = read (0, buf, sizeof buf);
            if (k <= 0) {
               /* No more input, but the session lives on: the shell
                  ends it (or the silence rule below does). */
               stdin_done = 1;
            } else if (write_all (sockfd, buf, k) != 0) {
               break;
            } else {
               last_traffic = time (0);
            }
         }
         if (p[nfds - 1].revents & POLLIN) {
            long k = recv (sockfd, buf, sizeof buf, 0);
            if (k <= 0)
               break;
            if (write_all (1, buf, k) != 0)
               break;
            last_traffic = time (0);
         }
         if (stdin_done && time (0) - last_traffic > 30)
            break;
      }
   }

   if (istty)
      tcsetattr (0, TCSANOW, &oldt);
   return 0;
}

/* Unbuffered line read from stdin for the manager dashboard.
   Reads byte-by-byte so no input is stolen from a later raw relay.
   Returns bytes stored (including trailing '\n'), 0 on EOF, -1 on error.
   On overflow, the rest of the line is discarded. */
int term_read_line (char *buf, int max)
{
   int n = 0;
   if (max <= 1)
      return -1;
   for (;;) {
      char c;
      long k;
      struct pollfd p;
      p.fd = 0;
      p.events = POLLIN;
      p.revents = 0;
      if (poll (&p, 1, -1) < 0) {
         if (errno == EINTR)
            continue;
         return n > 0 ? n : -1;
      }
      k = read (0, &c, 1);
      if (k < 0) {
         if (errno == EINTR)
            continue;
         return n > 0 ? n : -1;
      }
      if (k == 0)
         return n;
      if (n < max - 1)
         buf[n++] = c;
      if (c == '\n') {
         if (n >= max - 1) {
            /* discard rest of overlong line */
            for (;;) {
               k = read (0, &c, 1);
               if (k <= 0 || c == '\n')
                  break;
            }
         }
         return n;
      }
   }
}

/* Raw-mode switch for stdin (WS attach). Idempotent-ish via saved flag. */
void term_raw (int on)
{
   static struct termios oldt;
   static int saved = 0;
   if (on) {
      if (isatty (0) && tcgetattr (0, &oldt) == 0) {
         struct termios raw = oldt;
         cfmakeraw (&raw);
         tcsetattr (0, TCSANOW, &raw);
         saved = 1;
      }
   } else if (saved) {
      tcsetattr (0, TCSANOW, &oldt);
      saved = 0;
   }
}

/* O_NONBLOCK switch. Returns 0 on success, -1 on error. */
int term_set_nonblock (int fd, int on)
{
   int f = fcntl (fd, F_GETFL, 0);
   if (f < 0)
      return -1;
   if (on)
      f |= O_NONBLOCK;
   else
      f &= ~O_NONBLOCK;
   return fcntl (fd, F_SETFL, f) < 0 ? -1 : 0;
}

/* Single raw read() on stdin. >0 bytes, 0 EOF, -2 no data (EAGAIN), -1 error. */
int term_read_chunk (char *buf, int max)
{
   long k;
   if (max <= 0)
      return -1;
   k = read (0, buf, (unsigned) max);
   if (k < 0) {
      if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)
         return -2;
      return -1;
   }
   return (int) k;
}
