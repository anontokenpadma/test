From Coq Require Import String List ZArith.
From compcert Require Import Coqlib Integers Floats AST Ctypes Cop Clight Clightdefs.
Import Clightdefs.ClightNotations.
Local Open Scope Z_scope.
Local Open Scope string_scope.
Local Open Scope clight_scope.

Module Info.
  Definition version := "3.17".
  Definition build_number := "".
  Definition build_tag := "".
  Definition build_branch := "".
  Definition arch := "x86".
  Definition model := "64".
  Definition abi := "standard".
  Definition bitsize := 64.
  Definition big_endian := false.
  Definition source_file := "tlswrap.c".
  Definition normalized := true.
End Info.

Definition __IO_FILE : ident := $"_IO_FILE".
Definition __IO_backup_base : ident := $"_IO_backup_base".
Definition __IO_buf_base : ident := $"_IO_buf_base".
Definition __IO_buf_end : ident := $"_IO_buf_end".
Definition __IO_codecvt : ident := $"_IO_codecvt".
Definition __IO_marker : ident := $"_IO_marker".
Definition __IO_read_base : ident := $"_IO_read_base".
Definition __IO_read_end : ident := $"_IO_read_end".
Definition __IO_read_ptr : ident := $"_IO_read_ptr".
Definition __IO_save_base : ident := $"_IO_save_base".
Definition __IO_save_end : ident := $"_IO_save_end".
Definition __IO_wide_data : ident := $"_IO_wide_data".
Definition __IO_write_base : ident := $"_IO_write_base".
Definition __IO_write_end : ident := $"_IO_write_end".
Definition __IO_write_ptr : ident := $"_IO_write_ptr".
Definition ___builtin_ais_annot : ident := $"__builtin_ais_annot".
Definition ___builtin_annot : ident := $"__builtin_annot".
Definition ___builtin_annot_intval : ident := $"__builtin_annot_intval".
Definition ___builtin_bswap : ident := $"__builtin_bswap".
Definition ___builtin_bswap16 : ident := $"__builtin_bswap16".
Definition ___builtin_bswap32 : ident := $"__builtin_bswap32".
Definition ___builtin_bswap64 : ident := $"__builtin_bswap64".
Definition ___builtin_clz : ident := $"__builtin_clz".
Definition ___builtin_clzl : ident := $"__builtin_clzl".
Definition ___builtin_clzll : ident := $"__builtin_clzll".
Definition ___builtin_ctz : ident := $"__builtin_ctz".
Definition ___builtin_ctzl : ident := $"__builtin_ctzl".
Definition ___builtin_ctzll : ident := $"__builtin_ctzll".
Definition ___builtin_debug : ident := $"__builtin_debug".
Definition ___builtin_expect : ident := $"__builtin_expect".
Definition ___builtin_fabs : ident := $"__builtin_fabs".
Definition ___builtin_fabsf : ident := $"__builtin_fabsf".
Definition ___builtin_fmadd : ident := $"__builtin_fmadd".
Definition ___builtin_fmax : ident := $"__builtin_fmax".
Definition ___builtin_fmin : ident := $"__builtin_fmin".
Definition ___builtin_fmsub : ident := $"__builtin_fmsub".
Definition ___builtin_fnmadd : ident := $"__builtin_fnmadd".
Definition ___builtin_fnmsub : ident := $"__builtin_fnmsub".
Definition ___builtin_fsqrt : ident := $"__builtin_fsqrt".
Definition ___builtin_membar : ident := $"__builtin_membar".
Definition ___builtin_memcpy_aligned : ident := $"__builtin_memcpy_aligned".
Definition ___builtin_read16_reversed : ident := $"__builtin_read16_reversed".
Definition ___builtin_read32_reversed : ident := $"__builtin_read32_reversed".
Definition ___builtin_sel : ident := $"__builtin_sel".
Definition ___builtin_sqrt : ident := $"__builtin_sqrt".
Definition ___builtin_unreachable : ident := $"__builtin_unreachable".
Definition ___builtin_va_arg : ident := $"__builtin_va_arg".
Definition ___builtin_va_copy : ident := $"__builtin_va_copy".
Definition ___builtin_va_end : ident := $"__builtin_va_end".
Definition ___builtin_va_start : ident := $"__builtin_va_start".
Definition ___builtin_write16_reversed : ident := $"__builtin_write16_reversed".
Definition ___builtin_write32_reversed : ident := $"__builtin_write32_reversed".
Definition ___compcert_i64_dtos : ident := $"__compcert_i64_dtos".
Definition ___compcert_i64_dtou : ident := $"__compcert_i64_dtou".
Definition ___compcert_i64_sar : ident := $"__compcert_i64_sar".
Definition ___compcert_i64_sdiv : ident := $"__compcert_i64_sdiv".
Definition ___compcert_i64_shl : ident := $"__compcert_i64_shl".
Definition ___compcert_i64_shr : ident := $"__compcert_i64_shr".
Definition ___compcert_i64_smod : ident := $"__compcert_i64_smod".
Definition ___compcert_i64_smulh : ident := $"__compcert_i64_smulh".
Definition ___compcert_i64_stod : ident := $"__compcert_i64_stod".
Definition ___compcert_i64_stof : ident := $"__compcert_i64_stof".
Definition ___compcert_i64_udiv : ident := $"__compcert_i64_udiv".
Definition ___compcert_i64_umod : ident := $"__compcert_i64_umod".
Definition ___compcert_i64_umulh : ident := $"__compcert_i64_umulh".
Definition ___compcert_i64_utod : ident := $"__compcert_i64_utod".
Definition ___compcert_i64_utof : ident := $"__compcert_i64_utof".
Definition ___compcert_va_composite : ident := $"__compcert_va_composite".
Definition ___compcert_va_float64 : ident := $"__compcert_va_float64".
Definition ___compcert_va_int32 : ident := $"__compcert_va_int32".
Definition ___compcert_va_int64 : ident := $"__compcert_va_int64".
Definition ___errno_location : ident := $"__errno_location".
Definition ___pad5 : ident := $"__pad5".
Definition ___stringlit_1 : ident := $"__stringlit_1".
Definition ___stringlit_10 : ident := $"__stringlit_10".
Definition ___stringlit_11 : ident := $"__stringlit_11".
Definition ___stringlit_12 : ident := $"__stringlit_12".
Definition ___stringlit_13 : ident := $"__stringlit_13".
Definition ___stringlit_14 : ident := $"__stringlit_14".
Definition ___stringlit_15 : ident := $"__stringlit_15".
Definition ___stringlit_16 : ident := $"__stringlit_16".
Definition ___stringlit_17 : ident := $"__stringlit_17".
Definition ___stringlit_18 : ident := $"__stringlit_18".
Definition ___stringlit_19 : ident := $"__stringlit_19".
Definition ___stringlit_2 : ident := $"__stringlit_2".
Definition ___stringlit_20 : ident := $"__stringlit_20".
Definition ___stringlit_21 : ident := $"__stringlit_21".
Definition ___stringlit_22 : ident := $"__stringlit_22".
Definition ___stringlit_23 : ident := $"__stringlit_23".
Definition ___stringlit_3 : ident := $"__stringlit_3".
Definition ___stringlit_4 : ident := $"__stringlit_4".
Definition ___stringlit_5 : ident := $"__stringlit_5".
Definition ___stringlit_6 : ident := $"__stringlit_6".
Definition ___stringlit_7 : ident := $"__stringlit_7".
Definition ___stringlit_8 : ident := $"__stringlit_8".
Definition ___stringlit_9 : ident := $"__stringlit_9".
Definition __chain : ident := $"_chain".
Definition __codecvt : ident := $"_codecvt".
Definition __cur_column : ident := $"_cur_column".
Definition __exit : ident := $"_exit".
Definition __fileno : ident := $"_fileno".
Definition __flags : ident := $"_flags".
Definition __flags2 : ident := $"_flags2".
Definition __freeres_buf : ident := $"_freeres_buf".
Definition __freeres_list : ident := $"_freeres_list".
Definition __lock : ident := $"_lock".
Definition __markers : ident := $"_markers".
Definition __mode : ident := $"_mode".
Definition __offset : ident := $"_offset".
Definition __old_offset : ident := $"_old_offset".
Definition __shortbuf : ident := $"_shortbuf".
Definition __unused2 : ident := $"_unused2".
Definition __vtable_offset : ident := $"_vtable_offset".
Definition __wide_data : ident := $"_wide_data".
Definition _argv : ident := $"argv".
Definition _argv_rc : ident := $"argv_rc".
Definition _b : ident := $"b".
Definition _buf : ident := $"buf".
Definition _child_pid : ident := $"child_pid".
Definition _close : ident := $"close".
Definition _cols : ident := $"cols".
Definition _cpid : ident := $"cpid".
Definition _dn : ident := $"dn".
Definition _dup2 : ident := $"dup2".
Definition _events : ident := $"events".
Definition _execlp : ident := $"execlp".
Definition _execvp : ident := $"execvp".
Definition _f : ident := $"f".
Definition _fclose : ident := $"fclose".
Definition _fd : ident := $"fd".
Definition _fd1 : ident := $"fd1".
Definition _fd2 : ident := $"fd2".
Definition _fd_read_timeout : ident := $"fd_read_timeout".
Definition _fd_wait_read : ident := $"fd_wait_read".
Definition _fd_write_all : ident := $"fd_write_all".
Definition _fds_wait_read : ident := $"fds_wait_read".
Definition _fopen : ident := $"fopen".
Definition _fork : ident := $"fork".
Definition _fputs : ident := $"fputs".
Definition _from_child : ident := $"from_child".
Definition _getenv : ident := $"getenv".
Definition _grantpt : ident := $"grantpt".
Definition _home : ident := $"home".
Definition _host : ident := $"host".
Definition _i : ident := $"i".
Definition _ioctl : ident := $"ioctl".
Definition _k : ident := $"k".
Definition _kill : ident := $"kill".
Definition _m : ident := $"m".
Definition _main : ident := $"main".
Definition _master : ident := $"master".
Definition _master_fd : ident := $"master_fd".
Definition _max : ident := $"max".
Definition _memset : ident := $"memset".
Definition _n : ident := $"n".
Definition _off : ident := $"off".
Definition _open : ident := $"open".
Definition _out : ident := $"out".
Definition _outlen : ident := $"outlen".
Definition _p : ident := $"p".
Definition _pid : ident := $"pid".
Definition _pipe : ident := $"pipe".
Definition _poll : ident := $"poll".
Definition _pollfd : ident := $"pollfd".
Definition _port : ident := $"port".
Definition _portstr : ident := $"portstr".
Definition _posix_openpt : ident := $"posix_openpt".
Definition _ptsname : ident := $"ptsname".
Definition _pty_close : ident := $"pty_close".
Definition _pty_poll : ident := $"pty_poll".
Definition _pty_set_size : ident := $"pty_set_size".
Definition _pty_spawn_bash : ident := $"pty_spawn_bash".
Definition _r : ident := $"r".
Definition _rcf : ident := $"rcf".
Definition _read : ident := $"read".
Definition _revents : ident := $"revents".
Definition _rfd : ident := $"rfd".
Definition _rows : ident := $"rows".
Definition _s : ident := $"s".
Definition _setenv : ident := $"setenv".
Definition _setsid : ident := $"setsid".
Definition _slave : ident := $"slave".
Definition _snprintf : ident := $"snprintf".
Definition _st : ident := $"st".
Definition _strlen : ident := $"strlen".
Definition _target : ident := $"target".
Definition _term_get_size : ident := $"term_get_size".
Definition _timeout_ms : ident := $"timeout_ms".
Definition _tls_close_fd : ident := $"tls_close_fd".
Definition _tls_kill : ident := $"tls_kill".
Definition _tls_open : ident := $"tls_open".
Definition _tls_reap : ident := $"tls_reap".
Definition _to_child : ident := $"to_child".
Definition _unlockpt : ident := $"unlockpt".
Definition _usleep : ident := $"usleep".
Definition _w : ident := $"w".
Definition _waitpid : ident := $"waitpid".
Definition _wfd : ident := $"wfd".
Definition _winsize : ident := $"winsize".
Definition _write : ident := $"write".
Definition _write_tedex_rc : ident := $"write_tedex_rc".
Definition _ws : ident := $"ws".
Definition _ws_col : ident := $"ws_col".
Definition _ws_row : ident := $"ws_row".
Definition _ws_xpixel : ident := $"ws_xpixel".
Definition _ws_ypixel : ident := $"ws_ypixel".
Definition _t'1 : ident := 128%positive.
Definition _t'10 : ident := 137%positive.
Definition _t'11 : ident := 138%positive.
Definition _t'12 : ident := 139%positive.
Definition _t'13 : ident := 140%positive.
Definition _t'14 : ident := 141%positive.
Definition _t'15 : ident := 142%positive.
Definition _t'16 : ident := 143%positive.
Definition _t'17 : ident := 144%positive.
Definition _t'18 : ident := 145%positive.
Definition _t'19 : ident := 146%positive.
Definition _t'2 : ident := 129%positive.
Definition _t'20 : ident := 147%positive.
Definition _t'21 : ident := 148%positive.
Definition _t'22 : ident := 149%positive.
Definition _t'23 : ident := 150%positive.
Definition _t'3 : ident := 130%positive.
Definition _t'4 : ident := 131%positive.
Definition _t'5 : ident := 132%positive.
Definition _t'6 : ident := 133%positive.
Definition _t'7 : ident := 134%positive.
Definition _t'8 : ident := 135%positive.
Definition _t'9 : ident := 136%positive.

Definition v___stringlit_13 := {|
  gvar_info := (tarray tschar 60);
  gvar_init := (Init_int8 (Int.repr 35) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 77) :: Init_int8 (Int.repr 105) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 111) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 115) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 105) :: Init_int8 (Int.repr 110) ::
                Init_int8 (Int.repr 116) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 97) ::
                Init_int8 (Int.repr 99) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 105) :: Init_int8 (Int.repr 118) ::
                Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 110) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 110) :: Init_int8 (Int.repr 45) ::
                Init_int8 (Int.repr 108) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 103) :: Init_int8 (Int.repr 105) ::
                Init_int8 (Int.repr 110) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 115) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 97) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 116) :: Init_int8 (Int.repr 117) ::
                Init_int8 (Int.repr 112) :: Init_int8 (Int.repr 44) ::
                Init_int8 (Int.repr 32) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 104) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 110) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 107) :: Init_int8 (Int.repr 105) ::
                Init_int8 (Int.repr 108) :: Init_int8 (Int.repr 108) ::
                Init_int8 (Int.repr 115) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 84) :: Init_int8 (Int.repr 77) ::
                Init_int8 (Int.repr 79) :: Init_int8 (Int.repr 85) ::
                Init_int8 (Int.repr 84) :: Init_int8 (Int.repr 46) ::
                Init_int8 (Int.repr 10) :: Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_14 := {|
  gvar_info := (tarray tschar 55);
  gvar_init := (Init_int8 (Int.repr 105) :: Init_int8 (Int.repr 102) ::
                Init_int8 (Int.repr 32) :: Init_int8 (Int.repr 91) ::
                Init_int8 (Int.repr 32) :: Init_int8 (Int.repr 45) ::
                Init_int8 (Int.repr 102) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 34) :: Init_int8 (Int.repr 36) ::
                Init_int8 (Int.repr 72) :: Init_int8 (Int.repr 79) ::
                Init_int8 (Int.repr 77) :: Init_int8 (Int.repr 69) ::
                Init_int8 (Int.repr 47) :: Init_int8 (Int.repr 46) ::
                Init_int8 (Int.repr 98) :: Init_int8 (Int.repr 97) ::
                Init_int8 (Int.repr 115) :: Init_int8 (Int.repr 104) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 99) ::
                Init_int8 (Int.repr 34) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 93) :: Init_int8 (Int.repr 59) ::
                Init_int8 (Int.repr 32) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 104) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 110) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 46) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 34) :: Init_int8 (Int.repr 36) ::
                Init_int8 (Int.repr 72) :: Init_int8 (Int.repr 79) ::
                Init_int8 (Int.repr 77) :: Init_int8 (Int.repr 69) ::
                Init_int8 (Int.repr 47) :: Init_int8 (Int.repr 46) ::
                Init_int8 (Int.repr 98) :: Init_int8 (Int.repr 97) ::
                Init_int8 (Int.repr 115) :: Init_int8 (Int.repr 104) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 99) ::
                Init_int8 (Int.repr 34) :: Init_int8 (Int.repr 59) ::
                Init_int8 (Int.repr 32) :: Init_int8 (Int.repr 102) ::
                Init_int8 (Int.repr 105) :: Init_int8 (Int.repr 10) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_20 := {|
  gvar_info := (tarray tschar 6);
  gvar_init := (Init_int8 (Int.repr 84) :: Init_int8 (Int.repr 77) ::
                Init_int8 (Int.repr 79) :: Init_int8 (Int.repr 85) ::
                Init_int8 (Int.repr 84) :: Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_10 := {|
  gvar_info := (tarray tschar 13);
  gvar_init := (Init_int8 (Int.repr 37) :: Init_int8 (Int.repr 115) ::
                Init_int8 (Int.repr 47) :: Init_int8 (Int.repr 46) ::
                Init_int8 (Int.repr 116) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 100) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 120) :: Init_int8 (Int.repr 95) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 99) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_21 := {|
  gvar_info := (tarray tschar 10);
  gvar_init := (Init_int8 (Int.repr 47) :: Init_int8 (Int.repr 98) ::
                Init_int8 (Int.repr 105) :: Init_int8 (Int.repr 110) ::
                Init_int8 (Int.repr 47) :: Init_int8 (Int.repr 98) ::
                Init_int8 (Int.repr 97) :: Init_int8 (Int.repr 115) ::
                Init_int8 (Int.repr 104) :: Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_22 := {|
  gvar_info := (tarray tschar 9);
  gvar_init := (Init_int8 (Int.repr 45) :: Init_int8 (Int.repr 45) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 99) ::
                Init_int8 (Int.repr 102) :: Init_int8 (Int.repr 105) ::
                Init_int8 (Int.repr 108) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_9 := {|
  gvar_info := (tarray tschar 8);
  gvar_init := (Init_int8 (Int.repr 111) :: Init_int8 (Int.repr 112) ::
                Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 110) ::
                Init_int8 (Int.repr 115) :: Init_int8 (Int.repr 115) ::
                Init_int8 (Int.repr 108) :: Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_16 := {|
  gvar_info := (tarray tschar 5);
  gvar_init := (Init_int8 (Int.repr 72) :: Init_int8 (Int.repr 79) ::
                Init_int8 (Int.repr 77) :: Init_int8 (Int.repr 69) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_1 := {|
  gvar_info := (tarray tschar 10);
  gvar_init := (Init_int8 (Int.repr 47) :: Init_int8 (Int.repr 100) ::
                Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 118) ::
                Init_int8 (Int.repr 47) :: Init_int8 (Int.repr 110) ::
                Init_int8 (Int.repr 117) :: Init_int8 (Int.repr 108) ::
                Init_int8 (Int.repr 108) :: Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_5 := {|
  gvar_info := (tarray tschar 7);
  gvar_init := (Init_int8 (Int.repr 45) :: Init_int8 (Int.repr 113) ::
                Init_int8 (Int.repr 117) :: Init_int8 (Int.repr 105) ::
                Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_2 := {|
  gvar_info := (tarray tschar 3);
  gvar_init := (Init_int8 (Int.repr 37) :: Init_int8 (Int.repr 100) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_18 := {|
  gvar_info := (tarray tschar 15);
  gvar_init := (Init_int8 (Int.repr 120) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 109) :: Init_int8 (Int.repr 45) ::
                Init_int8 (Int.repr 50) :: Init_int8 (Int.repr 53) ::
                Init_int8 (Int.repr 54) :: Init_int8 (Int.repr 99) ::
                Init_int8 (Int.repr 111) :: Init_int8 (Int.repr 108) ::
                Init_int8 (Int.repr 111) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_7 := {|
  gvar_info := (tarray tschar 9);
  gvar_init := (Init_int8 (Int.repr 45) :: Init_int8 (Int.repr 99) ::
                Init_int8 (Int.repr 111) :: Init_int8 (Int.repr 110) ::
                Init_int8 (Int.repr 110) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 99) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_15 := {|
  gvar_info := (tarray tschar 50);
  gvar_init := (Init_int8 (Int.repr 117) :: Init_int8 (Int.repr 110) ::
                Init_int8 (Int.repr 115) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 116) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 84) :: Init_int8 (Int.repr 77) ::
                Init_int8 (Int.repr 79) :: Init_int8 (Int.repr 85) ::
                Init_int8 (Int.repr 84) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 50) :: Init_int8 (Int.repr 62) ::
                Init_int8 (Int.repr 47) :: Init_int8 (Int.repr 100) ::
                Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 118) ::
                Init_int8 (Int.repr 47) :: Init_int8 (Int.repr 110) ::
                Init_int8 (Int.repr 117) :: Init_int8 (Int.repr 108) ::
                Init_int8 (Int.repr 108) :: Init_int8 (Int.repr 59) ::
                Init_int8 (Int.repr 32) :: Init_int8 (Int.repr 84) ::
                Init_int8 (Int.repr 77) :: Init_int8 (Int.repr 79) ::
                Init_int8 (Int.repr 85) :: Init_int8 (Int.repr 84) ::
                Init_int8 (Int.repr 61) :: Init_int8 (Int.repr 48) ::
                Init_int8 (Int.repr 59) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 120) ::
                Init_int8 (Int.repr 112) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 32) :: Init_int8 (Int.repr 84) ::
                Init_int8 (Int.repr 77) :: Init_int8 (Int.repr 79) ::
                Init_int8 (Int.repr 85) :: Init_int8 (Int.repr 84) ::
                Init_int8 (Int.repr 61) :: Init_int8 (Int.repr 48) ::
                Init_int8 (Int.repr 10) :: Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_8 := {|
  gvar_info := (tarray tschar 9);
  gvar_init := (Init_int8 (Int.repr 115) :: Init_int8 (Int.repr 95) ::
                Init_int8 (Int.repr 99) :: Init_int8 (Int.repr 108) ::
                Init_int8 (Int.repr 105) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 110) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_3 := {|
  gvar_info := (tarray tschar 6);
  gvar_init := (Init_int8 (Int.repr 37) :: Init_int8 (Int.repr 115) ::
                Init_int8 (Int.repr 58) :: Init_int8 (Int.repr 37) ::
                Init_int8 (Int.repr 115) :: Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_4 := {|
  gvar_info := (tarray tschar 17);
  gvar_init := (Init_int8 (Int.repr 45) :: Init_int8 (Int.repr 118) ::
                Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 105) :: Init_int8 (Int.repr 102) ::
                Init_int8 (Int.repr 121) :: Init_int8 (Int.repr 95) ::
                Init_int8 (Int.repr 104) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 115) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 110) :: Init_int8 (Int.repr 97) ::
                Init_int8 (Int.repr 109) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_19 := {|
  gvar_info := (tarray tschar 2);
  gvar_init := (Init_int8 (Int.repr 48) :: Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_11 := {|
  gvar_info := (tarray tschar 2);
  gvar_init := (Init_int8 (Int.repr 119) :: Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_23 := {|
  gvar_info := (tarray tschar 3);
  gvar_init := (Init_int8 (Int.repr 45) :: Init_int8 (Int.repr 105) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_6 := {|
  gvar_info := (tarray tschar 12);
  gvar_init := (Init_int8 (Int.repr 45) :: Init_int8 (Int.repr 115) ::
                Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 118) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 110) ::
                Init_int8 (Int.repr 97) :: Init_int8 (Int.repr 109) ::
                Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_17 := {|
  gvar_info := (tarray tschar 5);
  gvar_init := (Init_int8 (Int.repr 84) :: Init_int8 (Int.repr 69) ::
                Init_int8 (Int.repr 82) :: Init_int8 (Int.repr 77) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_12 := {|
  gvar_info := (tarray tschar 63);
  gvar_init := (Init_int8 (Int.repr 35) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 116) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 100) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 120) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 100) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 118) :: Init_int8 (Int.repr 105) ::
                Init_int8 (Int.repr 99) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 32) :: Init_int8 (Int.repr 115) ::
                Init_int8 (Int.repr 104) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 108) :: Init_int8 (Int.repr 108) ::
                Init_int8 (Int.repr 32) :: Init_int8 (Int.repr 105) ::
                Init_int8 (Int.repr 110) :: Init_int8 (Int.repr 105) ::
                Init_int8 (Int.repr 116) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 40) :: Init_int8 (Int.repr 109) ::
                Init_int8 (Int.repr 97) :: Init_int8 (Int.repr 110) ::
                Init_int8 (Int.repr 97) :: Init_int8 (Int.repr 103) ::
                Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 100) ::
                Init_int8 (Int.repr 44) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 119) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 105) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 116) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 110) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 97) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 32) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 97) :: Init_int8 (Int.repr 99) ::
                Init_int8 (Int.repr 104) :: Init_int8 (Int.repr 32) ::
                Init_int8 (Int.repr 115) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 97) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 116) :: Init_int8 (Int.repr 41) ::
                Init_int8 (Int.repr 46) :: Init_int8 (Int.repr 10) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition f_fd_wait_read := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_fd, tint) :: (_timeout_ms, tint) :: nil);
  fn_vars := ((_p, (Tstruct _pollfd noattr)) :: nil);
  fn_temps := ((_r, tint) :: (_t'4, tint) :: (_t'3, (tptr tint)) ::
               (_t'2, tint) :: (_t'1, tint) :: (_t'6, tint) ::
               (_t'5, tshort) :: nil);
  fn_body :=
(Ssequence
  (Sassign (Efield (Evar _p (Tstruct _pollfd noattr)) _fd tint)
    (Etempvar _fd tint))
  (Ssequence
    (Sassign (Efield (Evar _p (Tstruct _pollfd noattr)) _events tshort)
      (Econst_int (Int.repr 1) tint))
    (Ssequence
      (Sassign (Efield (Evar _p (Tstruct _pollfd noattr)) _revents tshort)
        (Econst_int (Int.repr 0) tint))
      (Ssequence
        (Ssequence
          (Ssequence
            (Sifthenelse (Ebinop Olt (Etempvar _timeout_ms tint)
                           (Econst_int (Int.repr 0) tint) tint)
              (Sset _t'1
                (Ecast (Eunop Oneg (Econst_int (Int.repr 1) tint) tint) tint))
              (Sset _t'1 (Ecast (Etempvar _timeout_ms tint) tint)))
            (Scall (Some _t'2)
              (Evar _poll (Tfunction
                            ((tptr (Tstruct _pollfd noattr)) :: tulong ::
                             tint :: nil) tint cc_default))
              ((Eaddrof (Evar _p (Tstruct _pollfd noattr))
                 (tptr (Tstruct _pollfd noattr))) ::
               (Econst_int (Int.repr 1) tint) :: (Etempvar _t'1 tint) :: nil)))
          (Sset _r (Etempvar _t'2 tint)))
        (Ssequence
          (Sifthenelse (Ebinop Olt (Etempvar _r tint)
                         (Econst_int (Int.repr 0) tint) tint)
            (Ssequence
              (Ssequence
                (Scall (Some _t'3)
                  (Evar ___errno_location (Tfunction nil (tptr tint)
                                            cc_default)) nil)
                (Ssequence
                  (Sset _t'6 (Ederef (Etempvar _t'3 (tptr tint)) tint))
                  (Sifthenelse (Ebinop Oeq (Etempvar _t'6 tint)
                                 (Econst_int (Int.repr 4) tint) tint)
                    (Sset _t'4
                      (Ecast (Eunop Oneg (Econst_int (Int.repr 2) tint) tint)
                        tint))
                    (Sset _t'4
                      (Ecast (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)
                        tint)))))
              (Sreturn (Some (Etempvar _t'4 tint))))
            Sskip)
          (Ssequence
            (Sifthenelse (Ebinop Oeq (Etempvar _r tint)
                           (Econst_int (Int.repr 0) tint) tint)
              (Sreturn (Some (Econst_int (Int.repr 0) tint)))
              Sskip)
            (Ssequence
              (Ssequence
                (Sset _t'5
                  (Efield (Evar _p (Tstruct _pollfd noattr)) _revents tshort))
                (Sifthenelse (Ebinop Oand (Etempvar _t'5 tshort)
                               (Ebinop Oor (Econst_int (Int.repr 8) tint)
                                 (Econst_int (Int.repr 32) tint) tint) tint)
                  (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint)
                                   tint)))
                  Sskip))
              (Sreturn (Some (Econst_int (Int.repr 1) tint))))))))))
|}.

Definition f_fds_wait_read := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_fd1, tint) :: (_fd2, tint) :: (_timeout_ms, tint) :: nil);
  fn_vars := ((_p, (tarray (Tstruct _pollfd noattr) 2)) :: nil);
  fn_temps := ((_r, tint) :: (_out, tint) :: (_t'5, tint) :: (_t'4, tint) ::
               (_t'3, (tptr tint)) :: (_t'2, tint) :: (_t'1, tint) ::
               (_t'10, tint) :: (_t'9, tshort) :: (_t'8, tshort) ::
               (_t'7, tshort) :: (_t'6, tshort) :: nil);
  fn_body :=
(Ssequence
  (Sset _out (Econst_int (Int.repr 0) tint))
  (Ssequence
    (Sassign
      (Efield
        (Ederef
          (Ebinop Oadd (Evar _p (tarray (Tstruct _pollfd noattr) 2))
            (Econst_int (Int.repr 0) tint) (tptr (Tstruct _pollfd noattr)))
          (Tstruct _pollfd noattr)) _fd tint) (Etempvar _fd1 tint))
    (Ssequence
      (Sassign
        (Efield
          (Ederef
            (Ebinop Oadd (Evar _p (tarray (Tstruct _pollfd noattr) 2))
              (Econst_int (Int.repr 0) tint) (tptr (Tstruct _pollfd noattr)))
            (Tstruct _pollfd noattr)) _events tshort)
        (Econst_int (Int.repr 1) tint))
      (Ssequence
        (Sassign
          (Efield
            (Ederef
              (Ebinop Oadd (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                (Econst_int (Int.repr 0) tint)
                (tptr (Tstruct _pollfd noattr))) (Tstruct _pollfd noattr))
            _revents tshort) (Econst_int (Int.repr 0) tint))
        (Ssequence
          (Sassign
            (Efield
              (Ederef
                (Ebinop Oadd (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                  (Econst_int (Int.repr 1) tint)
                  (tptr (Tstruct _pollfd noattr))) (Tstruct _pollfd noattr))
              _fd tint) (Etempvar _fd2 tint))
          (Ssequence
            (Sassign
              (Efield
                (Ederef
                  (Ebinop Oadd (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                    (Econst_int (Int.repr 1) tint)
                    (tptr (Tstruct _pollfd noattr)))
                  (Tstruct _pollfd noattr)) _events tshort)
              (Econst_int (Int.repr 1) tint))
            (Ssequence
              (Sassign
                (Efield
                  (Ederef
                    (Ebinop Oadd
                      (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                      (Econst_int (Int.repr 1) tint)
                      (tptr (Tstruct _pollfd noattr)))
                    (Tstruct _pollfd noattr)) _revents tshort)
                (Econst_int (Int.repr 0) tint))
              (Ssequence
                (Ssequence
                  (Ssequence
                    (Sifthenelse (Ebinop Olt (Etempvar _timeout_ms tint)
                                   (Econst_int (Int.repr 0) tint) tint)
                      (Sset _t'1
                        (Ecast
                          (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)
                          tint))
                      (Sset _t'1 (Ecast (Etempvar _timeout_ms tint) tint)))
                    (Scall (Some _t'2)
                      (Evar _poll (Tfunction
                                    ((tptr (Tstruct _pollfd noattr)) ::
                                     tulong :: tint :: nil) tint cc_default))
                      ((Evar _p (tarray (Tstruct _pollfd noattr) 2)) ::
                       (Econst_int (Int.repr 2) tint) ::
                       (Etempvar _t'1 tint) :: nil)))
                  (Sset _r (Etempvar _t'2 tint)))
                (Ssequence
                  (Sifthenelse (Ebinop Olt (Etempvar _r tint)
                                 (Econst_int (Int.repr 0) tint) tint)
                    (Ssequence
                      (Ssequence
                        (Scall (Some _t'3)
                          (Evar ___errno_location (Tfunction nil (tptr tint)
                                                    cc_default)) nil)
                        (Ssequence
                          (Sset _t'10
                            (Ederef (Etempvar _t'3 (tptr tint)) tint))
                          (Sifthenelse (Ebinop Oeq (Etempvar _t'10 tint)
                                         (Econst_int (Int.repr 4) tint) tint)
                            (Sset _t'4
                              (Ecast
                                (Eunop Oneg (Econst_int (Int.repr 2) tint)
                                  tint) tint))
                            (Sset _t'4
                              (Ecast
                                (Eunop Oneg (Econst_int (Int.repr 1) tint)
                                  tint) tint)))))
                      (Sreturn (Some (Etempvar _t'4 tint))))
                    Sskip)
                  (Ssequence
                    (Sifthenelse (Ebinop Oeq (Etempvar _r tint)
                                   (Econst_int (Int.repr 0) tint) tint)
                      (Sreturn (Some (Econst_int (Int.repr 0) tint)))
                      Sskip)
                    (Ssequence
                      (Ssequence
                        (Sset _t'8
                          (Efield
                            (Ederef
                              (Ebinop Oadd
                                (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                                (Econst_int (Int.repr 0) tint)
                                (tptr (Tstruct _pollfd noattr)))
                              (Tstruct _pollfd noattr)) _revents tshort))
                        (Sifthenelse (Ebinop Oand (Etempvar _t'8 tshort)
                                       (Ebinop Oor
                                         (Econst_int (Int.repr 1) tint)
                                         (Econst_int (Int.repr 16) tint)
                                         tint) tint)
                          (Sset _out
                            (Ebinop Oor (Etempvar _out tint)
                              (Econst_int (Int.repr 1) tint) tint))
                          (Ssequence
                            (Sset _t'9
                              (Efield
                                (Ederef
                                  (Ebinop Oadd
                                    (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                                    (Econst_int (Int.repr 0) tint)
                                    (tptr (Tstruct _pollfd noattr)))
                                  (Tstruct _pollfd noattr)) _revents tshort))
                            (Sifthenelse (Ebinop Oand (Etempvar _t'9 tshort)
                                           (Ebinop Oor
                                             (Econst_int (Int.repr 8) tint)
                                             (Econst_int (Int.repr 32) tint)
                                             tint) tint)
                              (Sreturn (Some (Eunop Oneg
                                               (Econst_int (Int.repr 1) tint)
                                               tint)))
                              Sskip))))
                      (Ssequence
                        (Ssequence
                          (Sset _t'6
                            (Efield
                              (Ederef
                                (Ebinop Oadd
                                  (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                                  (Econst_int (Int.repr 1) tint)
                                  (tptr (Tstruct _pollfd noattr)))
                                (Tstruct _pollfd noattr)) _revents tshort))
                          (Sifthenelse (Ebinop Oand (Etempvar _t'6 tshort)
                                         (Ebinop Oor
                                           (Econst_int (Int.repr 1) tint)
                                           (Econst_int (Int.repr 16) tint)
                                           tint) tint)
                            (Sset _out
                              (Ebinop Oor (Etempvar _out tint)
                                (Econst_int (Int.repr 2) tint) tint))
                            (Ssequence
                              (Sset _t'7
                                (Efield
                                  (Ederef
                                    (Ebinop Oadd
                                      (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                                      (Econst_int (Int.repr 1) tint)
                                      (tptr (Tstruct _pollfd noattr)))
                                    (Tstruct _pollfd noattr)) _revents
                                  tshort))
                              (Sifthenelse (Ebinop Oand
                                             (Etempvar _t'7 tshort)
                                             (Ebinop Oor
                                               (Econst_int (Int.repr 8) tint)
                                               (Econst_int (Int.repr 32) tint)
                                               tint) tint)
                                (Sreturn (Some (Eunop Oneg
                                                 (Econst_int (Int.repr 1) tint)
                                                 tint)))
                                Sskip))))
                        (Ssequence
                          (Sifthenelse (Ebinop Oeq (Etempvar _out tint)
                                         (Econst_int (Int.repr 0) tint) tint)
                            (Sset _t'5
                              (Ecast (Econst_int (Int.repr 0) tint) tint))
                            (Sset _t'5 (Ecast (Etempvar _out tint) tint)))
                          (Sreturn (Some (Etempvar _t'5 tint))))))))))))))))
|}.

Definition f_tls_open := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_host, (tptr tschar)) :: (_port, tint) ::
                (_rfd, (tptr tint)) :: (_wfd, (tptr tint)) ::
                (_pid, (tptr tint)) :: nil);
  fn_vars := ((_to_child, (tarray tint 2)) ::
              (_from_child, (tarray tint 2)) ::
              (_portstr, (tarray tschar 16)) ::
              (_target, (tarray tschar 320)) :: nil);
  fn_temps := ((_cpid, tint) :: (_dn, tint) :: (_t'8, tint) ::
               (_t'7, tint) :: (_t'6, tint) :: (_t'5, tint) ::
               (_t'4, tint) :: (_t'3, tint) :: (_t'2, tint) ::
               (_t'1, tint) :: (_t'23, tschar) :: (_t'22, tint) ::
               (_t'21, tint) :: (_t'20, tint) :: (_t'19, tint) ::
               (_t'18, tint) :: (_t'17, tint) :: (_t'16, tint) ::
               (_t'15, tint) :: (_t'14, tint) :: (_t'13, tint) ::
               (_t'12, tint) :: (_t'11, tint) :: (_t'10, tint) ::
               (_t'9, tint) :: nil);
  fn_body :=
(Ssequence
  (Ssequence
    (Ssequence
      (Ssequence
        (Sifthenelse (Ebinop Oeq (Etempvar _host (tptr tschar))
                       (Ecast (Econst_int (Int.repr 0) tint) (tptr tvoid))
                       tint)
          (Sset _t'1 (Econst_int (Int.repr 1) tint))
          (Ssequence
            (Sset _t'23
              (Ederef
                (Ebinop Oadd (Etempvar _host (tptr tschar))
                  (Econst_int (Int.repr 0) tint) (tptr tschar)) tschar))
            (Sset _t'1
              (Ecast
                (Ebinop Oeq (Etempvar _t'23 tschar)
                  (Econst_int (Int.repr 0) tint) tint) tbool))))
        (Sifthenelse (Etempvar _t'1 tint)
          (Sset _t'2 (Econst_int (Int.repr 1) tint))
          (Sset _t'2
            (Ecast
              (Ebinop Ole (Etempvar _port tint)
                (Econst_int (Int.repr 0) tint) tint) tbool))))
      (Sifthenelse (Etempvar _t'2 tint)
        (Sset _t'3 (Econst_int (Int.repr 1) tint))
        (Sset _t'3
          (Ecast
            (Ebinop Ogt (Etempvar _port tint)
              (Econst_int (Int.repr 65535) tint) tint) tbool))))
    (Sifthenelse (Etempvar _t'3 tint)
      (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
      Sskip))
  (Ssequence
    (Ssequence
      (Ssequence
        (Scall (Some _t'4)
          (Evar _pipe (Tfunction ((tptr tint) :: nil) tint cc_default))
          ((Evar _to_child (tarray tint 2)) :: nil))
        (Sifthenelse (Ebinop Olt (Etempvar _t'4 tint)
                       (Econst_int (Int.repr 0) tint) tint)
          (Sset _t'5 (Econst_int (Int.repr 1) tint))
          (Ssequence
            (Scall (Some _t'6)
              (Evar _pipe (Tfunction ((tptr tint) :: nil) tint cc_default))
              ((Evar _from_child (tarray tint 2)) :: nil))
            (Sset _t'5
              (Ecast
                (Ebinop Olt (Etempvar _t'6 tint)
                  (Econst_int (Int.repr 0) tint) tint) tbool)))))
      (Sifthenelse (Etempvar _t'5 tint)
        (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
        Sskip))
    (Ssequence
      (Ssequence
        (Scall (Some _t'7) (Evar _fork (Tfunction nil tint cc_default)) nil)
        (Sset _cpid (Etempvar _t'7 tint)))
      (Ssequence
        (Sifthenelse (Ebinop Olt (Etempvar _cpid tint)
                       (Econst_int (Int.repr 0) tint) tint)
          (Ssequence
            (Ssequence
              (Sset _t'22
                (Ederef
                  (Ebinop Oadd (Evar _to_child (tarray tint 2))
                    (Econst_int (Int.repr 0) tint) (tptr tint)) tint))
              (Scall None
                (Evar _close (Tfunction (tint :: nil) tint cc_default))
                ((Etempvar _t'22 tint) :: nil)))
            (Ssequence
              (Ssequence
                (Sset _t'21
                  (Ederef
                    (Ebinop Oadd (Evar _to_child (tarray tint 2))
                      (Econst_int (Int.repr 1) tint) (tptr tint)) tint))
                (Scall None
                  (Evar _close (Tfunction (tint :: nil) tint cc_default))
                  ((Etempvar _t'21 tint) :: nil)))
              (Ssequence
                (Ssequence
                  (Sset _t'20
                    (Ederef
                      (Ebinop Oadd (Evar _from_child (tarray tint 2))
                        (Econst_int (Int.repr 0) tint) (tptr tint)) tint))
                  (Scall None
                    (Evar _close (Tfunction (tint :: nil) tint cc_default))
                    ((Etempvar _t'20 tint) :: nil)))
                (Ssequence
                  (Ssequence
                    (Sset _t'19
                      (Ederef
                        (Ebinop Oadd (Evar _from_child (tarray tint 2))
                          (Econst_int (Int.repr 1) tint) (tptr tint)) tint))
                    (Scall None
                      (Evar _close (Tfunction (tint :: nil) tint cc_default))
                      ((Etempvar _t'19 tint) :: nil)))
                  (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint)
                                   tint)))))))
          Sskip)
        (Ssequence
          (Sifthenelse (Ebinop Oeq (Etempvar _cpid tint)
                         (Econst_int (Int.repr 0) tint) tint)
            (Ssequence
              (Ssequence
                (Sset _t'18
                  (Ederef
                    (Ebinop Oadd (Evar _to_child (tarray tint 2))
                      (Econst_int (Int.repr 0) tint) (tptr tint)) tint))
                (Scall None
                  (Evar _dup2 (Tfunction (tint :: tint :: nil) tint
                                cc_default))
                  ((Etempvar _t'18 tint) :: (Econst_int (Int.repr 0) tint) ::
                   nil)))
              (Ssequence
                (Ssequence
                  (Sset _t'17
                    (Ederef
                      (Ebinop Oadd (Evar _from_child (tarray tint 2))
                        (Econst_int (Int.repr 1) tint) (tptr tint)) tint))
                  (Scall None
                    (Evar _dup2 (Tfunction (tint :: tint :: nil) tint
                                  cc_default))
                    ((Etempvar _t'17 tint) ::
                     (Econst_int (Int.repr 1) tint) :: nil)))
                (Ssequence
                  (Ssequence
                    (Ssequence
                      (Scall (Some _t'8)
                        (Evar _open (Tfunction ((tptr tschar) :: tint :: nil)
                                      tint
                                      {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|}))
                        ((Evar ___stringlit_1 (tarray tschar 10)) ::
                         (Econst_int (Int.repr 1) tint) :: nil))
                      (Sset _dn (Etempvar _t'8 tint)))
                    (Sifthenelse (Ebinop Oge (Etempvar _dn tint)
                                   (Econst_int (Int.repr 0) tint) tint)
                      (Scall None
                        (Evar _dup2 (Tfunction (tint :: tint :: nil) tint
                                      cc_default))
                        ((Etempvar _dn tint) ::
                         (Econst_int (Int.repr 2) tint) :: nil))
                      Sskip))
                  (Ssequence
                    (Ssequence
                      (Sset _t'16
                        (Ederef
                          (Ebinop Oadd (Evar _to_child (tarray tint 2))
                            (Econst_int (Int.repr 0) tint) (tptr tint)) tint))
                      (Scall None
                        (Evar _close (Tfunction (tint :: nil) tint
                                       cc_default))
                        ((Etempvar _t'16 tint) :: nil)))
                    (Ssequence
                      (Ssequence
                        (Sset _t'15
                          (Ederef
                            (Ebinop Oadd (Evar _to_child (tarray tint 2))
                              (Econst_int (Int.repr 1) tint) (tptr tint))
                            tint))
                        (Scall None
                          (Evar _close (Tfunction (tint :: nil) tint
                                         cc_default))
                          ((Etempvar _t'15 tint) :: nil)))
                      (Ssequence
                        (Ssequence
                          (Sset _t'14
                            (Ederef
                              (Ebinop Oadd (Evar _from_child (tarray tint 2))
                                (Econst_int (Int.repr 0) tint) (tptr tint))
                              tint))
                          (Scall None
                            (Evar _close (Tfunction (tint :: nil) tint
                                           cc_default))
                            ((Etempvar _t'14 tint) :: nil)))
                        (Ssequence
                          (Ssequence
                            (Sset _t'13
                              (Ederef
                                (Ebinop Oadd
                                  (Evar _from_child (tarray tint 2))
                                  (Econst_int (Int.repr 1) tint) (tptr tint))
                                tint))
                            (Scall None
                              (Evar _close (Tfunction (tint :: nil) tint
                                             cc_default))
                              ((Etempvar _t'13 tint) :: nil)))
                          (Ssequence
                            (Ssequence
                              (Scall None
                                (Evar _snprintf (Tfunction
                                                  ((tptr tschar) :: tulong ::
                                                   (tptr tschar) :: nil) tint
                                                  {|cc_vararg:=(Some 3); cc_unproto:=false; cc_structret:=false|}))
                                ((Evar _portstr (tarray tschar 16)) ::
                                 (Esizeof (tarray tschar 16) tulong) ::
                                 (Evar ___stringlit_2 (tarray tschar 3)) ::
                                 (Etempvar _port tint) :: nil))
                              (Ssequence
                                (Scall None
                                  (Evar _snprintf (Tfunction
                                                    ((tptr tschar) ::
                                                     tulong ::
                                                     (tptr tschar) :: nil)
                                                    tint
                                                    {|cc_vararg:=(Some 3); cc_unproto:=false; cc_structret:=false|}))
                                  ((Evar _target (tarray tschar 320)) ::
                                   (Esizeof (tarray tschar 320) tulong) ::
                                   (Evar ___stringlit_3 (tarray tschar 6)) ::
                                   (Etempvar _host (tptr tschar)) ::
                                   (Evar _portstr (tarray tschar 16)) :: nil))
                                (Scall None
                                  (Evar _execlp (Tfunction
                                                  ((tptr tschar) ::
                                                   (tptr tschar) :: nil) tint
                                                  {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|}))
                                  ((Evar ___stringlit_9 (tarray tschar 8)) ::
                                   (Evar ___stringlit_9 (tarray tschar 8)) ::
                                   (Evar ___stringlit_8 (tarray tschar 9)) ::
                                   (Evar ___stringlit_7 (tarray tschar 9)) ::
                                   (Evar _target (tarray tschar 320)) ::
                                   (Evar ___stringlit_6 (tarray tschar 12)) ::
                                   (Etempvar _host (tptr tschar)) ::
                                   (Evar ___stringlit_5 (tarray tschar 7)) ::
                                   (Evar ___stringlit_4 (tarray tschar 17)) ::
                                   (Etempvar _host (tptr tschar)) ::
                                   (Ecast (Econst_int (Int.repr 0) tint)
                                     (tptr tschar)) :: nil))))
                            (Scall None
                              (Evar __exit (Tfunction (tint :: nil) tvoid
                                             cc_default))
                              ((Econst_int (Int.repr 127) tint) :: nil))))))))))
            Sskip)
          (Ssequence
            (Ssequence
              (Sset _t'12
                (Ederef
                  (Ebinop Oadd (Evar _to_child (tarray tint 2))
                    (Econst_int (Int.repr 0) tint) (tptr tint)) tint))
              (Scall None
                (Evar _close (Tfunction (tint :: nil) tint cc_default))
                ((Etempvar _t'12 tint) :: nil)))
            (Ssequence
              (Ssequence
                (Sset _t'11
                  (Ederef
                    (Ebinop Oadd (Evar _from_child (tarray tint 2))
                      (Econst_int (Int.repr 1) tint) (tptr tint)) tint))
                (Scall None
                  (Evar _close (Tfunction (tint :: nil) tint cc_default))
                  ((Etempvar _t'11 tint) :: nil)))
              (Ssequence
                (Ssequence
                  (Sset _t'10
                    (Ederef
                      (Ebinop Oadd (Evar _to_child (tarray tint 2))
                        (Econst_int (Int.repr 1) tint) (tptr tint)) tint))
                  (Sassign (Ederef (Etempvar _wfd (tptr tint)) tint)
                    (Etempvar _t'10 tint)))
                (Ssequence
                  (Ssequence
                    (Sset _t'9
                      (Ederef
                        (Ebinop Oadd (Evar _from_child (tarray tint 2))
                          (Econst_int (Int.repr 0) tint) (tptr tint)) tint))
                    (Sassign (Ederef (Etempvar _rfd (tptr tint)) tint)
                      (Etempvar _t'9 tint)))
                  (Ssequence
                    (Sassign (Ederef (Etempvar _pid (tptr tint)) tint)
                      (Etempvar _cpid tint))
                    (Sreturn (Some (Econst_int (Int.repr 0) tint)))))))))))))
|}.

Definition f_tls_reap := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_pid, tint) :: nil);
  fn_vars := ((_st, tint) :: nil);
  fn_temps := ((_i, tint) :: (_r, tint) :: (_t'3, (tptr tint)) ::
               (_t'2, tint) :: (_t'1, tint) :: (_t'4, tint) :: nil);
  fn_body :=
(Ssequence
  (Sifthenelse (Ebinop Ole (Etempvar _pid tint)
                 (Econst_int (Int.repr 0) tint) tint)
    (Sreturn (Some (Econst_int (Int.repr 0) tint)))
    Sskip)
  (Ssequence
    (Ssequence
      (Sset _i (Econst_int (Int.repr 0) tint))
      (Sloop
        (Ssequence
          (Sifthenelse (Ebinop Olt (Etempvar _i tint)
                         (Econst_int (Int.repr 20) tint) tint)
            Sskip
            Sbreak)
          (Ssequence
            (Ssequence
              (Scall (Some _t'1)
                (Evar _waitpid (Tfunction
                                 (tint :: (tptr tint) :: tint :: nil) tint
                                 cc_default))
                ((Etempvar _pid tint) ::
                 (Eaddrof (Evar _st tint) (tptr tint)) ::
                 (Econst_int (Int.repr 1) tint) :: nil))
              (Sset _r (Etempvar _t'1 tint)))
            (Ssequence
              (Sifthenelse (Ebinop Oeq (Etempvar _r tint)
                             (Etempvar _pid tint) tint)
                (Sreturn (Some (Econst_int (Int.repr 0) tint)))
                Sskip)
              (Ssequence
                (Ssequence
                  (Sifthenelse (Ebinop Olt (Etempvar _r tint)
                                 (Econst_int (Int.repr 0) tint) tint)
                    (Ssequence
                      (Scall (Some _t'3)
                        (Evar ___errno_location (Tfunction nil (tptr tint)
                                                  cc_default)) nil)
                      (Ssequence
                        (Sset _t'4 (Ederef (Etempvar _t'3 (tptr tint)) tint))
                        (Sset _t'2
                          (Ecast
                            (Ebinop Oeq (Etempvar _t'4 tint)
                              (Econst_int (Int.repr 10) tint) tint) tbool))))
                    (Sset _t'2 (Econst_int (Int.repr 0) tint)))
                  (Sifthenelse (Etempvar _t'2 tint)
                    (Sreturn (Some (Econst_int (Int.repr 0) tint)))
                    Sskip))
                (Scall None
                  (Evar _usleep (Tfunction (tuint :: nil) tint cc_default))
                  ((Econst_int (Int.repr 100000) tint) :: nil))))))
        (Sset _i
          (Ebinop Oadd (Etempvar _i tint) (Econst_int (Int.repr 1) tint)
            tint))))
    (Sreturn (Some (Econst_int (Int.repr 1) tint)))))
|}.

Definition f_tls_kill := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_pid, tint) :: nil);
  fn_vars := ((_st, tint) :: nil);
  fn_temps := ((_i, tint) :: (_r, tint) :: (_t'3, (tptr tint)) ::
               (_t'2, tint) :: (_t'1, tint) :: (_t'4, tint) :: nil);
  fn_body :=
(Ssequence
  (Sifthenelse (Ebinop Ole (Etempvar _pid tint)
                 (Econst_int (Int.repr 0) tint) tint)
    (Sreturn (Some (Econst_int (Int.repr 0) tint)))
    Sskip)
  (Ssequence
    (Scall None
      (Evar _kill (Tfunction (tint :: tint :: nil) tint cc_default))
      ((Etempvar _pid tint) :: (Econst_int (Int.repr 15) tint) :: nil))
    (Ssequence
      (Ssequence
        (Sset _i (Econst_int (Int.repr 0) tint))
        (Sloop
          (Ssequence
            (Sifthenelse (Ebinop Olt (Etempvar _i tint)
                           (Econst_int (Int.repr 10) tint) tint)
              Sskip
              Sbreak)
            (Ssequence
              (Ssequence
                (Scall (Some _t'1)
                  (Evar _waitpid (Tfunction
                                   (tint :: (tptr tint) :: tint :: nil) tint
                                   cc_default))
                  ((Etempvar _pid tint) ::
                   (Eaddrof (Evar _st tint) (tptr tint)) ::
                   (Econst_int (Int.repr 1) tint) :: nil))
                (Sset _r (Etempvar _t'1 tint)))
              (Ssequence
                (Sifthenelse (Ebinop Oeq (Etempvar _r tint)
                               (Etempvar _pid tint) tint)
                  (Sreturn (Some (Econst_int (Int.repr 0) tint)))
                  Sskip)
                (Ssequence
                  (Ssequence
                    (Sifthenelse (Ebinop Olt (Etempvar _r tint)
                                   (Econst_int (Int.repr 0) tint) tint)
                      (Ssequence
                        (Scall (Some _t'3)
                          (Evar ___errno_location (Tfunction nil (tptr tint)
                                                    cc_default)) nil)
                        (Ssequence
                          (Sset _t'4
                            (Ederef (Etempvar _t'3 (tptr tint)) tint))
                          (Sset _t'2
                            (Ecast
                              (Ebinop Oeq (Etempvar _t'4 tint)
                                (Econst_int (Int.repr 10) tint) tint) tbool))))
                      (Sset _t'2 (Econst_int (Int.repr 0) tint)))
                    (Sifthenelse (Etempvar _t'2 tint)
                      (Sreturn (Some (Econst_int (Int.repr 0) tint)))
                      Sskip))
                  (Scall None
                    (Evar _usleep (Tfunction (tuint :: nil) tint cc_default))
                    ((Econst_int (Int.repr 100000) tint) :: nil))))))
          (Sset _i
            (Ebinop Oadd (Etempvar _i tint) (Econst_int (Int.repr 1) tint)
              tint))))
      (Ssequence
        (Scall None
          (Evar _kill (Tfunction (tint :: tint :: nil) tint cc_default))
          ((Etempvar _pid tint) :: (Econst_int (Int.repr 9) tint) :: nil))
        (Ssequence
          (Scall None
            (Evar _waitpid (Tfunction (tint :: (tptr tint) :: tint :: nil)
                             tint cc_default))
            ((Etempvar _pid tint) :: (Eaddrof (Evar _st tint) (tptr tint)) ::
             (Econst_int (Int.repr 0) tint) :: nil))
          (Sreturn (Some (Econst_int (Int.repr 0) tint))))))))
|}.

Definition f_tls_close_fd := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_fd, tint) :: nil);
  fn_vars := nil;
  fn_temps := ((_t'1, tint) :: nil);
  fn_body :=
(Ssequence
  (Scall (Some _t'1) (Evar _close (Tfunction (tint :: nil) tint cc_default))
    ((Etempvar _fd tint) :: nil))
  (Sreturn (Some (Etempvar _t'1 tint))))
|}.

Definition f_write_tedex_rc := {|
  fn_return := tvoid;
  fn_callconv := cc_default;
  fn_params := ((_home, (tptr tschar)) :: (_out, (tptr tschar)) ::
                (_outlen, tuint) :: nil);
  fn_vars := nil;
  fn_temps := ((_f, (tptr (Tstruct __IO_FILE noattr))) ::
               (_t'3, (tptr (Tstruct __IO_FILE noattr))) :: (_t'2, tulong) ::
               (_t'1, tint) :: (_t'4, tschar) :: nil);
  fn_body :=
(Ssequence
  (Sassign
    (Ederef
      (Ebinop Oadd (Etempvar _out (tptr tschar))
        (Econst_int (Int.repr 0) tint) (tptr tschar)) tschar)
    (Econst_int (Int.repr 0) tint))
  (Ssequence
    (Ssequence
      (Sifthenelse (Ebinop Oeq (Etempvar _home (tptr tschar))
                     (Ecast (Econst_int (Int.repr 0) tint) (tptr tvoid))
                     tint)
        (Sset _t'1 (Econst_int (Int.repr 1) tint))
        (Ssequence
          (Sset _t'4
            (Ederef
              (Ebinop Oadd (Etempvar _home (tptr tschar))
                (Econst_int (Int.repr 0) tint) (tptr tschar)) tschar))
          (Sset _t'1
            (Ecast
              (Ebinop Oeq (Etempvar _t'4 tschar)
                (Econst_int (Int.repr 0) tint) tint) tbool))))
      (Sifthenelse (Etempvar _t'1 tint) (Sreturn None) Sskip))
    (Ssequence
      (Ssequence
        (Scall (Some _t'2)
          (Evar _strlen (Tfunction ((tptr tschar) :: nil) tulong cc_default))
          ((Etempvar _home (tptr tschar)) :: nil))
        (Sifthenelse (Ebinop Oge
                       (Ebinop Oadd (Etempvar _t'2 tulong)
                         (Econst_int (Int.repr 16) tint) tulong)
                       (Etempvar _outlen tuint) tint)
          (Sreturn None)
          Sskip))
      (Ssequence
        (Scall None
          (Evar _snprintf (Tfunction
                            ((tptr tschar) :: tulong :: (tptr tschar) :: nil)
                            tint
                            {|cc_vararg:=(Some 3); cc_unproto:=false; cc_structret:=false|}))
          ((Etempvar _out (tptr tschar)) :: (Etempvar _outlen tuint) ::
           (Evar ___stringlit_10 (tarray tschar 13)) ::
           (Etempvar _home (tptr tschar)) :: nil))
        (Ssequence
          (Ssequence
            (Scall (Some _t'3)
              (Evar _fopen (Tfunction ((tptr tschar) :: (tptr tschar) :: nil)
                             (tptr (Tstruct __IO_FILE noattr)) cc_default))
              ((Etempvar _out (tptr tschar)) ::
               (Evar ___stringlit_11 (tarray tschar 2)) :: nil))
            (Sset _f (Etempvar _t'3 (tptr (Tstruct __IO_FILE noattr)))))
          (Ssequence
            (Sifthenelse (Ebinop Oeq
                           (Etempvar _f (tptr (Tstruct __IO_FILE noattr)))
                           (Ecast (Econst_int (Int.repr 0) tint)
                             (tptr tvoid)) tint)
              (Ssequence
                (Sassign
                  (Ederef
                    (Ebinop Oadd (Etempvar _out (tptr tschar))
                      (Econst_int (Int.repr 0) tint) (tptr tschar)) tschar)
                  (Econst_int (Int.repr 0) tint))
                (Sreturn None))
              Sskip)
            (Ssequence
              (Scall None
                (Evar _fputs (Tfunction
                               ((tptr tschar) ::
                                (tptr (Tstruct __IO_FILE noattr)) :: nil)
                               tint cc_default))
                ((Evar ___stringlit_12 (tarray tschar 63)) ::
                 (Etempvar _f (tptr (Tstruct __IO_FILE noattr))) :: nil))
              (Ssequence
                (Scall None
                  (Evar _fputs (Tfunction
                                 ((tptr tschar) ::
                                  (tptr (Tstruct __IO_FILE noattr)) :: nil)
                                 tint cc_default))
                  ((Evar ___stringlit_13 (tarray tschar 60)) ::
                   (Etempvar _f (tptr (Tstruct __IO_FILE noattr))) :: nil))
                (Ssequence
                  (Scall None
                    (Evar _fputs (Tfunction
                                   ((tptr tschar) ::
                                    (tptr (Tstruct __IO_FILE noattr)) :: nil)
                                   tint cc_default))
                    ((Evar ___stringlit_14 (tarray tschar 55)) ::
                     (Etempvar _f (tptr (Tstruct __IO_FILE noattr))) :: nil))
                  (Ssequence
                    (Scall None
                      (Evar _fputs (Tfunction
                                     ((tptr tschar) ::
                                      (tptr (Tstruct __IO_FILE noattr)) ::
                                      nil) tint cc_default))
                      ((Evar ___stringlit_15 (tarray tschar 50)) ::
                       (Etempvar _f (tptr (Tstruct __IO_FILE noattr))) ::
                       nil))
                    (Scall None
                      (Evar _fclose (Tfunction
                                      ((tptr (Tstruct __IO_FILE noattr)) ::
                                       nil) tint cc_default))
                      ((Etempvar _f (tptr (Tstruct __IO_FILE noattr))) ::
                       nil))))))))))))
|}.

Definition f_pty_spawn_bash := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_master_fd, (tptr tint)) :: (_child_pid, (tptr tint)) ::
                nil);
  fn_vars := ((_ws, (Tstruct _winsize noattr)) ::
              (_rcf, (tarray tschar 4096)) ::
              (_argv_rc, (tarray (tptr tschar) 5)) ::
              (_argv, (tarray (tptr tschar) 3)) :: nil);
  fn_temps := ((_m, tint) :: (_slave, (tptr tschar)) :: (_cpid, tint) ::
               (_s, tint) :: (_t'9, tint) :: (_t'8, (tptr tschar)) ::
               (_t'7, tint) :: (_t'6, (tptr tschar)) ::
               (_t'5, (tptr tschar)) :: (_t'4, tint) :: (_t'3, tint) ::
               (_t'2, tint) :: (_t'1, tint) :: (_t'12, (tptr tschar)) ::
               (_t'11, tschar) :: (_t'10, (tptr tschar)) :: nil);
  fn_body :=
(Ssequence
  (Ssequence
    (Scall (Some _t'1)
      (Evar _posix_openpt (Tfunction (tint :: nil) tint cc_default))
      ((Ebinop Oor (Econst_int (Int.repr 2) tint)
         (Econst_int (Int.repr 256) tint) tint) :: nil))
    (Sset _m (Etempvar _t'1 tint)))
  (Ssequence
    (Sifthenelse (Ebinop Olt (Etempvar _m tint)
                   (Econst_int (Int.repr 0) tint) tint)
      (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
      Sskip)
    (Ssequence
      (Ssequence
        (Ssequence
          (Scall (Some _t'2)
            (Evar _grantpt (Tfunction (tint :: nil) tint cc_default))
            ((Etempvar _m tint) :: nil))
          (Sifthenelse (Ebinop Olt (Etempvar _t'2 tint)
                         (Econst_int (Int.repr 0) tint) tint)
            (Sset _t'3 (Econst_int (Int.repr 1) tint))
            (Ssequence
              (Scall (Some _t'4)
                (Evar _unlockpt (Tfunction (tint :: nil) tint cc_default))
                ((Etempvar _m tint) :: nil))
              (Sset _t'3
                (Ecast
                  (Ebinop Olt (Etempvar _t'4 tint)
                    (Econst_int (Int.repr 0) tint) tint) tbool)))))
        (Sifthenelse (Etempvar _t'3 tint)
          (Ssequence
            (Scall None
              (Evar _close (Tfunction (tint :: nil) tint cc_default))
              ((Etempvar _m tint) :: nil))
            (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint))))
          Sskip))
      (Ssequence
        (Ssequence
          (Scall None
            (Evar _memset (Tfunction ((tptr tvoid) :: tint :: tulong :: nil)
                            (tptr tvoid) cc_default))
            ((Eaddrof (Evar _ws (Tstruct _winsize noattr))
               (tptr (Tstruct _winsize noattr))) ::
             (Econst_int (Int.repr 0) tint) ::
             (Esizeof (Tstruct _winsize noattr) tulong) :: nil))
          (Ssequence
            (Sassign
              (Efield (Evar _ws (Tstruct _winsize noattr)) _ws_col tushort)
              (Econst_int (Int.repr 80) tint))
            (Ssequence
              (Sassign
                (Efield (Evar _ws (Tstruct _winsize noattr)) _ws_row tushort)
                (Econst_int (Int.repr 24) tint))
              (Scall None
                (Evar _ioctl (Tfunction (tint :: tulong :: nil) tint
                               {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|}))
                ((Etempvar _m tint) :: (Econst_int (Int.repr 21524) tint) ::
                 (Eaddrof (Evar _ws (Tstruct _winsize noattr))
                   (tptr (Tstruct _winsize noattr))) :: nil)))))
        (Ssequence
          (Ssequence
            (Scall (Some _t'5)
              (Evar _ptsname (Tfunction (tint :: nil) (tptr tschar)
                               cc_default)) ((Etempvar _m tint) :: nil))
            (Sset _slave (Etempvar _t'5 (tptr tschar))))
          (Ssequence
            (Sifthenelse (Ebinop Oeq (Etempvar _slave (tptr tschar))
                           (Ecast (Econst_int (Int.repr 0) tint)
                             (tptr tvoid)) tint)
              (Ssequence
                (Scall None
                  (Evar _close (Tfunction (tint :: nil) tint cc_default))
                  ((Etempvar _m tint) :: nil))
                (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint)
                                 tint))))
              Sskip)
            (Ssequence
              (Ssequence
                (Scall (Some _t'6)
                  (Evar _getenv (Tfunction ((tptr tschar) :: nil)
                                  (tptr tschar) cc_default))
                  ((Evar ___stringlit_16 (tarray tschar 5)) :: nil))
                (Scall None
                  (Evar _write_tedex_rc (Tfunction
                                          ((tptr tschar) :: (tptr tschar) ::
                                           tuint :: nil) tvoid cc_default))
                  ((Etempvar _t'6 (tptr tschar)) ::
                   (Evar _rcf (tarray tschar 4096)) ::
                   (Esizeof (tarray tschar 4096) tulong) :: nil)))
              (Ssequence
                (Ssequence
                  (Scall (Some _t'7)
                    (Evar _fork (Tfunction nil tint cc_default)) nil)
                  (Sset _cpid (Etempvar _t'7 tint)))
                (Ssequence
                  (Sifthenelse (Ebinop Olt (Etempvar _cpid tint)
                                 (Econst_int (Int.repr 0) tint) tint)
                    (Ssequence
                      (Scall None
                        (Evar _close (Tfunction (tint :: nil) tint
                                       cc_default))
                        ((Etempvar _m tint) :: nil))
                      (Sreturn (Some (Eunop Oneg
                                       (Econst_int (Int.repr 1) tint) tint))))
                    Sskip)
                  (Ssequence
                    (Sifthenelse (Ebinop Oeq (Etempvar _cpid tint)
                                   (Econst_int (Int.repr 0) tint) tint)
                      (Ssequence
                        (Ssequence
                          (Scall (Some _t'8)
                            (Evar _getenv (Tfunction ((tptr tschar) :: nil)
                                            (tptr tschar) cc_default))
                            ((Evar ___stringlit_17 (tarray tschar 5)) :: nil))
                          (Sifthenelse (Ebinop Oeq
                                         (Etempvar _t'8 (tptr tschar))
                                         (Ecast
                                           (Econst_int (Int.repr 0) tint)
                                           (tptr tvoid)) tint)
                            (Scall None
                              (Evar _setenv (Tfunction
                                              ((tptr tschar) ::
                                               (tptr tschar) :: tint :: nil)
                                              tint cc_default))
                              ((Evar ___stringlit_17 (tarray tschar 5)) ::
                               (Evar ___stringlit_18 (tarray tschar 15)) ::
                               (Econst_int (Int.repr 0) tint) :: nil))
                            Sskip))
                        (Ssequence
                          (Scall None
                            (Evar _setenv (Tfunction
                                            ((tptr tschar) ::
                                             (tptr tschar) :: tint :: nil)
                                            tint cc_default))
                            ((Evar ___stringlit_20 (tarray tschar 6)) ::
                             (Evar ___stringlit_19 (tarray tschar 2)) ::
                             (Econst_int (Int.repr 1) tint) :: nil))
                          (Ssequence
                            (Scall None
                              (Evar _close (Tfunction (tint :: nil) tint
                                             cc_default))
                              ((Etempvar _m tint) :: nil))
                            (Ssequence
                              (Scall None
                                (Evar _setsid (Tfunction nil tint cc_default))
                                nil)
                              (Ssequence
                                (Ssequence
                                  (Scall (Some _t'9)
                                    (Evar _open (Tfunction
                                                  ((tptr tschar) :: tint ::
                                                   nil) tint
                                                  {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|}))
                                    ((Etempvar _slave (tptr tschar)) ::
                                     (Econst_int (Int.repr 2) tint) :: nil))
                                  (Sset _s (Etempvar _t'9 tint)))
                                (Ssequence
                                  (Sifthenelse (Ebinop Olt (Etempvar _s tint)
                                                 (Econst_int (Int.repr 0) tint)
                                                 tint)
                                    (Scall None
                                      (Evar __exit (Tfunction (tint :: nil)
                                                     tvoid cc_default))
                                      ((Econst_int (Int.repr 127) tint) ::
                                       nil))
                                    Sskip)
                                  (Ssequence
                                    (Scall None
                                      (Evar _dup2 (Tfunction
                                                    (tint :: tint :: nil)
                                                    tint cc_default))
                                      ((Etempvar _s tint) ::
                                       (Econst_int (Int.repr 0) tint) :: nil))
                                    (Ssequence
                                      (Scall None
                                        (Evar _dup2 (Tfunction
                                                      (tint :: tint :: nil)
                                                      tint cc_default))
                                        ((Etempvar _s tint) ::
                                         (Econst_int (Int.repr 1) tint) ::
                                         nil))
                                      (Ssequence
                                        (Scall None
                                          (Evar _dup2 (Tfunction
                                                        (tint :: tint :: nil)
                                                        tint cc_default))
                                          ((Etempvar _s tint) ::
                                           (Econst_int (Int.repr 2) tint) ::
                                           nil))
                                        (Ssequence
                                          (Sifthenelse (Ebinop Ogt
                                                         (Etempvar _s tint)
                                                         (Econst_int (Int.repr 2) tint)
                                                         tint)
                                            (Scall None
                                              (Evar _close (Tfunction
                                                             (tint :: nil)
                                                             tint cc_default))
                                              ((Etempvar _s tint) :: nil))
                                            Sskip)
                                          (Ssequence
                                            (Ssequence
                                              (Sset _t'11
                                                (Ederef
                                                  (Ebinop Oadd
                                                    (Evar _rcf (tarray tschar 4096))
                                                    (Econst_int (Int.repr 0) tint)
                                                    (tptr tschar)) tschar))
                                              (Sifthenelse (Ebinop One
                                                             (Etempvar _t'11 tschar)
                                                             (Econst_int (Int.repr 0) tint)
                                                             tint)
                                                (Ssequence
                                                  (Sassign
                                                    (Ederef
                                                      (Ebinop Oadd
                                                        (Evar _argv_rc (tarray (tptr tschar) 5))
                                                        (Econst_int (Int.repr 0) tint)
                                                        (tptr (tptr tschar)))
                                                      (tptr tschar))
                                                    (Evar ___stringlit_21 (tarray tschar 10)))
                                                  (Ssequence
                                                    (Sassign
                                                      (Ederef
                                                        (Ebinop Oadd
                                                          (Evar _argv_rc (tarray (tptr tschar) 5))
                                                          (Econst_int (Int.repr 1) tint)
                                                          (tptr (tptr tschar)))
                                                        (tptr tschar))
                                                      (Evar ___stringlit_22 (tarray tschar 9)))
                                                    (Ssequence
                                                      (Sassign
                                                        (Ederef
                                                          (Ebinop Oadd
                                                            (Evar _argv_rc (tarray (tptr tschar) 5))
                                                            (Econst_int (Int.repr 2) tint)
                                                            (tptr (tptr tschar)))
                                                          (tptr tschar))
                                                        (Evar _rcf (tarray tschar 4096)))
                                                      (Ssequence
                                                        (Sassign
                                                          (Ederef
                                                            (Ebinop Oadd
                                                              (Evar _argv_rc (tarray (tptr tschar) 5))
                                                              (Econst_int (Int.repr 3) tint)
                                                              (tptr (tptr tschar)))
                                                            (tptr tschar))
                                                          (Evar ___stringlit_23 (tarray tschar 3)))
                                                        (Ssequence
                                                          (Sassign
                                                            (Ederef
                                                              (Ebinop Oadd
                                                                (Evar _argv_rc (tarray (tptr tschar) 5))
                                                                (Econst_int (Int.repr 4) tint)
                                                                (tptr (tptr tschar)))
                                                              (tptr tschar))
                                                            (Econst_int (Int.repr 0) tint))
                                                          (Ssequence
                                                            (Sset _t'12
                                                              (Ederef
                                                                (Ebinop Oadd
                                                                  (Evar _argv_rc (tarray (tptr tschar) 5))
                                                                  (Econst_int (Int.repr 0) tint)
                                                                  (tptr (tptr tschar)))
                                                                (tptr tschar)))
                                                            (Scall None
                                                              (Evar _execvp 
                                                              (Tfunction
                                                                ((tptr tschar) ::
                                                                 (tptr (tptr tschar)) ::
                                                                 nil) tint
                                                                cc_default))
                                                              ((Etempvar _t'12 (tptr tschar)) ::
                                                               (Evar _argv_rc (tarray (tptr tschar) 5)) ::
                                                               nil))))))))
                                                Sskip))
                                            (Ssequence
                                              (Ssequence
                                                (Sassign
                                                  (Ederef
                                                    (Ebinop Oadd
                                                      (Evar _argv (tarray (tptr tschar) 3))
                                                      (Econst_int (Int.repr 0) tint)
                                                      (tptr (tptr tschar)))
                                                    (tptr tschar))
                                                  (Evar ___stringlit_21 (tarray tschar 10)))
                                                (Ssequence
                                                  (Sassign
                                                    (Ederef
                                                      (Ebinop Oadd
                                                        (Evar _argv (tarray (tptr tschar) 3))
                                                        (Econst_int (Int.repr 1) tint)
                                                        (tptr (tptr tschar)))
                                                      (tptr tschar))
                                                    (Evar ___stringlit_23 (tarray tschar 3)))
                                                  (Ssequence
                                                    (Sassign
                                                      (Ederef
                                                        (Ebinop Oadd
                                                          (Evar _argv (tarray (tptr tschar) 3))
                                                          (Econst_int (Int.repr 2) tint)
                                                          (tptr (tptr tschar)))
                                                        (tptr tschar))
                                                      (Econst_int (Int.repr 0) tint))
                                                    (Ssequence
                                                      (Sset _t'10
                                                        (Ederef
                                                          (Ebinop Oadd
                                                            (Evar _argv (tarray (tptr tschar) 3))
                                                            (Econst_int (Int.repr 0) tint)
                                                            (tptr (tptr tschar)))
                                                          (tptr tschar)))
                                                      (Scall None
                                                        (Evar _execvp 
                                                        (Tfunction
                                                          ((tptr tschar) ::
                                                           (tptr (tptr tschar)) ::
                                                           nil) tint
                                                          cc_default))
                                                        ((Etempvar _t'10 (tptr tschar)) ::
                                                         (Evar _argv (tarray (tptr tschar) 3)) ::
                                                         nil))))))
                                              (Scall None
                                                (Evar __exit (Tfunction
                                                               (tint :: nil)
                                                               tvoid
                                                               cc_default))
                                                ((Econst_int (Int.repr 127) tint) ::
                                                 nil))))))))))))))
                      Sskip)
                    (Ssequence
                      (Sassign
                        (Ederef (Etempvar _master_fd (tptr tint)) tint)
                        (Etempvar _m tint))
                      (Ssequence
                        (Sassign
                          (Ederef (Etempvar _child_pid (tptr tint)) tint)
                          (Etempvar _cpid tint))
                        (Sreturn (Some (Econst_int (Int.repr 0) tint)))))))))))))))
|}.

Definition f_pty_poll := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_master, tint) :: (_pid, tint) :: (_buf, (tptr tschar)) ::
                (_max, tint) :: (_timeout_ms, tint) :: nil);
  fn_vars := ((_p, (Tstruct _pollfd noattr)) :: (_st, tint) :: nil);
  fn_temps := ((_s, tint) :: (_k, tlong) :: (_t'11, (tptr tint)) ::
               (_t'10, tint) :: (_t'9, tint) :: (_t'8, (tptr tint)) ::
               (_t'7, (tptr tint)) :: (_t'6, tint) :: (_t'5, (tptr tint)) ::
               (_t'4, tint) :: (_t'3, tlong) :: (_t'2, (tptr tint)) ::
               (_t'1, tint) :: (_t'16, tint) :: (_t'15, tint) ::
               (_t'14, tint) :: (_t'13, tint) :: (_t'12, tint) :: nil);
  fn_body :=
(Ssequence
  (Sassign (Efield (Evar _p (Tstruct _pollfd noattr)) _fd tint)
    (Etempvar _master tint))
  (Ssequence
    (Sassign (Efield (Evar _p (Tstruct _pollfd noattr)) _events tshort)
      (Econst_int (Int.repr 1) tint))
    (Ssequence
      (Sassign (Efield (Evar _p (Tstruct _pollfd noattr)) _revents tshort)
        (Econst_int (Int.repr 0) tint))
      (Ssequence
        (Ssequence
          (Ssequence
            (Scall (Some _t'1)
              (Evar _poll (Tfunction
                            ((tptr (Tstruct _pollfd noattr)) :: tulong ::
                             tint :: nil) tint cc_default))
              ((Eaddrof (Evar _p (Tstruct _pollfd noattr))
                 (tptr (Tstruct _pollfd noattr))) ::
               (Econst_int (Int.repr 1) tint) ::
               (Etempvar _timeout_ms tint) :: nil))
            (Sset _s (Etempvar _t'1 tint)))
          (Ssequence
            (Sifthenelse (Ebinop Olt (Etempvar _s tint)
                           (Econst_int (Int.repr 0) tint) tint)
              (Ssequence
                (Ssequence
                  (Scall (Some _t'2)
                    (Evar ___errno_location (Tfunction nil (tptr tint)
                                              cc_default)) nil)
                  (Ssequence
                    (Sset _t'16 (Ederef (Etempvar _t'2 (tptr tint)) tint))
                    (Sifthenelse (Ebinop Oeq (Etempvar _t'16 tint)
                                   (Econst_int (Int.repr 4) tint) tint)
                      (Sreturn (Some (Econst_int (Int.repr 0) tint)))
                      Sskip)))
                (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 2) tint)
                                 tint))))
              Sskip)
            (Sifthenelse (Ebinop Oeq (Etempvar _s tint)
                           (Econst_int (Int.repr 0) tint) tint)
              (Sreturn (Some (Econst_int (Int.repr 0) tint)))
              Sskip)))
        (Ssequence
          (Ssequence
            (Scall (Some _t'3)
              (Evar _read (Tfunction (tint :: (tptr tvoid) :: tulong :: nil)
                            tlong cc_default))
              ((Etempvar _master tint) :: (Etempvar _buf (tptr tschar)) ::
               (Ecast (Etempvar _max tint) tuint) :: nil))
            (Sset _k (Etempvar _t'3 tlong)))
          (Ssequence
            (Sifthenelse (Ebinop Ogt (Etempvar _k tlong)
                           (Econst_int (Int.repr 0) tint) tint)
              (Sreturn (Some (Ecast (Etempvar _k tlong) tint)))
              Sskip)
            (Ssequence
              (Ssequence
                (Sifthenelse (Ebinop Olt (Etempvar _k tlong)
                               (Econst_int (Int.repr 0) tint) tint)
                  (Ssequence
                    (Ssequence
                      (Scall (Some _t'5)
                        (Evar ___errno_location (Tfunction nil (tptr tint)
                                                  cc_default)) nil)
                      (Ssequence
                        (Sset _t'14
                          (Ederef (Etempvar _t'5 (tptr tint)) tint))
                        (Sifthenelse (Ebinop Oeq (Etempvar _t'14 tint)
                                       (Econst_int (Int.repr 11) tint) tint)
                          (Sset _t'6 (Econst_int (Int.repr 1) tint))
                          (Ssequence
                            (Scall (Some _t'7)
                              (Evar ___errno_location (Tfunction nil
                                                        (tptr tint)
                                                        cc_default)) nil)
                            (Ssequence
                              (Sset _t'15
                                (Ederef (Etempvar _t'7 (tptr tint)) tint))
                              (Sset _t'6
                                (Ecast
                                  (Ebinop Oeq (Etempvar _t'15 tint)
                                    (Econst_int (Int.repr 11) tint) tint)
                                  tbool)))))))
                    (Sifthenelse (Etempvar _t'6 tint)
                      (Sset _t'4
                        (Ecast (Econst_int (Int.repr 1) tint) tbool))
                      (Ssequence
                        (Ssequence
                          (Scall (Some _t'8)
                            (Evar ___errno_location (Tfunction nil
                                                      (tptr tint) cc_default))
                            nil)
                          (Ssequence
                            (Sset _t'13
                              (Ederef (Etempvar _t'8 (tptr tint)) tint))
                            (Sset _t'4
                              (Ecast
                                (Ebinop Oeq (Etempvar _t'13 tint)
                                  (Econst_int (Int.repr 4) tint) tint) tbool))))
                        (Sset _t'4 (Ecast (Etempvar _t'4 tint) tbool)))))
                  (Sset _t'4 (Econst_int (Int.repr 0) tint)))
                (Sifthenelse (Etempvar _t'4 tint)
                  (Sreturn (Some (Econst_int (Int.repr 0) tint)))
                  Sskip))
              (Ssequence
                (Ssequence
                  (Sifthenelse (Ebinop Olt (Etempvar _k tlong)
                                 (Econst_int (Int.repr 0) tint) tint)
                    (Ssequence
                      (Scall (Some _t'11)
                        (Evar ___errno_location (Tfunction nil (tptr tint)
                                                  cc_default)) nil)
                      (Ssequence
                        (Sset _t'12
                          (Ederef (Etempvar _t'11 (tptr tint)) tint))
                        (Sset _t'10
                          (Ecast
                            (Ebinop Oeq (Etempvar _t'12 tint)
                              (Econst_int (Int.repr 5) tint) tint) tbool))))
                    (Sset _t'10 (Econst_int (Int.repr 0) tint)))
                  (Sifthenelse (Etempvar _t'10 tint)
                    (Ssequence
                      (Scall (Some _t'9)
                        (Evar _waitpid (Tfunction
                                         (tint :: (tptr tint) :: tint :: nil)
                                         tint cc_default))
                        ((Etempvar _pid tint) ::
                         (Eaddrof (Evar _st tint) (tptr tint)) ::
                         (Econst_int (Int.repr 1) tint) :: nil))
                      (Sifthenelse (Ebinop Oeq (Etempvar _t'9 tint)
                                     (Econst_int (Int.repr 0) tint) tint)
                        (Sreturn (Some (Econst_int (Int.repr 0) tint)))
                        Sskip))
                    Sskip))
                (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint)
                                 tint)))))))))))
|}.

Definition f_pty_set_size := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_master, tint) :: (_pid, tint) :: (_rows, tint) ::
                (_cols, tint) :: nil);
  fn_vars := ((_ws, (Tstruct _winsize noattr)) :: nil);
  fn_temps := ((_t'6, tint) :: (_t'5, tint) :: (_t'4, tint) ::
               (_t'3, tint) :: (_t'2, tint) :: (_t'1, tint) :: nil);
  fn_body :=
(Ssequence
  (Ssequence
    (Ssequence
      (Ssequence
        (Ssequence
          (Ssequence
            (Sifthenelse (Ebinop Olt (Etempvar _master tint)
                           (Econst_int (Int.repr 0) tint) tint)
              (Sset _t'1 (Econst_int (Int.repr 1) tint))
              (Sset _t'1
                (Ecast
                  (Ebinop Ole (Etempvar _pid tint)
                    (Econst_int (Int.repr 0) tint) tint) tbool)))
            (Sifthenelse (Etempvar _t'1 tint)
              (Sset _t'2 (Econst_int (Int.repr 1) tint))
              (Sset _t'2
                (Ecast
                  (Ebinop Ole (Etempvar _rows tint)
                    (Econst_int (Int.repr 0) tint) tint) tbool))))
          (Sifthenelse (Etempvar _t'2 tint)
            (Sset _t'3 (Econst_int (Int.repr 1) tint))
            (Sset _t'3
              (Ecast
                (Ebinop Ole (Etempvar _cols tint)
                  (Econst_int (Int.repr 0) tint) tint) tbool))))
        (Sifthenelse (Etempvar _t'3 tint)
          (Sset _t'4 (Econst_int (Int.repr 1) tint))
          (Sset _t'4
            (Ecast
              (Ebinop Ogt (Etempvar _rows tint)
                (Econst_int (Int.repr 1000) tint) tint) tbool))))
      (Sifthenelse (Etempvar _t'4 tint)
        (Sset _t'5 (Econst_int (Int.repr 1) tint))
        (Sset _t'5
          (Ecast
            (Ebinop Ogt (Etempvar _cols tint)
              (Econst_int (Int.repr 1000) tint) tint) tbool))))
    (Sifthenelse (Etempvar _t'5 tint)
      (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
      Sskip))
  (Ssequence
    (Scall None
      (Evar _memset (Tfunction ((tptr tvoid) :: tint :: tulong :: nil)
                      (tptr tvoid) cc_default))
      ((Eaddrof (Evar _ws (Tstruct _winsize noattr))
         (tptr (Tstruct _winsize noattr))) ::
       (Econst_int (Int.repr 0) tint) ::
       (Esizeof (Tstruct _winsize noattr) tulong) :: nil))
    (Ssequence
      (Sassign (Efield (Evar _ws (Tstruct _winsize noattr)) _ws_row tushort)
        (Ecast (Etempvar _rows tint) tushort))
      (Ssequence
        (Sassign
          (Efield (Evar _ws (Tstruct _winsize noattr)) _ws_col tushort)
          (Ecast (Etempvar _cols tint) tushort))
        (Ssequence
          (Ssequence
            (Scall (Some _t'6)
              (Evar _ioctl (Tfunction (tint :: tulong :: nil) tint
                             {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|}))
              ((Etempvar _master tint) ::
               (Econst_int (Int.repr 21524) tint) ::
               (Eaddrof (Evar _ws (Tstruct _winsize noattr))
                 (tptr (Tstruct _winsize noattr))) :: nil))
            (Sifthenelse (Ebinop Olt (Etempvar _t'6 tint)
                           (Econst_int (Int.repr 0) tint) tint)
              (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
              Sskip))
          (Ssequence
            (Scall None
              (Evar _kill (Tfunction (tint :: tint :: nil) tint cc_default))
              ((Etempvar _pid tint) :: (Econst_int (Int.repr 28) tint) ::
               nil))
            (Sreturn (Some (Econst_int (Int.repr 0) tint)))))))))
|}.

Definition f_term_get_size := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_rows, (tptr tint)) :: (_cols, (tptr tint)) :: nil);
  fn_vars := ((_ws, (Tstruct _winsize noattr)) :: nil);
  fn_temps := ((_t'5, tint) :: (_t'4, tint) :: (_t'3, tint) ::
               (_t'2, tint) :: (_t'1, tint) :: (_t'11, tushort) ::
               (_t'10, tushort) :: (_t'9, tushort) :: (_t'8, tushort) ::
               (_t'7, tushort) :: (_t'6, tushort) :: nil);
  fn_body :=
(Ssequence
  (Ssequence
    (Sifthenelse (Ebinop Oeq (Etempvar _rows (tptr tint))
                   (Ecast (Econst_int (Int.repr 0) tint) (tptr tvoid)) tint)
      (Sset _t'1 (Econst_int (Int.repr 1) tint))
      (Sset _t'1
        (Ecast
          (Ebinop Oeq (Etempvar _cols (tptr tint))
            (Ecast (Econst_int (Int.repr 0) tint) (tptr tvoid)) tint) tbool)))
    (Sifthenelse (Etempvar _t'1 tint)
      (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
      Sskip))
  (Ssequence
    (Sassign (Ederef (Etempvar _rows (tptr tint)) tint)
      (Econst_int (Int.repr 0) tint))
    (Ssequence
      (Sassign (Ederef (Etempvar _cols (tptr tint)) tint)
        (Econst_int (Int.repr 0) tint))
      (Ssequence
        (Scall None
          (Evar _memset (Tfunction ((tptr tvoid) :: tint :: tulong :: nil)
                          (tptr tvoid) cc_default))
          ((Eaddrof (Evar _ws (Tstruct _winsize noattr))
             (tptr (Tstruct _winsize noattr))) ::
           (Econst_int (Int.repr 0) tint) ::
           (Esizeof (Tstruct _winsize noattr) tulong) :: nil))
        (Ssequence
          (Ssequence
            (Scall (Some _t'2)
              (Evar _ioctl (Tfunction (tint :: tulong :: nil) tint
                             {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|}))
              ((Econst_int (Int.repr 0) tint) ::
               (Econst_int (Int.repr 21523) tint) ::
               (Eaddrof (Evar _ws (Tstruct _winsize noattr))
                 (tptr (Tstruct _winsize noattr))) :: nil))
            (Sifthenelse (Ebinop Olt (Etempvar _t'2 tint)
                           (Econst_int (Int.repr 0) tint) tint)
              (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
              Sskip))
          (Ssequence
            (Ssequence
              (Ssequence
                (Ssequence
                  (Ssequence
                    (Sset _t'10
                      (Efield (Evar _ws (Tstruct _winsize noattr)) _ws_row
                        tushort))
                    (Sifthenelse (Ebinop Ole (Etempvar _t'10 tushort)
                                   (Econst_int (Int.repr 0) tint) tint)
                      (Sset _t'3 (Econst_int (Int.repr 1) tint))
                      (Ssequence
                        (Sset _t'11
                          (Efield (Evar _ws (Tstruct _winsize noattr))
                            _ws_col tushort))
                        (Sset _t'3
                          (Ecast
                            (Ebinop Ole (Etempvar _t'11 tushort)
                              (Econst_int (Int.repr 0) tint) tint) tbool)))))
                  (Sifthenelse (Etempvar _t'3 tint)
                    (Sset _t'4 (Econst_int (Int.repr 1) tint))
                    (Ssequence
                      (Sset _t'9
                        (Efield (Evar _ws (Tstruct _winsize noattr)) _ws_row
                          tushort))
                      (Sset _t'4
                        (Ecast
                          (Ebinop Ogt (Etempvar _t'9 tushort)
                            (Econst_int (Int.repr 1000) tint) tint) tbool)))))
                (Sifthenelse (Etempvar _t'4 tint)
                  (Sset _t'5 (Econst_int (Int.repr 1) tint))
                  (Ssequence
                    (Sset _t'8
                      (Efield (Evar _ws (Tstruct _winsize noattr)) _ws_col
                        tushort))
                    (Sset _t'5
                      (Ecast
                        (Ebinop Ogt (Etempvar _t'8 tushort)
                          (Econst_int (Int.repr 1000) tint) tint) tbool)))))
              (Sifthenelse (Etempvar _t'5 tint)
                (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint)
                                 tint)))
                Sskip))
            (Ssequence
              (Ssequence
                (Sset _t'7
                  (Efield (Evar _ws (Tstruct _winsize noattr)) _ws_row
                    tushort))
                (Sassign (Ederef (Etempvar _rows (tptr tint)) tint)
                  (Etempvar _t'7 tushort)))
              (Ssequence
                (Ssequence
                  (Sset _t'6
                    (Efield (Evar _ws (Tstruct _winsize noattr)) _ws_col
                      tushort))
                  (Sassign (Ederef (Etempvar _cols (tptr tint)) tint)
                    (Etempvar _t'6 tushort)))
                (Sreturn (Some (Econst_int (Int.repr 0) tint)))))))))))
|}.

Definition f_pty_close := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_master, tint) :: (_pid, tint) :: nil);
  fn_vars := ((_st, tint) :: nil);
  fn_temps := ((_i, tint) :: (_t'2, tint) :: (_t'1, tint) :: nil);
  fn_body :=
(Ssequence
  (Sifthenelse (Ebinop Ogt (Etempvar _pid tint)
                 (Econst_int (Int.repr 0) tint) tint)
    (Ssequence
      (Scall None
        (Evar _kill (Tfunction (tint :: tint :: nil) tint cc_default))
        ((Etempvar _pid tint) :: (Econst_int (Int.repr 15) tint) :: nil))
      (Ssequence
        (Ssequence
          (Sset _i (Econst_int (Int.repr 0) tint))
          (Sloop
            (Ssequence
              (Sifthenelse (Ebinop Olt (Etempvar _i tint)
                             (Econst_int (Int.repr 10) tint) tint)
                Sskip
                Sbreak)
              (Ssequence
                (Ssequence
                  (Scall (Some _t'1)
                    (Evar _waitpid (Tfunction
                                     (tint :: (tptr tint) :: tint :: nil)
                                     tint cc_default))
                    ((Etempvar _pid tint) ::
                     (Eaddrof (Evar _st tint) (tptr tint)) ::
                     (Econst_int (Int.repr 1) tint) :: nil))
                  (Sifthenelse (Ebinop Oeq (Etempvar _t'1 tint)
                                 (Etempvar _pid tint) tint)
                    Sbreak
                    Sskip))
                (Scall None
                  (Evar _usleep (Tfunction (tuint :: nil) tint cc_default))
                  ((Econst_int (Int.repr 100000) tint) :: nil))))
            (Sset _i
              (Ebinop Oadd (Etempvar _i tint) (Econst_int (Int.repr 1) tint)
                tint))))
        (Ssequence
          (Scall (Some _t'2)
            (Evar _waitpid (Tfunction (tint :: (tptr tint) :: tint :: nil)
                             tint cc_default))
            ((Etempvar _pid tint) :: (Eaddrof (Evar _st tint) (tptr tint)) ::
             (Econst_int (Int.repr 1) tint) :: nil))
          (Sifthenelse (Ebinop One (Etempvar _t'2 tint) (Etempvar _pid tint)
                         tint)
            (Ssequence
              (Scall None
                (Evar _kill (Tfunction (tint :: tint :: nil) tint cc_default))
                ((Etempvar _pid tint) :: (Econst_int (Int.repr 9) tint) ::
                 nil))
              (Scall None
                (Evar _waitpid (Tfunction
                                 (tint :: (tptr tint) :: tint :: nil) tint
                                 cc_default))
                ((Etempvar _pid tint) ::
                 (Eaddrof (Evar _st tint) (tptr tint)) ::
                 (Econst_int (Int.repr 0) tint) :: nil)))
            Sskip))))
    Sskip)
  (Ssequence
    (Sifthenelse (Ebinop Oge (Etempvar _master tint)
                   (Econst_int (Int.repr 0) tint) tint)
      (Scall None (Evar _close (Tfunction (tint :: nil) tint cc_default))
        ((Etempvar _master tint) :: nil))
      Sskip)
    (Sreturn (Some (Econst_int (Int.repr 0) tint)))))
|}.

Definition f_fd_read_timeout := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_fd, tint) :: (_buf, (tptr tschar)) :: (_n, tint) ::
                (_timeout_ms, tint) :: nil);
  fn_vars := ((_p, (Tstruct _pollfd noattr)) :: nil);
  fn_temps := ((_s, tint) :: (_k, tlong) :: (_t'8, (tptr tint)) ::
               (_t'7, tint) :: (_t'6, (tptr tint)) :: (_t'5, tint) ::
               (_t'4, (tptr tint)) :: (_t'3, tlong) :: (_t'2, (tptr tint)) ::
               (_t'1, tint) :: (_t'12, tint) :: (_t'11, tint) ::
               (_t'10, tint) :: (_t'9, tint) :: nil);
  fn_body :=
(Ssequence
  (Sassign (Efield (Evar _p (Tstruct _pollfd noattr)) _fd tint)
    (Etempvar _fd tint))
  (Ssequence
    (Sassign (Efield (Evar _p (Tstruct _pollfd noattr)) _events tshort)
      (Econst_int (Int.repr 1) tint))
    (Ssequence
      (Sassign (Efield (Evar _p (Tstruct _pollfd noattr)) _revents tshort)
        (Econst_int (Int.repr 0) tint))
      (Ssequence
        (Ssequence
          (Ssequence
            (Scall (Some _t'1)
              (Evar _poll (Tfunction
                            ((tptr (Tstruct _pollfd noattr)) :: tulong ::
                             tint :: nil) tint cc_default))
              ((Eaddrof (Evar _p (Tstruct _pollfd noattr))
                 (tptr (Tstruct _pollfd noattr))) ::
               (Econst_int (Int.repr 1) tint) ::
               (Etempvar _timeout_ms tint) :: nil))
            (Sset _s (Etempvar _t'1 tint)))
          (Ssequence
            (Sifthenelse (Ebinop Olt (Etempvar _s tint)
                           (Econst_int (Int.repr 0) tint) tint)
              (Ssequence
                (Ssequence
                  (Scall (Some _t'2)
                    (Evar ___errno_location (Tfunction nil (tptr tint)
                                              cc_default)) nil)
                  (Ssequence
                    (Sset _t'12 (Ederef (Etempvar _t'2 (tptr tint)) tint))
                    (Sifthenelse (Ebinop Oeq (Etempvar _t'12 tint)
                                   (Econst_int (Int.repr 4) tint) tint)
                      (Sreturn (Some (Eunop Oneg
                                       (Econst_int (Int.repr 2) tint) tint)))
                      Sskip)))
                (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint)
                                 tint))))
              Sskip)
            (Sifthenelse (Ebinop Oeq (Etempvar _s tint)
                           (Econst_int (Int.repr 0) tint) tint)
              (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 3) tint) tint)))
              Sskip)))
        (Ssequence
          (Ssequence
            (Scall (Some _t'3)
              (Evar _read (Tfunction (tint :: (tptr tvoid) :: tulong :: nil)
                            tlong cc_default))
              ((Etempvar _fd tint) :: (Etempvar _buf (tptr tschar)) ::
               (Ecast (Etempvar _n tint) tuint) :: nil))
            (Sset _k (Etempvar _t'3 tlong)))
          (Ssequence
            (Sifthenelse (Ebinop Olt (Etempvar _k tlong)
                           (Econst_int (Int.repr 0) tint) tint)
              (Ssequence
                (Ssequence
                  (Ssequence
                    (Ssequence
                      (Scall (Some _t'4)
                        (Evar ___errno_location (Tfunction nil (tptr tint)
                                                  cc_default)) nil)
                      (Ssequence
                        (Sset _t'10
                          (Ederef (Etempvar _t'4 (tptr tint)) tint))
                        (Sifthenelse (Ebinop Oeq (Etempvar _t'10 tint)
                                       (Econst_int (Int.repr 4) tint) tint)
                          (Sset _t'5 (Econst_int (Int.repr 1) tint))
                          (Ssequence
                            (Scall (Some _t'6)
                              (Evar ___errno_location (Tfunction nil
                                                        (tptr tint)
                                                        cc_default)) nil)
                            (Ssequence
                              (Sset _t'11
                                (Ederef (Etempvar _t'6 (tptr tint)) tint))
                              (Sset _t'5
                                (Ecast
                                  (Ebinop Oeq (Etempvar _t'11 tint)
                                    (Econst_int (Int.repr 11) tint) tint)
                                  tbool)))))))
                    (Sifthenelse (Etempvar _t'5 tint)
                      (Sset _t'7 (Econst_int (Int.repr 1) tint))
                      (Ssequence
                        (Scall (Some _t'8)
                          (Evar ___errno_location (Tfunction nil (tptr tint)
                                                    cc_default)) nil)
                        (Ssequence
                          (Sset _t'9
                            (Ederef (Etempvar _t'8 (tptr tint)) tint))
                          (Sset _t'7
                            (Ecast
                              (Ebinop Oeq (Etempvar _t'9 tint)
                                (Econst_int (Int.repr 11) tint) tint) tbool))))))
                  (Sifthenelse (Etempvar _t'7 tint)
                    (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 2) tint)
                                     tint)))
                    Sskip))
                (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint)
                                 tint))))
              Sskip)
            (Sreturn (Some (Ecast (Etempvar _k tlong) tint)))))))))
|}.

Definition f_fd_write_all := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_fd, tint) :: (_b, (tptr tschar)) :: (_n, tint) :: nil);
  fn_vars := nil;
  fn_temps := ((_off, tint) :: (_w, tlong) :: (_t'2, (tptr tint)) ::
               (_t'1, tlong) :: (_t'3, tint) :: nil);
  fn_body :=
(Ssequence
  (Sset _off (Econst_int (Int.repr 0) tint))
  (Ssequence
    (Swhile
      (Ebinop Olt (Etempvar _off tint) (Etempvar _n tint) tint)
      (Ssequence
        (Ssequence
          (Scall (Some _t'1)
            (Evar _write (Tfunction (tint :: (tptr tvoid) :: tulong :: nil)
                           tlong cc_default))
            ((Etempvar _fd tint) ::
             (Ebinop Oadd (Etempvar _b (tptr tschar)) (Etempvar _off tint)
               (tptr tschar)) ::
             (Ecast
               (Ebinop Osub (Etempvar _n tint) (Etempvar _off tint) tint)
               tuint) :: nil))
          (Sset _w (Etempvar _t'1 tlong)))
        (Ssequence
          (Sifthenelse (Ebinop Olt (Etempvar _w tlong)
                         (Econst_int (Int.repr 0) tint) tint)
            (Ssequence
              (Ssequence
                (Scall (Some _t'2)
                  (Evar ___errno_location (Tfunction nil (tptr tint)
                                            cc_default)) nil)
                (Ssequence
                  (Sset _t'3 (Ederef (Etempvar _t'2 (tptr tint)) tint))
                  (Sifthenelse (Ebinop Oeq (Etempvar _t'3 tint)
                                 (Econst_int (Int.repr 4) tint) tint)
                    Scontinue
                    Sskip)))
              (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint))))
            Sskip)
          (Ssequence
            (Sifthenelse (Ebinop Oeq (Etempvar _w tlong)
                           (Econst_int (Int.repr 0) tint) tint)
              (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
              Sskip)
            (Sset _off
              (Ebinop Oadd (Etempvar _off tint)
                (Ecast (Etempvar _w tlong) tint) tint))))))
    (Sreturn (Some (Econst_int (Int.repr 0) tint)))))
|}.

Definition composites : list composite_definition :=
(Composite _pollfd Struct
   (Member_plain _fd tint :: Member_plain _events tshort ::
    Member_plain _revents tshort :: nil)
   noattr ::
 Composite _winsize Struct
   (Member_plain _ws_row tushort :: Member_plain _ws_col tushort ::
    Member_plain _ws_xpixel tushort :: Member_plain _ws_ypixel tushort ::
    nil)
   noattr ::
 Composite __IO_FILE Struct
   (Member_plain __flags tint :: Member_plain __IO_read_ptr (tptr tschar) ::
    Member_plain __IO_read_end (tptr tschar) ::
    Member_plain __IO_read_base (tptr tschar) ::
    Member_plain __IO_write_base (tptr tschar) ::
    Member_plain __IO_write_ptr (tptr tschar) ::
    Member_plain __IO_write_end (tptr tschar) ::
    Member_plain __IO_buf_base (tptr tschar) ::
    Member_plain __IO_buf_end (tptr tschar) ::
    Member_plain __IO_save_base (tptr tschar) ::
    Member_plain __IO_backup_base (tptr tschar) ::
    Member_plain __IO_save_end (tptr tschar) ::
    Member_plain __markers (tptr (Tstruct __IO_marker noattr)) ::
    Member_plain __chain (tptr (Tstruct __IO_FILE noattr)) ::
    Member_plain __fileno tint :: Member_plain __flags2 tint ::
    Member_plain __old_offset tlong :: Member_plain __cur_column tushort ::
    Member_plain __vtable_offset tschar ::
    Member_plain __shortbuf (tarray tschar 1) ::
    Member_plain __lock (tptr tvoid) :: Member_plain __offset tlong ::
    Member_plain __codecvt (tptr (Tstruct __IO_codecvt noattr)) ::
    Member_plain __wide_data (tptr (Tstruct __IO_wide_data noattr)) ::
    Member_plain __freeres_list (tptr (Tstruct __IO_FILE noattr)) ::
    Member_plain __freeres_buf (tptr tvoid) :: Member_plain ___pad5 tulong ::
    Member_plain __mode tint :: Member_plain __unused2 (tarray tschar 20) ::
    nil)
   noattr :: nil).

Definition global_definitions : list (ident * globdef fundef type) :=
((___compcert_va_int32,
   Gfun(External (EF_runtime "__compcert_va_int32"
                   (mksignature (AST.Xptr :: nil) AST.Xint cc_default))
     ((tptr tvoid) :: nil) tuint cc_default)) ::
 (___compcert_va_int64,
   Gfun(External (EF_runtime "__compcert_va_int64"
                   (mksignature (AST.Xptr :: nil) AST.Xlong cc_default))
     ((tptr tvoid) :: nil) tulong cc_default)) ::
 (___compcert_va_float64,
   Gfun(External (EF_runtime "__compcert_va_float64"
                   (mksignature (AST.Xptr :: nil) AST.Xfloat cc_default))
     ((tptr tvoid) :: nil) tdouble cc_default)) ::
 (___compcert_va_composite,
   Gfun(External (EF_runtime "__compcert_va_composite"
                   (mksignature (AST.Xptr :: AST.Xlong :: nil) AST.Xptr
                     cc_default)) ((tptr tvoid) :: tulong :: nil)
     (tptr tvoid) cc_default)) ::
 (___compcert_i64_dtos,
   Gfun(External (EF_runtime "__compcert_i64_dtos"
                   (mksignature (AST.Xfloat :: nil) AST.Xlong cc_default))
     (tdouble :: nil) tlong cc_default)) ::
 (___compcert_i64_dtou,
   Gfun(External (EF_runtime "__compcert_i64_dtou"
                   (mksignature (AST.Xfloat :: nil) AST.Xlong cc_default))
     (tdouble :: nil) tulong cc_default)) ::
 (___compcert_i64_stod,
   Gfun(External (EF_runtime "__compcert_i64_stod"
                   (mksignature (AST.Xlong :: nil) AST.Xfloat cc_default))
     (tlong :: nil) tdouble cc_default)) ::
 (___compcert_i64_utod,
   Gfun(External (EF_runtime "__compcert_i64_utod"
                   (mksignature (AST.Xlong :: nil) AST.Xfloat cc_default))
     (tulong :: nil) tdouble cc_default)) ::
 (___compcert_i64_stof,
   Gfun(External (EF_runtime "__compcert_i64_stof"
                   (mksignature (AST.Xlong :: nil) AST.Xsingle cc_default))
     (tlong :: nil) tfloat cc_default)) ::
 (___compcert_i64_utof,
   Gfun(External (EF_runtime "__compcert_i64_utof"
                   (mksignature (AST.Xlong :: nil) AST.Xsingle cc_default))
     (tulong :: nil) tfloat cc_default)) ::
 (___compcert_i64_sdiv,
   Gfun(External (EF_runtime "__compcert_i64_sdiv"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___compcert_i64_udiv,
   Gfun(External (EF_runtime "__compcert_i64_udiv"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tulong :: tulong :: nil) tulong
     cc_default)) ::
 (___compcert_i64_smod,
   Gfun(External (EF_runtime "__compcert_i64_smod"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___compcert_i64_umod,
   Gfun(External (EF_runtime "__compcert_i64_umod"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tulong :: tulong :: nil) tulong
     cc_default)) ::
 (___compcert_i64_shl,
   Gfun(External (EF_runtime "__compcert_i64_shl"
                   (mksignature (AST.Xlong :: AST.Xint :: nil) AST.Xlong
                     cc_default)) (tlong :: tint :: nil) tlong cc_default)) ::
 (___compcert_i64_shr,
   Gfun(External (EF_runtime "__compcert_i64_shr"
                   (mksignature (AST.Xlong :: AST.Xint :: nil) AST.Xlong
                     cc_default)) (tulong :: tint :: nil) tulong cc_default)) ::
 (___compcert_i64_sar,
   Gfun(External (EF_runtime "__compcert_i64_sar"
                   (mksignature (AST.Xlong :: AST.Xint :: nil) AST.Xlong
                     cc_default)) (tlong :: tint :: nil) tlong cc_default)) ::
 (___compcert_i64_smulh,
   Gfun(External (EF_runtime "__compcert_i64_smulh"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___compcert_i64_umulh,
   Gfun(External (EF_runtime "__compcert_i64_umulh"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tulong :: tulong :: nil) tulong
     cc_default)) :: (___stringlit_13, Gvar v___stringlit_13) ::
 (___stringlit_14, Gvar v___stringlit_14) ::
 (___stringlit_20, Gvar v___stringlit_20) ::
 (___stringlit_10, Gvar v___stringlit_10) ::
 (___stringlit_21, Gvar v___stringlit_21) ::
 (___stringlit_22, Gvar v___stringlit_22) ::
 (___stringlit_9, Gvar v___stringlit_9) ::
 (___stringlit_16, Gvar v___stringlit_16) ::
 (___stringlit_1, Gvar v___stringlit_1) ::
 (___stringlit_5, Gvar v___stringlit_5) ::
 (___stringlit_2, Gvar v___stringlit_2) ::
 (___stringlit_18, Gvar v___stringlit_18) ::
 (___stringlit_7, Gvar v___stringlit_7) ::
 (___stringlit_15, Gvar v___stringlit_15) ::
 (___stringlit_8, Gvar v___stringlit_8) ::
 (___stringlit_3, Gvar v___stringlit_3) ::
 (___stringlit_4, Gvar v___stringlit_4) ::
 (___stringlit_19, Gvar v___stringlit_19) ::
 (___stringlit_11, Gvar v___stringlit_11) ::
 (___stringlit_23, Gvar v___stringlit_23) ::
 (___stringlit_6, Gvar v___stringlit_6) ::
 (___stringlit_17, Gvar v___stringlit_17) ::
 (___stringlit_12, Gvar v___stringlit_12) ::
 (___builtin_ais_annot,
   Gfun(External (EF_builtin "__builtin_ais_annot"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     ((tptr tschar) :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (___builtin_bswap64,
   Gfun(External (EF_builtin "__builtin_bswap64"
                   (mksignature (AST.Xlong :: nil) AST.Xlong cc_default))
     (tulong :: nil) tulong cc_default)) ::
 (___builtin_bswap,
   Gfun(External (EF_builtin "__builtin_bswap"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tuint cc_default)) ::
 (___builtin_bswap32,
   Gfun(External (EF_builtin "__builtin_bswap32"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tuint cc_default)) ::
 (___builtin_bswap16,
   Gfun(External (EF_builtin "__builtin_bswap16"
                   (mksignature (AST.Xint16unsigned :: nil)
                     AST.Xint16unsigned cc_default)) (tushort :: nil) tushort
     cc_default)) ::
 (___builtin_clz,
   Gfun(External (EF_builtin "__builtin_clz"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tint cc_default)) ::
 (___builtin_clzl,
   Gfun(External (EF_builtin "__builtin_clzl"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_clzll,
   Gfun(External (EF_builtin "__builtin_clzll"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_ctz,
   Gfun(External (EF_builtin "__builtin_ctz"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tint cc_default)) ::
 (___builtin_ctzl,
   Gfun(External (EF_builtin "__builtin_ctzl"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_ctzll,
   Gfun(External (EF_builtin "__builtin_ctzll"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_fabs,
   Gfun(External (EF_builtin "__builtin_fabs"
                   (mksignature (AST.Xfloat :: nil) AST.Xfloat cc_default))
     (tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fabsf,
   Gfun(External (EF_builtin "__builtin_fabsf"
                   (mksignature (AST.Xsingle :: nil) AST.Xsingle cc_default))
     (tfloat :: nil) tfloat cc_default)) ::
 (___builtin_fsqrt,
   Gfun(External (EF_builtin "__builtin_fsqrt"
                   (mksignature (AST.Xfloat :: nil) AST.Xfloat cc_default))
     (tdouble :: nil) tdouble cc_default)) ::
 (___builtin_sqrt,
   Gfun(External (EF_builtin "__builtin_sqrt"
                   (mksignature (AST.Xfloat :: nil) AST.Xfloat cc_default))
     (tdouble :: nil) tdouble cc_default)) ::
 (___builtin_memcpy_aligned,
   Gfun(External (EF_builtin "__builtin_memcpy_aligned"
                   (mksignature
                     (AST.Xptr :: AST.Xptr :: AST.Xlong :: AST.Xlong :: nil)
                     AST.Xvoid cc_default))
     ((tptr tvoid) :: (tptr tvoid) :: tulong :: tulong :: nil) tvoid
     cc_default)) ::
 (___builtin_sel,
   Gfun(External (EF_builtin "__builtin_sel"
                   (mksignature (AST.Xbool :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     (tbool :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (___builtin_annot,
   Gfun(External (EF_builtin "__builtin_annot"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     ((tptr tschar) :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (___builtin_annot_intval,
   Gfun(External (EF_builtin "__builtin_annot_intval"
                   (mksignature (AST.Xptr :: AST.Xint :: nil) AST.Xint
                     cc_default)) ((tptr tschar) :: tint :: nil) tint
     cc_default)) ::
 (___builtin_membar,
   Gfun(External (EF_builtin "__builtin_membar"
                   (mksignature nil AST.Xvoid cc_default)) nil tvoid
     cc_default)) ::
 (___builtin_va_start,
   Gfun(External (EF_builtin "__builtin_va_start"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid cc_default))
     ((tptr tvoid) :: nil) tvoid cc_default)) ::
 (___builtin_va_arg,
   Gfun(External (EF_builtin "__builtin_va_arg"
                   (mksignature (AST.Xptr :: AST.Xint :: nil) AST.Xvoid
                     cc_default)) ((tptr tvoid) :: tuint :: nil) tvoid
     cc_default)) ::
 (___builtin_va_copy,
   Gfun(External (EF_builtin "__builtin_va_copy"
                   (mksignature (AST.Xptr :: AST.Xptr :: nil) AST.Xvoid
                     cc_default)) ((tptr tvoid) :: (tptr tvoid) :: nil) tvoid
     cc_default)) ::
 (___builtin_va_end,
   Gfun(External (EF_builtin "__builtin_va_end"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid cc_default))
     ((tptr tvoid) :: nil) tvoid cc_default)) ::
 (___builtin_unreachable,
   Gfun(External (EF_builtin "__builtin_unreachable"
                   (mksignature nil AST.Xvoid cc_default)) nil tvoid
     cc_default)) ::
 (___builtin_expect,
   Gfun(External (EF_builtin "__builtin_expect"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___builtin_fmax,
   Gfun(External (EF_builtin "__builtin_fmax"
                   (mksignature (AST.Xfloat :: AST.Xfloat :: nil) AST.Xfloat
                     cc_default)) (tdouble :: tdouble :: nil) tdouble
     cc_default)) ::
 (___builtin_fmin,
   Gfun(External (EF_builtin "__builtin_fmin"
                   (mksignature (AST.Xfloat :: AST.Xfloat :: nil) AST.Xfloat
                     cc_default)) (tdouble :: tdouble :: nil) tdouble
     cc_default)) ::
 (___builtin_fmadd,
   Gfun(External (EF_builtin "__builtin_fmadd"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fmsub,
   Gfun(External (EF_builtin "__builtin_fmsub"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fnmadd,
   Gfun(External (EF_builtin "__builtin_fnmadd"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fnmsub,
   Gfun(External (EF_builtin "__builtin_fnmsub"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_read16_reversed,
   Gfun(External (EF_builtin "__builtin_read16_reversed"
                   (mksignature (AST.Xptr :: nil) AST.Xint16unsigned
                     cc_default)) ((tptr tushort) :: nil) tushort
     cc_default)) ::
 (___builtin_read32_reversed,
   Gfun(External (EF_builtin "__builtin_read32_reversed"
                   (mksignature (AST.Xptr :: nil) AST.Xint cc_default))
     ((tptr tuint) :: nil) tuint cc_default)) ::
 (___builtin_write16_reversed,
   Gfun(External (EF_builtin "__builtin_write16_reversed"
                   (mksignature (AST.Xptr :: AST.Xint16unsigned :: nil)
                     AST.Xvoid cc_default))
     ((tptr tushort) :: tushort :: nil) tvoid cc_default)) ::
 (___builtin_write32_reversed,
   Gfun(External (EF_builtin "__builtin_write32_reversed"
                   (mksignature (AST.Xptr :: AST.Xint :: nil) AST.Xvoid
                     cc_default)) ((tptr tuint) :: tuint :: nil) tvoid
     cc_default)) ::
 (___builtin_debug,
   Gfun(External (EF_external "__builtin_debug"
                   (mksignature (AST.Xint :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     (tint :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (___errno_location,
   Gfun(External (EF_external "__errno_location"
                   (mksignature nil AST.Xptr cc_default)) nil (tptr tint)
     cc_default)) ::
 (_open,
   Gfun(External (EF_external "open"
                   (mksignature (AST.Xptr :: AST.Xint :: nil) AST.Xint
                     {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|}))
     ((tptr tschar) :: tint :: nil) tint
     {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|})) ::
 (_poll,
   Gfun(External (EF_external "poll"
                   (mksignature (AST.Xptr :: AST.Xlong :: AST.Xint :: nil)
                     AST.Xint cc_default))
     ((tptr (Tstruct _pollfd noattr)) :: tulong :: tint :: nil) tint
     cc_default)) ::
 (_kill,
   Gfun(External (EF_external "kill"
                   (mksignature (AST.Xint :: AST.Xint :: nil) AST.Xint
                     cc_default)) (tint :: tint :: nil) tint cc_default)) ::
 (_memset,
   Gfun(External (EF_external "memset"
                   (mksignature (AST.Xptr :: AST.Xint :: AST.Xlong :: nil)
                     AST.Xptr cc_default))
     ((tptr tvoid) :: tint :: tulong :: nil) (tptr tvoid) cc_default)) ::
 (_strlen,
   Gfun(External (EF_external "strlen"
                   (mksignature (AST.Xptr :: nil) AST.Xlong cc_default))
     ((tptr tschar) :: nil) tulong cc_default)) ::
 (_ioctl,
   Gfun(External (EF_external "ioctl"
                   (mksignature (AST.Xint :: AST.Xlong :: nil) AST.Xint
                     {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|}))
     (tint :: tulong :: nil) tint
     {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|})) ::
 (_waitpid,
   Gfun(External (EF_external "waitpid"
                   (mksignature (AST.Xint :: AST.Xptr :: AST.Xint :: nil)
                     AST.Xint cc_default))
     (tint :: (tptr tint) :: tint :: nil) tint cc_default)) ::
 (_close,
   Gfun(External (EF_external "close"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tint :: nil) tint cc_default)) ::
 (_read,
   Gfun(External (EF_external "read"
                   (mksignature (AST.Xint :: AST.Xptr :: AST.Xlong :: nil)
                     AST.Xlong cc_default))
     (tint :: (tptr tvoid) :: tulong :: nil) tlong cc_default)) ::
 (_write,
   Gfun(External (EF_external "write"
                   (mksignature (AST.Xint :: AST.Xptr :: AST.Xlong :: nil)
                     AST.Xlong cc_default))
     (tint :: (tptr tvoid) :: tulong :: nil) tlong cc_default)) ::
 (_pipe,
   Gfun(External (EF_external "pipe"
                   (mksignature (AST.Xptr :: nil) AST.Xint cc_default))
     ((tptr tint) :: nil) tint cc_default)) ::
 (_usleep,
   Gfun(External (EF_external "usleep"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tint cc_default)) ::
 (_dup2,
   Gfun(External (EF_external "dup2"
                   (mksignature (AST.Xint :: AST.Xint :: nil) AST.Xint
                     cc_default)) (tint :: tint :: nil) tint cc_default)) ::
 (_execvp,
   Gfun(External (EF_external "execvp"
                   (mksignature (AST.Xptr :: AST.Xptr :: nil) AST.Xint
                     cc_default))
     ((tptr tschar) :: (tptr (tptr tschar)) :: nil) tint cc_default)) ::
 (_execlp,
   Gfun(External (EF_external "execlp"
                   (mksignature (AST.Xptr :: AST.Xptr :: nil) AST.Xint
                     {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|}))
     ((tptr tschar) :: (tptr tschar) :: nil) tint
     {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|})) ::
 (__exit,
   Gfun(External (EF_external "_exit"
                   (mksignature (AST.Xint :: nil) AST.Xvoid cc_default))
     (tint :: nil) tvoid cc_default)) ::
 (_setsid,
   Gfun(External (EF_external "setsid" (mksignature nil AST.Xint cc_default))
     nil tint cc_default)) ::
 (_fork,
   Gfun(External (EF_external "fork" (mksignature nil AST.Xint cc_default))
     nil tint cc_default)) ::
 (_fclose,
   Gfun(External (EF_external "fclose"
                   (mksignature (AST.Xptr :: nil) AST.Xint cc_default))
     ((tptr (Tstruct __IO_FILE noattr)) :: nil) tint cc_default)) ::
 (_fopen,
   Gfun(External (EF_external "fopen"
                   (mksignature (AST.Xptr :: AST.Xptr :: nil) AST.Xptr
                     cc_default)) ((tptr tschar) :: (tptr tschar) :: nil)
     (tptr (Tstruct __IO_FILE noattr)) cc_default)) ::
 (_snprintf,
   Gfun(External (EF_external "snprintf"
                   (mksignature (AST.Xptr :: AST.Xlong :: AST.Xptr :: nil)
                     AST.Xint
                     {|cc_vararg:=(Some 3); cc_unproto:=false; cc_structret:=false|}))
     ((tptr tschar) :: tulong :: (tptr tschar) :: nil) tint
     {|cc_vararg:=(Some 3); cc_unproto:=false; cc_structret:=false|})) ::
 (_fputs,
   Gfun(External (EF_external "fputs"
                   (mksignature (AST.Xptr :: AST.Xptr :: nil) AST.Xint
                     cc_default))
     ((tptr tschar) :: (tptr (Tstruct __IO_FILE noattr)) :: nil) tint
     cc_default)) ::
 (_getenv,
   Gfun(External (EF_external "getenv"
                   (mksignature (AST.Xptr :: nil) AST.Xptr cc_default))
     ((tptr tschar) :: nil) (tptr tschar) cc_default)) ::
 (_setenv,
   Gfun(External (EF_external "setenv"
                   (mksignature (AST.Xptr :: AST.Xptr :: AST.Xint :: nil)
                     AST.Xint cc_default))
     ((tptr tschar) :: (tptr tschar) :: tint :: nil) tint cc_default)) ::
 (_posix_openpt,
   Gfun(External (EF_external "posix_openpt"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tint :: nil) tint cc_default)) ::
 (_grantpt,
   Gfun(External (EF_external "grantpt"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tint :: nil) tint cc_default)) ::
 (_unlockpt,
   Gfun(External (EF_external "unlockpt"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tint :: nil) tint cc_default)) ::
 (_ptsname,
   Gfun(External (EF_external "ptsname"
                   (mksignature (AST.Xint :: nil) AST.Xptr cc_default))
     (tint :: nil) (tptr tschar) cc_default)) ::
 (_fd_wait_read, Gfun(Internal f_fd_wait_read)) ::
 (_fds_wait_read, Gfun(Internal f_fds_wait_read)) ::
 (_tls_open, Gfun(Internal f_tls_open)) ::
 (_tls_reap, Gfun(Internal f_tls_reap)) ::
 (_tls_kill, Gfun(Internal f_tls_kill)) ::
 (_tls_close_fd, Gfun(Internal f_tls_close_fd)) ::
 (_write_tedex_rc, Gfun(Internal f_write_tedex_rc)) ::
 (_pty_spawn_bash, Gfun(Internal f_pty_spawn_bash)) ::
 (_pty_poll, Gfun(Internal f_pty_poll)) ::
 (_pty_set_size, Gfun(Internal f_pty_set_size)) ::
 (_term_get_size, Gfun(Internal f_term_get_size)) ::
 (_pty_close, Gfun(Internal f_pty_close)) ::
 (_fd_read_timeout, Gfun(Internal f_fd_read_timeout)) ::
 (_fd_write_all, Gfun(Internal f_fd_write_all)) :: nil).

Definition public_idents : list ident :=
(_fd_write_all :: _fd_read_timeout :: _pty_close :: _term_get_size ::
 _pty_set_size :: _pty_poll :: _pty_spawn_bash :: _tls_close_fd ::
 _tls_kill :: _tls_reap :: _tls_open :: _fds_wait_read :: _fd_wait_read ::
 _ptsname :: _unlockpt :: _grantpt :: _posix_openpt :: _setenv :: _getenv ::
 _fputs :: _snprintf :: _fopen :: _fclose :: _fork :: _setsid :: __exit ::
 _execlp :: _execvp :: _dup2 :: _usleep :: _pipe :: _write :: _read ::
 _close :: _waitpid :: _ioctl :: _strlen :: _memset :: _kill :: _poll ::
 _open :: ___errno_location :: ___builtin_debug ::
 ___builtin_write32_reversed :: ___builtin_write16_reversed ::
 ___builtin_read32_reversed :: ___builtin_read16_reversed ::
 ___builtin_fnmsub :: ___builtin_fnmadd :: ___builtin_fmsub ::
 ___builtin_fmadd :: ___builtin_fmin :: ___builtin_fmax ::
 ___builtin_expect :: ___builtin_unreachable :: ___builtin_va_end ::
 ___builtin_va_copy :: ___builtin_va_arg :: ___builtin_va_start ::
 ___builtin_membar :: ___builtin_annot_intval :: ___builtin_annot ::
 ___builtin_sel :: ___builtin_memcpy_aligned :: ___builtin_sqrt ::
 ___builtin_fsqrt :: ___builtin_fabsf :: ___builtin_fabs ::
 ___builtin_ctzll :: ___builtin_ctzl :: ___builtin_ctz :: ___builtin_clzll ::
 ___builtin_clzl :: ___builtin_clz :: ___builtin_bswap16 ::
 ___builtin_bswap32 :: ___builtin_bswap :: ___builtin_bswap64 ::
 ___builtin_ais_annot :: ___compcert_i64_umulh :: ___compcert_i64_smulh ::
 ___compcert_i64_sar :: ___compcert_i64_shr :: ___compcert_i64_shl ::
 ___compcert_i64_umod :: ___compcert_i64_smod :: ___compcert_i64_udiv ::
 ___compcert_i64_sdiv :: ___compcert_i64_utof :: ___compcert_i64_stof ::
 ___compcert_i64_utod :: ___compcert_i64_stod :: ___compcert_i64_dtou ::
 ___compcert_i64_dtos :: ___compcert_va_composite ::
 ___compcert_va_float64 :: ___compcert_va_int64 :: ___compcert_va_int32 ::
 nil).

Definition prog : Clight.program := 
  mkprogram composites global_definitions public_idents _main Logic.I.


