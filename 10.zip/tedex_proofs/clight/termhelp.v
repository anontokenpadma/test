From Coq Require Import String List ZArith.
From compcert Require Import Coqlib Integers Floats AST Ctypes Cop Clight Clightdefs.
Import Clightdefs.ClightNotations.
Local Open Scope Z_scope.
Local Open Scope string_scope.
Local Open Scope clight_scope.

Module Info.
  Definition version := "3.17".
  Definition build_number := "".
  Definition build_tag := "".
  Definition build_branch := "".
  Definition arch := "x86".
  Definition model := "64".
  Definition abi := "standard".
  Definition bitsize := 64.
  Definition big_endian := false.
  Definition source_file := "termhelp.c".
  Definition normalized := true.
End Info.

Definition ___builtin_ais_annot : ident := $"__builtin_ais_annot".
Definition ___builtin_annot : ident := $"__builtin_annot".
Definition ___builtin_annot_intval : ident := $"__builtin_annot_intval".
Definition ___builtin_bswap : ident := $"__builtin_bswap".
Definition ___builtin_bswap16 : ident := $"__builtin_bswap16".
Definition ___builtin_bswap32 : ident := $"__builtin_bswap32".
Definition ___builtin_bswap64 : ident := $"__builtin_bswap64".
Definition ___builtin_clz : ident := $"__builtin_clz".
Definition ___builtin_clzl : ident := $"__builtin_clzl".
Definition ___builtin_clzll : ident := $"__builtin_clzll".
Definition ___builtin_ctz : ident := $"__builtin_ctz".
Definition ___builtin_ctzl : ident := $"__builtin_ctzl".
Definition ___builtin_ctzll : ident := $"__builtin_ctzll".
Definition ___builtin_debug : ident := $"__builtin_debug".
Definition ___builtin_expect : ident := $"__builtin_expect".
Definition ___builtin_fabs : ident := $"__builtin_fabs".
Definition ___builtin_fabsf : ident := $"__builtin_fabsf".
Definition ___builtin_fmadd : ident := $"__builtin_fmadd".
Definition ___builtin_fmax : ident := $"__builtin_fmax".
Definition ___builtin_fmin : ident := $"__builtin_fmin".
Definition ___builtin_fmsub : ident := $"__builtin_fmsub".
Definition ___builtin_fnmadd : ident := $"__builtin_fnmadd".
Definition ___builtin_fnmsub : ident := $"__builtin_fnmsub".
Definition ___builtin_fsqrt : ident := $"__builtin_fsqrt".
Definition ___builtin_membar : ident := $"__builtin_membar".
Definition ___builtin_memcpy_aligned : ident := $"__builtin_memcpy_aligned".
Definition ___builtin_read16_reversed : ident := $"__builtin_read16_reversed".
Definition ___builtin_read32_reversed : ident := $"__builtin_read32_reversed".
Definition ___builtin_sel : ident := $"__builtin_sel".
Definition ___builtin_sqrt : ident := $"__builtin_sqrt".
Definition ___builtin_unreachable : ident := $"__builtin_unreachable".
Definition ___builtin_va_arg : ident := $"__builtin_va_arg".
Definition ___builtin_va_copy : ident := $"__builtin_va_copy".
Definition ___builtin_va_end : ident := $"__builtin_va_end".
Definition ___builtin_va_start : ident := $"__builtin_va_start".
Definition ___builtin_write16_reversed : ident := $"__builtin_write16_reversed".
Definition ___builtin_write32_reversed : ident := $"__builtin_write32_reversed".
Definition ___compcert_i64_dtos : ident := $"__compcert_i64_dtos".
Definition ___compcert_i64_dtou : ident := $"__compcert_i64_dtou".
Definition ___compcert_i64_sar : ident := $"__compcert_i64_sar".
Definition ___compcert_i64_sdiv : ident := $"__compcert_i64_sdiv".
Definition ___compcert_i64_shl : ident := $"__compcert_i64_shl".
Definition ___compcert_i64_shr : ident := $"__compcert_i64_shr".
Definition ___compcert_i64_smod : ident := $"__compcert_i64_smod".
Definition ___compcert_i64_smulh : ident := $"__compcert_i64_smulh".
Definition ___compcert_i64_stod : ident := $"__compcert_i64_stod".
Definition ___compcert_i64_stof : ident := $"__compcert_i64_stof".
Definition ___compcert_i64_udiv : ident := $"__compcert_i64_udiv".
Definition ___compcert_i64_umod : ident := $"__compcert_i64_umod".
Definition ___compcert_i64_umulh : ident := $"__compcert_i64_umulh".
Definition ___compcert_i64_utod : ident := $"__compcert_i64_utod".
Definition ___compcert_i64_utof : ident := $"__compcert_i64_utof".
Definition ___compcert_va_composite : ident := $"__compcert_va_composite".
Definition ___compcert_va_float64 : ident := $"__compcert_va_float64".
Definition ___compcert_va_int32 : ident := $"__compcert_va_int32".
Definition ___compcert_va_int64 : ident := $"__compcert_va_int64".
Definition ___errno_location : ident := $"__errno_location".
Definition _b : ident := $"b".
Definition _buf : ident := $"buf".
Definition _c : ident := $"c".
Definition _c_cc : ident := $"c_cc".
Definition _c_cflag : ident := $"c_cflag".
Definition _c_iflag : ident := $"c_iflag".
Definition _c_ispeed : ident := $"c_ispeed".
Definition _c_lflag : ident := $"c_lflag".
Definition _c_line : ident := $"c_line".
Definition _c_oflag : ident := $"c_oflag".
Definition _c_ospeed : ident := $"c_ospeed".
Definition _cfmakeraw : ident := $"cfmakeraw".
Definition _events : ident := $"events".
Definition _f : ident := $"f".
Definition _fcntl : ident := $"fcntl".
Definition _fd : ident := $"fd".
Definition _isatty : ident := $"isatty".
Definition _istty : ident := $"istty".
Definition _k : ident := $"k".
Definition _k__1 : ident := $"k__1".
Definition _last_traffic : ident := $"last_traffic".
Definition _main : ident := $"main".
Definition _max : ident := $"max".
Definition _maxfd : ident := $"maxfd".
Definition _n : ident := $"n".
Definition _nfds : ident := $"nfds".
Definition _off : ident := $"off".
Definition _oldt : ident := $"oldt".
Definition _on : ident := $"on".
Definition _p : ident := $"p".
Definition _poll : ident := $"poll".
Definition _pollfd : ident := $"pollfd".
Definition _raw : ident := $"raw".
Definition _read : ident := $"read".
Definition _recv : ident := $"recv".
Definition _revents : ident := $"revents".
Definition _saved : ident := $"saved".
Definition _signal : ident := $"signal".
Definition _sockfd : ident := $"sockfd".
Definition _stdin_done : ident := $"stdin_done".
Definition _tcgetattr : ident := $"tcgetattr".
Definition _tcsetattr : ident := $"tcsetattr".
Definition _tedex_ignore_sigpipe : ident := $"tedex_ignore_sigpipe".
Definition _term_attach : ident := $"term_attach".
Definition _term_raw : ident := $"term_raw".
Definition _term_read_chunk : ident := $"term_read_chunk".
Definition _term_read_line : ident := $"term_read_line".
Definition _term_set_nonblock : ident := $"term_set_nonblock".
Definition _termios : ident := $"termios".
Definition _time : ident := $"time".
Definition _w : ident := $"w".
Definition _write : ident := $"write".
Definition _write_all : ident := $"write_all".
Definition _t'1 : ident := 128%positive.
Definition _t'10 : ident := 137%positive.
Definition _t'11 : ident := 138%positive.
Definition _t'12 : ident := 139%positive.
Definition _t'13 : ident := 140%positive.
Definition _t'14 : ident := 141%positive.
Definition _t'15 : ident := 142%positive.
Definition _t'16 : ident := 143%positive.
Definition _t'17 : ident := 144%positive.
Definition _t'18 : ident := 145%positive.
Definition _t'2 : ident := 129%positive.
Definition _t'3 : ident := 130%positive.
Definition _t'4 : ident := 131%positive.
Definition _t'5 : ident := 132%positive.
Definition _t'6 : ident := 133%positive.
Definition _t'7 : ident := 134%positive.
Definition _t'8 : ident := 135%positive.
Definition _t'9 : ident := 136%positive.

Definition f_tedex_ignore_sigpipe := {|
  fn_return := tvoid;
  fn_callconv := cc_default;
  fn_params := nil;
  fn_vars := nil;
  fn_temps := nil;
  fn_body :=
(Scall None
  (Evar _signal (Tfunction
                  (tint ::
                   (tptr (Tfunction (tint :: nil) tvoid cc_default)) :: nil)
                  (tptr (Tfunction (tint :: nil) tvoid cc_default))
                  cc_default))
  ((Econst_int (Int.repr 13) tint) ::
   (Ecast (Econst_int (Int.repr 1) tint)
     (tptr (Tfunction (tint :: nil) tvoid cc_default))) :: nil))
|}.

Definition f_write_all := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_fd, tint) :: (_b, (tptr tschar)) :: (_n, tlong) :: nil);
  fn_vars := nil;
  fn_temps := ((_off, tlong) :: (_w, tlong) :: (_t'2, (tptr tint)) ::
               (_t'1, tlong) :: (_t'3, tint) :: nil);
  fn_body :=
(Ssequence
  (Sset _off (Ecast (Econst_int (Int.repr 0) tint) tlong))
  (Ssequence
    (Swhile
      (Ebinop Olt (Etempvar _off tlong) (Etempvar _n tlong) tint)
      (Ssequence
        (Ssequence
          (Scall (Some _t'1)
            (Evar _write (Tfunction (tint :: (tptr tvoid) :: tulong :: nil)
                           tlong cc_default))
            ((Etempvar _fd tint) ::
             (Ebinop Oadd (Etempvar _b (tptr tschar)) (Etempvar _off tlong)
               (tptr tschar)) ::
             (Ecast
               (Ebinop Osub (Etempvar _n tlong) (Etempvar _off tlong) tlong)
               tulong) :: nil))
          (Sset _w (Etempvar _t'1 tlong)))
        (Ssequence
          (Sifthenelse (Ebinop Olt (Etempvar _w tlong)
                         (Econst_int (Int.repr 0) tint) tint)
            (Ssequence
              (Ssequence
                (Scall (Some _t'2)
                  (Evar ___errno_location (Tfunction nil (tptr tint)
                                            cc_default)) nil)
                (Ssequence
                  (Sset _t'3 (Ederef (Etempvar _t'2 (tptr tint)) tint))
                  (Sifthenelse (Ebinop Oeq (Etempvar _t'3 tint)
                                 (Econst_int (Int.repr 4) tint) tint)
                    Scontinue
                    Sskip)))
              (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint))))
            Sskip)
          (Ssequence
            (Sifthenelse (Ebinop Oeq (Etempvar _w tlong)
                           (Econst_int (Int.repr 0) tint) tint)
              (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
              Sskip)
            (Sset _off
              (Ebinop Oadd (Etempvar _off tlong) (Etempvar _w tlong) tlong))))))
    (Sreturn (Some (Econst_int (Int.repr 0) tint)))))
|}.

Definition f_term_attach := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_sockfd, tint) :: nil);
  fn_vars := ((_oldt, (Tstruct _termios noattr)) ::
              (_raw, (Tstruct _termios noattr)) ::
              (_buf, (tarray tschar 4096)) ::
              (_p, (tarray (Tstruct _pollfd noattr) 2)) :: nil);
  fn_temps := ((_istty, tint) :: (_stdin_done, tint) :: (_maxfd, tint) ::
               (_last_traffic, tlong) :: (_nfds, tint) :: (_n, tint) ::
               (_k, tlong) :: (_k__1, tlong) :: (_t'15, tlong) ::
               (_t'14, tint) :: (_t'13, tlong) :: (_t'12, tint) ::
               (_t'11, tlong) :: (_t'10, tint) :: (_t'9, tint) ::
               (_t'8, tlong) :: (_t'7, tlong) :: (_t'6, (tptr tint)) ::
               (_t'5, tint) :: (_t'4, tlong) :: (_t'3, tint) ::
               (_t'2, tint) :: (_t'1, tint) :: (_t'18, tint) ::
               (_t'17, tshort) :: (_t'16, tshort) :: nil);
  fn_body :=
(Ssequence
  (Ssequence
    (Scall (Some _t'1)
      (Evar _isatty (Tfunction (tint :: nil) tint cc_default))
      ((Econst_int (Int.repr 0) tint) :: nil))
    (Sset _istty (Etempvar _t'1 tint)))
  (Ssequence
    (Sifthenelse (Etempvar _istty tint)
      (Ssequence
        (Scall (Some _t'2)
          (Evar _tcgetattr (Tfunction
                             (tint :: (tptr (Tstruct _termios noattr)) ::
                              nil) tint cc_default))
          ((Econst_int (Int.repr 0) tint) ::
           (Eaddrof (Evar _oldt (Tstruct _termios noattr))
             (tptr (Tstruct _termios noattr))) :: nil))
        (Sifthenelse (Ebinop Oeq (Etempvar _t'2 tint)
                       (Econst_int (Int.repr 0) tint) tint)
          (Ssequence
            (Sassign (Evar _raw (Tstruct _termios noattr))
              (Evar _oldt (Tstruct _termios noattr)))
            (Ssequence
              (Scall None
                (Evar _cfmakeraw (Tfunction
                                   ((tptr (Tstruct _termios noattr)) :: nil)
                                   tvoid cc_default))
                ((Eaddrof (Evar _raw (Tstruct _termios noattr))
                   (tptr (Tstruct _termios noattr))) :: nil))
              (Scall None
                (Evar _tcsetattr (Tfunction
                                   (tint :: tint ::
                                    (tptr (Tstruct _termios noattr)) :: nil)
                                   tint cc_default))
                ((Econst_int (Int.repr 0) tint) ::
                 (Econst_int (Int.repr 0) tint) ::
                 (Eaddrof (Evar _raw (Tstruct _termios noattr))
                   (tptr (Tstruct _termios noattr))) :: nil))))
          (Sset _istty (Econst_int (Int.repr 0) tint))))
      Sskip)
    (Ssequence
      (Scall None
        (Evar _signal (Tfunction
                        (tint ::
                         (tptr (Tfunction (tint :: nil) tvoid cc_default)) ::
                         nil)
                        (tptr (Tfunction (tint :: nil) tvoid cc_default))
                        cc_default))
        ((Econst_int (Int.repr 13) tint) ::
         (Ecast (Econst_int (Int.repr 1) tint)
           (tptr (Tfunction (tint :: nil) tvoid cc_default))) :: nil))
      (Ssequence
        (Ssequence
          (Sset _stdin_done (Econst_int (Int.repr 0) tint))
          (Ssequence
            (Ssequence
              (Sifthenelse (Ebinop Ogt (Etempvar _sockfd tint)
                             (Econst_int (Int.repr 1) tint) tint)
                (Sset _t'3 (Ecast (Etempvar _sockfd tint) tint))
                (Sset _t'3 (Ecast (Econst_int (Int.repr 1) tint) tint)))
              (Sset _maxfd (Etempvar _t'3 tint)))
            (Ssequence
              (Ssequence
                (Scall (Some _t'4)
                  (Evar _time (Tfunction ((tptr tlong) :: nil) tlong
                                cc_default))
                  ((Econst_int (Int.repr 0) tint) :: nil))
                (Sset _last_traffic (Etempvar _t'4 tlong)))
              (Sloop
                (Ssequence
                  Sskip
                  (Ssequence
                    (Sset _nfds (Econst_int (Int.repr 0) tint))
                    (Ssequence
                      (Sifthenelse (Eunop Onotbool
                                     (Etempvar _stdin_done tint) tint)
                        (Ssequence
                          (Sassign
                            (Efield
                              (Ederef
                                (Ebinop Oadd
                                  (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                                  (Etempvar _nfds tint)
                                  (tptr (Tstruct _pollfd noattr)))
                                (Tstruct _pollfd noattr)) _fd tint)
                            (Econst_int (Int.repr 0) tint))
                          (Ssequence
                            (Sassign
                              (Efield
                                (Ederef
                                  (Ebinop Oadd
                                    (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                                    (Etempvar _nfds tint)
                                    (tptr (Tstruct _pollfd noattr)))
                                  (Tstruct _pollfd noattr)) _events tshort)
                              (Econst_int (Int.repr 1) tint))
                            (Ssequence
                              (Sassign
                                (Efield
                                  (Ederef
                                    (Ebinop Oadd
                                      (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                                      (Etempvar _nfds tint)
                                      (tptr (Tstruct _pollfd noattr)))
                                    (Tstruct _pollfd noattr)) _revents
                                  tshort) (Econst_int (Int.repr 0) tint))
                              (Sset _nfds
                                (Ebinop Oadd (Etempvar _nfds tint)
                                  (Econst_int (Int.repr 1) tint) tint)))))
                        Sskip)
                      (Ssequence
                        (Sassign
                          (Efield
                            (Ederef
                              (Ebinop Oadd
                                (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                                (Etempvar _nfds tint)
                                (tptr (Tstruct _pollfd noattr)))
                              (Tstruct _pollfd noattr)) _fd tint)
                          (Etempvar _sockfd tint))
                        (Ssequence
                          (Sassign
                            (Efield
                              (Ederef
                                (Ebinop Oadd
                                  (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                                  (Etempvar _nfds tint)
                                  (tptr (Tstruct _pollfd noattr)))
                                (Tstruct _pollfd noattr)) _events tshort)
                            (Econst_int (Int.repr 1) tint))
                          (Ssequence
                            (Sassign
                              (Efield
                                (Ederef
                                  (Ebinop Oadd
                                    (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                                    (Etempvar _nfds tint)
                                    (tptr (Tstruct _pollfd noattr)))
                                  (Tstruct _pollfd noattr)) _revents tshort)
                              (Econst_int (Int.repr 0) tint))
                            (Ssequence
                              (Sset _nfds
                                (Ebinop Oadd (Etempvar _nfds tint)
                                  (Econst_int (Int.repr 1) tint) tint))
                              (Ssequence
                                (Ssequence
                                  (Ssequence
                                    (Scall (Some _t'5)
                                      (Evar _poll (Tfunction
                                                    ((tptr (Tstruct _pollfd noattr)) ::
                                                     tulong :: tint :: nil)
                                                    tint cc_default))
                                      ((Evar _p (tarray (Tstruct _pollfd noattr) 2)) ::
                                       (Ecast (Etempvar _nfds tint) tulong) ::
                                       (Econst_int (Int.repr 1000) tint) ::
                                       nil))
                                    (Sset _n (Etempvar _t'5 tint)))
                                  (Sifthenelse (Ebinop Olt (Etempvar _n tint)
                                                 (Econst_int (Int.repr 0) tint)
                                                 tint)
                                    (Ssequence
                                      (Ssequence
                                        (Scall (Some _t'6)
                                          (Evar ___errno_location (Tfunction
                                                                    nil
                                                                    (tptr tint)
                                                                    cc_default))
                                          nil)
                                        (Ssequence
                                          (Sset _t'18
                                            (Ederef
                                              (Etempvar _t'6 (tptr tint))
                                              tint))
                                          (Sifthenelse (Ebinop Oeq
                                                         (Etempvar _t'18 tint)
                                                         (Econst_int (Int.repr 4) tint)
                                                         tint)
                                            Scontinue
                                            Sskip)))
                                      Sbreak)
                                    Sskip))
                                (Ssequence
                                  (Ssequence
                                    (Sifthenelse (Eunop Onotbool
                                                   (Etempvar _stdin_done tint)
                                                   tint)
                                      (Ssequence
                                        (Sset _t'17
                                          (Efield
                                            (Ederef
                                              (Ebinop Oadd
                                                (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                                                (Econst_int (Int.repr 0) tint)
                                                (tptr (Tstruct _pollfd noattr)))
                                              (Tstruct _pollfd noattr))
                                            _revents tshort))
                                        (Sset _t'10
                                          (Ecast
                                            (Ebinop Oand
                                              (Etempvar _t'17 tshort)
                                              (Econst_int (Int.repr 1) tint)
                                              tint) tbool)))
                                      (Sset _t'10
                                        (Econst_int (Int.repr 0) tint)))
                                    (Sifthenelse (Etempvar _t'10 tint)
                                      (Ssequence
                                        (Ssequence
                                          (Scall (Some _t'7)
                                            (Evar _read (Tfunction
                                                          (tint ::
                                                           (tptr tvoid) ::
                                                           tulong :: nil)
                                                          tlong cc_default))
                                            ((Econst_int (Int.repr 0) tint) ::
                                             (Evar _buf (tarray tschar 4096)) ::
                                             (Esizeof (tarray tschar 4096) tulong) ::
                                             nil))
                                          (Sset _k (Etempvar _t'7 tlong)))
                                        (Sifthenelse (Ebinop Ole
                                                       (Etempvar _k tlong)
                                                       (Econst_int (Int.repr 0) tint)
                                                       tint)
                                          (Sset _stdin_done
                                            (Econst_int (Int.repr 1) tint))
                                          (Ssequence
                                            (Scall (Some _t'9)
                                              (Evar _write_all (Tfunction
                                                                 (tint ::
                                                                  (tptr tschar) ::
                                                                  tlong ::
                                                                  nil) tint
                                                                 cc_default))
                                              ((Etempvar _sockfd tint) ::
                                               (Evar _buf (tarray tschar 4096)) ::
                                               (Etempvar _k tlong) :: nil))
                                            (Sifthenelse (Ebinop One
                                                           (Etempvar _t'9 tint)
                                                           (Econst_int (Int.repr 0) tint)
                                                           tint)
                                              Sbreak
                                              (Ssequence
                                                (Scall (Some _t'8)
                                                  (Evar _time (Tfunction
                                                                ((tptr tlong) ::
                                                                 nil) tlong
                                                                cc_default))
                                                  ((Econst_int (Int.repr 0) tint) ::
                                                   nil))
                                                (Sset _last_traffic
                                                  (Etempvar _t'8 tlong)))))))
                                      Sskip))
                                  (Ssequence
                                    (Ssequence
                                      (Sset _t'16
                                        (Efield
                                          (Ederef
                                            (Ebinop Oadd
                                              (Evar _p (tarray (Tstruct _pollfd noattr) 2))
                                              (Ebinop Osub
                                                (Etempvar _nfds tint)
                                                (Econst_int (Int.repr 1) tint)
                                                tint)
                                              (tptr (Tstruct _pollfd noattr)))
                                            (Tstruct _pollfd noattr))
                                          _revents tshort))
                                      (Sifthenelse (Ebinop Oand
                                                     (Etempvar _t'16 tshort)
                                                     (Econst_int (Int.repr 1) tint)
                                                     tint)
                                        (Ssequence
                                          (Ssequence
                                            (Scall (Some _t'11)
                                              (Evar _recv (Tfunction
                                                            (tint ::
                                                             (tptr tvoid) ::
                                                             tulong ::
                                                             tint :: nil)
                                                            tlong cc_default))
                                              ((Etempvar _sockfd tint) ::
                                               (Evar _buf (tarray tschar 4096)) ::
                                               (Esizeof (tarray tschar 4096) tulong) ::
                                               (Econst_int (Int.repr 0) tint) ::
                                               nil))
                                            (Sset _k__1
                                              (Etempvar _t'11 tlong)))
                                          (Ssequence
                                            (Sifthenelse (Ebinop Ole
                                                           (Etempvar _k__1 tlong)
                                                           (Econst_int (Int.repr 0) tint)
                                                           tint)
                                              Sbreak
                                              Sskip)
                                            (Ssequence
                                              (Ssequence
                                                (Scall (Some _t'12)
                                                  (Evar _write_all (Tfunction
                                                                    (tint ::
                                                                    (tptr tschar) ::
                                                                    tlong ::
                                                                    nil) tint
                                                                    cc_default))
                                                  ((Econst_int (Int.repr 1) tint) ::
                                                   (Evar _buf (tarray tschar 4096)) ::
                                                   (Etempvar _k__1 tlong) ::
                                                   nil))
                                                (Sifthenelse (Ebinop One
                                                               (Etempvar _t'12 tint)
                                                               (Econst_int (Int.repr 0) tint)
                                                               tint)
                                                  Sbreak
                                                  Sskip))
                                              (Ssequence
                                                (Scall (Some _t'13)
                                                  (Evar _time (Tfunction
                                                                ((tptr tlong) ::
                                                                 nil) tlong
                                                                cc_default))
                                                  ((Econst_int (Int.repr 0) tint) ::
                                                   nil))
                                                (Sset _last_traffic
                                                  (Etempvar _t'13 tlong))))))
                                        Sskip))
                                    (Ssequence
                                      (Sifthenelse (Etempvar _stdin_done tint)
                                        (Ssequence
                                          (Scall (Some _t'15)
                                            (Evar _time (Tfunction
                                                          ((tptr tlong) ::
                                                           nil) tlong
                                                          cc_default))
                                            ((Econst_int (Int.repr 0) tint) ::
                                             nil))
                                          (Sset _t'14
                                            (Ecast
                                              (Ebinop Ogt
                                                (Ebinop Osub
                                                  (Etempvar _t'15 tlong)
                                                  (Etempvar _last_traffic tlong)
                                                  tlong)
                                                (Econst_int (Int.repr 30) tint)
                                                tint) tbool)))
                                        (Sset _t'14
                                          (Econst_int (Int.repr 0) tint)))
                                      (Sifthenelse (Etempvar _t'14 tint)
                                        Sbreak
                                        Sskip))))))))))))
                Sskip))))
        (Ssequence
          (Sifthenelse (Etempvar _istty tint)
            (Scall None
              (Evar _tcsetattr (Tfunction
                                 (tint :: tint ::
                                  (tptr (Tstruct _termios noattr)) :: nil)
                                 tint cc_default))
              ((Econst_int (Int.repr 0) tint) ::
               (Econst_int (Int.repr 0) tint) ::
               (Eaddrof (Evar _oldt (Tstruct _termios noattr))
                 (tptr (Tstruct _termios noattr))) :: nil))
            Sskip)
          (Sreturn (Some (Econst_int (Int.repr 0) tint))))))))
|}.

Definition f_term_read_line := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_buf, (tptr tschar)) :: (_max, tint) :: nil);
  fn_vars := ((_c, tschar) :: (_p, (Tstruct _pollfd noattr)) :: nil);
  fn_temps := ((_n, tint) :: (_k, tlong) :: (_t'9, tint) :: (_t'8, tlong) ::
               (_t'7, tint) :: (_t'6, tint) :: (_t'5, (tptr tint)) ::
               (_t'4, tlong) :: (_t'3, tint) :: (_t'2, tint) ::
               (_t'1, (tptr tint)) :: (_t'14, tint) :: (_t'13, tint) ::
               (_t'12, tschar) :: (_t'11, tschar) :: (_t'10, tschar) :: nil);
  fn_body :=
(Ssequence
  (Sset _n (Econst_int (Int.repr 0) tint))
  (Ssequence
    (Sifthenelse (Ebinop Ole (Etempvar _max tint)
                   (Econst_int (Int.repr 1) tint) tint)
      (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
      Sskip)
    (Sloop
      (Ssequence
        Sskip
        (Ssequence
          (Sassign (Efield (Evar _p (Tstruct _pollfd noattr)) _fd tint)
            (Econst_int (Int.repr 0) tint))
          (Ssequence
            (Sassign
              (Efield (Evar _p (Tstruct _pollfd noattr)) _events tshort)
              (Econst_int (Int.repr 1) tint))
            (Ssequence
              (Sassign
                (Efield (Evar _p (Tstruct _pollfd noattr)) _revents tshort)
                (Econst_int (Int.repr 0) tint))
              (Ssequence
                (Ssequence
                  (Scall (Some _t'3)
                    (Evar _poll (Tfunction
                                  ((tptr (Tstruct _pollfd noattr)) ::
                                   tulong :: tint :: nil) tint cc_default))
                    ((Eaddrof (Evar _p (Tstruct _pollfd noattr))
                       (tptr (Tstruct _pollfd noattr))) ::
                     (Econst_int (Int.repr 1) tint) ::
                     (Eunop Oneg (Econst_int (Int.repr 1) tint) tint) :: nil))
                  (Sifthenelse (Ebinop Olt (Etempvar _t'3 tint)
                                 (Econst_int (Int.repr 0) tint) tint)
                    (Ssequence
                      (Ssequence
                        (Scall (Some _t'1)
                          (Evar ___errno_location (Tfunction nil (tptr tint)
                                                    cc_default)) nil)
                        (Ssequence
                          (Sset _t'14
                            (Ederef (Etempvar _t'1 (tptr tint)) tint))
                          (Sifthenelse (Ebinop Oeq (Etempvar _t'14 tint)
                                         (Econst_int (Int.repr 4) tint) tint)
                            Scontinue
                            Sskip)))
                      (Ssequence
                        (Sifthenelse (Ebinop Ogt (Etempvar _n tint)
                                       (Econst_int (Int.repr 0) tint) tint)
                          (Sset _t'2 (Ecast (Etempvar _n tint) tint))
                          (Sset _t'2
                            (Ecast
                              (Eunop Oneg (Econst_int (Int.repr 1) tint)
                                tint) tint)))
                        (Sreturn (Some (Etempvar _t'2 tint)))))
                    Sskip))
                (Ssequence
                  (Ssequence
                    (Scall (Some _t'4)
                      (Evar _read (Tfunction
                                    (tint :: (tptr tvoid) :: tulong :: nil)
                                    tlong cc_default))
                      ((Econst_int (Int.repr 0) tint) ::
                       (Eaddrof (Evar _c tschar) (tptr tschar)) ::
                       (Econst_int (Int.repr 1) tint) :: nil))
                    (Sset _k (Etempvar _t'4 tlong)))
                  (Ssequence
                    (Sifthenelse (Ebinop Olt (Etempvar _k tlong)
                                   (Econst_int (Int.repr 0) tint) tint)
                      (Ssequence
                        (Ssequence
                          (Scall (Some _t'5)
                            (Evar ___errno_location (Tfunction nil
                                                      (tptr tint) cc_default))
                            nil)
                          (Ssequence
                            (Sset _t'13
                              (Ederef (Etempvar _t'5 (tptr tint)) tint))
                            (Sifthenelse (Ebinop Oeq (Etempvar _t'13 tint)
                                           (Econst_int (Int.repr 4) tint)
                                           tint)
                              Scontinue
                              Sskip)))
                        (Ssequence
                          (Sifthenelse (Ebinop Ogt (Etempvar _n tint)
                                         (Econst_int (Int.repr 0) tint) tint)
                            (Sset _t'6 (Ecast (Etempvar _n tint) tint))
                            (Sset _t'6
                              (Ecast
                                (Eunop Oneg (Econst_int (Int.repr 1) tint)
                                  tint) tint)))
                          (Sreturn (Some (Etempvar _t'6 tint)))))
                      Sskip)
                    (Ssequence
                      (Sifthenelse (Ebinop Oeq (Etempvar _k tlong)
                                     (Econst_int (Int.repr 0) tint) tint)
                        (Sreturn (Some (Etempvar _n tint)))
                        Sskip)
                      (Ssequence
                        (Sifthenelse (Ebinop Olt (Etempvar _n tint)
                                       (Ebinop Osub (Etempvar _max tint)
                                         (Econst_int (Int.repr 1) tint) tint)
                                       tint)
                          (Ssequence
                            (Ssequence
                              (Sset _t'7 (Etempvar _n tint))
                              (Sset _n
                                (Ebinop Oadd (Etempvar _t'7 tint)
                                  (Econst_int (Int.repr 1) tint) tint)))
                            (Ssequence
                              (Sset _t'12 (Evar _c tschar))
                              (Sassign
                                (Ederef
                                  (Ebinop Oadd (Etempvar _buf (tptr tschar))
                                    (Etempvar _t'7 tint) (tptr tschar))
                                  tschar) (Etempvar _t'12 tschar))))
                          Sskip)
                        (Ssequence
                          (Sset _t'10 (Evar _c tschar))
                          (Sifthenelse (Ebinop Oeq (Etempvar _t'10 tschar)
                                         (Econst_int (Int.repr 10) tint)
                                         tint)
                            (Ssequence
                              (Sifthenelse (Ebinop Oge (Etempvar _n tint)
                                             (Ebinop Osub
                                               (Etempvar _max tint)
                                               (Econst_int (Int.repr 1) tint)
                                               tint) tint)
                                (Sloop
                                  (Ssequence
                                    Sskip
                                    (Ssequence
                                      (Ssequence
                                        (Scall (Some _t'8)
                                          (Evar _read (Tfunction
                                                        (tint ::
                                                         (tptr tvoid) ::
                                                         tulong :: nil) tlong
                                                        cc_default))
                                          ((Econst_int (Int.repr 0) tint) ::
                                           (Eaddrof (Evar _c tschar)
                                             (tptr tschar)) ::
                                           (Econst_int (Int.repr 1) tint) ::
                                           nil))
                                        (Sset _k (Etempvar _t'8 tlong)))
                                      (Ssequence
                                        (Sifthenelse (Ebinop Ole
                                                       (Etempvar _k tlong)
                                                       (Econst_int (Int.repr 0) tint)
                                                       tint)
                                          (Sset _t'9
                                            (Econst_int (Int.repr 1) tint))
                                          (Ssequence
                                            (Sset _t'11 (Evar _c tschar))
                                            (Sset _t'9
                                              (Ecast
                                                (Ebinop Oeq
                                                  (Etempvar _t'11 tschar)
                                                  (Econst_int (Int.repr 10) tint)
                                                  tint) tbool))))
                                        (Sifthenelse (Etempvar _t'9 tint)
                                          Sbreak
                                          Sskip))))
                                  Sskip)
                                Sskip)
                              (Sreturn (Some (Etempvar _n tint))))
                            Sskip)))))))))))
      Sskip)))
|}.

Definition v_oldt := {|
  gvar_info := (Tstruct _termios noattr);
  gvar_init := (Init_space 60 :: nil);
  gvar_readonly := false;
  gvar_volatile := false
|}.

Definition v_saved := {|
  gvar_info := tint;
  gvar_init := (Init_int32 (Int.repr 0) :: nil);
  gvar_readonly := false;
  gvar_volatile := false
|}.

Definition f_term_raw := {|
  fn_return := tvoid;
  fn_callconv := cc_default;
  fn_params := ((_on, tint) :: nil);
  fn_vars := ((_raw, (Tstruct _termios noattr)) :: nil);
  fn_temps := ((_t'3, tint) :: (_t'2, tint) :: (_t'1, tint) ::
               (_t'4, tint) :: nil);
  fn_body :=
(Sifthenelse (Etempvar _on tint)
  (Ssequence
    (Ssequence
      (Scall (Some _t'1)
        (Evar _isatty (Tfunction (tint :: nil) tint cc_default))
        ((Econst_int (Int.repr 0) tint) :: nil))
      (Sifthenelse (Etempvar _t'1 tint)
        (Ssequence
          (Scall (Some _t'3)
            (Evar _tcgetattr (Tfunction
                               (tint :: (tptr (Tstruct _termios noattr)) ::
                                nil) tint cc_default))
            ((Econst_int (Int.repr 0) tint) ::
             (Eaddrof (Evar _oldt (Tstruct _termios noattr))
               (tptr (Tstruct _termios noattr))) :: nil))
          (Sset _t'2
            (Ecast
              (Ebinop Oeq (Etempvar _t'3 tint) (Econst_int (Int.repr 0) tint)
                tint) tbool)))
        (Sset _t'2 (Econst_int (Int.repr 0) tint))))
    (Sifthenelse (Etempvar _t'2 tint)
      (Ssequence
        (Sassign (Evar _raw (Tstruct _termios noattr))
          (Evar _oldt (Tstruct _termios noattr)))
        (Ssequence
          (Scall None
            (Evar _cfmakeraw (Tfunction
                               ((tptr (Tstruct _termios noattr)) :: nil)
                               tvoid cc_default))
            ((Eaddrof (Evar _raw (Tstruct _termios noattr))
               (tptr (Tstruct _termios noattr))) :: nil))
          (Ssequence
            (Scall None
              (Evar _tcsetattr (Tfunction
                                 (tint :: tint ::
                                  (tptr (Tstruct _termios noattr)) :: nil)
                                 tint cc_default))
              ((Econst_int (Int.repr 0) tint) ::
               (Econst_int (Int.repr 0) tint) ::
               (Eaddrof (Evar _raw (Tstruct _termios noattr))
                 (tptr (Tstruct _termios noattr))) :: nil))
            (Sassign (Evar _saved tint) (Econst_int (Int.repr 1) tint)))))
      Sskip))
  (Ssequence
    (Sset _t'4 (Evar _saved tint))
    (Sifthenelse (Etempvar _t'4 tint)
      (Ssequence
        (Scall None
          (Evar _tcsetattr (Tfunction
                             (tint :: tint ::
                              (tptr (Tstruct _termios noattr)) :: nil) tint
                             cc_default))
          ((Econst_int (Int.repr 0) tint) ::
           (Econst_int (Int.repr 0) tint) ::
           (Eaddrof (Evar _oldt (Tstruct _termios noattr))
             (tptr (Tstruct _termios noattr))) :: nil))
        (Sassign (Evar _saved tint) (Econst_int (Int.repr 0) tint)))
      Sskip)))
|}.

Definition f_term_set_nonblock := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_fd, tint) :: (_on, tint) :: nil);
  fn_vars := nil;
  fn_temps := ((_f, tint) :: (_t'3, tint) :: (_t'2, tint) :: (_t'1, tint) ::
               nil);
  fn_body :=
(Ssequence
  (Ssequence
    (Scall (Some _t'1)
      (Evar _fcntl (Tfunction (tint :: tint :: nil) tint
                     {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|}))
      ((Etempvar _fd tint) :: (Econst_int (Int.repr 3) tint) ::
       (Econst_int (Int.repr 0) tint) :: nil))
    (Sset _f (Etempvar _t'1 tint)))
  (Ssequence
    (Sifthenelse (Ebinop Olt (Etempvar _f tint)
                   (Econst_int (Int.repr 0) tint) tint)
      (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
      Sskip)
    (Ssequence
      (Sifthenelse (Etempvar _on tint)
        (Sset _f
          (Ebinop Oor (Etempvar _f tint) (Econst_int (Int.repr 2048) tint)
            tint))
        (Sset _f
          (Ebinop Oand (Etempvar _f tint)
            (Eunop Onotint (Econst_int (Int.repr 2048) tint) tint) tint)))
      (Ssequence
        (Ssequence
          (Scall (Some _t'2)
            (Evar _fcntl (Tfunction (tint :: tint :: nil) tint
                           {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|}))
            ((Etempvar _fd tint) :: (Econst_int (Int.repr 4) tint) ::
             (Etempvar _f tint) :: nil))
          (Sifthenelse (Ebinop Olt (Etempvar _t'2 tint)
                         (Econst_int (Int.repr 0) tint) tint)
            (Sset _t'3
              (Ecast (Eunop Oneg (Econst_int (Int.repr 1) tint) tint) tint))
            (Sset _t'3 (Ecast (Econst_int (Int.repr 0) tint) tint))))
        (Sreturn (Some (Etempvar _t'3 tint)))))))
|}.

Definition f_term_read_chunk := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_buf, (tptr tschar)) :: (_max, tint) :: nil);
  fn_vars := nil;
  fn_temps := ((_k, tlong) :: (_t'6, (tptr tint)) :: (_t'5, tint) ::
               (_t'4, (tptr tint)) :: (_t'3, tint) :: (_t'2, (tptr tint)) ::
               (_t'1, tlong) :: (_t'9, tint) :: (_t'8, tint) ::
               (_t'7, tint) :: nil);
  fn_body :=
(Ssequence
  (Sifthenelse (Ebinop Ole (Etempvar _max tint)
                 (Econst_int (Int.repr 0) tint) tint)
    (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
    Sskip)
  (Ssequence
    (Ssequence
      (Scall (Some _t'1)
        (Evar _read (Tfunction (tint :: (tptr tvoid) :: tulong :: nil) tlong
                      cc_default))
        ((Econst_int (Int.repr 0) tint) :: (Etempvar _buf (tptr tschar)) ::
         (Ecast (Etempvar _max tint) tuint) :: nil))
      (Sset _k (Etempvar _t'1 tlong)))
    (Ssequence
      (Sifthenelse (Ebinop Olt (Etempvar _k tlong)
                     (Econst_int (Int.repr 0) tint) tint)
        (Ssequence
          (Ssequence
            (Ssequence
              (Ssequence
                (Scall (Some _t'2)
                  (Evar ___errno_location (Tfunction nil (tptr tint)
                                            cc_default)) nil)
                (Ssequence
                  (Sset _t'8 (Ederef (Etempvar _t'2 (tptr tint)) tint))
                  (Sifthenelse (Ebinop Oeq (Etempvar _t'8 tint)
                                 (Econst_int (Int.repr 11) tint) tint)
                    (Sset _t'3 (Econst_int (Int.repr 1) tint))
                    (Ssequence
                      (Scall (Some _t'4)
                        (Evar ___errno_location (Tfunction nil (tptr tint)
                                                  cc_default)) nil)
                      (Ssequence
                        (Sset _t'9 (Ederef (Etempvar _t'4 (tptr tint)) tint))
                        (Sset _t'3
                          (Ecast
                            (Ebinop Oeq (Etempvar _t'9 tint)
                              (Econst_int (Int.repr 11) tint) tint) tbool)))))))
              (Sifthenelse (Etempvar _t'3 tint)
                (Sset _t'5 (Econst_int (Int.repr 1) tint))
                (Ssequence
                  (Scall (Some _t'6)
                    (Evar ___errno_location (Tfunction nil (tptr tint)
                                              cc_default)) nil)
                  (Ssequence
                    (Sset _t'7 (Ederef (Etempvar _t'6 (tptr tint)) tint))
                    (Sset _t'5
                      (Ecast
                        (Ebinop Oeq (Etempvar _t'7 tint)
                          (Econst_int (Int.repr 4) tint) tint) tbool))))))
            (Sifthenelse (Etempvar _t'5 tint)
              (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 2) tint) tint)))
              Sskip))
          (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint))))
        Sskip)
      (Sreturn (Some (Ecast (Etempvar _k tlong) tint))))))
|}.

Definition composites : list composite_definition :=
(Composite _pollfd Struct
   (Member_plain _fd tint :: Member_plain _events tshort ::
    Member_plain _revents tshort :: nil)
   noattr ::
 Composite _termios Struct
   (Member_plain _c_iflag tuint :: Member_plain _c_oflag tuint ::
    Member_plain _c_cflag tuint :: Member_plain _c_lflag tuint ::
    Member_plain _c_line tuchar :: Member_plain _c_cc (tarray tuchar 32) ::
    Member_plain _c_ispeed tuint :: Member_plain _c_ospeed tuint :: nil)
   noattr :: nil).

Definition global_definitions : list (ident * globdef fundef type) :=
((___compcert_va_int32,
   Gfun(External (EF_runtime "__compcert_va_int32"
                   (mksignature (AST.Xptr :: nil) AST.Xint cc_default))
     ((tptr tvoid) :: nil) tuint cc_default)) ::
 (___compcert_va_int64,
   Gfun(External (EF_runtime "__compcert_va_int64"
                   (mksignature (AST.Xptr :: nil) AST.Xlong cc_default))
     ((tptr tvoid) :: nil) tulong cc_default)) ::
 (___compcert_va_float64,
   Gfun(External (EF_runtime "__compcert_va_float64"
                   (mksignature (AST.Xptr :: nil) AST.Xfloat cc_default))
     ((tptr tvoid) :: nil) tdouble cc_default)) ::
 (___compcert_va_composite,
   Gfun(External (EF_runtime "__compcert_va_composite"
                   (mksignature (AST.Xptr :: AST.Xlong :: nil) AST.Xptr
                     cc_default)) ((tptr tvoid) :: tulong :: nil)
     (tptr tvoid) cc_default)) ::
 (___compcert_i64_dtos,
   Gfun(External (EF_runtime "__compcert_i64_dtos"
                   (mksignature (AST.Xfloat :: nil) AST.Xlong cc_default))
     (tdouble :: nil) tlong cc_default)) ::
 (___compcert_i64_dtou,
   Gfun(External (EF_runtime "__compcert_i64_dtou"
                   (mksignature (AST.Xfloat :: nil) AST.Xlong cc_default))
     (tdouble :: nil) tulong cc_default)) ::
 (___compcert_i64_stod,
   Gfun(External (EF_runtime "__compcert_i64_stod"
                   (mksignature (AST.Xlong :: nil) AST.Xfloat cc_default))
     (tlong :: nil) tdouble cc_default)) ::
 (___compcert_i64_utod,
   Gfun(External (EF_runtime "__compcert_i64_utod"
                   (mksignature (AST.Xlong :: nil) AST.Xfloat cc_default))
     (tulong :: nil) tdouble cc_default)) ::
 (___compcert_i64_stof,
   Gfun(External (EF_runtime "__compcert_i64_stof"
                   (mksignature (AST.Xlong :: nil) AST.Xsingle cc_default))
     (tlong :: nil) tfloat cc_default)) ::
 (___compcert_i64_utof,
   Gfun(External (EF_runtime "__compcert_i64_utof"
                   (mksignature (AST.Xlong :: nil) AST.Xsingle cc_default))
     (tulong :: nil) tfloat cc_default)) ::
 (___compcert_i64_sdiv,
   Gfun(External (EF_runtime "__compcert_i64_sdiv"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___compcert_i64_udiv,
   Gfun(External (EF_runtime "__compcert_i64_udiv"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tulong :: tulong :: nil) tulong
     cc_default)) ::
 (___compcert_i64_smod,
   Gfun(External (EF_runtime "__compcert_i64_smod"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___compcert_i64_umod,
   Gfun(External (EF_runtime "__compcert_i64_umod"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tulong :: tulong :: nil) tulong
     cc_default)) ::
 (___compcert_i64_shl,
   Gfun(External (EF_runtime "__compcert_i64_shl"
                   (mksignature (AST.Xlong :: AST.Xint :: nil) AST.Xlong
                     cc_default)) (tlong :: tint :: nil) tlong cc_default)) ::
 (___compcert_i64_shr,
   Gfun(External (EF_runtime "__compcert_i64_shr"
                   (mksignature (AST.Xlong :: AST.Xint :: nil) AST.Xlong
                     cc_default)) (tulong :: tint :: nil) tulong cc_default)) ::
 (___compcert_i64_sar,
   Gfun(External (EF_runtime "__compcert_i64_sar"
                   (mksignature (AST.Xlong :: AST.Xint :: nil) AST.Xlong
                     cc_default)) (tlong :: tint :: nil) tlong cc_default)) ::
 (___compcert_i64_smulh,
   Gfun(External (EF_runtime "__compcert_i64_smulh"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___compcert_i64_umulh,
   Gfun(External (EF_runtime "__compcert_i64_umulh"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tulong :: tulong :: nil) tulong
     cc_default)) ::
 (___builtin_ais_annot,
   Gfun(External (EF_builtin "__builtin_ais_annot"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     ((tptr tschar) :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (___builtin_bswap64,
   Gfun(External (EF_builtin "__builtin_bswap64"
                   (mksignature (AST.Xlong :: nil) AST.Xlong cc_default))
     (tulong :: nil) tulong cc_default)) ::
 (___builtin_bswap,
   Gfun(External (EF_builtin "__builtin_bswap"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tuint cc_default)) ::
 (___builtin_bswap32,
   Gfun(External (EF_builtin "__builtin_bswap32"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tuint cc_default)) ::
 (___builtin_bswap16,
   Gfun(External (EF_builtin "__builtin_bswap16"
                   (mksignature (AST.Xint16unsigned :: nil)
                     AST.Xint16unsigned cc_default)) (tushort :: nil) tushort
     cc_default)) ::
 (___builtin_clz,
   Gfun(External (EF_builtin "__builtin_clz"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tint cc_default)) ::
 (___builtin_clzl,
   Gfun(External (EF_builtin "__builtin_clzl"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_clzll,
   Gfun(External (EF_builtin "__builtin_clzll"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_ctz,
   Gfun(External (EF_builtin "__builtin_ctz"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tint cc_default)) ::
 (___builtin_ctzl,
   Gfun(External (EF_builtin "__builtin_ctzl"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_ctzll,
   Gfun(External (EF_builtin "__builtin_ctzll"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_fabs,
   Gfun(External (EF_builtin "__builtin_fabs"
                   (mksignature (AST.Xfloat :: nil) AST.Xfloat cc_default))
     (tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fabsf,
   Gfun(External (EF_builtin "__builtin_fabsf"
                   (mksignature (AST.Xsingle :: nil) AST.Xsingle cc_default))
     (tfloat :: nil) tfloat cc_default)) ::
 (___builtin_fsqrt,
   Gfun(External (EF_builtin "__builtin_fsqrt"
                   (mksignature (AST.Xfloat :: nil) AST.Xfloat cc_default))
     (tdouble :: nil) tdouble cc_default)) ::
 (___builtin_sqrt,
   Gfun(External (EF_builtin "__builtin_sqrt"
                   (mksignature (AST.Xfloat :: nil) AST.Xfloat cc_default))
     (tdouble :: nil) tdouble cc_default)) ::
 (___builtin_memcpy_aligned,
   Gfun(External (EF_builtin "__builtin_memcpy_aligned"
                   (mksignature
                     (AST.Xptr :: AST.Xptr :: AST.Xlong :: AST.Xlong :: nil)
                     AST.Xvoid cc_default))
     ((tptr tvoid) :: (tptr tvoid) :: tulong :: tulong :: nil) tvoid
     cc_default)) ::
 (___builtin_sel,
   Gfun(External (EF_builtin "__builtin_sel"
                   (mksignature (AST.Xbool :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     (tbool :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (___builtin_annot,
   Gfun(External (EF_builtin "__builtin_annot"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     ((tptr tschar) :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (___builtin_annot_intval,
   Gfun(External (EF_builtin "__builtin_annot_intval"
                   (mksignature (AST.Xptr :: AST.Xint :: nil) AST.Xint
                     cc_default)) ((tptr tschar) :: tint :: nil) tint
     cc_default)) ::
 (___builtin_membar,
   Gfun(External (EF_builtin "__builtin_membar"
                   (mksignature nil AST.Xvoid cc_default)) nil tvoid
     cc_default)) ::
 (___builtin_va_start,
   Gfun(External (EF_builtin "__builtin_va_start"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid cc_default))
     ((tptr tvoid) :: nil) tvoid cc_default)) ::
 (___builtin_va_arg,
   Gfun(External (EF_builtin "__builtin_va_arg"
                   (mksignature (AST.Xptr :: AST.Xint :: nil) AST.Xvoid
                     cc_default)) ((tptr tvoid) :: tuint :: nil) tvoid
     cc_default)) ::
 (___builtin_va_copy,
   Gfun(External (EF_builtin "__builtin_va_copy"
                   (mksignature (AST.Xptr :: AST.Xptr :: nil) AST.Xvoid
                     cc_default)) ((tptr tvoid) :: (tptr tvoid) :: nil) tvoid
     cc_default)) ::
 (___builtin_va_end,
   Gfun(External (EF_builtin "__builtin_va_end"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid cc_default))
     ((tptr tvoid) :: nil) tvoid cc_default)) ::
 (___builtin_unreachable,
   Gfun(External (EF_builtin "__builtin_unreachable"
                   (mksignature nil AST.Xvoid cc_default)) nil tvoid
     cc_default)) ::
 (___builtin_expect,
   Gfun(External (EF_builtin "__builtin_expect"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___builtin_fmax,
   Gfun(External (EF_builtin "__builtin_fmax"
                   (mksignature (AST.Xfloat :: AST.Xfloat :: nil) AST.Xfloat
                     cc_default)) (tdouble :: tdouble :: nil) tdouble
     cc_default)) ::
 (___builtin_fmin,
   Gfun(External (EF_builtin "__builtin_fmin"
                   (mksignature (AST.Xfloat :: AST.Xfloat :: nil) AST.Xfloat
                     cc_default)) (tdouble :: tdouble :: nil) tdouble
     cc_default)) ::
 (___builtin_fmadd,
   Gfun(External (EF_builtin "__builtin_fmadd"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fmsub,
   Gfun(External (EF_builtin "__builtin_fmsub"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fnmadd,
   Gfun(External (EF_builtin "__builtin_fnmadd"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fnmsub,
   Gfun(External (EF_builtin "__builtin_fnmsub"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_read16_reversed,
   Gfun(External (EF_builtin "__builtin_read16_reversed"
                   (mksignature (AST.Xptr :: nil) AST.Xint16unsigned
                     cc_default)) ((tptr tushort) :: nil) tushort
     cc_default)) ::
 (___builtin_read32_reversed,
   Gfun(External (EF_builtin "__builtin_read32_reversed"
                   (mksignature (AST.Xptr :: nil) AST.Xint cc_default))
     ((tptr tuint) :: nil) tuint cc_default)) ::
 (___builtin_write16_reversed,
   Gfun(External (EF_builtin "__builtin_write16_reversed"
                   (mksignature (AST.Xptr :: AST.Xint16unsigned :: nil)
                     AST.Xvoid cc_default))
     ((tptr tushort) :: tushort :: nil) tvoid cc_default)) ::
 (___builtin_write32_reversed,
   Gfun(External (EF_builtin "__builtin_write32_reversed"
                   (mksignature (AST.Xptr :: AST.Xint :: nil) AST.Xvoid
                     cc_default)) ((tptr tuint) :: tuint :: nil) tvoid
     cc_default)) ::
 (___builtin_debug,
   Gfun(External (EF_external "__builtin_debug"
                   (mksignature (AST.Xint :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     (tint :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (___errno_location,
   Gfun(External (EF_external "__errno_location"
                   (mksignature nil AST.Xptr cc_default)) nil (tptr tint)
     cc_default)) ::
 (_fcntl,
   Gfun(External (EF_external "fcntl"
                   (mksignature (AST.Xint :: AST.Xint :: nil) AST.Xint
                     {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|}))
     (tint :: tint :: nil) tint
     {|cc_vararg:=(Some 2); cc_unproto:=false; cc_structret:=false|})) ::
 (_poll,
   Gfun(External (EF_external "poll"
                   (mksignature (AST.Xptr :: AST.Xlong :: AST.Xint :: nil)
                     AST.Xint cc_default))
     ((tptr (Tstruct _pollfd noattr)) :: tulong :: tint :: nil) tint
     cc_default)) ::
 (_signal,
   Gfun(External (EF_external "signal"
                   (mksignature (AST.Xint :: AST.Xptr :: nil) AST.Xptr
                     cc_default))
     (tint :: (tptr (Tfunction (tint :: nil) tvoid cc_default)) :: nil)
     (tptr (Tfunction (tint :: nil) tvoid cc_default)) cc_default)) ::
 (_recv,
   Gfun(External (EF_external "recv"
                   (mksignature
                     (AST.Xint :: AST.Xptr :: AST.Xlong :: AST.Xint :: nil)
                     AST.Xlong cc_default))
     (tint :: (tptr tvoid) :: tulong :: tint :: nil) tlong cc_default)) ::
 (_tcgetattr,
   Gfun(External (EF_external "tcgetattr"
                   (mksignature (AST.Xint :: AST.Xptr :: nil) AST.Xint
                     cc_default))
     (tint :: (tptr (Tstruct _termios noattr)) :: nil) tint cc_default)) ::
 (_tcsetattr,
   Gfun(External (EF_external "tcsetattr"
                   (mksignature (AST.Xint :: AST.Xint :: AST.Xptr :: nil)
                     AST.Xint cc_default))
     (tint :: tint :: (tptr (Tstruct _termios noattr)) :: nil) tint
     cc_default)) ::
 (_cfmakeraw,
   Gfun(External (EF_external "cfmakeraw"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid cc_default))
     ((tptr (Tstruct _termios noattr)) :: nil) tvoid cc_default)) ::
 (_time,
   Gfun(External (EF_external "time"
                   (mksignature (AST.Xptr :: nil) AST.Xlong cc_default))
     ((tptr tlong) :: nil) tlong cc_default)) ::
 (_read,
   Gfun(External (EF_external "read"
                   (mksignature (AST.Xint :: AST.Xptr :: AST.Xlong :: nil)
                     AST.Xlong cc_default))
     (tint :: (tptr tvoid) :: tulong :: nil) tlong cc_default)) ::
 (_write,
   Gfun(External (EF_external "write"
                   (mksignature (AST.Xint :: AST.Xptr :: AST.Xlong :: nil)
                     AST.Xlong cc_default))
     (tint :: (tptr tvoid) :: tulong :: nil) tlong cc_default)) ::
 (_isatty,
   Gfun(External (EF_external "isatty"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tint :: nil) tint cc_default)) ::
 (_tedex_ignore_sigpipe, Gfun(Internal f_tedex_ignore_sigpipe)) ::
 (_write_all, Gfun(Internal f_write_all)) ::
 (_term_attach, Gfun(Internal f_term_attach)) ::
 (_term_read_line, Gfun(Internal f_term_read_line)) ::
 (_oldt, Gvar v_oldt) :: (_saved, Gvar v_saved) ::
 (_term_raw, Gfun(Internal f_term_raw)) ::
 (_term_set_nonblock, Gfun(Internal f_term_set_nonblock)) ::
 (_term_read_chunk, Gfun(Internal f_term_read_chunk)) :: nil).

Definition public_idents : list ident :=
(_term_read_chunk :: _term_set_nonblock :: _term_raw :: _term_read_line ::
 _term_attach :: _tedex_ignore_sigpipe :: _isatty :: _write :: _read ::
 _time :: _cfmakeraw :: _tcsetattr :: _tcgetattr :: _recv :: _signal ::
 _poll :: _fcntl :: ___errno_location :: ___builtin_debug ::
 ___builtin_write32_reversed :: ___builtin_write16_reversed ::
 ___builtin_read32_reversed :: ___builtin_read16_reversed ::
 ___builtin_fnmsub :: ___builtin_fnmadd :: ___builtin_fmsub ::
 ___builtin_fmadd :: ___builtin_fmin :: ___builtin_fmax ::
 ___builtin_expect :: ___builtin_unreachable :: ___builtin_va_end ::
 ___builtin_va_copy :: ___builtin_va_arg :: ___builtin_va_start ::
 ___builtin_membar :: ___builtin_annot_intval :: ___builtin_annot ::
 ___builtin_sel :: ___builtin_memcpy_aligned :: ___builtin_sqrt ::
 ___builtin_fsqrt :: ___builtin_fabsf :: ___builtin_fabs ::
 ___builtin_ctzll :: ___builtin_ctzl :: ___builtin_ctz :: ___builtin_clzll ::
 ___builtin_clzl :: ___builtin_clz :: ___builtin_bswap16 ::
 ___builtin_bswap32 :: ___builtin_bswap :: ___builtin_bswap64 ::
 ___builtin_ais_annot :: ___compcert_i64_umulh :: ___compcert_i64_smulh ::
 ___compcert_i64_sar :: ___compcert_i64_shr :: ___compcert_i64_shl ::
 ___compcert_i64_umod :: ___compcert_i64_smod :: ___compcert_i64_udiv ::
 ___compcert_i64_sdiv :: ___compcert_i64_utof :: ___compcert_i64_stof ::
 ___compcert_i64_utod :: ___compcert_i64_stod :: ___compcert_i64_dtou ::
 ___compcert_i64_dtos :: ___compcert_va_composite ::
 ___compcert_va_float64 :: ___compcert_va_int64 :: ___compcert_va_int32 ::
 nil).

Definition prog : Clight.program := 
  mkprogram composites global_definitions public_idents _main Logic.I.


