(* VST verification of term_read_chunk (termhelp.c).
   HONEST STATUS (2026-10-07): PARTIAL -- this file does NOT compile clean.
   Proven so far: specs+Gprog typecheck; max<=0 split (then-branch CLOSED);
   _read forward_call with full POST; k<0 split (via manual seq_assoc
   normalization -- bare forward_if fails, see RESUME_NOTES.md).
   BLOCKER: first __errno_location forward_call. Root cause isolated
   (Floyd prove_call_setup_aux leaves frame-entailment + call_setup2
   goals, VST 2.17 positional dispatch doesn't consume them; see
   RESUME_NOTES.md "The errno blocker" for probes + next step).
   Syscall model: read(2) + __errno_location are AXIOMS (external specs).
   EAGAIN=11, EWOULDBLOCK=11, EINTR=4 (Linux x86_64, matches Clight).
   The three errno reads are specified independently (may differ);
   proved property: branch-structure correctness + memory safety.
   PRE allows 0 <= max (max=0: empty buffer, returns -1 via then-branch).
   Negative max is EXCLUDED from the spec (vacuous); the Ada caller
   always passes 1024. *)

Require Import VST.floyd.proofauto.
Require Import Clight.termhelp.

Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.

(* Axiom: read(fd, buf, n). Nondeterministic POSIX behaviour. *)
Definition read_spec : ident * funspec :=
  DECLARE _read
  WITH fd : Z, buf : val, n : Z, sh : share, pre : list val
  PRE [ tint, tptr tvoid, tulong ]
    PROP (0 <= fd <= Int.max_signed;
          0 < n <= Int64.max_unsigned;
          Zlength pre = n;
          writable_share sh)
    PARAMS (Vint (Int.repr fd); buf; Vlong (Int64.repr n))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre buf)
  POST [ tlong ]
    EX ret : Z, EX post : list val,
    PROP (Int64.min_signed <= ret <= Int64.max_signed;
          ret <= n;
          Zlength post = n;
          (ret <= 0 -> post = pre))
    LOCAL (temp ret_temp (Vlong (Int64.repr ret)))
    SEP (data_at sh (tarray tschar n) post buf).

(* Axiom: __errno_location() returns a valid int pointer. *)
Definition errno_loc_spec : ident * funspec :=
  DECLARE ___errno_location
  WITH sh : share
  PRE [ ]
    PROP (writable_share sh)
    PARAMS () GLOBALS () SEP (emp)
  POST [ tptr tint ]
    EX p : val, EX e : Z,
    PROP (Int.min_signed <= e <= Int.max_signed)
    LOCAL (temp ret_temp p)
    SEP (data_at sh tint (Vint (Int.repr e)) p).

Definition term_read_chunk_spec : ident * funspec :=
  DECLARE _term_read_chunk
  WITH buf : val, max : Z, sh : share, pre : list val
  PRE [ tptr tschar, tint ]
    PROP (0 <= max <= Int.max_signed;
          Zlength pre = max;
          writable_share sh)
    PARAMS (buf; Vint (Int.repr max))
    GLOBALS ()
    SEP (data_at sh (tarray tschar max) pre buf)
  POST [ tint ]
    EX ret : Z, EX post : list val,
    PROP (Int.min_signed <= ret <= Int.max_signed;
          Zlength post = max;
          (ret = -1 \/ ret = -2 \/ 0 <= ret <= max);
          (ret <= 0 -> post = pre))
    LOCAL (temp ret_temp (Vint (Int.repr ret)))
    SEP (data_at sh (tarray tschar max) post buf).

Definition Gprog : funspecs :=
  ltac:(with_library prog [read_spec; errno_loc_spec;
                           term_read_chunk_spec]).

Lemma body_term_read_chunk :
  semax_body Vprog Gprog f_term_read_chunk term_read_chunk_spec.
Proof.
  start_function.
  forward_if.
  - (* max <= 0, hence max = 0: return -1, buffer empty *)
    forward.
    Exists (-1) pre.
    entailer!.
  - (* max > 0: call read *)
    forward_call (0, buf, max, sh, pre).
    Intros vret. destruct vret as [ret post].
    change (fst (ret, post)) with ret in *.
    change (snd (ret, post)) with post in *.
      (* forward_call already processed Sset _k; program is at if (k<0).
         Bare forward_if fails on this statement shape in VST 2.17, so
         normalize manually first (same rewrites forward_if'_new does). *)
      repeat (apply -> semax_seq_skip).
      repeat (apply seq_assoc1; try apply -> semax_seq_skip).
      forward_if.
      * (* k < 0: errno dispatch *)
        forward_call (sh).
        Intros p1 e1.
        forward. (* _t'8 = e1 *)
        forward_if.
        -- (* e1 = 11 (EAGAIN): _t'3 = 1 *)
           forward. (* Sset _t'3 *)
           forward_if.
           ++ (* _t'3 nonzero: _t'5 = 1 *)
              forward.
              forward_if.
              ** (* _t'5 nonzero: return -2 *)
                 forward.
                 Exists (-2) post.
                 entailer!.
                 admit. (* dispatch + buffer facts *)
              ** (* _t'5 = 0: impossible, it was just set to 1 *)
                 admit.
           ++ (* _t'3 = 0: impossible *)
              admit.
        -- (* e1 <> 11: check EWOULDBLOCK *)
           forward_call (sh).
           Intros p2 e2.
           forward. forward.
           forward_if.
           ++ (* e2 = 11: _t'5 path to -2 *)
              forward. forward.
              forward_if.
              ** forward.
                 Exists (-2) post.
                 entailer!.
                 admit.
              ** admit.
           ++ (* e2 <> 11: check EINTR *)
              forward_call (sh).
              Intros p3 e3.
              forward. forward.
              forward_if.
              ** (* e3 = 4: return -2 *)
                 forward. forward.
                 Exists (-2) post.
                 entailer!.
                 admit.
              ** (* else return -1 *)
                 forward.
                 Exists (-1) post.
                 entailer!.
                 admit.
      * (* k >= 0: return (int)k *)
        forward.
        Exists ret post.
        entailer!.
        admit.
Admitted.
