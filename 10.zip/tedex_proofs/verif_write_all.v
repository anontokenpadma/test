(* VST specification of write_all (termhelp.c):
     static int write_all(int fd, const char *b, long n)
     { long off = 0; while (off < n) {
         long w = write(fd, b+off, n-off);
         if (w < 0) { if (errno == EINTR) continue; return -1; }
         if (w == 0) return -1; off += w; } return 0; }
   HONEST STATUS: specs below TYPECHECK; the semax_body proof is
   Admitted (pending). Future proof needs a forward_while invariant:
     off in [0,n] /\ bytes [0,off) accepted /\ buffer unchanged,
   variant n-off, plus the write() axiom below and an EINTR=4 errno
   spec (same pattern as verif_read_chunk.v).
   Syscall model: write(2) is an AXIOM (external spec). *)

Require Import VST.floyd.proofauto.
Require Import Clight.termhelp.

Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.

(* Axiom: write(fd, buf, n). Buffer unchanged by the call. *)
Definition write_spec : ident * funspec :=
  DECLARE _write
  WITH fd : Z, buf : val, n : Z, sh : share, pre : list val
  PRE [ tint, tptr tvoid, tulong ]
    PROP (0 <= fd <= Int.max_signed;
          0 <= n <= Int64.max_unsigned;
          Zlength pre = n;
          readable_share sh)
    PARAMS (Vint (Int.repr fd); buf; Vlong (Int64.repr n))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre buf)
  POST [ tlong ]
    EX ret : Z,
    PROP (Int64.min_signed <= ret <= Int64.max_signed;
          ret <= n)
    LOCAL (temp ret_temp (Vlong (Int64.repr ret)))
    SEP (data_at sh (tarray tschar n) pre buf).

Definition write_all_spec : ident * funspec :=
  DECLARE _write_all
  WITH fd : Z, b : val, n : Z, sh : share, pre : list val
  PRE [ tint, tptr tschar, tlong ]
    PROP (0 <= fd <= Int.max_signed;
          0 <= n <= Int64.max_signed;
          Zlength pre = n;
          readable_share sh)
    PARAMS (Vint (Int.repr fd); b; Vlong (Int64.repr n))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre b)
  POST [ tint ]
    EX r : Z,
    PROP ((r = 0 \/ r = -1);
          Int.min_signed <= r <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr r)))
    SEP (data_at sh (tarray tschar n) pre b).

Definition Gprog : funspecs :=
  ltac:(with_library prog [write_spec; write_all_spec]).

(* PENDING (Admitted): loop invariant off in [0,n], variant n-off. *)
Lemma body_write_all :
  semax_body Vprog Gprog f_write_all write_all_spec.
Proof.
Admitted.
