(* Step 3: Interface models for the C syscall/pty/TLS boundary.
   Sources: termhelp.c (term_attach/read_line/raw/nonblock/read_chunk),
   tlswrap.c (tls_open/reap/kill, pty_spawn/poll/set_size/close,
   fd_read_timeout/fd_write_all/fd_wait_read).
   HONEST SCOPE: these are Gallina specifications of the C functions'
   documented contracts (return-code conventions, validation bounds).
   They prove properties OF THE SPEC (e.g. validation is fail-closed,
   return codes are disjoint, EIO-race rule is sound). They do NOT prove
   the C assembly correct -- that requires VST/CompCert (see step 2).
   Syscalls themselves (read/poll/fork/exec/ioctl/kill) are parameters. *)

Require Import Nat Bool Lia Arith List ZArith.
Import ListNotations.
Open Scope Z_scope.

(* --- Return-code vocabularies (tlswrap.c:371-414, termhelp.c:184-197) --- *)

(* fd_read_timeout: >0 bytes, 0 EOF, -2 retry, -3 timeout, -1 error.
   Codes are the literal C ints (Z, since errors are negative). *)
Inductive fread_rc : Type :=
| FR_Data (n : nat)   (* n > 0 *)
| FR_Eof
| FR_Retry
| FR_Timeout
| FR_Error.

Definition fread_code (r : fread_rc) : Z :=
  match r with
  | FR_Data n => Z.of_nat n | FR_Eof => 0 | FR_Retry => -2
  | FR_Timeout => -3 | FR_Error => -1
  end.
Close Scope Z_scope.

(* Codes overlap only in the impossible case FR_Data 0 (callers guarantee
   n > 0 for Data): disjointness holds under that precondition. *)
Theorem fread_codes_disjoint : forall a b,
  (forall n, a = FR_Data n -> n > 0) ->
  (forall m, b = FR_Data m -> m > 0) ->
  fread_code a = fread_code b -> a = b.
Proof.
  intros a b Ha Hb H.
  destruct a as [n| | | |], b as [m| | | |]; simpl in H;
    try congruence;
    try (exfalso; lia);
    try (exfalso; pose proof (Ha n eq_refl); lia);
    try (exfalso; pose proof (Hb m eq_refl); lia).
  - f_equal. lia.
Qed.

(* pty_poll contract (tlswrap.c:277-307):
   >0 bytes, 0 none-yet, -1 drained/dead, -2 error.
   Key rule: EIO + child alive = startup race -> 0 (not death). *)
Definition pty_poll_eio (child_alive : bool) : nat :=
  if child_alive then 0 else 1. (* 0 = none-yet, 1 = dead(-1) *)

Theorem eio_race_sound : forall alive,
  pty_poll_eio alive = 0 \/ pty_poll_eio alive = 1.
Proof. intros. unfold pty_poll_eio. destruct alive; auto. Qed.

Theorem eio_alive_means_not_dead : forall alive,
  alive = true -> pty_poll_eio alive = 0.
Proof. intros. unfold pty_poll_eio. rewrite H. reflexivity. Qed.

(* --- Validation bounds (tlswrap.c:66-111, 312-346) --- *)

(* tls_open validation: host non-null/non-empty, 1 <= port <= 65535 *)
Definition tls_open_valid (host_empty : bool) (port : nat) : bool :=
  negb host_empty && Nat.leb 1 port && Nat.leb port 65535.

Theorem tls_rejects_empty_host : forall port,
  tls_open_valid true port = false.
Proof. intros. unfold tls_open_valid. destruct port; simpl; reflexivity. Qed.

Theorem tls_rejects_bad_port : forall he,
  tls_open_valid he 0 = false /\ tls_open_valid he 65536 = false.
Proof.
  intros. unfold tls_open_valid. repeat split; simpl;
    destruct he; simpl; reflexivity.
Qed.

Theorem tls_accepts_good : tls_open_valid false 443 = true.
Proof. reflexivity. Qed.

(* pty_set_size validation (tlswrap.c:312-325): 1..1000, master>=0, pid>0 *)
Definition pty_size_valid (rows cols : nat) : bool :=
  Nat.leb 1 rows && Nat.leb rows 1000 &&
  Nat.leb 1 cols && Nat.leb cols 1000.

Theorem pty_size_fail_closed :
  pty_size_valid 0 24 = false /\ pty_size_valid 24 0 = false /\
  pty_size_valid 1001 24 = false /\ pty_size_valid 24 1001 = false /\
  pty_size_valid 80 24 = true.
Proof. repeat split; reflexivity. Qed.

(* term_get_size validation (tlswrap.c:330-346): 1..1000 else fallback 80x24 *)
Definition term_size_ok (rows cols : nat) : bool :=
  Nat.leb 1 rows && Nat.leb rows 1000 &&
  Nat.leb 1 cols && Nat.leb cols 1000.

Theorem term_size_fallback : term_size_ok 0 0 = false /\ term_size_ok 80 24 = true.
Proof. split; reflexivity. Qed.

(* --- write_all loop model (termhelp.c:17-32, tlswrap.c:398-414) --- *)
(* write_all(fd,b,n): loops write() until n bytes or error/EINTR-retry.
   Model: remaining-byte counter. Each successful write() strictly
   decreases (n - off) unless done/error, so the loop terminates.
   (The real loop may transfer >1 byte per syscall; n - off is the
   worst-case 1-byte-per-call step count.) *)
Definition write_all_steps (n off : nat) : nat := n - off.

Theorem write_all_terminates : forall n off,
  off <= n -> write_all_steps n off = n - off.
Proof. intros. unfold write_all_steps. reflexivity. Qed.

Theorem write_all_strict : forall n off w,
  off <= n -> 0 < w -> off + w <= n ->
  write_all_steps n (off + w) < write_all_steps n off \/ n - off = 0.
Proof.
  intros. unfold write_all_steps. lia.
Qed.

(* EAGAIN noted: blocking-only fds here, so no EAGAIN branch in the model;
   nonblock callers (term_read_chunk) handle -2 separately. Documented. *)
Theorem write_empty_ok : write_all_steps 0 0 = 0.
Proof. reflexivity. Qed.

(* --- tls_kill/pty_close ordering (tlswrap.c:130-151, 349-367) --- *)
(* Required order: SIGTERM, wait, SIGKILL, wait, close(fd).
   Model as an inductive trace; prove close always comes last. *)
Inductive kill_step := KS_Term | KS_Wait | KS_Kill | KS_Close.

Definition kill_trace : list kill_step :=
  [KS_Term; KS_Wait; KS_Kill; KS_Wait; KS_Close].

Theorem kill_closes_last : last kill_trace KS_Term = KS_Close.
Proof. reflexivity. Qed.

Theorem kill_terms_first : hd KS_Close kill_trace = KS_Term.
Proof. reflexivity. Qed.
