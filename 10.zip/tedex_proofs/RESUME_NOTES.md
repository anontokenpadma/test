# Tedex Rocq/VST verification — resume notes (2026-10-07, honest status)

## Environment (verified working)
- Switch `rocq-9.2` (OCaml 5.2.1): Rocq 9.2.0 + CompCert 3.18 + coq-vst 2.17 + Flocq 4.2.2.
- Rebuild note: Flocq/VST MUST be built with system gcc (`CC=/usr/bin/gcc`,
  `/usr/bin` before `/opt/conda/bin` in PATH, unset LIBRARY_PATH/CPATH);
  conda `ld`+sysroot breaks Flocq `remake` with `_dl_vsym@GLIBC_PRIVATE`.
- `opam install coq-vst.2.17 -y -j4 --no-depexts` (needs `coq-released` repo
  + conda `clang` for conf-clang).

## File inventory (`~/tedex_proofs/`, packaged in `/home/jovyan/10.zip`)
| File | Status |
|---|---|
| AuthVerdict.v (.vo) | PROVED (7 thms, Qed) |
| EchoModel.v (.vo) | PROVED (13 thms, Qed) |
| AttachHandoff.v (.vo) | PROVED (7 thms, Qed) |
| SysModel.v (.vo) | PROVED (13 thms, Qed) |
| vst_specs.v (.vo) | skeleton, typechecks, documentation only |
| verif_close_fd.v (.vo 73KB) | PROVED end-to-end (Qed): tls_close_fd |
| verif_write_all.v | specs typecheck, Lemma Admitted (loop proof pending) |
| verif_fd_read.v | specs typecheck, Lemma Admitted (poll/struct proof pending) |
| verif_read_chunk.v | PARTIAL, does NOT compile clean (see blocker) |
| clight/termhelp.{c,v}, tlswrap.{c,v} | clightgen -normalize exit 0 both |

## The errno blocker (verif_read_chunk.v, 1st of 3 `__errno_location` calls)
Target: `forward_call` on `Scall (Some _t'2) (Evar ___errno_location ...)`
with spec `errno_loc_spec` (WITH sh:share, PRE SEP emp,
POST EX p EX e, data_at sh tint).

Established facts (each verified by compiling probe):
1. Specs + Gprog typecheck; `with_library` accepts all specs.
2. `forward_if` (max<=0) works; then-branch CLOSED by entailer!.
3. `forward_call (0,buf,max,sh,pre)` for `_read` works (explicit witness).
4. `prove_call_setup1 funspec_sub_refl` works for errno call.
5. `prove_call_setup ... (sh)` works; afterward exactly 2 goals remain:
   A. frame entailment `data_at sh (tarray tschar max) post buf
      |-- emp * fold_right_sepcon Frame` — solved by `cancel`.
   B. `call_setup2 <17 args incl. funspec pieces> -> semax ...`
      (full text captured 2026-10-07; premises include WITH/PRE/POST
      pieces, super_non_expansive terms, `[] [] sh Frame
      [writable_share sh] [emp] None [] []`).
6. Bare `forward_if` fails on `Ssequence(Sifthenelse... conseqüent Sreturn)`
   with "No matching clauses"; workaround (verified): precede with
   `repeat (apply -> semax_seq_skip).`
   `repeat (apply seq_assoc1; try apply -> semax_seq_skip).`
7. `semax_call_id1_wow` (call_lemmas.v:1207) takes
   `SETUP: call_setup2 ...` + ret/Post2/Qnew/B/Ppost/F/Rpost/Espec/
   TYret/OKretty/POST1/DELETE/H0/PPRE and concludes
   `@semax ... (Scall (Some ret) a bl)` — BARE call only.
   `eapply` fails on Ssequence-headed goals: split/restructure first.

## Next concrete step (whoever resumes)
In the k<0 branch after the workaround splits: handle the errno call by
`prove_call_setup (@nil Type) funspec_sub_refl (sh)`, solve goal A with
`cancel`, then prove goal B by intro-ing its premises and applying
`semax_call_id1_wow` with explicit SETUP (or `eapply` after isolating the
bare-Scall goal via semax_seq split). Same pattern then applies to the
2nd/3rd errno calls, the 3 errno ifs, 2 temp ifs, and returns. After that:
write_all loop (`forward_while`, invariant off in [0,n], variant n-off)
and fd_read_timeout (poll struct field_at reasoning).

## Honest scope reminders
- Gallina models prove MODELS transcribed from Ada/C, not the binaries.
- VST specs for read/write/poll/errno/close are AXIOMS over syscalls.
- The 3 errno reads are specified independently (may differ); the proved
  property is branch-structure + memory safety, not errno-value identity
  (needs a ghost global invariant — future work).
- SPARK (1538 checks) remains the authority for the Ada code.
