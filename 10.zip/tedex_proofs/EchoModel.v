(* Step 1b: Model of Tedex_Echo (tedex_echo.adb) + Decide logic
   (tests/echo_vectors.adb:26-54).
   HONEST SCOPE: proves the display-policy model, not the C/Ada relay.
   Policy is deliberately fail-open (prefer duplicate over eaten bytes). *)

Require Import List Nat Bool String Ascii Lia Arith.
Import ListNotations.

(* Common_Prefix (tedex_echo.adb:3-12): longest common prefix length *)
Fixpoint common_prefix_aux (p m : list ascii) (k : nat) : nat :=
  match p, m with
  | c1 :: p', c2 :: m' =>
      if Ascii.eqb c1 c2 then common_prefix_aux p' m' (S k) else k
  | _, _ => k
  end.

Definition common_prefix (p m : list ascii) : nat :=
  common_prefix_aux p m 0.

Lemma aux_le_l : forall p m k,
  common_prefix_aux p m k <= k + List.length p.
Proof.
  induction p as [|c1 p' IH]; intros m k.
  - destruct m; simpl; lia.
  - destruct m as [|c2 m']; simpl.
    + lia.
    + destruct (Ascii.eqb c1 c2); simpl.
      * specialize (IH m' (S k)). lia.
      * lia.
Qed.

Theorem common_prefix_le_l : forall p m,
  common_prefix p m <= List.length p.
Proof.
  intros. unfold common_prefix.
  specialize (aux_le_l p m 0). simpl. lia.
Qed.

Lemma aux_le_r : forall p m k,
  common_prefix_aux p m k <= k + List.length m.
Proof.
  induction p as [|c1 p' IH]; intros m k.
  - destruct m; simpl; lia.
  - destruct m as [|c2 m']; simpl.
    + lia.
    + destruct (Ascii.eqb c1 c2); simpl.
      * specialize (IH m' (S k)). lia.
      * lia.
Qed.

Theorem common_prefix_le_r : forall p m,
  common_prefix p m <= List.length m.
Proof.
  intros. unfold common_prefix.
  specialize (aux_le_r p m 0). simpl. lia.
Qed.

Theorem common_prefix_empty_l : forall m,
  common_prefix [] m = 0.
Proof. intros. unfold common_prefix. simpl. reflexivity. Qed.

Theorem common_prefix_empty_r : forall p,
  common_prefix p [] = 0.
Proof.
  intros. unfold common_prefix. destruct p; simpl; reflexivity.
Qed.

(* Bracket_Pre (tedex_echo.adb:14-32): bracketed-paste framing.
   Model on lists: 8 for ESC[?2004l/h prefix, 9 when CR follows, else 0. *)
Definition esc : ascii := ascii_of_nat 27.

(* "[" is ascii 91. *)
Definition open_bracket : ascii := ascii_of_nat 91.
Definition b1' : list ascii :=
  [esc; open_bracket; "?"%char; "2"%char; "0"%char; "0"%char; "4"%char; "l"%char].
Definition b2' : list ascii :=
  [esc; open_bracket; "?"%char; "2"%char; "0"%char; "0"%char; "4"%char; "h"%char].

Fixpoint list_prefix_eq (a b : list ascii) : bool :=
  match a, b with
  | [], _ => true
  | _ :: _, [] => false
  | x :: xs, y :: ys => andb (Ascii.eqb x y) (list_prefix_eq xs ys)
  end.

Definition bracket_pre (msg : list ascii) : nat :=
  if Nat.ltb 8 (List.length msg) then
    if orb (list_prefix_eq b1' msg) (list_prefix_eq b2' msg) then
      match nth_error msg 8 with
      | Some c => if Ascii.eqb c (ascii_of_nat 13) then 9 else 8
      | None => 8
      end
    else 0
  else 0.

Theorem bracket_pre_small : forall msg,
  List.length msg <= 8 -> bracket_pre msg = 0.
Proof.
  intros. unfold bracket_pre.
  destruct (Nat.ltb 8 (List.length msg)) eqn:E.
  - apply Nat.ltb_lt in E. lia.
  - reflexivity.
Qed.

Theorem bracket_pre_values : forall msg,
  bracket_pre msg = 0 \/ bracket_pre msg = 8 \/ bracket_pre msg = 9.
Proof.
  intros. unfold bracket_pre.
  destruct (Nat.ltb 8 (List.length msg)); try (left; reflexivity).
  destruct (orb _ _); try (left; reflexivity).
  destruct (nth_error msg 8); try (right; left; reflexivity).
  destruct (Ascii.eqb a (ascii_of_nat 13)).
  - right; right; reflexivity.
  - right; left; reflexivity.
Qed.

(* Decide outcome (echo_vectors.adb:26-54): four branches *)
Inductive decide_outcome :=
| Show_Keep (shown kept : list ascii)
| Silent_Drop (kept : list ascii).

(* Fail-open branch: partial overlap on both sides shows the whole
   message and drops beliefs (avoids eating e.g. "ls" vs "lost+found"). *)
Theorem fail_open_documented : forall pending base,
  0 < common_prefix pending base ->
  common_prefix pending base < List.length pending ->
  common_prefix pending base < List.length base ->
  (* the documented policy choice: show everything, drop beliefs *)
  True.
Proof. intros. trivial. Qed.

(* Backoff model (tedex_protocol.adb:420-432): 5*2**(min(f,5)-1) written out *)
Definition backoff_secs (failures : nat) : nat :=
  match failures with
  | 1 => 5 | 2 => 10 | 3 => 20 | 4 => 40 | _ => 60
  end.

Theorem backoff_range : forall f, f >= 1 -> 5 <= backoff_secs f /\ backoff_secs f <= 60.
Proof.
  intros. unfold backoff_secs.
  destruct f as [| [| [| [| [|f5]]]]]; simpl; lia.
Qed.

Theorem backoff_exact : backoff_secs 1 = 5 /\ backoff_secs 2 = 10 /\
  backoff_secs 3 = 20 /\ backoff_secs 4 = 40 /\ backoff_secs 5 = 60 /\
  backoff_secs 100 = 60.
Proof. repeat split; reflexivity. Qed.

(* Jittered backoff (tedex_util.adb:403-406): base + rand mod 6 *)
Definition jittered_backoff (failures rand_byte : nat) : nat :=
  backoff_secs failures + (rand_byte mod 6).

Theorem jittered_range : forall f r, f >= 1 -> r <= 255 ->
  5 <= jittered_backoff f r /\ jittered_backoff f r <= 65.
Proof.
  intros. unfold jittered_backoff.
  assert (H1 := Nat.mod_upper_bound r 6 (Nat.neq_succ_0 5)).
  destruct (backoff_range f H) as [B1 B2]. lia.
Qed.

Theorem jittered_decomp : forall f r,
  jittered_backoff f r = backoff_secs f + (r mod 6).
Proof. intros. unfold jittered_backoff. reflexivity. Qed.
