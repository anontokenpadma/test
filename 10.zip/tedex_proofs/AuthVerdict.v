(* Step 1a: Model of Tedex_Util.Auth_Verdict (tedex_util.adb:387-401)
   plus the server auth composition (server.adb:1043-1095).
   HONEST SCOPE: this proves the MODEL extracted line-for-line from Ada,
   not the Ada binary itself. The Ada SPARK proof (1538 checks) remains
   the authority for the deployed code; these Gallina lemmas cross-check
   the decision logic and document protocol properties. *)

Require Import Bool.

Inductive deny : Type :=
| Deny_None
| Deny_Bad_Password
| Deny_Stopped.

(* Direct transcription of Auth_Verdict body *)
Definition auth_verdict (pass_ok is_device key_ok disabled : bool)
  : bool * deny :=
  if negb (pass_ok || (is_device && key_ok)) then (false, Deny_Bad_Password)
  else if disabled then (false, Deny_Stopped)
       else (true, Deny_None).

Definition allow_of (p : bool * deny) : bool := fst p.
Definition reason_of (p : bool * deny) : deny := snd p.

(* Contract from tedex_util.ads:175-186 *)
Theorem allow_correct : forall pass_ok is_device key_ok disabled allow reason,
  auth_verdict pass_ok is_device key_ok disabled = (allow, reason) ->
  allow = ((pass_ok || (is_device && key_ok)) && negb disabled).
Proof.
  intros. unfold auth_verdict in H.
  destruct pass_ok, is_device, key_ok, disabled; simpl in *;
    inversion H; subst; simpl; reflexivity.
Qed.

Theorem reason_correct : forall pass_ok is_device key_ok disabled allow reason,
  auth_verdict pass_ok is_device key_ok disabled = (allow, reason) ->
  ((allow = true /\ reason = Deny_None) \/
   (allow = false /\ reason = Deny_Bad_Password /\
    negb (pass_ok || (is_device && key_ok)) = true) \/
   (allow = false /\ reason = Deny_Stopped /\
    (pass_ok || (is_device && key_ok)) = true /\ disabled = true)).
Proof.
  intros. unfold auth_verdict in H.
  destruct pass_ok, is_device, key_ok, disabled; simpl in *;
    inversion H; subst; simpl;
    try (left; split; reflexivity);
    try (right; left; repeat split; reflexivity);
    try (right; right; repeat split; reflexivity).
Qed.

(* Server policy (server.adb:1060-1075): manager leg never consults the
   device key. Modelled as: Key_Ok input is forced false for managers. *)
Theorem manager_never_uses_key : forall pass_ok key_ok disabled allow reason,
  auth_verdict pass_ok false key_ok disabled = (allow, reason) ->
  allow = (pass_ok && negb disabled).
Proof.
  intros. unfold auth_verdict in H.
  destruct pass_ok, key_ok, disabled; simpl in *;
    inversion H; subst; simpl; reflexivity.
Qed.

(* Device enrollment key cannot grant access unless this is a device leg
   AND the key verifies. In particular a key alone (pass_ok=false)
   implies is_device=true whenever access is granted. *)
Theorem key_alone_needs_device : forall is_device key_ok disabled,
  allow_of (auth_verdict false is_device key_ok disabled) = true ->
  is_device = true /\ key_ok = true /\ disabled = false.
Proof.
  intros. unfold allow_of, auth_verdict in H.
  destruct is_device, key_ok, disabled; simpl in H; inversion H;
    repeat split; reflexivity.
Qed.

(* A stopped (disabled) account is reported distinctly from a bad password,
   and never grants access even with correct credentials. *)
Theorem disabled_blocks_all : forall pass_ok is_device key_ok reason,
  auth_verdict pass_ok is_device key_ok true = (false, reason) ->
  reason <> Deny_None.
Proof.
  intros. unfold auth_verdict in H.
  destruct pass_ok, is_device, key_ok; simpl in H;
    inversion H; subst; simpl; congruence.
Qed.

Theorem disabled_distinct : forall pass_ok is_device key_ok,
  (pass_ok || (is_device && key_ok)) = true ->
  reason_of (auth_verdict pass_ok is_device key_ok true) = Deny_Stopped.
Proof.
  intros. unfold reason_of, auth_verdict.
  destruct pass_ok, is_device, key_ok; simpl in *;
    inversion H; reflexivity.
Qed.

(* Password-first ordering: wrong password + valid key on a manager leg
   is still a password failure, never a "stopped" verdict. *)
Theorem manager_wrong_pass_is_badpass : forall key_ok disabled,
  reason_of (auth_verdict false false key_ok disabled) = Deny_Bad_Password.
Proof.
  intros. unfold reason_of, auth_verdict.
  destruct key_ok, disabled; reflexivity.
Qed.
