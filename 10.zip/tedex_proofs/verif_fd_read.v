(* VST specification of fd_read_timeout (tlswrap.c):
     int fd_read_timeout(int fd, char *buf, int n, int timeout_ms)
     { poll(&p,1,timeout); s<0: EINTR->-2 else -1; s==0 -> -3;
       k=read(fd,buf,n); k<0: EINTR/EAGAIN/EWOULDBLOCK->-2 else -1;
       return k; }
   HONEST STATUS: specs below are written to TYPECHECK; the semax_body
   proof is Admitted (pending). Proof plan: forward through struct
   assignments, forward_call poll (axiom), branch on s, forward_call
   read (axiom, same pattern as verif_read_chunk.v), errno dispatch
   (same errno_loc_spec pattern), return entailment.
   Syscall model: poll(2) + read(2) + __errno_location are AXIOMS.
   POLLIN=1. EAGAIN=11, EWOULDBLOCK=11, EINTR=4 (Linux x86_64). *)

Require Import VST.floyd.proofauto.
Require Import Clight.tlswrap.

Instance CompSpecs : compspecs. Proof. make_compspecs prog. Defined.
Definition Vprog : varspecs. Proof. mk_varspecs prog. Defined.

(* Axiom: poll(&pfd, 1, timeout_ms). Models one struct pollfd. *)
Definition poll_spec : ident * funspec :=
  DECLARE _poll
  WITH fds : val, sh : share,
       fdfd : Z, ev : Z, rev : Z, timeout : Z
  PRE [ tptr (Tstruct _pollfd noattr), tulong, tint ]
    PROP (0 <= timeout <= Int.max_signed;
          Int.min_signed <= fdfd <= Int.max_signed;
          writable_share sh)
    PARAMS (fds; Vlong (Int64.repr 1); Vint (Int.repr timeout))
    GLOBALS ()
    SEP (data_at sh (Tstruct _pollfd noattr)
           (Vint (Int.repr fdfd),
            (Vint (Int.repr ev), Vint (Int.repr rev))) fds)
  POST [ tint ]
    EX s : Z, EX rev' : Z,
    PROP (Int.min_signed <= s <= Int.max_signed;
          Int.min_signed <= rev' <= Int.max_signed)
    LOCAL (temp ret_temp (Vint (Int.repr s)))
    SEP (data_at sh (Tstruct _pollfd noattr)
           (Vint (Int.repr fdfd),
            (Vint (Int.repr ev), Vint (Int.repr rev'))) fds).

(* Axiom: read(fd, buf, n). Nondeterministic POSIX behaviour. *)
Definition read_spec : ident * funspec :=
  DECLARE _read
  WITH fd : Z, buf : val, n : Z, sh : share, pre : list val
  PRE [ tint, tptr tvoid, tulong ]
    PROP (0 <= fd <= Int.max_signed;
          0 < n <= Int64.max_unsigned;
          Zlength pre = n;
          writable_share sh)
    PARAMS (Vint (Int.repr fd); buf; Vlong (Int64.repr n))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre buf)
  POST [ tlong ]
    EX ret : Z, EX post : list val,
    PROP (Int64.min_signed <= ret <= Int64.max_signed;
          ret <= n;
          Zlength post = n;
          (ret <= 0 -> post = pre))
    LOCAL (temp ret_temp (Vlong (Int64.repr ret)))
    SEP (data_at sh (tarray tschar n) post buf).

(* Axiom: __errno_location() returns a valid int pointer. *)
Definition errno_loc_spec : ident * funspec :=
  DECLARE ___errno_location
  WITH sh : share
  PRE [ ]
    PROP (writable_share sh)
    PARAMS () GLOBALS () SEP (emp)
  POST [ tptr tint ]
    EX p : val, EX e : Z,
    PROP (Int.min_signed <= e <= Int.max_signed)
    LOCAL (temp ret_temp p)
    SEP (data_at sh tint (Vint (Int.repr e)) p).

Definition fd_read_timeout_spec : ident * funspec :=
  DECLARE _fd_read_timeout
  WITH fd : Z, buf : val, n : Z, timeout : Z,
       sh : share, pre : list val
  PRE [ tint, tptr tschar, tint, tint ]
    PROP (0 <= fd <= Int.max_signed;
          0 < n <= Int.max_signed;
          0 <= timeout <= Int.max_signed;
          Zlength pre = n;
          writable_share sh)
    PARAMS (Vint (Int.repr fd); buf;
            Vint (Int.repr n); Vint (Int.repr timeout))
    GLOBALS ()
    SEP (data_at sh (tarray tschar n) pre buf)
  POST [ tint ]
    EX ret : Z, EX post : list val,
    PROP (Int.min_signed <= ret <= Int.max_signed;
          Zlength post = n;
          (ret = -3 \/ ret = -2 \/ ret = -1 \/ 0 <= ret <= n);
          (ret <= 0 -> post = pre))
    LOCAL (temp ret_temp (Vint (Int.repr ret)))
    SEP (data_at sh (tarray tschar n) post buf).

Definition Gprog : funspecs :=
  ltac:(with_library prog [poll_spec; read_spec; errno_loc_spec;
                           fd_read_timeout_spec]).

(* PENDING (Admitted): see proof plan in the header comment. *)
Lemma body_fd_read_timeout :
  semax_body Vprog Gprog f_fd_read_timeout fd_read_timeout_spec.
Proof.
Admitted.
