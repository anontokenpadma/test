import os
import math

# ==========================================
# PHẦN 1: KIỂM TRA RAM (CGROUP LIMIT)
# ==========================================
def get_cgroup_memory_limit_gb():
    """Đọc giới hạn RAM thực tế từ Cgroup v1 hoặc v2"""
    # Thử đọc Cgroup v2 (Tiêu chuẩn mới)
    try:
        with open('/sys/fs/cgroup/memory.max', 'r') as f:
            val = f.read().strip()
            if val != 'max': 
                return int(val) / (1024**3)
    except (FileNotFoundError, ValueError, PermissionError):
        pass
    
    # Thử đọc Cgroup v1 (Tiêu chuẩn cũ)
    try:
        with open('/sys/fs/cgroup/memory/memory.limit_in_bytes', 'r') as f:
            val = int(f.read().strip())
            # Nếu không giới hạn, Linux thường trả về một số cực lớn
            if val < 1000000000000000: 
                return val / (1024**3)
    except (FileNotFoundError, ValueError, PermissionError):
        pass
        
    return None # Không đọc được Cgroup RAM (có thể là unlimited)

def get_host_memory_gb():
    """Lấy RAM của máy chủ vật lý (Host)"""
    try:
        import psutil
        return psutil.virtual_memory().total / (1024**3)
    except ImportError:
        # Fallback: Đọc trực tiếp từ /proc/meminfo nếu không có psutil
        try:
            with open('/proc/meminfo', 'r') as f:
                for line in f:
                    if line.startswith('MemTotal:'):
                        return int(line.split()[1]) / (1024**2) # Đổi từ kB sang GB
        except Exception:
            return None

# ==========================================
# PHẦN 2: KIỂM TRA CPU (CGROUP QUOTA)
# ==========================================
def parse_cpuset(cpuset_str):
    """Hàm phụ để parse chuỗi cpuset dạng '0-23' hoặc '0,2,4'"""
    count = 0
    for part in cpuset_str.split(','):
        if '-' in part:
            start, end = map(int, part.split('-'))
            count += end - start + 1
        else:
            if part.strip():
                count += 1
    return count

def get_real_cpu_limit():
    """Đọc giới hạn CPU thực tế (Quota) hoặc danh sách Core được ghim (Cpuset)"""
    # 1. Thử đọc Cgroup v2
    try:
        with open('/sys/fs/cgroup/cpu.max', 'r') as f:
            parts = f.read().strip().split()
            if parts[0] != 'max': 
                quota = int(parts[0])
                period = int(parts[1])
                return quota / period
    except (FileNotFoundError, ValueError, PermissionError, IndexError):
        pass

    # 2. Thử đọc Cgroup v1
    try:
        with open('/sys/fs/cgroup/cpu/cpu.cfs_quota_us', 'r') as f:
            quota = int(f.read().strip())
        with open('/sys/fs/cgroup/cpu/cpu.cfs_period_us', 'r') as f:
            period = int(f.read().strip())
        if quota > 0 and period > 0:
            return quota / period
    except (FileNotFoundError, ValueError, PermissionError):
        pass

    # 3. Fallback: Đọc cpuset (Danh sách core được ghim cứng)
    for path in ['/sys/fs/cgroup/cpuset.cpus.effective', '/sys/fs/cgroup/cpuset.cpus', '/sys/fs/cgroup/cpuset/cpuset.cpus']:
        try:
            with open(path, 'r') as f:
                cpuset_str = f.read().strip()
                if cpuset_str:
                    return parse_cpuset(cpuset_str)
        except (FileNotFoundError, PermissionError):
            continue

    # 4. Fallback cuối cùng
    return len(os.sched_getaffinity(0))

# ==========================================
# PHẦN 3: IN BÁO CÁO TỔNG HỢP
# ==========================================
def main():
    print("="*55)
    print("  BÁO CÁO TÀI NGUYÊN THỰC TẾ (CHỐNG ĐẠN TOÀN DIỆN)")
    print("="*55)
    
    # --- Xử lý CPU ---
    host_cpu = os.cpu_count()
    affinity_cpu = len(os.sched_getaffinity(0))
    real_cpu = get_real_cpu_limit()
    
    print("\n[ 💻 CPU ]")
    print(f" - CPU Vật lý (Host):             {host_cpu} cores")
    print(f" - CPU Affinity Mask (Scheduler): {affinity_cpu} cores")
    print(f" - CPU Giới hạn thực (Cgroup):    {real_cpu} cores")
    
    if real_cpu < affinity_cpu:
        print(f" ⚠️  CẢNH BÁO: Bạn đang bị bóp CPU (Quota)!")
        print(f" 👉 Khuyến nghị: Chỉ nên dùng multiprocessing(n_jobs={math.ceil(real_cpu)}) hoặc Polars(num_threads={math.ceil(real_cpu)}).")
    else:
        print(f" ✅ TUYỆT VỜI: Bạn được sử dụng tối đa {affinity_cpu} cores cho đa luồng!")
        
    # --- Xử lý RAM ---
    host_ram = get_host_memory_gb()
    cgroup_ram = get_cgroup_memory_limit_gb()
    
    print("\n[ 🐏 RAM ]")
    if host_ram:
        print(f" - RAM Máy chủ vật lý (Host):     {host_ram:.2f} GB")
    else:
        print(f" - RAM Máy chủ vật lý (Host):     Không xác định được")
        
    if cgroup_ram:
        print(f" - RAM Giới hạn thực (Cgroup):    {cgroup_ram:.2f} GB")
    else:
        print(f" - RAM Giới hạn thực (Cgroup):    Không bị giới hạn (Unlimited)")
        cgroup_ram = host_ram # Fallback để so sánh
        
    if host_ram and cgroup_ram and (cgroup_ram < host_ram - 1):
        print(f" ⚠️  CẢNH BÁO: Container của bạn đang bị bóp RAM!")
        print(f" 👉 Khuyến nghị: Không load dataset lớn hơn {cgroup_ram * 0.8:.1f} GB vào bộ nhớ (chừa 20% RAM cho OS và Python overhead).")
    else:
        print(f" ✅ TUYỆT VỜI: Container của bạn được phép sử dụng toàn bộ RAM của máy chủ!")

    # --- Kết luận ---
    print("\n" + "="*55)
    print("  💡 KẾT LUẬN ĐỂ CODE ĐA LUỒNG (MULTIPROCESSING)")
    print("="*55)
    safe_cpus = math.ceil(real_cpu) if real_cpu < affinity_cpu else affinity_cpu
    safe_ram = f"{cgroup_ram * 0.8:.1f} GB" if cgroup_ram else "Unlimited"
    print(f" -> Số luồng (threads/processes) tối ưu: {safe_cpus}")
    print(f" -> Dung lượng RAM an toàn để load data: {safe_ram}")
    print("="*55)

if __name__ == '__main__':
    main()