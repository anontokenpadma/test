# tedex — remote shell only

Ada+C remote shell system: a central `server` relays `manager`
consoles to `device` shells (`/bin/bash -i` over a pty). No screen
sharing, no input injection, no viewer, no JPEG: the binaries need
no display, no Wayland/X11, no compositor.

## Build

```sh
sudo apt install gprbuild gnat libsqlite3-dev
gprbuild -P tedex.gpr -p
```

Produces `server`, `client`, `admin`.

## Run

```sh
# 1. user database (next to the binaries)
./admin add <user> <password>
./admin create-key <user>   # device enrollment key (shown once)

# 2. server
./server -p 9999 --db ./users.db

# 3. device (or install as a service with -r)
./client -s <server> -p <port> [--ws ws[s]://host[:port][/path]] \
  -c <user> <password-or-key> --name <id> [--persist]

# 4. manager console
./client -s <server> -p <port> [--ws ...] -u <user> <password>
> list
> attach <id>
> remove <id>
> quit
```

Raw TCP and WebSocket (`ws://`, `wss://` via an `openssl s_client`
child with hostname verification) are both supported on every leg.
TLS for `wss://` is provided by `openssl` in `PATH`; plain Internet
deployments should terminate TLS in front of the server instead of
relying on it.

## Notes / limits

* Shells are interactive `/bin/bash -i` on a pty; no file transfer,
  no port forwarding, no terminal emulation beyond raw relay.
* Passwords/keys travel on the command line and (with `-r`) land in
  the systemd unit file: prefer enrollment keys for devices.
* Manager sessions have no idle timeout (24 h budget with keepalive);
  device reconnects every 5 s with `--persist`.
