--  Deterministic unit tests for the Attach_Ws display policy, with
--  Tedex_Echo.Common_Prefix/Bracket_Pre as the decision core. Each case
--  feeds an exact (Pending, Msg) pair and asserts (Shown, New_Pending)
--  under the CURRENT relay policy:
--    * K = 0                              -> show Msg whole, keep Pending
--    * full Msg consumed, Pending remains -> silent, Pending advances
--    * Pending fully consumed              -> show remainder, drop Pending
--    * partial on both sides               -> show Msg WHOLE, drop Pending
--      (fail-open: a fresh-output collision is likelier than a delayed
--      echo fragment; eating bytes corrupted displays, duplicating a
--      line does not). Bracket framing (Pre>0) is kept verbatim while
--      the remainder behind it follows the same rules.
with Ada.Strings.Unbounded;
with Ada.Text_IO;
with Tedex_Echo;

procedure Echo_Vectors is
   use Ada.Strings.Unbounded;
   use Ada.Text_IO;

   Failures : Natural := 0;

   function Tail (S : String; N : Natural) return String is
     (if N >= S'Length then "" else S (S'First + N .. S'Last));

   procedure Decide (Pending, Msg : String;
                     Shown, New_Pend : out Unbounded_String)
   is
      Pre  : constant Natural := Tedex_Echo.Bracket_Pre (Msg);
      Head : constant String :=
        (if Pre = 0 then "" else Msg (Msg'First .. Msg'First + Pre - 1));
      R0   : constant String :=
        (if Pre >= Msg'Length then ""
         else Msg (Msg'First + Pre .. Msg'Last));
      Base : constant String := (if Pre = 0 then Msg else R0);
      K    : constant Natural :=
        Tedex_Echo.Common_Prefix (Pending, Base);
      FP   : constant Boolean := K >= Pending'Length;
      FM   : constant Boolean := K >= Base'Length;
   begin
      if K = 0 then
         Shown := To_Unbounded_String (Msg);
         New_Pend := To_Unbounded_String (Pending);
      elsif FM and not FP then
         Shown := Null_Unbounded_String;
         New_Pend := To_Unbounded_String (Tail (Pending, K));
      elsif FP then
         Shown := To_Unbounded_String (Head & Tail (Base, K));
         New_Pend := Null_Unbounded_String;
      else
         Shown := To_Unbounded_String (Msg);
         New_Pend := Null_Unbounded_String;
      end if;
   end Decide;

   procedure Check (Name      : String;
                    Pending   : String;
                    Msg       : String;
                    Exp_Show  : String;
                    Exp_Pend  : String)
   is
      Shown, New_Pend : Unbounded_String;
   begin
      Decide (Pending, Msg, Shown, New_Pend);
      if To_String (Shown) /= Exp_Show
        or To_String (New_Pend) /= Exp_Pend
      then
         Put_Line ("FAIL " & Name & " show=[" & To_String (Shown)
                   & "] pend=[" & To_String (New_Pend) & "]");
         Failures := Failures + 1;
      else
         Put_Line ("ok   " & Name);
      end if;
   end Check;

   ESC : constant Character := Character'Val (27);
   CR  : constant Character := Character'Val (13);
   LF  : constant Character := Character'Val (10);

begin
   --  1. exact typed echo: silent.
   Check ("exact-echo", "ls" & CR & LF, "ls" & CR & LF, "", "");
   --  2. per-keystroke fragments: silent each, advance.
   Check ("frag-1", "ls" & CR & LF, "l", "", "s" & CR & LF);
   Check ("frag-2", "s" & CR & LF, "s" & CR & LF, "", "");
   --  3. echo + glued own output: strip echo, show rest.
   Check ("glued", "ls" & CR & LF, "ls" & CR & LF & "bin",
          "bin", "");
   --  4. THE NIBBLE SHAPE: output colliding with fresh pending
   --  shows whole, belief dropped (never eats bytes).
   Check ("lost+found-collision", "ls" & CR & LF,
          "lost+found mnt", "lost+found mnt", "");
   Check ("lib-collision", "ls" & CR & LF, "lib", "lib", "");
   Check ("sbin-collision", "s" & CR & LF, "sbin", "sbin", "");
   --  5. unrelated bytes: show whole, keep belief.
   Check ("unrelated", "abc", "bin", "bin", "abc");
   --  6. empty inputs never raise, never strip wrongly.
   Check ("empty-msg", "abc", "", "", "abc");
   Check ("empty-pend", "", "abc", "abc", "");
   Check ("empty-both", "", "", "", "");
   --  7. bracket-prefixed echo: framing kept, echo dropped.
   Check ("bracket-echo",
          "ls" & CR & LF,
          ESC & "[?2004h" & "ls" & CR & LF,
          ESC & "[?2004h", "");
   --  8. bracket + CR framing ahead of echo.
   Check ("bracket-cr-echo",
          "ls" & CR & LF,
          ESC & "[?2004l" & CR & "ls" & CR & LF,
          ESC & "[?2004l" & CR, "");
   --  9. bracket + colliding output shows whole (no nibble).
   Check ("bracket-collision",
          "ls" & CR & LF,
          ESC & "[?2004l" & CR & "lost+found",
          ESC & "[?2004l" & CR & "lost+found", "");
   --  10. output line byte-identical to typed echo: silent (accepted
   --  documented edge; the alternative duplicates every keystroke).
   Check ("exact-output-line", "ls", "ls", "", "");

   --  Bracket_Pre unit checks.
   declare
      procedure BC (Name : String; S : String; Exp : Natural) is
         Got : constant Natural := Tedex_Echo.Bracket_Pre (S);
      begin
         if Got /= Exp then
            Put_Line ("FAIL " & Name);
            Failures := Failures + 1;
         else
            Put_Line ("ok   " & Name);
         end if;
      end BC;
   begin
      BC ("bracket-plain", "plain", 0);
      BC ("bracket-8", ESC & "[?2004lrest", 8);
      BC ("bracket-9", ESC & "[?2004l" & CR & "x", 9);
      BC ("bracket-short", ESC & "[?2004", 0);
      BC ("bracket-bare8", ESC & "[?2004h", 0);
   end;

   if Failures = 0 then
      Put_Line ("ECHO_VECTORS ALL PASS");
   else
      Put_Line ("ECHO_VECTORS" & Natural'Image (Failures) & " FAILURES");
   end if;
end Echo_Vectors;
