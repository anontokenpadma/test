--  SHA test vectors: pure-SPARK digests vs the GNAT reference libs.
--  Covers every length 0..512 (SHA-256) and 0..128 (SHA-1) with two
--  patterns each (byte 'a' fill, cycling 0..255), plus the empty input.
--  Exit 0 + "ALL PASS" when every vector matches, else exit 1.
with Ada.Streams;
with Ada.Text_IO;
with GNAT.SHA1;
with GNAT.SHA256;
with Tedex_SHA;
with Tedex_SHA1;

procedure Sha_Vectors is
   use Ada.Text_IO;
   use Ada.Streams;
   Fail : Natural := 0;

   function Ref256 (S : String) return String is
     (GNAT.SHA256.Digest (S));

   function Ref1_Hex (S : String) return String is
      D : constant Stream_Element_Array := GNAT.SHA1.Digest (S);
      H : constant String := "0123456789abcdef";
      R : String (1 .. 40);
   begin
      for I in 1 .. 20 loop
         R (2 * I - 1) :=
           H (Natural (D (Stream_Element_Offset (I))) / 16 + 1);
         R (2 * I) :=
           H (Natural (D (Stream_Element_Offset (I))) mod 16 + 1);
      end loop;
      return R;
   end Ref1_Hex;

   function Ours1_Hex (S : String) return String is
      Raw : constant String := Tedex_SHA1.Digest20 (S);
      H : constant String := "0123456789abcdef";
      R : String (1 .. 40);
   begin
      for I in 1 .. 20 loop
         R (2 * I - 1) :=
           H (Character'Pos (Raw (I)) / 16 + 1);
         R (2 * I) :=
           H (Character'Pos (Raw (I)) mod 16 + 1);
      end loop;
      return R;
   end Ours1_Hex;

begin
   for N in 0 .. 512 loop
      declare
         A : String (1 .. N) := [others => 'a'];
         B : String (1 .. N);
      begin
         for I in 1 .. N loop
            B (I) := Character'Val ((I - 1) mod 256);
         end loop;
         if Tedex_SHA.Digest (A) /= Ref256 (A) then
            Put_Line ("FAIL sha256 fill len" & Integer'Image (N));
            Fail := Fail + 1;
         end if;
         if Tedex_SHA.Digest (B) /= Ref256 (B) then
            Put_Line ("FAIL sha256 cycle len" & Integer'Image (N));
            Fail := Fail + 1;
         end if;
         if N <= 128 then
            if Ours1_Hex (A) /= Ref1_Hex (A) then
               Put_Line ("FAIL sha1 fill len" & Integer'Image (N));
               Fail := Fail + 1;
            end if;
            if Ours1_Hex (B) /= Ref1_Hex (B) then
               Put_Line ("FAIL sha1 cycle len" & Integer'Image (N));
               Fail := Fail + 1;
            end if;
         end if;
      end;
   end loop;
   if Fail = 0 then
      Put_Line ("ALL PASS (sha256 0..512 x2, sha1 0..128 x2)");
   else
      Put_Line ("FAILURES:" & Natural'Image (Fail));
      raise Program_Error with "vectors mismatch";
   end if;
end Sha_Vectors;
