--  Parser fuzz + runtime round-trips (deterministic LCG, seed fixed).
--  Feeds only Pre-satisfying inputs (First = 1, bounded lengths, full
--  0..255 byte alphabet incl. NUL/CR/LF/colon/space) and fails on any
--  escaping exception. Also replays at runtime what SPARK proves
--  statically: Nat_Image/Parse_Count 0..999_999, WS frame round-trips,
--  Xor double-mask restore, handshake accept shape.
with Ada.Text_IO;
with Tedex_B64;
with Tedex_Crypto;
with Tedex_Net_Pure;
with Tedex_Protocol;
with Tedex_Store;
with Tedex_Util;
with Tedex_Ws;

procedure Fuzz_Parsers is
   use Ada.Text_IO;

   Seed : Long_Long_Integer := 16#1234_5678#;
   Fail : Natural := 0;

   function Rnd (M : Positive) return Natural is
   begin
      Seed := (Seed * 1_103_515_245 + 12_345) mod 2_147_483_648;
      return Natural (Seed mod Long_Long_Integer (M));
   end Rnd;

   function RStr (Max : Natural) return String is
      N : constant Natural := Rnd (Max + 1);
      S : String (1 .. N);
   begin
      for I in 1 .. N loop
         S (I) := Character'Val (Rnd (256));
      end loop;
      return S;
   end RStr;

   procedure Check (Cond : Boolean; What : String) is
   begin
      if not Cond then
         Put_Line ("FAIL " & What);
         Fail := Fail + 1;
      end if;
   end Check;

begin
   --  1. Crash-freedom over hostile bytes (20000 cases) --
   for K in 1 .. 20_000 loop
      declare
         L : constant String := RStr (300);
      begin
         declare
            R : Tedex_Protocol.Auth_Request;
         begin
            Tedex_Protocol.Parse_Auth (L, R);
         exception
            when others => Check (False, "Parse_Auth raised");
         end;
         declare
            C : Tedex_Protocol.Manager_Cmd;
            A : String (1 .. Tedex_Protocol.Max_Dev) :=
              [others => ' '];
            AL : Natural;
         begin
            Tedex_Protocol.Parse_Command (L, C, A, AL);
         exception
            when others => Check (False, "Parse_Command raised");
         end;
         declare
            Cc, Rr : Natural;
         begin
            Tedex_Protocol.Parse_Start_Dims (L, Cc, Rr);
         exception
            when others => Check (False, "Parse_Start_Dims raised");
         end;
         declare
            D : String (1 .. Tedex_Protocol.Max_Dev) :=
              [others => ' '];
            DL, Cl, Rw : Natural;
            Ok : Boolean;
         begin
            Tedex_Protocol.Parse_Resize (L, D, DL, Cl, Rw, Ok);
         exception
            when others => Check (False, "Parse_Resize raised");
         end;
         Check (Tedex_Protocol.Valid_Token (L)
                = Tedex_Protocol.Valid_Token (L), "token pure");
         Check (Tedex_Crypto.Valid_Password (L)
                = Tedex_Crypto.Valid_Password (L), "pass pure");
         if L'Length <= Tedex_Store.Max_Account_Line then
            declare
               Acc : Tedex_Store.Account;
               Ok : Boolean;
            begin
               Tedex_Store.Parse_Account_Line (L, Acc, Ok);
            exception
               when others => Check (False, "Parse_Account raised");
            end;
         end if;
         if L'Length <= Tedex_Crypto.Stored_Len then
            declare
               S : Tedex_Crypto.Salt_String := [others => ' '];
               H : Tedex_Crypto.Hash_String := [others => ' '];
               Ok : Boolean;
            begin
               Tedex_Crypto.Split_Stored (L, S, H, Ok);
            exception
               when others => Check (False, "Split_Stored raised");
            end;
         end if;
         declare
            Secure : Boolean;
            H : String (1 .. Tedex_Util.Max_Host) := [others => ' '];
            HL, PL : Natural;
            Port : Natural;
            P : String (1 .. Tedex_Util.Max_Path) := [others => ' '];
            Ok : Boolean;
         begin
            Tedex_Util.Parse_Ws_Url (L, Secure, H, HL, Port, P, PL, Ok);
         exception
            when others => Check (False, "Parse_Ws_Url raised");
         end;
         if L'Length <= Tedex_Util.Max_Cmd then
            declare
               V : String (1 .. Tedex_Util.Max_Cmd) := [others => ' '];
               G : String (1 .. Tedex_Util.Max_Cmd) := [others => ' '];
               VL, GL : Natural;
            begin
               Tedex_Util.Split_Verb (L, V, VL, G, GL);
            exception
               when others => Check (False, "Split_Verb raised");
            end;
         end if;
         if L'Length <= Tedex_Util.Max_Trim then
            declare
               R : constant Tedex_Util.Hs_Outcome :=
                 Tedex_Util.Check_Handshake
                   (L, "s3pPLMBiTxaQ9kYGzzhZRbK+xOo=Y2o=");
               pragma Unreferenced (R);
            begin
               null;
            exception
               when others => Check (False, "Check_Handshake raised");
            end;
         end if;
         if L'Last <= Tedex_Net_Pure.Max_Hdr then
            declare
               F, T, Np : Natural;
            begin
               Tedex_Net_Pure.Next_Line_Bounds (L, 1, F, T, Np);
            exception
               when others => Check (False, "Next_Line_Bounds raised");
            end;
            declare
               Nm : String (1 .. L'Last) := [others => ' '];
               Val_S : String (1 .. L'Last) := [others => ' '];
               NLen, VLen : Natural;
               Hc : Boolean;
            begin
               Tedex_Net_Pure.Header_Parts (L, Nm, NLen, Val_S, VLen, Hc);
            exception
               when others => Check (False, "Header_Parts raised");
            end;
            if L'Last >= 4 then
               declare
                  P : String (1 .. L'Last) := [others => '/'];
                  PL : Natural;
               begin
                  Tedex_Net_Pure.Request_Path (L, P, PL);
               exception
                  when others => Check (False, "Request_Path raised");
               end;
            end if;
         end if;
         if L'First = 1 and L'Length <= Tedex_Protocol.Max_Line then
            declare
               Id : String (1 .. Tedex_Protocol.Max_Line) := [others => ' '];
               IL : Natural;
               St : Tedex_Protocol.Device_Status;
               Info : String (1 .. Tedex_Protocol.Max_Line) := [others => ' '];
               InfoL : Natural;
               Ok : Boolean;
            begin
               Tedex_Protocol.Parse_Device_Line (L, Id, IL, St, Info, InfoL, Ok);
               if Ok then
                  Check (Id (1 .. IL)'Length = IL, "Device_Line Id length");
                  Check (Info (1 .. InfoL)'Length = InfoL, "Device_Line Info length");
                  Check ("DEVICE " & Id (1 .. IL) & " "
                         & Tedex_Protocol.Status_Image (St) & " "
                         & Info (1 .. InfoL) = L, "Device_Line roundtrip");
               end if;
            exception
               when others => Check (False, "Parse_Device_Line raised");
            end;
         end if;
      end;
   end loop;

   --  2. Full Nat round-trip 0..999_999 --
   for N in 0 .. 999_999 loop
      if Tedex_Util.Parse_Count (Tedex_Protocol.Nat_Image (N)) /= N then
         Check (False, "nat roundtrip" & Integer'Image (N));
         exit;
      end if;
   end loop;

   --  3. WS frame round-trips (short + extended) --
   declare
      Lens : constant array (1 .. 8) of Natural :=
        [1, 2, 125, 126, 127, 200, 1_000, 32_768];
   begin
   for N of Lens loop
      declare
         Pay : String (1 .. N) := [others => 'x'];
         Buf : String (1 .. 10 + Tedex_Ws.Max_Frame_Payload) :=
           [others => ASCII.NUL];
         FL : Natural;
         H : Tedex_Ws.Frame_Header;
         Ok : Boolean;
         Need : constant Natural := (if N < 126 then 2 else 4);
      begin
         Tedex_Ws.Encode_Frame (Pay, 2, Buf, FL);
         Check (FL = N + Need, "frame len" & Integer'Image (N));
         Tedex_Ws.Decode_Header
           (Buf (1 .. Need), H, Ok, Require_Mask => False);
         Check (Ok and H.Pay_Len = N and H.Opcode = 2 and H.Fin
                and H.Hdr_Len = Need, "frame decode" & Integer'Image (N));
      exception
         when others => Check (False, "frame raised" & Integer'Image (N));
      end;
   end loop;
   end;

   --  4. Xor double-mask restore on hostile bytes --
   for K in 1 .. 2_000 loop
      declare
         N : constant Positive := Rnd (200) + 1;
         D : String (1 .. N);
         E : constant String (1 .. 4) :=
           [Character'Val (Rnd (256)), Character'Val (Rnd (256)),
            Character'Val (Rnd (256)), Character'Val (Rnd (256))];
         Orig : String (1 .. N);
      begin
         for I in 1 .. N loop
            D (I) := Character'Val (Rnd (256));
         end loop;
         Orig := D;
         Tedex_Ws.Xor_Mask (D, E);
         Tedex_Ws.Xor_Mask (D, E);
         Check (D = Orig, "xor restore");
      exception
         when others => Check (False, "xor raised");
      end;
   end loop;

   --  5. B64 accept-key shape + hex nibble shape --
   for K in 1 .. 1_000 loop
      declare
         Raw : String (1 .. 16);
      begin
         for I in Raw'Range loop
            Raw (I) := Character'Val (Rnd (256));
         end loop;
         Check (Tedex_B64.Encode (Raw)'Length = 24, "b64 len");
      exception
         when others => Check (False, "b64 raised");
      end;
   end loop;

   if Fail = 0 then
      Put_Line ("ALL PASS (fuzz 20k + nat 1M + ws + xor 2k + b64 1k)");
   else
      Put_Line ("FAILURES:" & Natural'Image (Fail));
      raise Program_Error with "fuzz mismatch";
   end if;
end Fuzz_Parsers;
