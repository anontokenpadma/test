package body Tedex_Echo with SPARK_Mode => Off is

   function Common_Prefix (Pending, Msg : String) return Natural is
      K : Natural := 0;
   begin
      while K < Pending'Length and then K < Msg'Length
        and then Pending (Pending'First + K) = Msg (Msg'First + K)
      loop
         K := K + 1;
      end loop;
      return K;
   end Common_Prefix;

   function Bracket_Pre (Msg : String) return Natural is
      B1 : constant String :=
        [Character'Val (27), '[', '?', '2', '0', '0', '4', 'l'];
      B2 : constant String :=
        [Character'Val (27), '[', '?', '2', '0', '0', '4', 'h'];
   begin
      if Msg'Length > 8
        and then (Msg (Msg'First .. Msg'First + 7) = B1
                  or Msg (Msg'First .. Msg'First + 7) = B2)
      then
         --  Readline redraws as brackets+CR ahead of the echo
         --  itself; that CR is framing, not echoed input.
         if Msg (Msg'First + 8) = Character'Val (13) then
            return 9;
         end if;
         return 8;
      end if;
      return 0;
   end Bracket_Pre;

end Tedex_Echo;
