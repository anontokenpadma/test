--  WebSocket framing per RFC 6455 (server side of the handshake,
--  unmasked server frames, masked client frames). Fully in SPARK.
package Tedex_Ws with SPARK_Mode is

   Ws_Guid : constant String := "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

   Max_Key_In : constant := 64;

   --  Sec-WebSocket-Accept value for a client key. Always 28 chars.
   --  Boundary obligation: caller must normalize Client_Key to First = 1.
   function Accept_Key (Client_Key : String) return String
     with Pre  => Client_Key'First = 1
                  and Client_Key'Length in 1 .. Max_Key_In,
          Post => Accept_Key'Result'Length = 28
                  and Accept_Key'Result'First = 1,
          Global => null,
          Depends => (Accept_Key'Result => Client_Key);

   Max_Frame_Payload : constant := 32_768;

   --  Encode one server->client frame (never masked).
   --  Opcode: 2 = binary, 8 = close, 9 = ping, 10 = pong; 0 = continuation.
   procedure Encode_Frame (Payload : String;
                           Opcode  : Natural;
                           Frame   : out String;
                           Frame_Len : out Natural;
                           Fin     : Boolean := True)
     with Pre  => Payload'First = 1 and Payload'Length <= Max_Frame_Payload
                  and (Opcode in 0 .. 2 or Opcode in 8 .. 10)
                  and Frame'First = 1
                  and Frame'Length >= 10 + Max_Frame_Payload,
          Post => Frame_Len = Payload'Length
                    + (if Payload'Length < 126 then 2 else 4)
                  and Frame (1) =
                    Character'Val ((if Fin then 128 else 0) + Opcode)
                  and (if Payload'Length < 126 then
                         Frame (2) = Character'Val (Payload'Length)
                       else
                         Frame (2) = Character'Val (126)
                         and Frame (3) =
                           Character'Val (Payload'Length / 256)
                         and Frame (4) =
                           Character'Val (Payload'Length mod 256))
                  and Frame (Frame_Len - Payload'Length + 1 .. Frame_Len)
                    = Payload,
          Global => null,
          Depends => (Frame =>+ (Payload, Opcode, Fin),
                      Frame_Len => Payload);

   --  Encode one client->server frame (masked, as RFC 6455 requires).
   --  Mask is a fresh 4-byte key chosen by the caller.
   procedure Encode_Client_Frame (Payload : String;
                                  Opcode  : Natural;
                                  Mask    : String;
                                  Frame   : out String;
                                  Frame_Len : out Natural;
                                  Fin     : Boolean := True)
     with Pre  => Payload'First = 1 and Payload'Length <= Max_Frame_Payload
                  and (Opcode in 0 .. 2 or Opcode in 8 .. 10)
                  and Mask'First = 1 and Mask'Length = 4
                  and Frame'First = 1
                  and Frame'Length >= 14 + Max_Frame_Payload,
          Post => Frame_Len = Payload'Length
                    + (if Payload'Length < 126 then 6 else 8),
          Global => null,
          Depends => (Frame =>+ (Payload, Opcode, Mask, Fin),
                      Frame_Len => Payload);

   Msg_Cap : constant := 1_000_000;

   type Frame_Header is record
      Fin     : Boolean := False;
      Opcode  : Natural range 0 .. 15 := 0;
      Pay_Len : Natural range 0 .. Msg_Cap := 0;
      Hdr_Len : Natural range 2 .. 14 := 2;
   end record;

   --  Validate one frame header.
   --  Require_Mask=True validates client->server headers (mask REQUIRED);
   --  False validates server->client headers (mask FORBIDDEN).
   --  Data holds exactly the header bytes (2 + ext-length + mask-if-any).
   --  The Ok post mirrors the body decision point-for-point, so an
   --  encoded header decodes back to its length (see Roundtrip below);
   --  the 8-byte branch only promises the Msg_Cap bound (enough for the
   --  cap check, avoids a nonlinear 64-bit sum identity).
   --  Completeness (Ok = guards) is stated for the short and 16-bit
   --  branches only: callers with an agreed header shape derive Ok=True
   --  instead of merely "if Ok then fields". The 8-byte branch stays
   --  soundness-only (early prefix exits have no closed-form sum here).
   procedure Decode_Header (Data : String;
                            H    : out Frame_Header;
                            Ok   : out Boolean;
                            Require_Mask : Boolean := True)
     with Pre => Data'First = 1 and Data'Length in 2 .. 14,
          Post => (if Ok then
                     H.Hdr_Len = Data'Length
                     and H.Fin =
                       (Character'Pos (Data (1)) >= 128)
                     and H.Opcode =
                       (Character'Pos (Data (1)) mod 16)
                     and ((Character'Pos (Data (1)) / 16) mod 8) = 0
                     and (H.Opcode = 0 or H.Opcode = 1 or H.Opcode = 2
                          or H.Opcode = 8 or H.Opcode = 9
                          or H.Opcode = 10)
                     and ((Character'Pos (Data (2)) >= 128)
                          = Require_Mask)
                     and Data'Length = 2
                       + (if (Character'Pos (Data (2)) mod 128) < 126
                          then 0
                          elsif (Character'Pos (Data (2)) mod 128) = 126
                          then 2
                          else 8)
                       + (if Require_Mask then 4 else 0)
                     and (if (Character'Pos (Data (2)) mod 128) < 126 then
                            H.Pay_Len =
                              (Character'Pos (Data (2)) mod 128)
                          elsif (Character'Pos (Data (2)) mod 128) = 126 then
                            H.Pay_Len =
                              Character'Pos (Data (3)) * 256
                              + Character'Pos (Data (4))
                          else
                            H.Pay_Len <= Msg_Cap)
                     and (if H.Opcode >= 8 then
                            H.Fin and H.Pay_Len <= 125))
                  and (if (Character'Pos (Data (2)) mod 128) < 126 then
                         (Ok = (((((Character'Pos (Data (1)) / 16) mod 8)
                                 = 0)
                                and (Character'Pos (Data (1)) mod 16 = 0
                                     or Character'Pos (Data (1)) mod 16 = 1
                                     or Character'Pos (Data (1)) mod 16 = 2
                                     or Character'Pos (Data (1)) mod 16 = 8
                                     or Character'Pos (Data (1)) mod 16 = 9
                                     or Character'Pos (Data (1)) mod 16
                                       = 10)
                                and ((Character'Pos (Data (2)) >= 128)
                                     = Require_Mask)
                                and (Data'Length = 2
                                     + (if Require_Mask then 4 else 0)))
                               and then
                                 (if (Character'Pos (Data (1)) mod 16)
                                     >= 8
                                  then
                                    (Character'Pos (Data (1)) >= 128)
                                    and (Character'Pos (Data (2))
                                         mod 128) <= 125
                                  else True)))
                       elsif (Character'Pos (Data (2)) mod 128) = 126 then
                         (Ok = (((((Character'Pos (Data (1)) / 16) mod 8)
                                 = 0)
                                and (Character'Pos (Data (1)) mod 16 = 0
                                     or Character'Pos (Data (1)) mod 16 = 1
                                     or Character'Pos (Data (1)) mod 16 = 2
                                     or Character'Pos (Data (1)) mod 16 = 8
                                     or Character'Pos (Data (1)) mod 16 = 9
                                     or Character'Pos (Data (1)) mod 16
                                       = 10)
                                and ((Character'Pos (Data (2)) >= 128)
                                     = Require_Mask)
                                and (Data'Length = 4
                                     + (if Require_Mask then 4 else 0)))
                               and then
                                 (if (Character'Pos (Data (1)) mod 16)
                                     >= 8
                                  then
                                    (Character'Pos (Data (1)) >= 128)
                                    and Character'Pos (Data (3)) * 256
                                      + Character'Pos (Data (4)) <= 125
                                  else True)))
                       else True),
          Global => null,
          Depends => ((H, Ok) => (Data, Require_Mask));

   --  Encode/decode round-trip on short and extended headers (ghost).
   --  Exercises (N / 256) * 256 + (N mod 256) = N: Colibri2 interval
   --  propagation plus Z3/CVC5 div-mod lemmas in the portfolio.
   procedure Frame_Header_Roundtrip (Payload : String; Opcode : Natural)
     with Ghost,
          Pre  => Payload'First = 1 and Payload'Length in 1 .. 1_000
                  and Opcode in 1 .. 2,
          Global => null;

   --  Remove the client mask in place. Mask is the 4-byte masking key.
   procedure Xor_Mask (Data : in out String; Mask : String)
     with Pre  => Data'First = 1 and Mask'First = 1 and Mask'Length = 4,
          Post => Data'First = 1 and Data'Length = Data'Old'Length
                  and (for all I in Data'Range =>
                         Data (I) = Masked_Byte
                           (Data'Old (I), Mask, I - Data'First + 1)),
          Global => null,
          Depends => (Data => (Data, Mask));

   --  Colibri2 showcase: BV xor at high level (no bit-blasting).
   --  Alt-Ergo solo level 1 leaves Xor_Involution unproved (0/1);
   --  the 4-prover portfolio at level 4 discharges it (colibri2 credit).
   type U8 is mod 256;
   function Xor_Twice (X, M : U8) return U8
     with Post => Xor_Twice'Result = ((X xor M) xor M),
          Global => null;
   function Xor_Holds (X, M : U8) return Boolean
     with Post => Xor_Holds'Result = (((X xor M) xor M) = X),
          Global => null;

   --  Byte function behind Xor_Mask, so the mask removal carries a
   --  value contract (was Depends-only): Colibri2 propagates the
   --  mod-4 mask index through intervals, DPLL(T) solvers case-split.
   function Masked_Byte (C : Character; Mask : String; I : Positive)
     return Character
     with Pre  => Mask'First = 1 and Mask'Length = 4,
          Post => Character'Pos (Masked_Byte'Result) =
                  Natural (U8 (Character'Pos (C))
                           xor U8 (Character'Pos
                                     (Mask (((I - 1) mod 4) + 1)))),
          Global => null;

   --  Double masking restores the input (RFC 6455 mask involution on
   --  whole strings, via Masked_Byte + Xor_Holds). Ghost: proof only.
   procedure Xor_Twice_Restores (Data : in out String; Mask : String)
     with Ghost,
          Pre  => Data'First = 1 and Mask'First = 1 and Mask'Length = 4,
          Post => Data = Data'Old,
          Global => null,
          Depends => (Data => (Data, Mask));

end Tedex_Ws;
