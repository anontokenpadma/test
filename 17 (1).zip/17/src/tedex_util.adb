package body Tedex_Util with SPARK_Mode is

   function Fold_Char (C : Character) return Character is
   begin
      if C in 'A' .. 'Z' then
         return Character'Val (Character'Pos (C) + 32);
      else
         return C;
      end if;
   end Fold_Char;

   procedure To_Lower (S : in out String) is
   begin
      for I in S'Range loop
         pragma Loop_Invariant
           (for all J in S'First .. I - 1 =>
              S (J) = Fold_Char (S'Loop_Entry (J)));
         S (I) := Fold_Char (S (I));
      end loop;
   end To_Lower;

   function Folded_Equal (A, B : String) return Boolean is
   begin
      if A'Length /= B'Length then
         return False;
      end if;
      for I in 0 .. A'Length - 1 loop
         pragma Loop_Invariant
           (for all K in 0 .. I - 1 =>
              Fold_Char (A (A'First + K)) =
              Fold_Char (B (B'First + K)));
         if Fold_Char (A (A'First + I)) /=
            Fold_Char (B (B'First + I))
         then
            return False;
         end if;
      end loop;
      return True;
   end Folded_Equal;

   --  Two sets, matching the historical copies exactly: leading
   --  strips only space/HT (Net Trimmed, Client Trim_Copy), trailing
   --  also strips CR/LF. (Manager Stripped additionally stripped a
   --  leading CR; that path is covered by Split_Verb below, which
   --  keeps Stripped''s exact set.)
   function Is_Lead_Blank (C : Character) return Boolean is
     (C = ' ' or C = ASCII.HT)
   with Global => null,
        Depends => (Is_Lead_Blank'Result => C);

   function Is_Trail_Blank (C : Character) return Boolean is
     (C = ' ' or C = ASCII.HT or C = ASCII.CR or C = ASCII.LF)
   with Global => null,
        Depends => (Is_Trail_Blank'Result => C);

   function Trim_Blanks (S : String) return String is
      --  Offset form (no S''First/S''Last +/- 1 in invariants: those can
      --  overflow Integer when a slice sits at the type bounds).
      N  : constant Natural := S'Length;
      Lo : Natural := 0;
      Hi : Natural := 0;
   begin
      while Lo < N and then Is_Lead_Blank (S (S'First + Lo)) loop
         pragma Loop_Invariant (Lo in 0 .. N);
         pragma Loop_Variant (Decreases => N - Lo);
         Lo := Lo + 1;
      end loop;
      while Lo + Hi < N and then Is_Trail_Blank (S (S'Last - Hi)) loop
         pragma Loop_Invariant (Hi in 0 .. N - Lo);
         pragma Loop_Variant (Decreases => N - Lo - Hi);
         Hi := Hi + 1;
      end loop;
      if Lo + Hi >= N then
         return "";
      end if;
      declare
         Len : constant Natural := N - Lo - Hi;
         R : String (1 .. Len);
      begin
         R := S (S'First + Lo .. S'Last - Hi);
         return R;
      end;
   end Trim_Blanks;

   function Encode_Hex (Data : String) return String is
      HexD : constant String (1 .. 16) := "0123456789abcdef";
      N    : constant Natural := Data'Length;
      Outp : String (1 .. 2 * Max_Hex_In) := [others => '0'];
      O    : Natural range 0 .. 2 * Max_Hex_In := 0;
   begin
      for I in 1 .. N loop
         pragma Loop_Invariant (O = 2 * (I - 1));
         pragma Loop_Invariant
           (for all K in 1 .. O =>
              Outp (K) in '0' .. '9' or Outp (K) in 'a' .. 'f');
         declare
            V : constant Natural := Character'Pos (Data (I));
         begin
            Outp (O + 1) := HexD (V / 16 + 1);
            Outp (O + 2) := HexD (V mod 16 + 1);
            O := O + 2;
         end;
      end loop;
      return Outp (1 .. O);
   end Encode_Hex;

   function Parse_Count (S : String) return Natural is
      V : Natural := 0;
   begin
      if S'Length = 0 or else S'Length > 6 then
         return 0;
      end if;
      for C of S loop
         pragma Loop_Invariant (V <= 999_999);
         if C not in '0' .. '9' then
            return 0;
         end if;
         V := V * 10 + (Character'Pos (C) - Character'Pos ('0'));
         if V > 999_999 then
            return 0;
         end if;
      end loop;
      return V;
   end Parse_Count;

   procedure Parse_Ws_Url (Url       : String;
                           Secure    : out Boolean;
                           WHost     : out String;
                           WHost_Len : out Natural;
                           WPort     : out Natural;
                           WPath     : out String;
                           WPath_Len : out Natural;
                           Ok        : out Boolean) is
      Rest  : Integer;
      Slash : Integer;
      Colon : Integer;
      --  Validated into locals first; outputs are written once, at the
      --  single commit point at the end (postcondition needs zeroed
      --  outputs on every failure path).
      HL       : Integer;
      Port_Loc : Natural;
      PL       : Integer;
   begin
      Secure    := False;
      WHost     := [others => ' '];
      WHost_Len := 0;
      WPort     := 0;
      WPath     := [others => ' '];
      WPath_Len := 0;
      Ok        := False;
      if Url'Length > 5 and then Url (1 .. 5) = "ws://" then
         Rest := 6;
      elsif Url'Length > 6 and then Url (1 .. 6) = "wss://" then
         Secure := True;
         Rest := 7;
      else
         return;
      end if;
      Slash := Rest;
      Colon := 0;
      while Slash <= Url'Last and then Url (Slash) /= '/' loop
         pragma Loop_Invariant (Slash in Rest .. Url'Last + 1);
         pragma Loop_Invariant (Colon = 0
                                or Colon in Rest .. Slash - 1);
         pragma Loop_Variant (Decreases => Url'Last - Slash + 1);
         if Url (Slash) = ':' and then Colon = 0 then
            Colon := Slash;
         end if;
         Slash := Slash + 1;
      end loop;
      --  Explicit exit bound for the port-field scans below: without it
      --  the P1/P2 index checks time out (the bound is otherwise buried
      --  two loop-exits deep for the solvers' heuristics).
      pragma Assert (Slash <= Url'Last + 1);
      if Colon = 0 then
         HL := Slash - Rest;
         if HL not in 1 .. Max_Host then
            return;
         end if;
         Port_Loc := (if Secure then 443 else 80);
      else
         declare
            P1 : Integer := Colon + 1;
            P2 : Integer := Slash - 1;
            V  : Natural := 0;
         begin
            HL := Colon - Rest;
            if HL not in 1 .. Max_Host then
               return;
            end if;
            while P1 <= P2
              and then (Url (P1) = ' ' or Url (P1) = ASCII.HT)
            loop
               pragma Loop_Invariant (P1 in Colon + 1 .. P2 + 1);
               pragma Loop_Invariant (P1 <= Slash);
               pragma Loop_Variant (Decreases => P2 - P1 + 1);
               P1 := P1 + 1;
            end loop;
            while P2 >= P1
              and then (Url (P2) = ' ' or Url (P2) = ASCII.HT)
            loop
               pragma Loop_Invariant (P2 in P1 - 1 .. Slash - 1);
               pragma Loop_Invariant (P2 <= Slash - 1);
               pragma Loop_Variant (Decreases => P2 - P1 + 1);
               P2 := P2 - 1;
            end loop;
            if P1 > P2 then
               return;  --  empty port field
            end if;
            if Url (P1) = '+' then
               P1 := P1 + 1;
               if P1 > P2 then
                  return;
               end if;
            end if;
            for I in P1 .. P2 loop
               pragma Loop_Invariant (V <= 65_535);
               declare
                  C : constant Character := Url (I);
                  D : Natural;
               begin
                  if C not in '0' .. '9' then
                     return;
                  end if;
                  D := Character'Pos (C) - Character'Pos ('0');
                  if V > 6_553 then
                     return;
                  end if;
                  V := V * 10 + D;
                  if V > 65_535 then
                     return;
                  end if;
               end;
            end loop;
            if V not in 1 .. 65_535 then
               return;
            end if;
            Port_Loc := V;
         end;
      end if;
      if Slash > Url'Last then
         PL := 6;
      else
         PL := Url'Last - Slash + 1;
         if PL not in 1 .. Max_Path then
            return;
         end if;
      end if;
      --  Single commit point: every failure path above returns with the
      --  zeroed outputs untouched, so the postcondition holds.
      WHost (1 .. HL) := Url (Rest .. Rest + HL - 1);
      WHost_Len := HL;
      WPort := Port_Loc;
      if Slash > Url'Last then
         WPath (1 .. 6) := "/tedex";
      else
         WPath (1 .. PL) := Url (Slash .. Url'Last);
      end if;
      WPath_Len := PL;
      Ok := True;
   end Parse_Ws_Url;

   procedure Split_Verb (Cmd      : String;
                         Verb     : out String;
                         Verb_Len : out Natural;
                         Arg      : out String;
                         Arg_Len  : out Natural) is
      Sp : Integer := 1;
      A  : Integer;
      B  : Integer;
   begin
      Verb := [others => ' '];
      Arg := [others => ' '];
      Arg_Len := 0;
      while Sp <= Cmd'Last
        and then Cmd (Sp) /= ' ' and then Cmd (Sp) /= ASCII.HT
      loop
         pragma Loop_Invariant (Sp in 1 .. Cmd'Last + 1);
         pragma Loop_Variant (Decreases => Cmd'Last - Sp + 1);
         Sp := Sp + 1;
      end loop;
      Verb_Len := Sp - 1;
      for I in 1 .. Verb_Len loop
         pragma Loop_Invariant (I in 1 .. Verb_Len + 1);
         pragma Loop_Invariant
           (for all J in 1 .. I - 1 => Verb (J) not in 'A' .. 'Z');
         Verb (I) := Fold_Char (Cmd (I));
      end loop;
      if Sp > Cmd'Last then
         return;
      end if;
      A := Sp + 1;
      B := Cmd'Last;
      while A <= Cmd'Last
        and then (Cmd (A) = ' ' or Cmd (A) = ASCII.HT
                  or Cmd (A) = ASCII.CR)
      loop
         pragma Loop_Invariant (A in Sp + 1 .. Cmd'Last + 1);
         pragma Loop_Variant (Decreases => Cmd'Last - A + 1);
         A := A + 1;
      end loop;
      while B >= A
        and then (Cmd (B) = ' ' or Cmd (B) = ASCII.HT
                  or Cmd (B) = ASCII.CR)
      loop
         pragma Loop_Invariant (B in A - 1 .. Cmd'Last);
         pragma Loop_Invariant (B <= Cmd'Last);
         pragma Loop_Variant (Decreases => B - A + 1);
         B := B - 1;
      end loop;
      if A > B then
         return;
      end if;
      Arg_Len := B - A + 1;
      Arg (1 .. Arg_Len) := Cmd (A .. B);
   end Split_Verb;

   function Check_Handshake (Resp, Want : String) return Hs_Outcome is
      Pos : Integer := 1;
   begin
      if Resp'Length < 12
        or else (Resp (1 .. 12) /= "HTTP/1.1 101"
                 and then Resp (1 .. 12) /= "HTTP/1.0 101")
      then
         return Hs_Bad_Status;
      end if;
      while Pos <= Resp'Last loop
         pragma Loop_Invariant (Pos in 1 .. Resp'Last + 2);
         pragma Loop_Variant (Decreases => Resp'Last - Pos);
         declare
            Eol : Integer := Pos;
            Col : Integer := Pos;
         begin
            while Eol <= Resp'Last and then Resp (Eol) /= ASCII.LF loop
               pragma Loop_Invariant (Eol in Pos .. Resp'Last + 1);
               pragma Loop_Variant (Decreases => Resp'Last - Eol);
               Eol := Eol + 1;
            end loop;
            while Col < Eol and then Resp (Col) /= ':' loop
               pragma Loop_Invariant (Col in Pos .. Eol);
               pragma Loop_Variant (Decreases => Eol - Col);
               Col := Col + 1;
            end loop;
            if Col < Eol then
               if Folded_Equal (Trim_Blanks (Resp (Pos .. Col - 1)),
                                "sec-websocket-accept")
                 and then Trim_Blanks (Resp (Col + 1 .. Eol - 1)) = Want
               then
                  return Hs_Ok;
               end if;
            end if;
            Pos := Eol + 1;
         end;
      end loop;
      return Hs_Bad_Key;
   end Check_Handshake;

   procedure Hs_Verdict (Res : Hs_Outcome; Act : out Hs_Action) is
   begin
      case Res is
         when Hs_Ok =>
            Act := Act_Accept;
         when Hs_Bad_Status =>
            Act := Act_Reject_Status;
         when Hs_Bad_Key =>
            Act := Act_Reject_Key;
      end case;
   end Hs_Verdict;

   procedure Ws_Url_Head (Url : String;
                          Buf : out String; Len : out Natural;
                          Ok  : out Boolean) is
   begin
      Buf := [others => ' '];
      Len := 0;
      Ok := False;
      if Url'First /= 1 or else Url'Length > Max_Url then
         return;
      end if;
      Len := Url'Length;
      if Len > 0 then
         Buf (1 .. Len) := Url;
      end if;
      Ok := True;
   end Ws_Url_Head;

   procedure Auth_Verdict (Pass_Ok, Is_Device, Key_Ok, Disabled : Boolean;
                           Allow   : out Boolean;
                           Reason  : out Auth_Deny) is
   begin
      if not (Pass_Ok or (Is_Device and Key_Ok)) then
         Allow := False;
         Reason := Deny_Bad_Password;
      elsif Disabled then
         Allow := False;
         Reason := Deny_Stopped;
      else
         Allow := True;
         Reason := Deny_None;
      end if;
   end Auth_Verdict;

   function Jittered_Backoff (Failures, Rand_Byte : Natural) return Natural is
   begin
      return Tedex_Protocol.Backoff_Secs (Failures) + (Rand_Byte mod 6);
   end Jittered_Backoff;

   function Should_Forward_Resize (Pend_Dev, A : String;
                                   Cols, Rows : Natural) return Boolean is
   begin
      return Pend_Dev'Length in 1 .. Tedex_Protocol.Max_Dev
        and then Pend_Dev = A
        and then Cols in 1 .. 1000 and then Rows in 1 .. 1000;
   end Should_Forward_Resize;

   function Tail_Blank (S : String) return Boolean is
   begin
      if S'Length < 4 then
         return False;
      end if;
      return S (S'Last - 3) = ASCII.CR
        and then S (S'Last - 2) = ASCII.LF
        and then S (S'Last - 1) = ASCII.CR
        and then S (S'Last) = ASCII.LF;
   end Tail_Blank;

   function Is_Predict_Byte (B : Character) return Boolean is
     (Character'Pos (B) >= 32
      and Character'Pos (B) /= 127
      and B /= ASCII.ESC);

   function Has_Newline (S : String) return Boolean is
   begin
      for I in S'Range loop
         pragma Loop_Invariant
           (for all J in S'First .. I - 1 =>
              S (J) /= ASCII.CR and S (J) /= ASCII.LF);
         if S (I) = ASCII.CR or S (I) = ASCII.LF then
            return True;
         end if;
      end loop;
      return False;
   end Has_Newline;

   function Low_Contains (Haystack, Needle : String) return Boolean is
   begin
      if Needle'Length = 0
        or else Haystack'Length < Needle'Length
      then
         return False;
      end if;
      for I in 0 .. Haystack'Length - Needle'Length loop
         declare
            Hit : Boolean := True;
         begin
            for J in 0 .. Needle'Length - 1 loop
               if Fold_Char (Haystack (Haystack'First + I + J)) /=
                  Fold_Char (Needle (Needle'First + J))
               then
                  Hit := False;
                  exit;
               end if;
            end loop;
            if Hit then
               return True;
            end if;
         end;
      end loop;
      return False;
   end Low_Contains;

   function Service_Unit_Name (Dev : String) return String is
     ("tedex-" & Dev & ".service");

   function Nat_Parse_Roundtrip (N : Natural) return Boolean is
     (Parse_Count (Tedex_Protocol.Nat_Image (N)) = N);

   procedure Poll_Slice (Rc : Integer; Buf_Last : Natural;
                         Lo : out Natural; Hi : out Natural;
                         Oc : out Poll_Outcome) is
      pragma Unreferenced (Buf_Last);
      --  Buf_Last only bounds the contract (caller slice safety); the
      --  classification itself reads Rc alone.
   begin
      if Rc > 0 then
         Oc := Outcome_Data;
         Lo := 1;
         Hi := Rc;
      elsif Rc = 0 then
         Oc := Outcome_Empty;
         Lo := 0;
         Hi := 0;
      else
         Oc := Outcome_Closed;
         Lo := 0;
         Hi := 0;
      end if;
   end Poll_Slice;

end Tedex_Util;
