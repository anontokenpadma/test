--  tedex admin: manage accounts in the shared users.db.
--  Usage: ./admin add user password | passwd user newpassword
--         ./admin stop user | start user | remove user | limit user 10
--         ./admin list | create-key user | change-key user
--  Device keys let a device register without knowing the account
--  password: ./client -c user KEY ...  The key is printed once.
with Ada.Command_Line;
with Ada.Directories;
with Ada.Streams;
with Ada.Streams.Stream_IO;
with Ada.Strings.Unbounded;
with Ada.Text_IO;

with Tedex_Crypto;
with Tedex_DB;
with Tedex_Protocol;
with Tedex_Store;
with Tedex_Util;

--  Boundary main, not in SPARK (filesystem, OS exit codes);
--  account parsing/hashing delegated to proved SPARK units.
procedure Admin with SPARK_Mode => Off is

   use Ada.Text_IO;
   use Ada.Strings.Unbounded;

   DB_Path : Unbounded_String;

   function Default_DB return String is
   begin
      return Ada.Directories.Compose
        (Ada.Directories.Containing_Directory
           (Ada.Command_Line.Command_Name),
         "users.db");
   end Default_DB;

   function Valid_Name (S : String) return Boolean is
   begin
      return Tedex_Protocol.Valid_Token (S);
   end Valid_Name;

   function Valid_Pass (S : String) return Boolean is
   begin
      return Tedex_Crypto.Valid_Password (S);
   end Valid_Pass;

   function Random_Hex (Bytes : Positive) return String is
      use Ada.Streams;
      use Ada.Streams.Stream_IO;
      F    : Ada.Streams.Stream_IO.File_Type;
      Buf  : Stream_Element_Array (1 .. Stream_Element_Offset (Bytes));
      Last : Stream_Element_Offset;
   begin
      Open (F, In_File, "/dev/urandom");
      Read (F, Buf, Last);
      Close (F);
      if Last /= Buf'Last then
         raise Program_Error with "short random read";
      end if;
      --  Nibble split is proved in Tedex_Util.Encode_Hex (only tiny
      --  lengths occur: 16-byte salts); fail closed if ever abused.
      if Bytes > Tedex_Util.Max_Hex_In then
         raise Program_Error with "random too long";
      end if;
      declare
         Raw : String (1 .. Bytes);
      begin
         for I in 1 .. Bytes loop
            Raw (I) := Character'Val (Buf (Stream_Element_Offset (I)));
         end loop;
         return Tedex_Util.Encode_Hex (Raw);
      end;
   end Random_Hex;

   procedure Usage is
   begin
      Put_Line (Standard_Error,
        "usage: admin add user password | passwd user newpassword");
      Put_Line (Standard_Error,
        "       admin stop user | start user | remove user");
      Put_Line (Standard_Error,
        "       admin limit user N | list");
      Put_Line (Standard_Error,
        "       admin create-key user | change-key user");
   end Usage;

   Args   : Natural;
   First  : Natural;
   DB     : Tedex_DB.Acct_Vectors.Vector;
   Cmd    : Unbounded_String;

begin
   DB_Path := To_Unbounded_String (Default_DB);
   Args := Ada.Command_Line.Argument_Count;
   First := 1;
   if Args >= 2 and then Ada.Command_Line.Argument (1) = "--db" then
      DB_Path := To_Unbounded_String (Ada.Command_Line.Argument (2));
      First := 3;
   end if;
   if Args < First then
      Usage;
      return;
   end if;
   Cmd := To_Unbounded_String (Ada.Command_Line.Argument (First));

   if Cmd = "add" then
      if Args /= First + 2 then
         Put_Line (Standard_Error, "usage: admin add user password");
         return;
      end if;
      declare
         User : constant String := Ada.Command_Line.Argument (First + 1);
         Pass : constant String := Ada.Command_Line.Argument (First + 2);
      begin
         if not Valid_Name (User) then
            Put_Line ("ERR bad user (1..64 chars: alnum _ - .)");
            return;
         end if;
         if not Valid_Pass (Pass) then
            Put_Line ("ERR bad password (1..128 chars, no space/colon)");
            return;
         end if;
         DB := Tedex_DB.Load (To_String (DB_Path));
         if Tedex_DB.Find (DB, User) /= 0 then
            Put_Line ("ERR user exists");
            return;
         end if;
         declare
            Salt_Str : constant String := Random_Hex (16);
            Salt : Tedex_Crypto.Salt_String;
            H    : Tedex_Crypto.Hash_String;
            Stored : String (1 .. Tedex_Crypto.Stored_Len);
            Acc  : Tedex_Store.Account;
         begin
            if Salt_Str'Length /= Tedex_Crypto.Salt_Len then
               Put_Line ("ERR internal");
               return;
            end if;
            Salt := Salt_Str;
            H := Tedex_Crypto.Hash_Password (Pass, Salt);
            Stored := Salt & "$" & H;
            Acc.Name_Len := User'Length;
            Acc.Name (1 .. User'Length) := User;
            Acc.Hash := Stored;
            Acc.Disabled := False;
            Acc.Limit := 10;
            DB.Append (Acc);
            Tedex_DB.Save_All (To_String (DB_Path), DB);
            Put_Line ("OK added " & User & " (limit 10)");
         end;
      end;
   elsif Cmd = "stop" or Cmd = "start" then
      if Args /= First + 1 then
         Put_Line (Standard_Error, "usage: admin " & To_String (Cmd) & " user");
         return;
      end if;
      declare
         User : constant String := Ada.Command_Line.Argument (First + 1);
         Ix   : Natural;
      begin
         DB := Tedex_DB.Load (To_String (DB_Path));
         Ix := Tedex_DB.Find (DB, User);
         if Ix = 0 then
            Put_Line ("ERR unknown user");
            return;
         end if;
         declare
            Acc : Tedex_Store.Account := DB (Ix);
         begin
            Acc.Disabled := (To_String (Cmd) = "stop");
            DB.Replace_Element (Ix, Acc);
            Tedex_DB.Save_All (To_String (DB_Path), DB);
            if Acc.Disabled then
               Put_Line ("OK stopped " & User);
            else
               Put_Line ("OK started " & User);
            end if;
         end;
      end;
   elsif Cmd = "remove" then
      if Args /= First + 1 then
         Put_Line (Standard_Error, "usage: admin remove user");
         return;
      end if;
      declare
         User : constant String := Ada.Command_Line.Argument (First + 1);
         Gone : Boolean := False;
      begin
         Tedex_DB.Remove_Account (To_String (DB_Path), User, Gone);
         if not Gone then
            Put_Line ("ERR unknown user");
            return;
         end if;
         Put_Line ("OK removed " & User);
      end;
   elsif Cmd = "passwd" then
      if Args /= First + 2 then
         Put_Line (Standard_Error, "usage: admin passwd user newpassword");
         return;
      end if;
      declare
         User : constant String := Ada.Command_Line.Argument (First + 1);
         Pass : constant String := Ada.Command_Line.Argument (First + 2);
         Ix   : Natural;
      begin
         if not Valid_Pass (Pass) then
            Put_Line ("ERR bad password (1..128 chars, no space/colon)");
            return;
         end if;
         DB := Tedex_DB.Load (To_String (DB_Path));
         Ix := Tedex_DB.Find (DB, User);
         if Ix = 0 then
            Put_Line ("ERR unknown user");
            return;
         end if;
         declare
            Salt_Str : constant String := Random_Hex (16);
            Salt : Tedex_Crypto.Salt_String;
            H    : Tedex_Crypto.Hash_String;
            Acc  : Tedex_Store.Account := DB (Ix);
         begin
            if Salt_Str'Length /= Tedex_Crypto.Salt_Len then
               Put_Line ("ERR internal");
               return;
            end if;
            Salt := Salt_Str;
            H := Tedex_Crypto.Hash_Password (Pass, Salt);
            Acc.Hash := Salt & "$" & String (H);
            DB.Replace_Element (Ix, Acc);
            Tedex_DB.Save_All (To_String (DB_Path), DB);
            Put_Line ("OK password changed for " & User);
         end;
      end;
   elsif Cmd = "limit" then
      if Args /= First + 2 then
         Put_Line (Standard_Error, "usage: admin limit user N");
         return;
      end if;
      declare
         User : constant String := Ada.Command_Line.Argument (First + 1);
         N    : Integer;
         Ix   : Natural;
      begin
         begin
            N := Integer'Value (Ada.Command_Line.Argument (First + 2));
         exception
            when Constraint_Error =>
               Put_Line ("ERR limit must be 1..10000");
               return;
         end;
         if N not in 1 .. Tedex_Store.Max_Limit then
            Put_Line ("ERR limit must be 1..10000");
            return;
         end if;
         DB := Tedex_DB.Load (To_String (DB_Path));
         Ix := Tedex_DB.Find (DB, User);
         if Ix = 0 then
            Put_Line ("ERR unknown user");
            return;
         end if;
         declare
            Acc : Tedex_Store.Account := DB (Ix);
         begin
            Acc.Limit := N;
            DB.Replace_Element (Ix, Acc);
            Tedex_DB.Save_All (To_String (DB_Path), DB);
            Put_Line ("OK " & User & " limit=" & Integer'Image (N));
         end;
      end;
   elsif Cmd = "create-key" or Cmd = "change-key" then
      if Args /= First + 1 then
         Put_Line (Standard_Error,
           "usage: ./admin " & To_String (Cmd) & " user");
         return;
      end if;
      declare
         User : constant String := Ada.Command_Line.Argument (First + 1);
         function Has_Key return Boolean is
         begin
            return Tedex_DB.Has_Key (To_String (DB_Path), User);
         end Has_Key;
      begin
         if not Valid_Name (User) then
            Put_Line ("ERR bad user");
            return;
         end if;
         DB := Tedex_DB.Load (To_String (DB_Path));
         if Tedex_DB.Find (DB, User) = 0 then
            Put_Line ("ERR unknown user");
            return;
         end if;
         if To_String (Cmd) = "create-key" and then Has_Key then
            Put_Line ("ERR key exists (use change-key)");
            return;
         end if;
         declare
            Salt_Str : constant String := Random_Hex (16);
            Salt : Tedex_Crypto.Salt_String;
            Token : constant String := "tdk_" & Random_Hex (16);
            H    : Tedex_Crypto.Hash_String;
         begin
            if Salt_Str'Length /= Tedex_Crypto.Salt_Len then
               Put_Line ("ERR internal");
               return;
            end if;
            Salt := Salt_Str;
            H := Tedex_Crypto.Hash_Password (Token, Salt);
            Tedex_DB.Store_Key
              (To_String (DB_Path), User, Salt & "$" & String (H));
            Put_Line ("OK key for " & User & " (save it now, shown once):");
            Put_Line (Token);
         end;
      end;
   elsif Cmd = "list" then
      DB := Tedex_DB.Load (To_String (DB_Path));
      Put_Line ("users" & Natural'Image (Natural (DB.Length)));
      for Acc of DB loop
         Put_Line (Acc.Name (1 .. Acc.Name_Len)
                   & " disabled=" & (if Acc.Disabled then "1" else "0")
                   & " limit=" & Integer'Image (Acc.Limit));
      end loop;
   else
      Usage;
   end if;
exception
   when Tedex_DB.DB_Error | Program_Error =>
      --  DB_Error here means the store was locked/corrupt mid-command
      --  (retry the command); it is never a silent empty result.
      Put_Line ("ERR failed");
end Admin;
