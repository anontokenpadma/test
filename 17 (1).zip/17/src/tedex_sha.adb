--  SHA-256, implemented in pure SPARK (FIPS 180-4).
--  The former wrapper merely called GNAT.SHA256 with SPARK_Mode => Off,
--  so its contract was trusted, not proved. This body lives entirely in
--  the SPARK subset (modular arithmetic only), so callers such as
--  Tedex_Crypto.Hash_Password no longer rest on an unchecked assumption.
--  The padding, byte serialization and hex rendering carry functional
--  contracts (proved); the round function's FIPS value is established by
--  the GNAT.SHA256 comparison test vectors.
with Interfaces;

package body Tedex_SHA with SPARK_Mode is

   subtype Word is Interfaces.Unsigned_32;
   use type Interfaces.Unsigned_32;
   use type Interfaces.Unsigned_64;

   Max_Input  : constant := 512;                 --  spec Pre bound
   Block_Len  : constant := 64;
   Max_Blocks : constant := 9;                   --  ceil((512 + 9) / 64)
   Max_Padded : constant := Max_Blocks * Block_Len;  --  576

   K : constant array (0 .. 63) of Word :=
     [16#428a2f98#, 16#71374491#, 16#b5c0fbcf#, 16#e9b5dba5#,
      16#3956c25b#, 16#59f111f1#, 16#923f82a4#, 16#ab1c5ed5#,
      16#d807aa98#, 16#12835b01#, 16#243185be#, 16#550c7dc3#,
      16#72be5d74#, 16#80deb1fe#, 16#9bdc06a7#, 16#c19bf174#,
      16#e49b69c1#, 16#efbe4786#, 16#0fc19dc6#, 16#240ca1cc#,
      16#2de92c6f#, 16#4a7484aa#, 16#5cb0a9dc#, 16#76f988da#,
      16#983e5152#, 16#a831c66d#, 16#b00327c8#, 16#bf597fc7#,
      16#c6e00bf3#, 16#d5a79147#, 16#06ca6351#, 16#14292967#,
      16#27b70a85#, 16#2e1b2138#, 16#4d2c6dfc#, 16#53380d13#,
      16#650a7354#, 16#766a0abb#, 16#81c2c92e#, 16#92722c85#,
      16#a2bfe8a1#, 16#a81a664b#, 16#c24b8b70#, 16#c76c51a3#,
      16#d192e819#, 16#d6990624#, 16#f40e3585#, 16#106aa070#,
      16#19a4c116#, 16#1e376c08#, 16#2748774c#, 16#34b0bcb5#,
      16#391c0cb3#, 16#4ed8aa4a#, 16#5b9cca4f#, 16#682e6ff3#,
      16#748f82ee#, 16#78a5636f#, 16#84c87814#, 16#8cc70208#,
      16#90befffa#, 16#a4506ceb#, 16#bef9a3f7#, 16#c67178f2#];

   function Rotr (X : Word; N : Natural) return Word
     with Pre  => N in 1 .. 31,
          Post => Rotr'Result = Interfaces.Rotate_Right (X, N),
          Global => null;
   function Rotr (X : Word; N : Natural) return Word is
     (Interfaces.Rotate_Right (X, N));

   function Shr (X : Word; N : Natural) return Word
     with Pre  => N in 1 .. 31,
          Post => Shr'Result = Interfaces.Shift_Right (X, N),
          Global => null;
   function Shr (X : Word; N : Natural) return Word is
     (Interfaces.Shift_Right (X, N));

   function Sigma0 (X : Word) return Word
     with Global => null;
   function Sigma0 (X : Word) return Word is
     (Rotr (X, 2) xor Rotr (X, 13) xor Rotr (X, 22));

   function Sigma1 (X : Word) return Word
     with Global => null;
   function Sigma1 (X : Word) return Word is
     (Rotr (X, 6) xor Rotr (X, 11) xor Rotr (X, 25));

   function Small0 (X : Word) return Word
     with Global => null;
   function Small0 (X : Word) return Word is
     (Rotr (X, 7) xor Rotr (X, 18) xor Shr (X, 3));

   function Small1 (X : Word) return Word
     with Global => null;
   function Small1 (X : Word) return Word is
     (Rotr (X, 17) xor Rotr (X, 19) xor Shr (X, 10));

   function Ch (X, Y, Z : Word) return Word
     with Global => null;
   function Ch (X, Y, Z : Word) return Word is
     ((X and Y) xor ((not X) and Z));

   function Maj (X, Y, Z : Word) return Word
     with Global => null;
   function Maj (X, Y, Z : Word) return Word is
     ((X and Y) xor (X and Z) xor (Y and Z));

   --  Nibble (0 .. 15) at 4-bit position Shift (0 = least significant).
   function Nib (X : Word; Shift : Natural) return Natural
     with Pre  => Shift in 0 .. 28,
          Post => Nib'Result in 0 .. 15,
          Global => null;
   function Nib (X : Word; Shift : Natural) return Natural is
     (Natural (Interfaces.Shift_Right (X, Shift) and 16#F#));

   --  Standard lowercase-hex alphabet, as an arithmetic function so the
   --  "is a hex digit" contract is proved without unfolding a table:
   --  1..10 -> '0'..'9', 11..16 -> 'a'..'f'.
   function Hex_Char (K : Natural) return Character
     with Pre  => K in 1 .. 16,
          Post => Hex_Char'Result in '0' .. '9'
                  or Hex_Char'Result in 'a' .. 'f',
          Global => null;
   function Hex_Char (K : Natural) return Character is
     (if K <= 10 then Character'Val (Character'Pos ('0') + (K - 1))
      else Character'Val (Character'Pos ('a') + (K - 11)));

   --  8 lowercase hex chars, most-significant nibble first.
   function Hex_Of (X : Word) return String
     with Post => Hex_Of'Result'Length = 8
                  and Hex_Of'Result'First = 1
                  and (for all I in 1 .. 8 =>
                         Hex_Of'Result (I) =
                           Hex_Char (Nib (X, (8 - I) * 4) + 1)),
          Global => null;
   function Hex_Of (X : Word) return String is
      R : String (1 .. 8) := [others => '0'];
   begin
      for I in 1 .. 8 loop
         pragma Loop_Invariant
           (for all J in 1 .. I - 1 =>
              R (J) = Hex_Char (Nib (X, (8 - J) * 4) + 1));
         R (I) := Hex_Char (Nib (X, (8 - I) * 4) + 1);
      end loop;
      return R;
   end Hex_Of;

   --  IEEE 180-4 padding: 0x80, zero fill, then 64-bit big-endian length.
   procedure Pad (S : String; Buf : out String; Padded : out Natural)
     with Pre  => S'First = 1 and S'Length <= Max_Input
                  and Buf'First = 1 and Buf'Length >= Max_Padded,
          Post => Padded in 64 .. Max_Padded and Padded mod Block_Len = 0
                  and (for all I in 1 .. S'Length => Buf (I) = S (I))
                  and Buf (S'Length + 1) = Character'Val (128)
                  and (for all I in S'Length + 2 .. Padded - 8 =>
                         Buf (I) = ASCII.NUL)
                  and (for all I in 0 .. 7 =>
                         Buf (Padded - I) =
                           Character'Val
                             (Natural
                                (Interfaces.Shift_Right
                                   (Interfaces.Unsigned_64 (S'Length) * 8,
                                    8 * I) and 16#FF#))),
          Global => null;
   procedure Pad (S : String; Buf : out String; Padded : out Natural) is
      L      : constant Natural := S'Length;
      Blocks : constant Natural := (L + 9 + (Block_Len - 1)) / Block_Len;
      P      : constant Natural := Blocks * Block_Len;
      Bitlen : constant Interfaces.Unsigned_64 :=
        Interfaces.Unsigned_64 (L) * 8;
   begin
      Buf := [others => ASCII.NUL];
      for I in 1 .. L loop
         pragma Loop_Invariant (for all J in 1 .. I - 1 => Buf (J) = S (J));
         pragma Loop_Invariant
           (for all J in I .. Buf'Length => Buf (J) = ASCII.NUL);
         Buf (I) := S (I);
      end loop;
      pragma Assert (P >= L + 9);
      pragma Assert (Buf (L + 1) = ASCII.NUL);
      Buf (L + 1) := Character'Val (128);
      for I in 0 .. 7 loop
         pragma Loop_Invariant (P - I >= 1);
         pragma Loop_Invariant (Buf (L + 1) = Character'Val (128));
         pragma Loop_Invariant (for all J in 1 .. L => Buf (J) = S (J));
         pragma Loop_Invariant
           (for all J in L + 2 .. P - 8 => Buf (J) = ASCII.NUL);
         pragma Loop_Invariant
           (for all J in 0 .. I - 1 =>
              Buf (P - J) =
                Character'Val
                  (Natural
                     (Interfaces.Shift_Right (Bitlen, 8 * J) and 16#FF#)));
         Buf (P - I) := Character'Val
           (Natural (Interfaces.Shift_Right (Bitlen, 8 * I) and 16#FF#));
      end loop;
      Padded := P;
   end Pad;

   function Read_Word (Buf : String; Pos : Natural) return Word
     with Pre  => Buf'First = 1 and Buf'Length >= 4 and Pos <= Buf'Length - 4,
          Post => Read_Word'Result =
                    Word (Character'Pos (Buf (Pos + 1))) * 16#0100_0000#
                    + Word (Character'Pos (Buf (Pos + 2))) * 16#0001_0000#
                    + Word (Character'Pos (Buf (Pos + 3))) * 16#0000_0100#
                    + Word (Character'Pos (Buf (Pos + 4))),
          Global => null;
   function Read_Word (Buf : String; Pos : Natural) return Word is
     (Word (Character'Pos (Buf (Pos + 1))) * 16#0100_0000#
      + Word (Character'Pos (Buf (Pos + 2))) * 16#0001_0000#
      + Word (Character'Pos (Buf (Pos + 3))) * 16#0000_0100#
      + Word (Character'Pos (Buf (Pos + 4))));

   function Digest (S : String) return String is
      Buf    : String (1 .. Max_Padded);
      Padded : Natural;
      W      : array (0 .. 63) of Word := [others => 0];
      H      : array (0 .. 7) of Word :=
        [16#6a09e667#, 16#bb67ae85#, 16#3c6ef372#, 16#a54ff53a#,
         16#510e527f#, 16#9b05688c#, 16#1f83d9ab#, 16#5be0cd19#];
      Blocks : Natural;
      R      : String (1 .. SHA_Hex_Len) := [others => '0'];
      T1, T2 : Word;
      A, B, C, D, E, F, G, Hh : Word;
   begin
      Pad (S, Buf, Padded);
      Blocks := Padded / Block_Len;
      for Blk in 0 .. Blocks - 1 loop
         pragma Loop_Invariant (Blk * Block_Len + Block_Len <= Padded);
         declare
            Base : constant Natural := Blk * Block_Len;
         begin
            for T in 0 .. 15 loop
               pragma Loop_Invariant (Base + 4 * T + 4 <= Buf'Length);
               pragma Loop_Invariant
                 (for all U in 0 .. T - 1 =>
                    W (U) = Read_Word (Buf, Base + 4 * U));
               W (T) := Read_Word (Buf, Base + 4 * T);
            end loop;
         end;
         for T in 16 .. 63 loop
            pragma Loop_Invariant
              (for all U in 16 .. T - 1 =>
                 W (U) = Small1 (W (U - 2)) + W (U - 7)
                        + Small0 (W (U - 15)) + W (U - 16));
            W (T) := Small1 (W (T - 2)) + W (T - 7)
                     + Small0 (W (T - 15)) + W (T - 16);
         end loop;
         A := H (0); B := H (1); C := H (2); D := H (3);
         E := H (4); F := H (5); G := H (6); Hh := H (7);
         for T in 0 .. 63 loop
            T1 := Hh + Sigma1 (E) + Ch (E, F, G) + K (T) + W (T);
            T2 := Sigma0 (A) + Maj (A, B, C);
            Hh := G; G := F; F := E; E := D + T1;
            D := C; C := B; B := A; A := T1 + T2;
         end loop;
         H (0) := H (0) + A; H (1) := H (1) + B;
         H (2) := H (2) + C; H (3) := H (3) + D;
         H (4) := H (4) + E; H (5) := H (5) + F;
         H (6) := H (6) + G; H (7) := H (7) + Hh;
      end loop;
      for I in 0 .. 7 loop
         pragma Loop_Invariant
           (for all J in 1 .. 8 * I =>
              R (J) in '0' .. '9' or R (J) in 'a' .. 'f');
         R (8 * I + 1 .. 8 * I + 8) := Hex_Of (H (I));
      end loop;
      return R;
   end Digest;

end Tedex_SHA;
