--  tedex server: listen on -p PORT, relay managers and devices.
--  Usage: ./server -p 9999 [--host 0.0.0.0] [--db ./users.db]
with Ada.Calendar;
with Ada.Calendar.Formatting;
with Ada.Command_Line;
with Ada.Containers.Vectors;
with Ada.Directories;
with Ada.Exceptions;
with Ada.Strings.Unbounded;
with Ada.Text_IO;
with GNAT.Sockets;

with Tedex_Crypto;
with Tedex_DB;
with Tedex_Net;
with Tedex_Protocol;
with Tedex_Store;
with Tedex_Util;

--  Boundary main, not in SPARK (sockets, tasking, filesystem,
--  infinite accept loop); all parsing/crypto/validation delegated to
--  proved SPARK units (Protocol, Ws, Crypto, Store, DB validators).
procedure Server with SPARK_Mode => Off is

   use GNAT.Sockets;
   use Ada.Strings.Unbounded;
   use Tedex_Net;
   use type Tedex_Protocol.Auth_Kind;
   use type Tedex_Protocol.Manager_Cmd;
   use type Tedex_Util.Auth_Deny;

   Port    : Integer := 9999;
   Host    : Unbounded_String := To_Unbounded_String ("0.0.0.0");
   DB_Path : Unbounded_String;

   procedure Log (S : String) is
   begin
      Ada.Text_IO.Put_Line (Ada.Calendar.Formatting.Image
        (Ada.Calendar.Clock) & " " & S);
   end Log;

   --  Registry of live connections -----------------------------------

   type Dev_Rec is record
      User  : Unbounded_String;
      Id    : Unbounded_String;
      Addr  : Unbounded_String;
      Since : Unbounded_String;
      Sock  : Socket_Type;
      Ws    : Boolean := False;
      Seq   : Natural;
   end record;

   package Dev_Vec is new Ada.Containers.Vectors (Positive, Dev_Rec);

   type Mgr_Rec is record
      Sock : Socket_Type;
      User : Unbounded_String;
      Ws   : Boolean := False;
      Id   : Natural;
   end record;

   package Mgr_Vec is new Ada.Containers.Vectors (Positive, Mgr_Rec);
   package Str_Vec is new Ada.Containers.Vectors (Positive, Unbounded_String);

   type Att_Rec is record
      User  : Unbounded_String;
      Dev   : Unbounded_String;
      Addr  : Unbounded_String;
      Since : Unbounded_String;
      Sock  : Socket_Type;
   end record;

   package Att_Vec is new Ada.Containers.Vectors (Positive, Att_Rec);

   type Pair_Rec is record
      User : Unbounded_String;
      Dev  : Unbounded_String;
   end record;

   package Pair_Vec is new Ada.Containers.Vectors (Positive, Pair_Rec);

   protected Registry is
      procedure Reg_Dev (U, D, A, S : String; Sock : Socket_Type; Ws : Boolean;
                       Replaced : out Socket_Type);
      --  Register (or re-register) a device. On name clash the old
      --  socket is superseded and returned in Replaced (No_Socket when
      --  fresh) so the caller can close it outside the protected
      --  object; its dying task must not wipe the new entry (see
      --  Unreg_Dev).
      procedure Unreg_Dev (U, D : String; Sock : Socket_Type);
      --  Unregister only if the entry still points at Sock: a stale
      --  task (superseded registration, delayed EOF) must not delete
      --  a live re-registration under the same name.
      procedure Drop_Device (U, D : String; Dropped : out Natural);
      procedure Take_Dev (U, D : String; Found : out Boolean;
                          Sock : out Socket_Type; Ws : out Boolean;
                          Addr : out Unbounded_String;
                          Since : out Unbounded_String);
      function List_Attached return Att_Vec.Vector;
      function Count_Dev (U : String) return Natural;
      function Count_Attached (U : String) return Natural;
      function List_Dev (U : String) return Dev_Vec.Vector;
      procedure Reg_Mgr (U : String; Sock : Socket_Type; Ws : Boolean;
                         Id : out Natural);
      procedure Unreg_Mgr (Id : Natural);
      procedure Drop_User (U : String; Dropped : out Natural);
      procedure Trim_User (U : String; Keep : Natural; Dropped : out Natural;
                           Last_Dropped : out Unbounded_String);
      function All_Users return Str_Vec.Vector;
      procedure Mark_Attached (U, D, A, S : String; Sock : Socket_Type);
      procedure Unmark_Attached (U, D : String);
      function Is_Attached (U, D : String) return Boolean;
      procedure Mark_Gone (U, D : String);
      function Is_Gone (U, D : String) return Boolean;
      procedure Unmark_Gone (U, D : String);
      procedure Find_Dev_Sock (U, D : String; Sock : out Socket_Type;
                               Ws : out Boolean; Found : out Boolean);
   private
      Devs     : Dev_Vec.Vector;
      Mgrs     : Mgr_Vec.Vector;
      Atts     : Att_Vec.Vector;
      Gones    : Pair_Vec.Vector;
      Next_Seq : Natural := 0;
   end Registry;

   protected body Registry is

      procedure Reg_Dev (U, D, A, S : String; Sock : Socket_Type; Ws : Boolean;
                       Replaced : out Socket_Type) is
      begin
         Replaced := No_Socket;
         for I in 1 .. Natural (Devs.Length) loop
            if Devs (I).User = U and then Devs (I).Id = D then
               Replaced := Devs (I).Sock;
               Devs.Replace_Element
                 (I, Dev_Rec'
                   (User  => Devs (I).User, Id => Devs (I).Id,
                    Addr  => To_Unbounded_String (A),
                    Since => To_Unbounded_String (S),
                    Sock  => Sock, Ws => Ws, Seq => Devs (I).Seq));
               return;
            end if;
         end loop;
         Next_Seq := Next_Seq + 1;
         Devs.Append (Dev_Rec'
           (User  => To_Unbounded_String (U),
            Id    => To_Unbounded_String (D),
            Addr  => To_Unbounded_String (A),
            Since => To_Unbounded_String (S),
            Sock  => Sock, Ws => Ws, Seq => Next_Seq));
      end Reg_Dev;

      procedure Unreg_Dev (U, D : String; Sock : Socket_Type) is
      begin
         for I in 1 .. Natural (Devs.Length) loop
            if Devs (I).User = U and then Devs (I).Id = D
              and then Devs (I).Sock = Sock
            then
               Devs.Delete (I);
               return;
            end if;
         end loop;
      end Unreg_Dev;

      procedure Drop_Device (U, D : String; Dropped : out Natural) is
      begin
         Dropped := 0;
         for I in 1 .. Natural (Devs.Length) loop
            if Devs (I).User = U and then Devs (I).Id = D then
               begin
                  Close_Socket (Devs (I).Sock);
               exception
                  when Socket_Error => null;
               end;
               Devs.Delete (I);
               Dropped := Dropped + 1;
               exit;
            end if;
         end loop;
         for I in 1 .. Natural (Atts.Length) loop
            if Atts (I).User = U and then Atts (I).Dev = D then
               begin
                  Close_Socket (Atts (I).Sock);
               exception
                  when Socket_Error => null;
               end;
               Atts.Delete (I);
               Dropped := Dropped + 1;
               exit;
            end if;
         end loop;
      end Drop_Device;

      procedure Take_Dev (U, D : String; Found : out Boolean;
                          Sock : out Socket_Type; Ws : out Boolean;
                          Addr : out Unbounded_String;
                          Since : out Unbounded_String) is
      begin
         Found := False;
         Sock := No_Socket;
         Ws := False;
         Addr := Null_Unbounded_String;
         Since := Null_Unbounded_String;
         for I in 1 .. Natural (Devs.Length) loop
            if Devs (I).User = U and then Devs (I).Id = D then
               Found := True;
               Sock := Devs (I).Sock;
               Ws := Devs (I).Ws;
               Addr := Devs (I).Addr;
               Since := Devs (I).Since;
               Devs.Delete (I);
               return;
            end if;
         end loop;
      end Take_Dev;

      function List_Attached return Att_Vec.Vector is
         V : Att_Vec.Vector;
      begin
         for A of Atts loop
            V.Append (A);
         end loop;
         return V;
      end List_Attached;

      function Count_Dev (U : String) return Natural is
         N : Natural := 0;
      begin
         for D of Devs loop
            if D.User = U then
               N := N + 1;
            end if;
         end loop;
         return N;
      end Count_Dev;

      function Count_Attached (U : String) return Natural is
         N : Natural := 0;
      begin
         for A of Atts loop
            if A.User = U then
               N := N + 1;
            end if;
         end loop;
         return N;
      end Count_Attached;

      function List_Dev (U : String) return Dev_Vec.Vector is
         V : Dev_Vec.Vector;
      begin
         for D of Devs loop
            if D.User = U then
               V.Append (D);
            end if;
         end loop;
         return V;
      end List_Dev;

      procedure Reg_Mgr (U : String; Sock : Socket_Type; Ws : Boolean;
                         Id : out Natural) is
      begin
         Next_Seq := Next_Seq + 1;
         Id := Next_Seq;
         Mgrs.Append (Mgr_Rec'(Sock => Sock, User => To_Unbounded_String (U),
                                Ws => Ws, Id   => Id));
      end Reg_Mgr;

      procedure Unreg_Mgr (Id : Natural) is
      begin
         for I in 1 .. Natural (Mgrs.Length) loop
            if Mgrs (I).Id = Id then
               Mgrs.Delete (I);
               return;
            end if;
         end loop;
      end Unreg_Mgr;

      procedure Drop_User (U : String; Dropped : out Natural) is
      begin
         Dropped := 0;
         loop
            declare
               Found : Boolean := False;
            begin
               for I in 1 .. Natural (Devs.Length) loop
                  if Devs (I).User = U then
                     begin
                        Close_Socket (Devs (I).Sock);
                     exception
                        when Socket_Error => null;
                     end;
                     Devs.Delete (I);
                     Dropped := Dropped + 1;
                     Found := True;
                     exit;
                  end if;
               end loop;
               exit when not Found;
            end;
         end loop;
         loop
            declare
               Found : Boolean := False;
            begin
               for I in 1 .. Natural (Mgrs.Length) loop
                  if Mgrs (I).User = U then
                     begin
                        Close_Socket (Mgrs (I).Sock);
                     exception
                        when Socket_Error => null;
                     end;
                     Mgrs.Delete (I);
                     Dropped := Dropped + 1;
                     Found := True;
                     exit;
                  end if;
               end loop;
               exit when not Found;
            end;
         end loop;
         loop
            declare
               Found : Boolean := False;
            begin
               for I in 1 .. Natural (Atts.Length) loop
                  if Atts (I).User = U then
                     begin
                        Close_Socket (Atts (I).Sock);
                     exception
                        when Socket_Error => null;
                     end;
                     Atts.Delete (I);
                     Dropped := Dropped + 1;
                     Found := True;
                     exit;
                  end if;
               end loop;
               exit when not Found;
            end;
         end loop;
      end Drop_User;

      procedure Trim_User (U : String; Keep : Natural; Dropped : out Natural;
                           Last_Dropped : out Unbounded_String) is
         N : Natural := 0;
      begin
         Dropped := 0;
         Last_Dropped := Null_Unbounded_String;
         --  Live shells count toward the quota like idle ones, but only
         --  idle connections are ever evicted (never kill a live shell
         --  on quota shrink: grandfather it, block new ones at AUTH).
         for D of Devs loop
            if D.User = U then
               N := N + 1;
            end if;
         end loop;
         for A of Atts loop
            if A.User = U then
               N := N + 1;
            end if;
         end loop;
         while N > Keep loop
            declare
               Best_Seq : Natural := Natural'Last;
               Best_Ix  : Natural := 0;
            begin
               --  Evict the OLDEST idle first: with same-name supersede
               --  keeping its slot age, evicting the newest would flap
               --  every fresh enrollment forever (persist reconnect keeps
               --  climbing Seq and stays trim-prime).
               for I in 1 .. Natural (Devs.Length) loop
                  if Devs (I).User = U and then Devs (I).Seq < Best_Seq then
                     Best_Seq := Devs (I).Seq;
                     Best_Ix := I;
                  end if;
               end loop;
               exit when Best_Ix = 0;
               Last_Dropped := Devs (Best_Ix).Id;
               begin
                  Close_Socket (Devs (Best_Ix).Sock);
               exception
                  when Socket_Error => null;
               end;
               Devs.Delete (Best_Ix);
               N := N - 1;
               Dropped := Dropped + 1;
            end;
         end loop;
      end Trim_User;

      function All_Users return Str_Vec.Vector is
         V : Str_Vec.Vector;
      begin
         for D of Devs loop
            declare
               Seen : Boolean := False;
            begin
               for U of V loop
                  if U = D.User then
                     Seen := True;
                  end if;
               end loop;
               if not Seen then
                  V.Append (D.User);
               end if;
            end;
         end loop;
         for M of Mgrs loop
            declare
               Seen : Boolean := False;
            begin
               for U of V loop
                  if U = M.User then
                     Seen := True;
                  end if;
               end loop;
               if not Seen then
                  V.Append (M.User);
               end if;
            end;
         end loop;
         return V;
      end All_Users;

      procedure Mark_Attached (U, D, A, S : String; Sock : Socket_Type) is
      begin
         for X of Atts loop
            if X.User = U and then X.Dev = D then
               return;  --  already marked
            end if;
         end loop;
         Atts.Append (Att_Rec'(User => To_Unbounded_String (U),
                                Dev  => To_Unbounded_String (D),
                                Addr => To_Unbounded_String (A),
                                Since => To_Unbounded_String (S),
                                Sock => Sock));
      end Mark_Attached;

      procedure Unmark_Attached (U, D : String) is
      begin
         for I in 1 .. Natural (Atts.Length) loop
            if Atts (I).User = U and then Atts (I).Dev = D then
               Atts.Delete (I);
               return;
            end if;
         end loop;
      end Unmark_Attached;

      function Is_Attached (U, D : String) return Boolean is
      begin
         for A of Atts loop
            if A.User = U and then A.Dev = D then
               return True;
            end if;
         end loop;
         return False;
      end Is_Attached;

      procedure Mark_Gone (U, D : String) is
      begin
         for G of Gones loop
            if G.User = U and then G.Dev = D then
               return;
            end if;
         end loop;
         Gones.Append (Pair_Rec'(User => To_Unbounded_String (U),
                                  Dev  => To_Unbounded_String (D)));
      end Mark_Gone;

      function Is_Gone (U, D : String) return Boolean is
      begin
         for G of Gones loop
            if G.User = U and then G.Dev = D then
               return True;
            end if;
         end loop;
         return False;
      end Is_Gone;

      procedure Unmark_Gone (U, D : String) is
      begin
         for I in 1 .. Natural (Gones.Length) loop
            if Gones (I).User = U and then Gones (I).Dev = D then
               Gones.Delete (I);
               return;
            end if;
         end loop;
      end Unmark_Gone;

      procedure Find_Dev_Sock (U, D : String; Sock : out Socket_Type;
                               Ws : out Boolean; Found : out Boolean) is
      begin
         Found := False;
         Sock := No_Socket;
         Ws := False;
         for I in 1 .. Natural (Devs.Length) loop
            if Devs (I).User = U and then Devs (I).Id = D then
               Found := True;
               Sock := Devs (I).Sock;
               Ws := Devs (I).Ws;
               return;
            end if;
         end loop;
      end Find_Dev_Sock;

   end Registry;


   function Notify_Dev (U, D, Line : String) return Boolean is
      Sock  : Socket_Type;
      Ws    : Boolean;
      Found : Boolean;
   begin
      Registry.Find_Dev_Sock (U, D, Sock, Ws, Found);
      if not Found then
         return False;
      end if;
      begin
         if Ws then
            Ws_Send_Line (Sock, Line);
         else
            Send_Line (Sock, Line);
         end if;
      exception
         when Net_Error =>
            return False;
      end;
      return True;
   end Notify_Dev;







   --  Single proved image (Tedex_Protocol.Nat_Image): the only
   --  callers pass small Naturals (ports, dims), so the precondition
   --  always holds; kept as a wrapper to avoid touching call sites.
   function Trim_Image (N : Natural) return String is
   begin
      return Tedex_Protocol.Nat_Image (N);
   end Trim_Image;

   procedure Close_Quiet (S : Socket_Type) is
   begin
      Close_Socket (S);
   exception
      when Socket_Error => null;
   end Close_Quiet;

   type Conn is record
      Sock : Socket_Type;
      Ws   : Boolean := False;
   end record;

   procedure CSend (C : Conn; S : String) is
   begin
      if C.Ws then
         Ws_Send_Line (C.Sock, S);
      else
         Send_Line (C.Sock, S);
      end if;
   end CSend;

   function CRecv (C : Conn; Timeout : Duration := 3_600.0) return String is
      use type Ada.Calendar.Time;
      Deadln : constant Ada.Calendar.Time :=
        Ada.Calendar.Clock + Timeout;
   begin
      if not C.Ws then
         return Recv_Line (C.Sock, Timeout);
      end if;
      --  WS links (possibly Cloudflare-proxied) get keepalive pings
      --  while waiting, so idle connections survive past edge timeouts.
      loop
         declare
            Left : constant Duration := Deadln - Ada.Calendar.Clock;
         begin
            if Left <= 0.0 then
               raise Net_Error with "timeout";
            end if;
            declare
               Line_US : Unbounded_String;
            begin
               Ws_Recv_Line (C.Sock, Duration'Min (Left, 30.0), Line => Line_US);
               return To_String (Line_US);
            end;
         exception
            when E : Net_Error =>
               if Ada.Exceptions.Exception_Message (E) /= "timeout" then
                  raise;
               end if;
               exit when (Deadln - Ada.Calendar.Clock) <= 0.0;
               Ws_Send (C.Sock, "", 9);
         end;
      end loop;
      raise Net_Error with "timeout";  --  unreachable
   end CRecv;

   --  Manager command wait without a blind hourly kick: refresh the
   --  3_600 s budget while the manager idles (30 s WS pings keep
   --  flowing inside CRecv), so a panel left open stays connected
   --  until QUIT. A full day of silence still ends the session, to
   --  bound leaked tasks if the peer vanished without closing.
   function CRecv_Manager (C : Conn) return String is
      use type Ada.Calendar.Time;
      Deadln : constant Ada.Calendar.Time :=
        Ada.Calendar.Clock + 86_400.0;
   begin
      loop
         begin
            return CRecv (C);
         exception
            when E : Net_Error =>
               if Ada.Exceptions.Exception_Message (E) /= "timeout" then
                  raise;
               end if;
               if Ada.Calendar.Clock >= Deadln then
                  raise;
               end if;
         end;
      end loop;
   end CRecv_Manager;

   --  Best-effort one line to a live device control channel.

   procedure Handle_Device (C : Conn; User, Dev : String) is
      Idle : Natural := 0;

      procedure Clean_Exit (Close_It : Boolean := True) is
      begin
         Registry.Unreg_Dev (User, Dev, C.Sock);
         if Close_It then
            Close_Quiet (C.Sock);
         end if;
      end Clean_Exit;

      function Idle_Recv return String is
      begin
         --  Short waits so an attach handoff is noticed within ~0.1 s.
         --  The socket has a single reader at any moment: either this
         --  loop (idle device) or the splice (attached device).
         if C.Ws then
            declare
               Line_US : Unbounded_String;
            begin
               Ws_Recv_Line (C.Sock, 0.1, Line => Line_US);
               return To_String (Line_US);
            end;
         else
            return Recv_Line (C.Sock, 0.1);
         end if;
      end Idle_Recv;
   begin
      loop
         begin
            declare
               L : constant String := Idle_Recv;
            begin
               Idle := 0;
               if L = "PING" then
                  CSend (C, "PONG");
               elsif L = "QUIT" then
                  Clean_Exit;
                  return;
               end if;
            end;
         exception
            when E : Net_Error =>
               if Ada.Exceptions.Exception_Message (E) /= "timeout" then
                  Clean_Exit;
                  return;
               end if;
               --  Idle tick: step aside if a manager is attaching.
               if Registry.Is_Attached (User, Dev) then
                  Registry.Mark_Gone (User, Dev);
                  return;  --  splice owns the socket now; do NOT close
               end if;
               Idle := Idle + 1;
               if C.Ws and then Idle >= 300 then  --  ~30 s of 0.1 s ticks
                  Idle := 0;
                  begin
                     Ws_Send (C.Sock, "", 9);
                  exception
                     when Net_Error =>
                        Clean_Exit;
                        return;
                  end;
               end if;
         end;
      end loop;
   end Handle_Device;


   procedure Handle_Manager (C : Conn; User : String) is
      Mgr_Id  : Natural;
      Arg_Buf : String (1 .. Tedex_Protocol.Max_Dev) := [others => ' '];
      Arg_Len : Natural;
      Cmd     : Tedex_Protocol.Manager_Cmd;
      --  Pending terminal size for the next ATTACH on this connection
      --  ("RESIZE <dev> <cols> <rows>"): consumed and cleared by
      --  Do_Attach whether the attach succeeds or not, so a stale size
      --  can never leak into a later attach of another device.
      Pend_Dev  : Unbounded_String := Null_Unbounded_String;
      Pend_Cols : Natural := 0;
      Pend_Rows : Natural := 0;

      --  Manual "RESIZE <dev> <cols> <rows>" parse (kept out of the
      --  proved Tedex_Protocol unit on purpose): strict digits, dev a
      --  valid token, dims 1..1000. Replies "OK resized"/"ERR bad resize".
      --  Terminal-size announcement, parsed by the proved SPARK
      --  unit (identical accept/reject behavior); this wrapper only
      --  stashes the result and answers.
      procedure Do_Resize (L : String) is
         R_Buf  : String (1 .. Tedex_Protocol.Max_Dev) := [others => ' '];
         R_Len  : Natural := 0;
         R_Cols : Natural := 0;
         R_Rows : Natural := 0;
         R_Ok   : Boolean := False;
      begin
         Tedex_Protocol.Parse_Resize (L, R_Buf, R_Len, R_Cols, R_Rows, R_Ok);
         if not R_Ok then
            CSend (C, "ERR bad resize");
            return;
         end if;
         Pend_Dev := To_Unbounded_String (R_Buf (1 .. R_Len));
         Pend_Cols := R_Cols;
         Pend_Rows := R_Rows;
         CSend (C, "OK resized");
      end Do_Resize;

      procedure Clear_Pend is
      begin
         Pend_Dev := Null_Unbounded_String;
         Pend_Cols := 0;
         Pend_Rows := 0;
      end Clear_Pend;

      function Wait_Handler_Gone (U, D : String) return Boolean is
      begin
         for W in 1 .. 100 loop
            if Registry.Is_Gone (U, D) then
               return True;
            end if;
            delay 0.05;
         end loop;
         return False;
      end Wait_Handler_Gone;

      function Account_Still_Active (U : String) return Boolean is
         DB : constant Tedex_DB.Acct_Vectors.Vector :=
           Tedex_DB.Load (To_String (DB_Path));
         Ix : constant Natural := Tedex_DB.Find (DB, U);
         Ele : Tedex_Store.Account;
      begin
         if Ix = 0 then
            return False;
         end if;
         Ele := Tedex_DB.Acct_Vectors.Element (DB, Ix);
         return not Ele.Disabled;
      end Account_Still_Active;

      procedure Do_Attach_Splice (U, A : String;
                                  MC  : Conn;
                                  Mgr : Natural;
                                  DSock : Socket_Type;
                                  DWs   : Boolean;
                                  Spliced : in out Boolean) is
         Alive : Boolean := True;
         DC : constant Conn := (Sock => DSock, Ws => DWs);
         Start_Line : Unbounded_String :=
           To_Unbounded_String ("SHELL_START");
      begin
         --  Forward a matching pending RESIZE (proved predicate:
         --  only when it names this ATTACH target with in-range dims,
         --  so a stale size never leaks across devices). Plain
         --  "SHELL_START" keeps old-device compat.
         if Tedex_Util.Should_Forward_Resize
           (To_String (Pend_Dev), A, Pend_Cols, Pend_Rows)
         then
            Start_Line := To_Unbounded_String
              ("SHELL_START " & Trim_Image (Pend_Cols)
               & " " & Trim_Image (Pend_Rows));
         end if;
         Pend_Dev := Null_Unbounded_String;
         Pend_Cols := 0;
         Pend_Rows := 0;
         begin
            CSend (DC, To_String (Start_Line));
         exception
            when Net_Error =>
               Alive := False;
               CSend (MC, "ERR device unreachable");
         end;
         if not Alive then
            Registry.Unmark_Attached (U, A);
            Registry.Unmark_Gone (U, A);
            Close_Quiet (DSock);
            return;
         end if;
         CSend (MC, "ATTACHED " & A);
         Log ("attach " & U & " -> " & A);
         Spliced := True;
         if MC.Ws or DWs then
            Ws_Splice (MC.Sock, MC.Ws, DSock, DWs);
         else
            Splice (MC.Sock, DSock);
         end if;
         Registry.Unmark_Attached (U, A);
         Registry.Unmark_Gone (U, A);
         Registry.Unreg_Mgr (Mgr);
      end Do_Attach_Splice;

      procedure Do_Attach (A : String) is
         Found : Boolean;
         DSock : Socket_Type;
         DWs   : Boolean;
         DAddr : Unbounded_String;
         DSince : Unbounded_String;
         Spliced : Boolean := False;
      begin
         Registry.Take_Dev
           (User, A, Found, DSock, DWs, DAddr, DSince);
         if not Found then
            Clear_Pend;
            CSend (C, "ERR no such device");
            return;
         end if;
         Registry.Mark_Attached
           (User, A, To_String (DAddr), To_String (DSince), DSock);
         begin
            if not Wait_Handler_Gone (User, A) then
               Clear_Pend;
               Registry.Unmark_Attached (User, A);
               Close_Quiet (DSock);
               CSend (C, "ERR device busy");
            elsif not Account_Still_Active (User) then
               Clear_Pend;
               Registry.Unmark_Attached (User, A);
               Registry.Unmark_Gone (User, A);
               Close_Quiet (DSock);
               CSend (C, "ERR account stopped");
            else
               Do_Attach_Splice
                 (User, A, C, Mgr_Id, DSock, DWs, Spliced);
               Registry.Unreg_Mgr (Mgr_Id);
               return;
            end if;
         exception
            when Tedex_DB.DB_Error =>
               --  Account check hit a transient store failure: keep
               --  the manager connected with a retryable error (same
               --  rule as the AUTH path, never a fake auth verdict).
               Clear_Pend;
               Registry.Unmark_Attached (User, A);
               Registry.Unmark_Gone (User, A);
               if not Spliced then
                  Close_Quiet (DSock);
               end if;
               begin
                  CSend (C, "ERR busy, retry");
               exception
                  when Net_Error => null;
               end;
            when others =>
               Clear_Pend;
               Registry.Unmark_Attached (User, A);
               Registry.Unmark_Gone (User, A);
               if not Spliced then
                  Close_Quiet (DSock);
               end if;
               raise;
         end;
      end Do_Attach;

   begin
      Registry.Reg_Mgr (User, C.Sock, C.Ws, Mgr_Id);
      loop
         declare
            L : constant String := CRecv_Manager (C);
         begin
            --  Terminal-size announcement: handled here, not in the
            --  proved command parser (unknown to old managers/servers:
            --  they just see ERR and carry on with an 80x24 default).
            if L'Length > 7
              and then L (L'First .. L'First + 6) = "RESIZE "
            then
               Do_Resize (L);
            else
               Tedex_Protocol.Parse_Command (L, Cmd, Arg_Buf, Arg_Len);
            case Cmd is
               when Tedex_Protocol.Cmd_Quit =>
                  exit;
               when Tedex_Protocol.Cmd_Bad =>
                  CSend (C, "ERR unknown command");
               when Tedex_Protocol.Cmd_List =>
                  declare
                     V : constant Dev_Vec.Vector := Registry.List_Dev (User);
                     Known : constant Tedex_DB.Known_Vec.Vector :=
                       Tedex_DB.Known_Devices (To_String (DB_Path), User);
                     Att : constant Att_Vec.Vector :=
                       Registry.List_Attached;
                     Total : Natural := Natural (V.Length);
                  begin
                     for A of Att loop
                        if A.User = User then
                           Total := Total + 1;
                        end if;
                     end loop;
                     for K of Known loop
                        declare
                           Seen : Boolean := False;
                        begin
                           for D of V loop
                              if D.Id = K.Dev then
                                 Seen := True;
                              end if;
                           end loop;
                           if not Seen then
                              for A of Att loop
                                 if A.User = User and then A.Dev = K.Dev then
                                    Seen := True;
                                 end if;
                              end loop;
                           end if;
                           if not Seen then
                              Total := Total + 1;
                           end if;
                        end;
                     end loop;
                     if Total > 999_999 then
                        Total := 999_999;
                     end if;
                     CSend (C, Tedex_Protocol.Devices_Header (Total));
                     for D of V loop
                        CSend (C, "DEVICE " & To_String (D.Id)
                               & " online " & To_String (D.Addr)
                               & " " & To_String (D.Since));
                     end loop;
                     for A of Att loop
                        if A.User = User then
                           CSend (C, "DEVICE " & To_String (A.Dev)
                                  & " busy " & To_String (A.Addr)
                                  & " " & To_String (A.Since));
                        end if;
                     end loop;
                     for K of Known loop
                        declare
                           Seen : Boolean := False;
                        begin
                           for D of V loop
                              if D.Id = K.Dev then
                                 Seen := True;
                              end if;
                           end loop;
                           if not Seen then
                              for A of Att loop
                                 if A.User = User and then A.Dev = K.Dev then
                                    Seen := True;
                                 end if;
                              end loop;
                           end if;
                           if not Seen then
                              CSend (C, "DEVICE " & To_String (K.Dev)
                                     & " offline - "
                                     & To_String (K.Last_Seen));
                           end if;
                        end;
                     end loop;
                     CSend (C, "END");
                  end;
               when Tedex_Protocol.Cmd_Attach =>
                  Do_Attach (Arg_Buf (1 .. Arg_Len));
               when Tedex_Protocol.Cmd_Remove =>
                  declare
                     A : constant String := Arg_Buf (1 .. Arg_Len);
                     Dropped : Natural := 0;
                     Known   : Boolean := False;
                  begin
                     --  Order a live device to stop/uninstall itself
                     --  ("REMOVED") before dropping it (shell parity with
                     --  the base project). Same name may register again
                     --  afterwards: nothing is banned.
                     if Notify_Dev (User, A, "REMOVED") then
                        delay 0.5;  --  let the device consume REMOVED
                     end if;
                     Registry.Drop_Device (User, A, Dropped);
                     declare
                        Ks : constant Tedex_DB.Known_Vec.Vector :=
                          Tedex_DB.Known_Devices
                            (To_String (DB_Path), User);
                     begin
                        for K of Ks loop
                           if K.Dev = A then
                              Known := True;
                           end if;
                        end loop;
                     end;
                     if Dropped = 0 and then not Known then
                        CSend (C, "ERR no such device");
                     else
                        Tedex_DB.Forget_Device
                          (To_String (DB_Path), User, A);
                        Log ("remove " & User & "/" & A);
                        CSend (C, "OK removed " & A);
                     end if;
                  end;
            end case;
            end if;
         end;
      end loop;
      Registry.Unreg_Mgr (Mgr_Id);
   exception
      when Net_Error =>
         begin
            Registry.Unreg_Mgr (Mgr_Id);
         exception
            when others => null;
         end;
   end Handle_Manager;

   procedure Handle_Connection (Sock : Socket_Type; Peer : String) is
      Use_Ws : Boolean := False;
      C      : Conn;
   begin
      begin
         if Peek_Http (Sock) then
            --  WebSocket managers/devices (wss): complete the RFC 6455
            --  handshake, then fall through to the AUTH line below.
            declare
               P : Ada.Strings.Unbounded.Unbounded_String;
            begin
               Ws_Server_Handshake (Sock, P);
               Use_Ws := True;
               Log ("ws handshake from " & Peer & " path="
                    & Ada.Strings.Unbounded.To_String (P));
            end;
         end if;
      exception
         when Net_Error =>
            Close_Quiet (Sock);
            return;
      end;
      C := (Sock => Sock, Ws => Use_Ws);
      declare
         Line : constant String := CRecv (C, 60.0);
         Req  : Tedex_Protocol.Auth_Request;
      begin
         Tedex_Protocol.Parse_Auth (Line, Req);
         if Req.Kind = Tedex_Protocol.Auth_Bad then
            CSend (C, "ERR bad auth");
            Close_Quiet (Sock);
            return;
         end if;
         declare
            User : constant String := Req.User (1 .. Req.User_Len);
            Pass : constant String := Req.Pass (1 .. Req.Pass_Len);
            DB : constant Tedex_DB.Acct_Vectors.Vector :=
              Tedex_DB.Load (To_String (DB_Path));
            Ix : constant Natural := Tedex_DB.Find (DB, User);
         begin
            if Ix = 0 then
               Log ("auth " & User & " from " & Peer & ": unknown user");
               CSend (C, "ERR unknown user");
               Close_Quiet (Sock);
               return;
            end if;
            declare
               Acc  : constant Tedex_Store.Account :=
                 Tedex_DB.Acct_Vectors.Element (DB, Ix);
               Salt : Tedex_Crypto.Salt_String;
               HH   : Tedex_Crypto.Hash_String;
               HOk  : Boolean;
            begin
               Tedex_Crypto.Split_Stored (Acc.Hash, Salt, HH, HOk);
               if not HOk then
                  CSend (C, "ERR server db corrupt");
                  Close_Quiet (Sock);
                  return;
               end if;
               declare
                  Calc : constant Tedex_Crypto.Hash_String :=
                    Tedex_Crypto.Hash_Password (Pass, Salt);
                  Pass_Ok : constant Boolean :=
                    Tedex_Crypto.Secure_Equal (String (Calc), String (HH));
                  Key_Ok : Boolean := False;
               begin
                  --  Managers authenticate by password only; devices may
                  --  alternatively present an enrollment key, so a leaked
                  --  device key never grants manager powers. The key
                  --  lookup runs only when the password fails on a device
                  --  leg (short-circuit preserved; store errors still
                  --  propagate to the busy-retry handler, never reported
                  --  as an auth refusal).
                  if not Pass_Ok
                    and then Req.Kind = Tedex_Protocol.Auth_Device
                  then
                     Key_Ok := Tedex_DB.Verify_Key
                       (To_String (DB_Path), User, Pass);
                  end if;
                  declare
                     Allow  : Boolean;
                     Reason : Tedex_Util.Auth_Deny;
                  begin
                     --  Single proved commit point for the login
                     --  decision (password first, then disabled).
                     Tedex_Util.Auth_Verdict
                       (Pass_Ok, Req.Kind = Tedex_Protocol.Auth_Device,
                        Key_Ok, Acc.Disabled, Allow, Reason);
                     if not Allow then
                        if Reason = Tedex_Util.Deny_Bad_Password then
                           Log ("auth " & User & " from " & Peer
                                & ": bad password");
                           CSend (C, "ERR bad password");
                        else
                           CSend (C, "ERR account stopped");
                        end if;
                        Close_Quiet (Sock);
                        return;
                     end if;
                  end;
               end;
               --  Disabled is already decided by Auth_Verdict above
               --  (Allow implies not Disabled); no second check here.
               if Req.Kind = Tedex_Protocol.Auth_Device then
                  declare
                     Dev : constant String := Req.Dev (1 .. Req.Dev_Len);
                     Dev_Ok : constant Boolean :=
                        Tedex_Protocol.Valid_Token (Dev);
                     Replaced_Sock : Socket_Type := No_Socket;
                  begin
                     if not Dev_Ok then
                        CSend (C, "ERR bad device id");
                        Close_Quiet (Sock);
                        return;
                     end if;
                     Tedex_DB.Touch_Device (To_String (DB_Path), User, Dev);
                     --  Strict duplicate-name policy: same (user, dev) may
                     --  exist only once (idle or attached/busy). Second
                     --  registration is rejected so one machine cannot kick
                     --  another by reusing its name. Reconnect after a real
                     --  disconnect still works because Unreg/Drop clears it.
                     declare
                        Dup_Sock : Socket_Type := No_Socket;
                        Dup_Ws   : Boolean := False;
                        Dup_Found : Boolean := False;
                     begin
                        Registry.Find_Dev_Sock (User, Dev,
                                                Dup_Sock, Dup_Ws, Dup_Found);
                        if Dup_Found or else Registry.Is_Attached (User, Dev) then
                           CSend (C, "ERR device id in use");
                           Close_Quiet (Sock);
                           return;
                        end if;
                     end;
                     if Registry.Count_Dev (User)
                       + Registry.Count_Attached (User)
                       >= Acc.Limit
                     then
                        CSend (C, "ERR device limit reached ("
                               & Tedex_Protocol.Nat_Image (Acc.Limit) & ")");
                        Close_Quiet (Sock);
                        return;
                     end if;
                     Registry.Reg_Dev
                       (User, Dev,
                        Peer,
                        Ada.Calendar.Formatting.Image (Ada.Calendar.Clock),
                        Sock, Use_Ws, Replaced_Sock);
                     --  Replaced_Sock is No_Socket under the strict policy
                     --  above (kept only as safety for races).
                     if Replaced_Sock /= No_Socket then
                        Close_Quiet (Replaced_Sock);
                     end if;
                     CSend (C, "OK device-registered " & Dev);
                     Log ("device up: " & User & "/" & Dev & " from " & Peer);
                     Handle_Device (C, User, Dev);
                     Log ("device down: " & User & "/" & Dev);
                  end;
               else
                  CSend (C, "OK manager " & User);
                  Log ("manager login: " & User & " from " & Peer);
                  Handle_Manager (C, User);
                  Close_Quiet (Sock);
               end if;
            end;
         end;
      end;
   exception
      when Tedex_DB.DB_Error =>
         --  Transient store failure (lock contention under burst):
         --  NEVER report it as unknown-user/bad-password, which
         --  clients treat as permanent deprovisioning. Tell them to
         --  retry with backoff instead.
         Log ("auth from " & Peer & ": store busy, sent retry");
         begin
            CSend (C, "ERR busy, retry");
         exception
            when Net_Error => null;
         end;
         Close_Quiet (Sock);
      when Net_Error =>
         Close_Quiet (Sock);
   end Handle_Connection;

   task type Session is
      entry Start (S : Socket_Type; P : Unbounded_String);
   end Session;

   type Session_Ptr is access Session;
   --  Library-level access type: tasks created through it do not block
   --  the accept loop on master completion (declared-block access types
   --  would serialize all connections).

   task body Session is
      Sock : Socket_Type;
      Peer : Unbounded_String;
   begin
      accept Start (S : Socket_Type; P : Unbounded_String) do
         Sock := S;
         Peer := P;
      end Start;
      Handle_Connection (Sock, To_String (Peer));
   exception
      when E : others =>
         Log ("session " & To_String (Peer) & " ended: "
              & Ada.Exceptions.Exception_Information (E));
         Close_Quiet (Sock);
   end Session;

   task Poller;

   task body Poller is
      DB : Tedex_DB.Acct_Vectors.Vector;
   begin
      loop
         delay 2.0;
         begin
            DB := Tedex_DB.Load (To_String (DB_Path));
            declare
               Users : constant Str_Vec.Vector := Registry.All_Users;
            begin
               for U of Users loop
                  declare
                     Ix : constant Natural :=
                       Tedex_DB.Find (DB, To_String (U));
                  begin
                     if Ix = 0 then
                        declare
                           Dropped : Natural;
                        begin
                           Registry.Drop_User (To_String (U), Dropped);
                           if Dropped > 0 then
                              Log ("drop removed user " & To_String (U));
                           end if;
                        end;
                     else
                        declare
                           Acc : constant Tedex_Store.Account :=
                             Tedex_DB.Acct_Vectors.Element (DB, Ix);
                           Dropped : Natural;
                        begin
                           if Acc.Disabled then
                              Registry.Drop_User (To_String (U), Dropped);
                              if Dropped > 0 then
                                 Log ("drop stopped user " & To_String (U));
                              end if;
                           else
                              declare
                                 Vic : Unbounded_String :=
                                   Null_Unbounded_String;
                              begin
                                 Registry.Trim_User
                                   (To_String (U), Acc.Limit, Dropped, Vic);
                                 if Dropped > 0 then
                                    Log ("trim " & To_String (U) & "/"
                                         & To_String (Vic));
                                 end if;
                              end;
                           end if;
                        end;
                     end if;
                  end;
               end loop;
            end;
         exception
            when others => null;
         end;
      end loop;
   end Poller;

   Srv : Socket_Type;

begin
   Ignore_Sigpipe;
   DB_Path := To_Unbounded_String
     (Ada.Directories.Compose
        (Ada.Directories.Containing_Directory
           (Ada.Command_Line.Command_Name),
         "users.db"));
   declare
      use Ada.Command_Line;
      I : Natural := 1;
   begin
      while I <= Argument_Count loop
         declare
            A : constant String := Argument (I);
         begin
            if (A = "-p" or A = "--port") and then I < Argument_Count then
               Port := Integer'Value (Argument (I + 1));
               I := I + 2;
            elsif A = "--host" and then I < Argument_Count then
               Host := To_Unbounded_String (Argument (I + 1));
               I := I + 2;
            elsif A = "--db" and then I < Argument_Count then
               DB_Path := To_Unbounded_String (Argument (I + 1));
               I := I + 2;
            else
               Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,
                 "usage: server -p PORT [--host ADDR] [--db FILE]");
               return;
            end if;
         end;
      end loop;
   exception
      when Constraint_Error =>
         Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error, "bad port");
         return;
   end;
   if Port not in 1 .. 65_535 then
      Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error, "bad port");
      return;
   end if;
   Create_Socket (Srv);
   Set_Socket_Option (Srv, Socket_Level, (Reuse_Address, True));
   begin
      Bind_Socket (Srv, (Family => Family_Inet,
                         Addr   => (if To_String (Host) = "0.0.0.0"
                                    then Any_Inet_Addr
                                    else Inet_Addr (To_String (Host))),
                         Port   => Port_Type (Port)));
   exception
      when Socket_Error | Constraint_Error =>
         Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error, "cannot bind");
         return;
   end;
   Listen_Socket (Srv, 100);
   Log ("tedex server on " & To_String (Host) & ":"
        & Trim_Image (Natural (Port)) & " db=" & To_String (DB_Path));
   loop
      declare
         Acc       : Socket_Type := No_Socket;
         Peer_Addr : Sock_Addr_Type;
         Peer      : Unbounded_String := To_Unbounded_String ("?");
      begin
         Accept_Socket (Srv, Acc, Peer_Addr);
         Set_No_Delay (Acc);
         begin
            Peer := To_Unbounded_String (Image (Peer_Addr.Addr));
         exception
            when others => null;
         end;
         Log ("accept from " & To_String (Peer));
         --  Spawn after a successful accept: a failed accept must
         --  not orphan a task forever waiting at its Start entry.
         declare
            W : constant Session_Ptr := new Session;
         begin
            W.Start (Acc, Peer);
         end;
         Log ("rendezvous ok " & To_String (Peer));
      exception
         when E : others =>
            Log ("accept/handoff failed: "
                 & Ada.Exceptions.Exception_Information (E));
            if Acc /= No_Socket then
               Close_Quiet (Acc);
            end if;
      end;
   end loop;
end Server;
