--  Display-side echo-suppression decisions for the manager attach
--  relay. Boundary unit, explicitly SPARK_Mode => Off with rationale:
--  the fail-open rule below deliberately prefers a duplicated line over
--  eaten output bytes under timing ambiguity (typeahead colliding with
--  late output), which is a display-policy judgment, not a provable
--  functional contract; wire framing/parsing stay in the proved units.
--  Rationale for Off: depends on wall-clock-free but timing-tuned
--  policy (aged-expectation drop) and unbounded message shapes that
--  would drown the solvers for zero safety gain -- display text is
--  never trusted downstream. Verified instead by deterministic unit
--  tests in tests/echo_vectors.adb covering every historical shape
--  (exact echo, per-keystroke fragments, echo+glued output,
--  output/echo prefix collisions such as "ls" vs "lost+found",
--  bracket-prefixed variants, empty inputs).
package Tedex_Echo with SPARK_Mode => Off is

   --  Longest common prefix length of Pending and Msg, scanning from
   --  their first characters. Total on all inputs (empty-safe).
   function Common_Prefix (Pending, Msg : String) return Natural;

   --  Bracket framing at the head of Msg (readline redraw wrappers):
   --  8 for ESC[?2004l / ESC[?2004h, 9 when a framing CR follows,
   --  else 0. Total on all inputs.
   function Bracket_Pre (Msg : String) return Natural;

end Tedex_Echo;
