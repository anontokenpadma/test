--  Shared pure helpers extracted from boundary units (Net, Client,
--  Server, Admin) so they can be formally proved. Fully in SPARK.
--
--  What lives here: string normalization shared by the three historical
--  copies (Net Trimmed/To_Lower, Client Trim_Copy/Lower_In_Place,
--  Manager Stripped/Lowered), hex encoding shared by Client Rand_Hex and
--  Admin Random_Hex, the DEVICES counter, ws[s]:// URL parsing, manager
--  verb splitting, the WebSocket accept-key check shared by the
--  socket and TLS-pipe transports, the server auth verdict, jittered
--  reconnect backoff, resize forwarding, and the attach predictor
--  predicates. All inputs that are slices use First = 1 normalization
--  (same boundary obligation as Tedex_Protocol); total functions state
--  it explicitly by having no Pre on bounds.
--
--  Deliberately NOT here (stays Off with rationale at each caller):
--  * sqlite C bindings, sockets, poll, tasking, protected Registry;
--  * /dev/urandom reads, wall clock, file IO, openssl subprocess;
--  * Unbounded_String flows (heap): callers convert at the boundary;
--  * debug-only Hex_Of (unbounded trace input, best-effort by design);
--  * manager LIST display shaping (display-only, fail-open already).
with Tedex_Protocol;

package Tedex_Util with SPARK_Mode is

   Max_Trim   : constant := 8192;  --  longest single line we normalize
   Max_Hex_In : constant := 64;    --  hex-encode input cap (salts/keys)
   Max_Url    : constant := 512;   --  ws[s]:// URL cap (fail-closed above)
   Max_Host   : constant := 255;   --  DNS names fit; longer is rejected
   Max_Path   : constant := 255;
   Max_Cmd    : constant := 1024;  --  manager prompt line cap

   function Fold_Char (C : Character) return Character
     with Post => Fold_Char'Result =
                    (if C in 'A' .. 'Z'
                     then Character'Val (Character'Pos (C) + 32)
                     else C),
          Global => null,
          Depends => (Fold_Char'Result => C);

   procedure To_Lower (S : in out String)
     with Post => S'Length = S'Old'Length
                  and (for all I in S'Range =>
                         S (I) = Fold_Char (S'Old (I))),
          Global => null,
          Depends => (S => S);

   --  NOTE: and-then (not and) below: the index arithmetic
   --  B-First + I is only safe once equal lengths are known.
   function Folded_Equal (A, B : String) return Boolean
     with Post => Folded_Equal'Result =
                    (A'Length = B'Length
                     and then (for all I in 0 .. A'Length - 1 =>
                            Fold_Char (A (A'First + I)) =
                            Fold_Char (B (B'First + I)))),
          Global => null,
          Depends => (Folded_Equal'Result => (A, B));
   --  Case-insensitive equality, bounds-independent (header names).

   function Trim_Blanks (S : String) return String
     with Pre  => S'Length <= Max_Trim,
          Post => Trim_Blanks'Result'Length <= S'Length
                  and (Trim_Blanks'Result'Length = 0
                       or Trim_Blanks'Result'First = 1),
          Global => null,
          Depends => (Trim_Blanks'Result => S);
   --  Strip ' ', HT, CR, LF on both ends (the exact set of the three
   --  historical copies: leading space/HT, trailing also CR/LF).
   --  Empty/all-blank input gives "".

   function Encode_Hex (Data : String) return String
     with Pre  => Data'First = 1 and Data'Length in 1 .. Max_Hex_In,
          Post => Encode_Hex'Result'Length = 2 * Data'Length
                  and Encode_Hex'Result'First = 1
                  and (for all C of Encode_Hex'Result =>
                         C in '0' .. '9' or C in 'a' .. 'f'),
          Global => null,
          Depends => (Encode_Hex'Result => Data);

   function Parse_Count (S : String) return Natural
     with Post => Parse_Count'Result <= 999_999,
          Global => null,
          Depends => (Parse_Count'Result => S);
   --  Total function: 0 on empty/non-digit/overlong/overflow input.

   procedure Parse_Ws_Url (Url       : String;
                           Secure    : out Boolean;
                           WHost     : out String;
                           WHost_Len : out Natural;
                           WPort     : out Natural;
                           WPath     : out String;
                           WPath_Len : out Natural;
                           Ok        : out Boolean)
     with Pre  => Url'First = 1 and Url'Length <= Max_Url
                  and WHost'First = 1 and WHost'Length >= Max_Host
                  and WPath'First = 1 and WPath'Length >= Max_Path,
          Post => (if Ok then WHost_Len in 1 .. Max_Host
                              and WHost_Len <= WHost'Length
                              and WPort in 1 .. 65_535
                              and WPath_Len in 1 .. Max_Path
                              and WPath_Len <= WPath'Length
                              and WPath (WPath'First) = '/'
                   else WHost_Len = 0 and WPort = 0 and WPath_Len = 0),
          Global => null,
          Depends => (Secure     => Url,
                      WHost      => (Url, WHost),
                      WHost_Len  => Url,
                      WPort      => Url,
                      WPath      => (Url, WPath),
                      WPath_Len  => Url,
                      Ok         => Url);
   --  Parse ws://host[:port][/path] (default port 80, default path
   --  "/tedex") and wss:// (default 443). Port field allows surrounding
   --  blanks and one leading '+' like Integer'Value; anything else is a
   --  shape error. Overlong URL/host/path is fail-closed (Ok = False
   --  with zeroed outputs, single commit point like Parse_Resize).

   procedure Split_Verb (Cmd      : String;
                         Verb     : out String;
                         Verb_Len : out Natural;
                         Arg      : out String;
                         Arg_Len  : out Natural)
     with Pre  => Cmd'First = 1 and Cmd'Length <= Max_Cmd
                  and Verb'First = 1 and Verb'Length >= Max_Cmd
                  and Arg'First = 1 and Arg'Length >= Max_Cmd,
          Post => Verb_Len <= Max_Cmd and Verb_Len <= Verb'Length
                  and Arg_Len <= Max_Cmd and Arg_Len <= Arg'Length
                  and (for all C of Verb (1 .. Verb_Len) =>
                         C not in 'A' .. 'Z'),
          Global => null,
          Depends => (Verb     => (Cmd, Verb),
                      Verb_Len => Cmd,
                      Arg      => (Cmd, Arg),
                      Arg_Len  => Cmd);
   --  Split "verb arg" on space/HT; verb is lowercased, arg is
   --  blank-stripped (' ', HT, CR). Empty verb means blank input.

   type Hs_Outcome is (Hs_Ok, Hs_Bad_Status, Hs_Bad_Key);

   function Check_Handshake (Resp, Want : String) return Hs_Outcome
     with Pre  => Resp'First = 1 and Resp'Length <= Max_Trim
                  and Want'First = 1 and Want'Length in 1 .. 128,
          Global => null,
          Depends => (Check_Handshake'Result => (Resp, Want));
   --  Client-side 101 validation shared by the socket and TLS-pipe
   --  transports (same accept/reject behavior as the two historical
   --  copies): bad status line -> Hs_Bad_Status ("handshake rejected"),
   --  missing accept key -> Hs_Bad_Key ("bad accept key").

   type Hs_Action is (Act_Accept, Act_Reject_Status, Act_Reject_Key);
   --  Transport action for one 101 validation outcome.

   procedure Hs_Verdict (Res : Hs_Outcome; Act : out Hs_Action)
     with Post => (Act = Act_Accept) = (Res = Hs_Ok)
                  and (Act = Act_Reject_Status) = (Res = Hs_Bad_Status)
                  and (Act = Act_Reject_Key) = (Res = Hs_Bad_Key),
          Global => null,
          Depends => (Act => Res);
   --  Total outcome mapping (boundary raise sites stay with callers).

   procedure Ws_Url_Head (Url : String;
                          Buf : out String; Len : out Natural;
                          Ok  : out Boolean)
     with Pre  => Buf'First = 1 and Buf'Length >= Max_Url,
          Post => (if Ok then Len = Url'Length
                           and Buf (1 .. Len) = Url
                    else Len = 0)
                  and (Ok = (Url'First = 1 and Url'Length <= Max_Url)),
          Global => null,
          Depends => ((Len, Ok) => Url, Buf =>+ Url);
   --  Normalize a ws[s]:// URL head into Buf for the proved
   --  Parse_Ws_Url (total: every input maps to Ok or fail-closed).

   type Auth_Deny is (Deny_None, Deny_Bad_Password, Deny_Stopped);

   procedure Auth_Verdict (Pass_Ok, Is_Device, Key_Ok, Disabled : Boolean;
                           Allow   : out Boolean;
                           Reason  : out Auth_Deny)
     with Post => (Allow = ((Pass_Ok or (Is_Device and Key_Ok))
                             and not Disabled))
                 and (if Allow then Reason = Deny_None
                      elsif not (Pass_Ok or (Is_Device and Key_Ok)) then
                        Reason = Deny_Bad_Password
                      else Reason = Deny_Stopped),
          Global => null,
          Depends => ((Allow, Reason) => (Pass_Ok, Is_Device, Key_Ok,
                                          Disabled));
   --  Single commit point for the login decision (password first, then
   --  disabled): a device enrollment key can never grant manager power,
   --  and a stopped account is reported distinctly from a bad password.

   function Jittered_Backoff (Failures, Rand_Byte : Natural) return Natural
     with Pre  => Failures >= 1 and Rand_Byte <= 255,
          Post => Jittered_Backoff'Result in 5 .. 65
                  and Jittered_Backoff'Result =
                    Tedex_Protocol.Backoff_Secs (Failures)
                    + (Rand_Byte mod 6),
          Global => null,
          Depends => (Jittered_Backoff'Result => (Failures, Rand_Byte));
   --  Backoff_Secs plus 0..5 s jitter (fleet anti-herd). Total on its
   --  domain; callers cap Failures and floor the random byte at 0 when
   --  /dev/urandom is unreadable. Exact decomposition is proved
   --  (Colibri2 interval+mod propagation); the range follows from it.

   function Should_Forward_Resize (Pend_Dev, A : String;
                                   Cols, Rows : Natural) return Boolean
     with Post => Should_Forward_Resize'Result =
                    (Pend_Dev'Length in 1 .. Tedex_Protocol.Max_Dev
                     and Pend_Dev = A
                     and Cols in 1 .. 1000 and Rows in 1 .. 1000),
          Global => null,
          Depends => (Should_Forward_Resize'Result =>
                        (Pend_Dev, A, Cols, Rows));
   --  Forward a stashed RESIZE only when it names this ATTACH target
   --  with in-range dims, so a stale size never leaks across devices.

   function Tail_Blank (S : String) return Boolean
     with Post => Tail_Blank'Result =
                    (S'Length >= 4
                     and then S (S'Last - 3) = ASCII.CR
                     and then S (S'Last - 2) = ASCII.LF
                     and then S (S'Last - 1) = ASCII.CR
                     and then S (S'Last) = ASCII.LF),
          Global => null,
          Depends => (Tail_Blank'Result => S);
   --  Total function: end-of-headers marker for the pipe handshake.

   function Is_Predict_Byte (B : Character) return Boolean
     with Post => Is_Predict_Byte'Result =
                    (Character'Pos (B) >= 32
                     and Character'Pos (B) /= 127
                     and B /= ASCII.ESC),
          Global => null,
          Depends => (Is_Predict_Byte'Result => B);
   --  Printable keystrokes safe for predictive echo (never ESC/DEL).

   function Has_Newline (S : String) return Boolean
     with Post => Has_Newline'Result =
                    (for some C of S =>
                       C = ASCII.CR or C = ASCII.LF),
          Global => null,
          Depends => (Has_Newline'Result => S);

   function Low_Contains (Haystack, Needle : String) return Boolean
     with Post => (if Low_Contains'Result then
                     Needle'Length > 0
                     and Haystack'Length >= Needle'Length),
          Global => null,
          Depends => (Low_Contains'Result => (Haystack, Needle));
   --  Case-insensitive substring (password-prompt/fullscreen sensing).
   --  Empty needle or short haystack never matches (fail-dark: secrets
   --  stay hidden); full equivalence is pinned by unit tests.

   function Service_Unit_Name (Dev : String) return String
     with Pre  => Tedex_Protocol.Valid_Token (Dev),
          Post => Service_Unit_Name'Result'Length = Dev'Length + 14
                  and Service_Unit_Name'Result'First = 1,
          Global => null,
          Depends => (Service_Unit_Name'Result => Dev);
   --  "tedex-<dev>.service" (6 + 8 fixed chars around the device id).

   --  Decimal printing parses back (ghost): div/mod round-trip over the
   --  Nat_Image digit loop and the Parse_Count accumulator, for the
   --  Colibri2 interval + Z3/CVC5 div-mod portfolio.
   function Nat_Parse_Roundtrip (N : Natural) return Boolean
     with Ghost,
          Pre  => N <= 999_999,
          Post => Nat_Parse_Roundtrip'Result =
                    (Parse_Count (Tedex_Protocol.Nat_Image (N)) = N),
          Global => null;

   Max_Poll_Buf : constant := 32_768;  --  shell drain chunk (Tedex_Shell)

   type Poll_Outcome is (Outcome_Data, Outcome_Empty, Outcome_Closed);
   --  Classification of one pty drain return code.

   procedure Poll_Slice (Rc : Integer; Buf_Last : Natural;
                         Lo : out Natural; Hi : out Natural;
                         Oc : out Poll_Outcome)
     with Pre  => Buf_Last in 1 .. Max_Poll_Buf and Rc <= Buf_Last,
          Post => (if Oc = Outcome_Data then Lo = 1 and Hi in 1 .. Buf_Last)
                  and (if Oc /= Outcome_Data then Lo = 0 and Hi = 0)
                  and (if Rc > 0 then Oc = Outcome_Data)
                  and (if Rc = 0 then Oc = Outcome_Empty)
                  and (if Rc < 0 then Oc = Outcome_Closed),
          Global => null,
          Depends => ((Lo, Hi, Oc) => Rc, null => Buf_Last);
   --  Slice bounds for a drain buffer of length Buf_Last holding Rc new
   --  bytes (any negative Rc means the shell is gone). Total: every Rc
   --  maps to an outcome, so boundary callers carry no obligation.

end Tedex_Util;
