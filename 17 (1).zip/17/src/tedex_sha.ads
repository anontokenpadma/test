--  SHA-256 primitive, fully in SPARK (body in tedex_sha.adb is proved).
--  Was a GNAT.SHA256 wrapper (body Off, contract trusted); now a pure
--  modular-arithmetic implementation so callers rest on proved code.
package Tedex_SHA with SPARK_Mode is

   SHA_Hex_Len : constant := 64;

   --  Lowercase-hex digest of S. The contract pins the shape (64 chars,
   --  all lowercase hex); the exact FIPS 180-4 value is checked against
   --  GNAT.SHA256 by the test vectors ship-with validation.
   function Digest (S : String) return String
     with Pre    => S'Length <= 512 and S'First = 1,
          Post   => Digest'Result'Length = SHA_Hex_Len
                    and Digest'Result'First = 1
                    and (for all C of Digest'Result =>
                           C in '0' .. '9' or C in 'a' .. 'f'),
          Global => null;

end Tedex_SHA;
