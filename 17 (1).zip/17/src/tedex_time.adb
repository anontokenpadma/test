package body Tedex_Time with SPARK_Mode is

   function To_Timeout_Ms (Timeout : Duration) return Integer is
      Raw : Duration;
      Tr  : Integer;
   begin
      if Timeout <= Zero_Sec then
         return 0;
      end if;
      if Timeout > Cap_Sec then
         return Cap_Ms;
      end if;
      --  Raw is exact fixed-point in 0 .. 2.0e9, well inside both
      --  Duration and Integer.
      Raw := Timeout * 1000;
      Tr := Integer (Raw);
      if Raw - Duration (Tr) >= Half_Ms then
         return Tr + 1;
      else
         return Tr;
      end if;
   end To_Timeout_Ms;

end Tedex_Time;
