with Tedex_Util;

package body Tedex_Net_Pure with SPARK_Mode is

   function To_Elements (S : String) return Ada.Streams.Stream_Element_Array is
      use Ada.Streams;
      R : Stream_Element_Array (1 .. S'Length) := [others => 0];
   begin
      for I in S'Range loop
         pragma Loop_Invariant
           (for all J in S'First .. I - 1 =>
              R (Stream_Element_Offset (J - S'First + 1)) =
                Stream_Element (Character'Pos (S (J))));
         R (Stream_Element_Offset (I - S'First + 1)) :=
           Stream_Element (Character'Pos (S (I)));
      end loop;
      return R;
   end To_Elements;

   function To_String (B : Ada.Streams.Stream_Element_Array) return String is
      use Ada.Streams;
      R : String (1 .. B'Length) := [others => ASCII.NUL];
   begin
      for I in R'Range loop
         pragma Loop_Invariant
           (for all J in 1 .. I - 1 =>
              B (Stream_Element_Offset (J)) =
                Stream_Element (Character'Pos (R (J))));
         R (I) := Character'Val (B (Stream_Element_Offset (I)));
      end loop;
      return R;
   end To_String;

   function Is_Http_Get (Line : String) return Boolean is
     (Line'Length >= 4 and then Line (Line'First .. Line'First + 3) = "GET ");

   procedure Next_Line_Bounds (Buf : String; Pos : Natural;
                               Line_First : out Natural;
                               Line_Last  : out Natural;
                               Next_Pos   : out Natural) is
      LE : Natural;
   begin
      if Pos > Buf'Last then
         Line_First := 1;
         Line_Last  := 0;
         Next_Pos   := Pos;
         return;
      end if;
      LE := Pos;
      while LE <= Buf'Last and then Buf (LE) /= ASCII.LF loop
         pragma Loop_Invariant (LE in Pos .. Buf'Last + 1);
         pragma Loop_Invariant
           (for all I in Pos .. LE - 1 => Buf (I) /= ASCII.LF);
         pragma Loop_Variant (Decreases => Buf'Last - LE + 1);
         LE := LE + 1;
      end loop;
      Line_First := Pos;
      if LE <= Buf'Last then
         Line_Last := LE - 1;
      else
         Line_Last := Buf'Last;
      end if;
      Next_Pos := LE + 1;
   end Next_Line_Bounds;

   procedure Header_Parts (L     : String;
                           Name  : out String;
                           Name_Len : out Natural;
                           Value : out String;
                           Value_Len : out Natural;
                           Has_Colon : out Boolean) is
   begin
      Name_Len := 0;
      Value_Len := 0;
      Has_Colon := False;
      Name := [others => ' '];
      Value := [others => ' '];
      for I in L'Range loop
         pragma Loop_Invariant
           (for all J in L'First .. I - 1 => L (J) /= ':');
         if L (I) = ':' then
            Has_Colon := True;
            declare
               Nm : constant String :=
                 Tedex_Util.Trim_Blanks (L (L'First .. I - 1));
               Vl : constant String :=
                 Tedex_Util.Trim_Blanks (L (I + 1 .. L'Last));
            begin
               Name_Len := Nm'Length;
               Name (Name'First .. Name'First + Nm'Length - 1) := Nm;
               Value_Len := Vl'Length;
               Value (Value'First .. Value'First + Vl'Length - 1) := Vl;
            end;
            return;
         end if;
      end loop;
   end Header_Parts;

   procedure Request_Path (Line : String;
                           Path : out String;
                           Path_Len : out Natural) is
      Sp1 : constant Natural := Line'First + 4;
      Sp2 : Natural := Sp1;
   begin
      Path := [others => '/'];
      while Sp2 <= Line'Last and then Line (Sp2) /= ' ' loop
         pragma Loop_Invariant (Sp2 in Sp1 .. Line'Last + 1);
         pragma Loop_Invariant
           (for all I in Sp1 .. Sp2 - 1 => Line (I) /= ' ');
         pragma Loop_Variant (Decreases => Line'Last - Sp2 + 1);
         Sp2 := Sp2 + 1;
      end loop;
      if Sp2 > Sp1 then
         Path_Len := Sp2 - Sp1;
         Path (Path'First .. Path'First + Path_Len - 1) :=
           Line (Sp1 .. Sp2 - 1);
      else
         Path_Len := 1;
         Path (Path'First) := '/';
      end if;
   end Request_Path;

end Tedex_Net_Pure;
