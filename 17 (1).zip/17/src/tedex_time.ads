--  Millisecond timeout kernel extracted from Tedex_Net.Wait_One/Wait_Two.
--  Fully in SPARK. Mirrors the historical branches point-for-point:
--  non-positive -> 0, above Cap_Sec -> Cap_Ms, else the nearest
--  millisecond with halves rounded up, computed in exact fixed-point.
--  The former code rounded in binary floating point, so the two agree
--  up to an unavoidable 1 ms edge on exact halves -- immaterial for
--  poll deadlines, which callers re-check against their own clocks.
package Tedex_Time with SPARK_Mode is

   Zero_Sec : constant Duration := 0.0;
   Cap_Sec  : constant Duration := 2_000_000.0;
   Cap_Ms   : constant Integer  := 2_147_000;
   Half_Ms  : constant Duration := 0.0005;

   function To_Timeout_Ms (Timeout : Duration) return Integer
     with Post => To_Timeout_Ms'Result >= 0
                  and (if Timeout <= Zero_Sec then
                         To_Timeout_Ms'Result = 0)
                  and (if Timeout > Cap_Sec then
                         To_Timeout_Ms'Result = Cap_Ms)
                  and (if Timeout > Zero_Sec and Timeout <= Cap_Sec then
                         To_Timeout_Ms'Result = Integer (Timeout * 1000)
                         or To_Timeout_Ms'Result =
                            Integer (Timeout * 1000) + 1),
          Global => null,
          Depends => (To_Timeout_Ms'Result => Timeout);
   --  Total function: every Duration maps to a poll timeout in
   --  milliseconds, so boundary callers carry no proof obligation and
   --  see no new runtime check.

end Tedex_Time;
