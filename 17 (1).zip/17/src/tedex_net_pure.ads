--  Pure kernels extracted out of the boundary unit Tedex_Net so they can
--  be formally proved. Everything here is inside the SPARK subset (no
--  sockets, no poll, no tasking); Net calls these instead of keeping the
--  loops inline and unchecked. Covers byte conversions and the HTTP
--  request-line / header parsing used by the WebSocket server handshake.
with Ada.Streams;

package Tedex_Net_Pure with SPARK_Mode is

   use type Ada.Streams.Stream_Element;
   use type Ada.Streams.Stream_Element_Offset;

   Max_Conv : constant := 1_048_576;  --  one-message cap (matches Msg_Cap)
   Max_Hdr  : constant := 8192;       --  handshake request buffer cap

   --  String -> socket bytes, byte-for-byte (was Net.To_Elements inline).
   function To_Elements (S : String) return Ada.Streams.Stream_Element_Array
     with Pre  => S'First = 1 and S'Length <= Max_Conv,
          Post => To_Elements'Result'Length = S'Length
                  and To_Elements'Result'First = 1
                  and (for all I in S'Range =>
                         To_Elements'Result
                           (Ada.Streams.Stream_Element_Offset (I)) =
                         Ada.Streams.Stream_Element (Character'Pos (S (I)))),
          Global => null;

   --  Socket bytes -> String (was the inline Chunk/One conversions in Net).
   function To_String (B : Ada.Streams.Stream_Element_Array) return String
     with Pre  => B'First = 1 and B'Length <= Max_Conv,
          Post => To_String'Result'Length = B'Length
                  and To_String'Result'First = 1
                  and (for all I in To_String'Result'Range =>
                         B (Ada.Streams.Stream_Element_Offset (I)) =
                           Ada.Streams.Stream_Element
                             (Character'Pos (To_String'Result (I)))),
          Global => null;

   --  HTTP request-line / header parsing --------------------------------

   --  Request line starts with "GET ".
   function Is_Http_Get (Line : String) return Boolean
     with Pre  => Line'First = 1 and Line'Last <= Max_Hdr,
          Post => Is_Http_Get'Result = (Line'Last >= 4
                                        and then Line (1 .. 4) = "GET "),
          Global => null;

   --  Next LF-terminated line inside the handshake buffer. Buf is
   --  normalized to First = 1; Pos is the next scan position. The line is
   --  Buf (Line_First .. Line_Last) (empty when Line_Last < Line_First);
   --  Next_Pos is where the next call resumes. Line_First = 1/Line_Last = 0
   --  once Pos is past the end, exactly as Net's local Next_Line did.
   procedure Next_Line_Bounds (Buf : String; Pos : Natural;
                               Line_First : out Natural;
                               Line_Last  : out Natural;
                               Next_Pos   : out Natural)
     with Pre  => Buf'First = 1 and Buf'Last in 0 .. Max_Hdr
                  and Pos in 1 .. Max_Hdr + 1,
          Post => Line_Last <= Buf'Last
                  and Next_Pos <= Max_Hdr + 2
                  and (if Pos > Buf'Last
                       then Line_First = 1 and Line_Last = 0
                            and Next_Pos = Pos
                       else Line_First = Pos
                            and Line_Last >= Line_First - 1
                            and (for all I in Line_First .. Line_Last =>
                                   Buf (I) /= ASCII.LF)),
          Global => null;

   --  Split a trimmed header line at its first ':'. Has_Colon is False
   --  (with zeroed lengths) when there is none; otherwise Name/Value are
   --  the blank-trimmed parts around the colon. Same as Net's inline loop.
   procedure Header_Parts (L     : String;
                           Name  : out String;
                           Name_Len : out Natural;
                           Value : out String;
                           Value_Len : out Natural;
                           Has_Colon : out Boolean)
     with Pre  => L'First = 1 and L'Last <= Max_Hdr
                  and Name'First = 1 and Name'Last >= L'Last
                  and Value'First = 1 and Value'Last >= L'Last,
          Post => Name_Len <= L'Length and Name_Len <= Name'Length
                  and Value_Len <= L'Length and Value_Len <= Value'Length
                  and (if not Has_Colon
                       then Name_Len = 0 and Value_Len = 0),
          Global => null;

   --  Path from a "GET <path> HTTP/1.x" request line: chars after "GET "
   --  up to the next blank, or "/" when empty.
   procedure Request_Path (Line : String;
                           Path : out String;
                           Path_Len : out Natural)
     with Pre  => Line'First = 1 and Line'Last in 4 .. Max_Hdr
                  and Path'First = 1 and Path'Last >= Line'Last,
          Post => Path_Len in 1 .. Path'Length,
          Global => null;

end Tedex_Net_Pure;
