with Tedex_B64;
with Tedex_SHA1;

package body Tedex_Ws with SPARK_Mode is

   function Accept_Key (Client_Key : String) return String is
      Raw : constant String :=
        Tedex_SHA1.Digest20 (Client_Key & Ws_Guid);
   begin
      return Tedex_B64.Encode (Raw);
   end Accept_Key;

   procedure Encode_Frame (Payload : String;
                           Opcode  : Natural;
                           Frame   : out String;
                           Frame_Len : out Natural;
                           Fin     : Boolean := True) is
      N : constant Natural := Payload'Length;
   begin
      Frame := [others => ASCII.NUL];
      Frame (1) :=
        Character'Val ((if Fin then 128 else 0) + Opcode);
      if N < 126 then
         Frame (2) := Character'Val (N);
         Frame_Len := N + 2;
      else
         Frame (2) := Character'Val (126);
         Frame (3) := Character'Val (N / 256);
         Frame (4) := Character'Val (N mod 256);
         Frame_Len := N + 4;
      end if;
      Frame (((Frame_Len - N) + 1) .. Frame_Len) := Payload;
   end Encode_Frame;

   procedure Decode_Header (Data : String;
                            H    : out Frame_Header;
                            Ok   : out Boolean;
                            Require_Mask : Boolean := True) is
      B0, B1 : Natural range 0 .. 255;
      L7     : Natural range 0 .. 127;
      Ext    : Natural range 0 .. 8;
      Need   : Natural range 2 .. 14;
      V      : Long_Long_Integer range 0 .. Long_Long_Integer'Last := 0;
   begin
      H := (Fin => False, Opcode => 0, Pay_Len => 0, Hdr_Len => 2);
      Ok := False;
      B0 := Character'Pos (Data (1));
      B1 := Character'Pos (Data (2));
      H.Fin := B0 >= 128;
      H.Opcode := B0 mod 16;
      if (B0 / 16) mod 8 /= 0 then
         return;  --  RSV bits must be zero
      end if;
      if H.Opcode /= 0 and H.Opcode /= 1 and H.Opcode /= 2
        and H.Opcode /= 8 and H.Opcode /= 9 and H.Opcode /= 10
      then
         return;
      end if;
      if (B1 >= 128) /= Require_Mask then
         return;  --  mask bit must match the direction
      end if;
      L7 := B1 mod 128;
      if L7 < 126 then
         Ext := 0;
      elsif L7 = 126 then
         Ext := 2;
      else
         Ext := 8;
      end if;
      Need := (2 + Ext) + (if Require_Mask then 4 else 0);
      if Data'Length /= Need then
         return;
      end if;
      if L7 < 126 then
         H.Pay_Len := L7;
      elsif L7 = 126 then
         H.Pay_Len :=
           ((Character'Pos (Data (3)) * 256) + Character'Pos (Data (4)));
      else
         for I in 3 .. 10 loop
            pragma Loop_Invariant
              (V <= Long_Long_Integer (Msg_Cap) * 256 + 255);
            if V > Long_Long_Integer (Msg_Cap) then
               return;
            end if;
            V := (V * 256) + Long_Long_Integer (Character'Pos (Data (I)));
         end loop;
         if V > Long_Long_Integer (Msg_Cap) then
            return;
         end if;
         H.Pay_Len := Natural (V);
      end if;
      if H.Opcode >= 8
        and then (not H.Fin or else H.Pay_Len > 125)
      then
         return;  --  control frames: final fragment, tiny payload
      end if;
      H.Hdr_Len := Need;
      Ok := True;
   end Decode_Header;

   procedure Xor_Mask (Data : in out String; Mask : String) is
   begin
      for I in Data'Range loop
         pragma Loop_Invariant
           (for all J in Data'First .. I - 1 =>
              Data (J) = Masked_Byte
                (Data'Loop_Entry (J), Mask, J - Data'First + 1));
         Data (I) :=
           Masked_Byte (Data (I), Mask, I - Data'First + 1);
      end loop;
   end Xor_Mask;

   procedure Encode_Client_Frame (Payload : String;
                                  Opcode  : Natural;
                                  Mask    : String;
                                  Frame   : out String;
                                  Frame_Len : out Natural;
                                  Fin     : Boolean := True) is
      N : constant Natural := Payload'Length;
      Hdr : Natural range 6 .. 8;
      Masked : String (1 .. Max_Frame_Payload) := [others => ASCII.NUL];
   begin
      Frame := [others => ASCII.NUL];
      Frame (1) :=
        Character'Val ((if Fin then 128 else 0) + Opcode);
      if N < 126 then
         Frame (2) := Character'Val (128 + N);
         Hdr := 6;
      else
         Frame (2) := Character'Val (128 + 126);
         Frame (3) := Character'Val (N / 256);
         Frame (4) := Character'Val (N mod 256);
         Hdr := 8;
      end if;
      Frame ((Hdr - 3) .. Hdr) := Mask;
      Masked (1 .. N) := Payload;
      Xor_Mask (Masked (1 .. N), Mask);
      Frame ((Hdr + 1) .. (Hdr + N)) := Masked (1 .. N);
      Frame_Len := Hdr + N;
   end Encode_Client_Frame;

   function Xor_Twice (X, M : U8) return U8 is
     (((X xor M) xor M));

   function Masked_Byte (C : Character; Mask : String; I : Positive)
     return Character is
     (Character'Val
        (Natural (U8 (Character'Pos (C))
                 xor U8 (Character'Pos (Mask (((I - 1) mod 4) + 1))))));

   procedure Xor_Twice_Restores (Data : in out String; Mask : String) is
   begin
      Xor_Mask (Data, Mask);
      Xor_Mask (Data, Mask);
   end Xor_Twice_Restores;

   function Xor_Holds (X, M : U8) return Boolean is
     (((X xor M) xor M) = X);

   procedure Frame_Header_Roundtrip (Payload : String; Opcode : Natural) is
      Buf : String (1 .. 10 + Max_Frame_Payload) := [others => ASCII.NUL];
      FL  : Natural;
      H   : Frame_Header;
      Ok  : Boolean;
   begin
      Encode_Frame (Payload, Opcode, Buf, FL);
      if Payload'Length < 126 then
         --  Staged for the solvers: header bytes first (direct Encode
         --  post instances), then the Decode verdict built from them.
         pragma Assert (Buf (1) = Character'Val (128 + Opcode));
         pragma Assert (Buf (2) = Character'Val (Payload'Length));
         --  Guard bisection: each Decode early-exit guard, so the failing
         --  conjunct (not just "Ok") is reported.
         pragma Assert (((Character'Pos (Buf (1)) / 16) mod 8) = 0);
         pragma Assert (Character'Pos (Buf (1)) mod 16 = Opcode);
         pragma Assert ((Character'Pos (Buf (2)) >= 128) = False);
         Decode_Header (Buf (1 .. 2), H, Ok, Require_Mask => False);
         pragma Assert (Ok and H.Pay_Len = Payload'Length
                        and H.Opcode = Opcode and H.Fin
                        and H.Hdr_Len = 2);
      else
         pragma Assert (Buf (1) = Character'Val (128 + Opcode));
         pragma Assert (Buf (2) = Character'Val (126));
         pragma Assert (Buf (3) =
           Character'Val (Payload'Length / 256));
         pragma Assert (Buf (4) =
           Character'Val (Payload'Length mod 256));
         pragma Assert (((Character'Pos (Buf (1)) / 16) mod 8) = 0);
         pragma Assert (Character'Pos (Buf (1)) mod 16 = Opcode);
         pragma Assert ((Character'Pos (Buf (2)) >= 128) = False);
         pragma Assert (Character'Pos (Buf (3)) * 256
                       + Character'Pos (Buf (4)) = Payload'Length);
         Decode_Header (Buf (1 .. 4), H, Ok, Require_Mask => False);
         pragma Assert (Ok and H.Pay_Len = Payload'Length
                        and H.Opcode = Opcode and H.Fin
                        and H.Hdr_Len = 4);
      end if;
   end Frame_Header_Roundtrip;

end Tedex_Ws;
