package body Tedex_B64 with SPARK_Mode is

   function Encode (Data : String) return String is
      Alphabet : constant String (1 .. 64) :=
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      N      : constant Natural := Data'Length;
      Groups : constant Natural := (N + 2) / 3;
      Outp   : String (1 .. B64_Max_Out) := [others => 'A'];
      O      : Natural range 0 .. B64_Max_Out := 0;
      C0, C1, C2 : Natural range 0 .. 255;
      V      : Natural range 0 .. 16_777_215;
   begin
      for G in 0 .. Groups - 1 loop
         pragma Loop_Invariant (O = 4 * G);
         declare
            J : constant Integer range 1 .. B64_Max_In := (3 * G) + 1;
            Blk : String (1 .. 4) := [others => 'A'];
         begin
            C0 := (if J <= N then Character'Pos (Data (J)) else 0);
            C1 := (if (J + 1) <= N then Character'Pos (Data (J + 1)) else 0);
            C2 := (if (J + 2) <= N then Character'Pos (Data (J + 2)) else 0);
            V := ((C0 * 65_536) + (C1 * 256)) + C2;
            Blk (1) := Alphabet ((V / 262_144) + 1);
            Blk (2) := Alphabet (((V / 4_096) mod 64) + 1);
            Blk (3) :=
              (if (J + 1) <= N then Alphabet ((((V / 64) mod 64)) + 1) else '=');
            Blk (4) :=
              (if (J + 2) <= N then Alphabet ((V mod 64) + 1) else '=');
            Outp ((O + 1) .. (O + 4)) := Blk;
            O := O + 4;
         end;
      end loop;
      return Outp (1 .. O);
   end Encode;

end Tedex_B64;
