--  SHA-1 binary digest, fully in SPARK (body in tedex_sha1.adb is proved).
--  Was a GNAT.SHA1 wrapper (body Off, contract trusted by Ws.Accept_Key);
--  now a pure modular-arithmetic implementation.
--  Needed for the WebSocket handshake.
package Tedex_SHA1 with SPARK_Mode is

   SHA1_Bytes : constant := 20;

   function Digest20 (S : String) return String
     with Pre    => S'Length <= 128 and S'First = 1,
          Post   => Digest20'Result'Length = SHA1_Bytes
                    and Digest20'Result'First = 1,
          Global => null;

end Tedex_SHA1;
