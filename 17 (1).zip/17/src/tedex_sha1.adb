--  SHA-1, implemented in pure SPARK (FIPS 180-4).
--  Replaces the former GNAT.SHA1 wrapper (SPARK_Mode => Off), whose
--  contract was trusted by Tedex_Ws.Accept_Key. Modular arithmetic only,
--  so the body is inside the SPARK subset and its contract is proved.
with Interfaces;

package body Tedex_SHA1 with SPARK_Mode is

   subtype Word is Interfaces.Unsigned_32;
   use type Interfaces.Unsigned_32;
   use type Interfaces.Unsigned_64;

   Max_Input  : constant := 128;                 --  spec Pre bound
   Block_Len  : constant := 64;
   Max_Blocks : constant := 3;                   --  ceil((128 + 9) / 64)
   Max_Padded : constant := Max_Blocks * Block_Len;  --  192

   function Rotl (X : Word; N : Natural) return Word
     with Pre  => N in 1 .. 31,
          Global => null;
   function Rotl (X : Word; N : Natural) return Word is
     (Interfaces.Rotate_Left (X, N));

   function F (T : Natural; B, C, D : Word) return Word
     with Pre  => T <= 79,
          Global => null;
   function F (T : Natural; B, C, D : Word) return Word is
     (if T < 20 then (B and C) or ((not B) and D)
      elsif T < 40 then B xor C xor D
      elsif T < 60 then (B and C) or (B and D) or (C and D)
      else B xor C xor D);

   function Kc (T : Natural) return Word
     with Pre  => T <= 79,
          Global => null;
   function Kc (T : Natural) return Word is
     (if T < 20 then 16#5a827999#
      elsif T < 40 then 16#6ed9eba1#
      elsif T < 60 then 16#8f1bbcdc#
      else 16#ca62c1d6#);

   procedure Pad (S : String; Buf : out String; Padded : out Natural)
     with Pre  => S'First = 1 and S'Length <= Max_Input
                  and Buf'First = 1 and Buf'Length >= Max_Padded,
          Post => Padded in 64 .. Max_Padded and Padded mod Block_Len = 0,
          Global => null;
   procedure Pad (S : String; Buf : out String; Padded : out Natural) is
      L      : constant Natural := S'Length;
      Blocks : constant Natural := (L + 9 + (Block_Len - 1)) / Block_Len;
      P      : constant Natural := Blocks * Block_Len;
      Bitlen : constant Interfaces.Unsigned_64 :=
        Interfaces.Unsigned_64 (L) * 8;
   begin
      Buf := [others => ASCII.NUL];
      for I in 1 .. L loop
         pragma Loop_Invariant (for all J in 1 .. I - 1 => Buf (J) = S (J));
         Buf (I) := S (I);
      end loop;
      Buf (L + 1) := Character'Val (128);
      for I in 0 .. 7 loop
         pragma Loop_Invariant (P - I >= 1);
         Buf (P - I) := Character'Val
           (Natural (Interfaces.Shift_Right (Bitlen, 8 * I) and 16#FF#));
      end loop;
      Padded := P;
   end Pad;

   function Read_Word (Buf : String; Pos : Natural) return Word
     with Pre  => Buf'First = 1 and Buf'Length >= 4 and Pos <= Buf'Length - 4,
          Global => null;
   function Read_Word (Buf : String; Pos : Natural) return Word is
     (Word (Character'Pos (Buf (Pos + 1))) * 16#0100_0000#
      + Word (Character'Pos (Buf (Pos + 2))) * 16#0001_0000#
      + Word (Character'Pos (Buf (Pos + 3))) * 16#0000_0100#
      + Word (Character'Pos (Buf (Pos + 4))));

   function Byte_At (X : Word; N : Natural) return Character
     with Pre  => N in 0 .. 3,
          Post => Byte_At'Result =
                    Character'Val (Natural
                       (Interfaces.Shift_Right (X, (3 - N) * 8) and 16#FF#)),
          Global => null;
   --  N = 0 selects the most significant byte.
   function Byte_At (X : Word; N : Natural) return Character is
     (Character'Val (Natural
        (Interfaces.Shift_Right (X, (3 - N) * 8) and 16#FF#)));

   function Digest20 (S : String) return String is
      Buf    : String (1 .. Max_Padded);
      Padded : Natural;
      W      : array (0 .. 79) of Word := [others => 0];
      H      : array (0 .. 4) of Word :=
        [16#67452301#, 16#efcdab89#, 16#98badcfe#,
         16#10325476#, 16#c3d2e1f0#];
      Blocks : Natural;
      R      : String (1 .. SHA1_Bytes) := [others => ASCII.NUL];
      A, B, C, D, E, Tmp : Word;
   begin
      Pad (S, Buf, Padded);
      Blocks := Padded / Block_Len;
      for Blk in 0 .. Blocks - 1 loop
         pragma Loop_Invariant (Blk * Block_Len + Block_Len <= Padded);
         declare
            Base : constant Natural := Blk * Block_Len;
         begin
            for T in 0 .. 15 loop
               pragma Loop_Invariant (Base + 4 * T + 4 <= Buf'Length);
               pragma Loop_Invariant
                 (for all U in 0 .. T - 1 => W (U) = Read_Word (Buf, Base + 4 * U));
               W (T) := Read_Word (Buf, Base + 4 * T);
            end loop;
         end;
         for T in 16 .. 79 loop
            pragma Loop_Invariant
              (for all U in 16 .. T - 1 =>
                 W (U) = Rotl (W (U - 3) xor W (U - 8)
                               xor W (U - 14) xor W (U - 16), 1));
            W (T) := Rotl (W (T - 3) xor W (T - 8)
                           xor W (T - 14) xor W (T - 16), 1);
         end loop;
         A := H (0); B := H (1); C := H (2); D := H (3); E := H (4);
         for T in 0 .. 79 loop
            Tmp := Rotl (A, 5) + F (T, B, C, D) + E + Kc (T) + W (T);
            E := D; D := C; C := Rotl (B, 30); B := A; A := Tmp;
         end loop;
         H (0) := H (0) + A; H (1) := H (1) + B; H (2) := H (2) + C;
         H (3) := H (3) + D; H (4) := H (4) + E;
      end loop;
      for I in 0 .. 4 loop
         for N in 0 .. 3 loop
            R (4 * I + N + 1) := Byte_At (H (I), N);
         end loop;
      end loop;
      return R;
   end Digest20;

end Tedex_SHA1;
