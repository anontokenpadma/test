with Ada.Calendar;
with Ada.Exceptions;
with Ada.Streams;
with Ada.Streams.Stream_IO;
with Interfaces.C;
with Tedex_Ws;
with Tedex_Tls;
with Tedex_Util;
with Tedex_Net_Pure;
with Tedex_Time;

package body Tedex_Net with SPARK_Mode => Off is

   use GNAT.Sockets;
   use Ada.Streams;
   use type Interfaces.C.int;

   --  Inbound-pong tally shared by every socket task in the process.
   --  Protected: the server runs one reader task per connection.
   protected Pong_Track is
      procedure Note;
      function Count return Natural;
   private
      N : Natural := 0;
   end Pong_Track;

   protected body Pong_Track is
      procedure Note is
      begin
         if N < Natural'Last then
            N := N + 1;
         end if;
      end Note;
      function Count return Natural is (N);
   end Pong_Track;

   procedure Ws_Pong_Count (Count : out Natural) is
   begin
      Count := Pong_Track.Count;
   end Ws_Pong_Count;

   function Sock_Fd (Sock : Socket_Type) return Interfaces.C.int is
   begin
      return Interfaces.C.int (To_C (Sock));
   end Sock_Fd;

   --  Poll-based readability wait (no FD_SETSIZE limit, unlike select).
   --  True = readable, False = timed out. Raises Net_Error on fd errors.
   function Wait_One (Fd : Interfaces.C.int; Timeout : Duration)
     return Boolean
   is
      Ms : constant Integer := Tedex_Time.To_Timeout_Ms (Timeout);
      Rc : Interfaces.C.int;
   begin
      Rc := Tedex_Tls.Fd_Wait_Read (Fd, Interfaces.C.int (Ms));
      if Rc = 1 then
         return True;
      elsif Rc = -1 then
         raise Net_Error with "socket error";
      else
         return False;  --  timeout or EINTR: caller re-checks its deadline
      end if;
   end Wait_One;

   --  Dual-fd wait. Returns bitmask (1 and/or 2), 0 on timeout.
   --  Raises Net_Error on fd errors.
   function Wait_Two (Fd1, Fd2 : Interfaces.C.int; Timeout : Duration)
     return Natural
   is
      Ms : constant Integer := Tedex_Time.To_Timeout_Ms (Timeout);
      Rc : Interfaces.C.int;
   begin
      Rc := Tedex_Tls.Fds_Wait_Read (Fd1, Fd2, Interfaces.C.int (Ms));
      if Rc >= 0 then
         return Natural (Rc);
      else
         raise Net_Error with "socket error";
      end if;
   end Wait_Two;

   function Wait_Readable (Sock : Socket_Type;
                             Timeout : Duration) return Boolean is
   begin
      return Wait_One (Sock_Fd (Sock), Timeout);
   end Wait_Readable;

   procedure Ignore_Sigpipe is
      procedure C_Ignore_Sigpipe;
      pragma Import (C, C_Ignore_Sigpipe, "tedex_ignore_sigpipe");
   begin
      C_Ignore_Sigpipe;
   end Ignore_Sigpipe;

   procedure Set_No_Delay (Sock : Socket_Type) is
   begin
      Set_Socket_Option (Sock, IP_Protocol_For_TCP_Level,
                         (No_Delay, True));
   exception
      when Socket_Error => null;
   end Set_No_Delay;

   function To_Elements (S : String) return Stream_Element_Array is
   begin
      return Tedex_Net_Pure.To_Elements (S);
   end To_Elements;

   procedure Send_All (Sock : Socket_Type; Data : Stream_Element_Array) is
      Sent : Stream_Element_Count := 0;
      Last : Stream_Element_Offset;
   begin
      while Sent < Data'Length loop
         Send_Socket (Sock, Data (Data'First + Sent .. Data'Last), Last);
         if Last < Data'First + Sent then
            raise Net_Error with "closed";
         end if;
         Sent := Sent + (Last - (Data'First + Sent) + 1);
      end loop;
   exception
      when Socket_Error =>
         raise Net_Error;
   end Send_All;

   procedure Send_Line (Sock : Socket_Type; S : String) is
   begin
      Send_All (Sock, To_Elements (S & ASCII.LF));
   end Send_Line;

   procedure Send_Data (Sock : Socket_Type; S : String) is
   begin
      if S'Length > 0 then
         Send_All (Sock, To_Elements (S));
      end if;
   end Send_Data;

   function Recv_Line (Sock    : Socket_Type;
                       Timeout : Duration := 3_600.0) return String is
      Fd     : constant Interfaces.C.int := Sock_Fd (Sock);
      Buf    : String (1 .. Max_Line_Len);
      N      : Natural := 0;
      Left   : Duration := Timeout;
   begin
      loop
         if not Wait_One (Fd, (if Left > 5.0 then 5.0 else Left)) then
            Left := Left - 5.0;
            if Left <= 0.0 then
               raise Net_Error with "timeout";
            end if;
         else
            declare
               One  : Stream_Element_Array (1 .. 1);
               Last : Stream_Element_Offset;
            begin
               Receive_Socket (Sock, One, Last);
               if Last < One'First then
                  raise Net_Error with "closed";
               end if;
               if One (1) = Character'Pos (ASCII.LF) then
                  declare
                     Raw : String renames Buf (1 .. N);
                  begin
                     if N > 0 and then Raw (N) = ASCII.CR then
                        return Raw (1 .. N - 1);
                     end if;
                     return Raw;
                  end;
               end if;
               N := N + 1;
               if N > Max_Line_Len then
                  raise Net_Error with "line too long";
               end if;
               Buf (N) := Character'Val (One (1));
            end;
         end if;
      end loop;
   exception
      when Socket_Error =>
         raise Net_Error with "socket error";
   end Recv_Line;

   procedure Splice (A, B : Socket_Type) is
      --  Half-close aware relay: EOF from one side shuts down the write
      --  side of the other (so pending output still gets through), and the
      --  session ends only after both sides reach EOF.
      A_Eof, B_Eof : Boolean := False;

      procedure Quiet_Close (S : Socket_Type) is
      begin
         Close_Socket (S);
      exception
         when Socket_Error => null;
      end Quiet_Close;

      procedure Pump (Src, Dst : Socket_Type;
                      Src_Eof  : in out Boolean) is
         Item : Stream_Element_Array (1 .. 32_768);
         Last : Stream_Element_Offset;
      begin
         if Src_Eof then
            return;
         end if;
         Receive_Socket (Src, Item, Last);
         if Last < Item'First then
            Src_Eof := True;
            begin
               Shutdown_Socket (Dst, Shut_Write);
            exception
               when Socket_Error => null;
            end;
         else
            begin
               Send_All (Dst, Item (Item'First .. Last));
            exception
               when Net_Error =>
                  Src_Eof := True;
                  B_Eof := True;
                  A_Eof := True;
            end;
         end if;
      exception
         when Socket_Error =>
            Src_Eof := True;
            begin
               Shutdown_Socket (Dst, Shut_Write);
            exception
               when Socket_Error => null;
            end;
      end Pump;

   begin
      declare
         FA : constant Interfaces.C.int := Sock_Fd (A);
         FB : constant Interfaces.C.int := Sock_Fd (B);
         Ready : Natural;
      begin
         while not (A_Eof and B_Eof) loop
            Ready := Wait_Two (FA, FB, 1.0);
            if (Ready mod 2 = 1) and then not A_Eof then
               Pump (A, B, A_Eof);
            end if;
            if (Ready / 2 = 1) and then not B_Eof then
               Pump (B, A, B_Eof);
            end if;
         end loop;
      exception
         when Net_Error =>
            null;  --  fd error while waiting; fall through to close
      end;
      Quiet_Close (A);
      Quiet_Close (B);
   exception
      when Socket_Error =>
         null;
   end Splice;

   ----------------
   -- WebSocket  --
   ----------------

   CRLF : constant String := [ASCII.CR, ASCII.LF];

   --  String normalization/parsing lives in the proved Tedex_Util
   --  unit (single copy); the two historical locals were removed.

   function Peek_Http (Sock : Socket_Type) return Boolean is
      Item   : Stream_Element_Array (1 .. 4);
      Last   : Stream_Element_Offset;
   begin
      if not Wait_One (Sock_Fd (Sock), 60.0) then
         raise Net_Error with "timeout";
      end if;
      Receive_Socket (Sock, Item, Last, Flags => Peek_At_Incoming_Data);
      if Last - Item'First + 1 < 4 then
         return False;
      end if;
      return Item (1) = Character'Pos ('G')
        and Item (2) = Character'Pos ('E')
        and Item (3) = Character'Pos ('T')
        and Item (4) = Character'Pos (' ');
   exception
      when Socket_Error =>
         raise Net_Error with "socket error";
   end Peek_Http;


   function Read_Until_Blank (Sock : Socket_Type;
                              Max  : Natural;
                              Timeout : Duration) return String is
      use Ada.Calendar;
      Fd     : constant Interfaces.C.int := Sock_Fd (Sock);
      Buf    : String (1 .. Max);
      N      : Natural := 0;
      Deadln : constant Time := Clock + Timeout;
      One    : Stream_Element_Array (1 .. 1);
      Last   : Stream_Element_Offset;
   begin
      loop
         declare
            Now  : constant Time := Clock;
            Left : constant Duration := Deadln - Now;
         begin
            if Left <= 0.0 then
               raise Net_Error with "timeout";
            end if;
            if not Wait_One (Fd, (if Left > 5.0 then 5.0 else Left)) then
               null;  --  idle slice elapsed; re-check deadline above
            else
               --  Byte at a time: never read past the blank line, so a
               --  pipelined first frame is left intact for the next stage.
               Receive_Socket (Sock, One, Last);
               if Last < One'First then
                  raise Net_Error with "closed";
               end if;
               if N = Max then
                  raise Net_Error with "headers too big";
               end if;
               N := N + 1;
               Buf (N) := Character'Val (One (1));
               if N >= 4
                 and then Buf (N - 3) = ASCII.CR
                 and then Buf (N - 2) = ASCII.LF
                 and then Buf (N - 1) = ASCII.CR
                 and then Buf (N) = ASCII.LF
               then
                  return Buf (1 .. N);
               end if;
            end if;
         end;
      end loop;
   exception
      when Socket_Error =>
         raise Net_Error with "socket error";
   end Read_Until_Blank;

   procedure Ws_Server_Handshake
     (Sock : Socket_Type;
      Path : out Ada.Strings.Unbounded.Unbounded_String)
   is
      use Ada.Strings.Unbounded;
      Req   : constant String := Read_Until_Blank (Sock, 8192, 10.0);
      Pos   : Natural := Req'First;
      L0    : Unbounded_String;
      Key   : Unbounded_String := Null_Unbounded_String;
      Is_Ws : Boolean := False;

      function Next_Line return String is
         Lf, Ll, Np : Natural;
      begin
         Tedex_Net_Pure.Next_Line_Bounds (Req, Pos, Lf, Ll, Np);
         Pos := Np;
         if Ll < Lf then
            return "";
         end if;
         return Req (Lf .. Ll);
      end Next_Line;
   begin
      Path := Null_Unbounded_String;
      L0 := To_Unbounded_String (Next_Line);
      --  request line: GET <path> HTTP/1.x
      if not Tedex_Net_Pure.Is_Http_Get (To_String (L0)) then
         raise Net_Error with "not websocket";
      end if;
      loop
         declare
            L : constant String := Tedex_Util.Trim_Blanks (Next_Line);
         begin
            exit when L = "";
            declare
               Nm : String (1 .. L'Length) := [others => ' '];
               Vl : String (1 .. L'Length) := [others => ' '];
               Nm_Len, Vl_Len : Natural;
               Has_Colon : Boolean;
            begin
               Tedex_Net_Pure.Header_Parts
                 (L, Nm, Nm_Len, Vl, Vl_Len, Has_Colon);
               if Has_Colon then
                  if Tedex_Util.Folded_Equal (Nm (1 .. Nm_Len), "upgrade")
                    and then Tedex_Util.Folded_Equal
                               (Vl (1 .. Vl_Len), "websocket")
                  then
                     Is_Ws := True;
                  elsif Tedex_Util.Folded_Equal
                          (Nm (1 .. Nm_Len), "sec-websocket-key")
                  then
                     Key := To_Unbounded_String (Vl (1 .. Vl_Len));
                  end if;
               end if;
            end;
         end;
      end loop;
      if not Is_Ws or else Length (Key) not in 1 .. Tedex_Ws.Max_Key_In then
         Send_All (Sock,
           To_Elements ("HTTP/1.1 404 Not Found" & CRLF
                        & "Content-Length: 11" & CRLF
                        & "Connection: close" & CRLF
                        & "Content-Type: text/plain" & CRLF & CRLF
                        & "no service" & ASCII.LF));
         raise Net_Error with "not websocket";
      end if;
      declare
         K       : constant String := To_String (Key);
         Acc_Key : constant String := Tedex_Ws.Accept_Key (K);
         P       : constant String := To_String (L0);
         PBuf    : String (1 .. P'Length) := [others => '/'];
         PLen    : Natural;
      begin
         Tedex_Net_Pure.Request_Path (P, PBuf, PLen);
         Path := To_Unbounded_String (PBuf (1 .. PLen));
         Send_All (Sock,
           To_Elements ("HTTP/1.1 101 Switching Protocols" & CRLF
                        & "Upgrade: websocket" & CRLF
                        & "Connection: Upgrade" & CRLF
                        & "Sec-WebSocket-Accept: " & Acc_Key & CRLF & CRLF));
      end;
   end Ws_Server_Handshake;

   function Next_Mask return String is
      use Ada.Streams.Stream_IO;
      F   : File_Type;
      Buf : Stream_Element_Array (1 .. 4);
      Last : Stream_Element_Offset;
      M   : String (1 .. 4);
   begin
      Open (F, In_File, "/dev/urandom");
      Read (F, Buf, Last);
      Close (F);
      for I in 1 .. 4 loop
         M (I) := Character'Val (Buf (Stream_Element_Offset (I)));
      end loop;
      return M;
   exception
      when others =>
         return "1234";  --  never in practice; framing stays valid
   end Next_Mask;

   procedure Ws_Send (Sock   : Socket_Type;
                      Data   : String;
                      Opcode : Natural := 2;
                      Masked : Boolean := False) is
      Buf   : String (1 .. 14 + Tedex_Ws.Max_Frame_Payload);
      First : Integer := Data'First;
      Rest  : Integer := Data'Length;
      First_Frag : Boolean := True;
   begin
      if Rest = 0 then
         declare
            FL : Natural;
         begin
            if Masked then
               Tedex_Ws.Encode_Client_Frame
                 ("", Opcode, Next_Mask, Buf, FL, Fin => True);
            else
               Tedex_Ws.Encode_Frame ("", Opcode, Buf, FL, Fin => True);
            end if;
            Send_All (Sock, To_Elements (Buf (1 .. FL)));
            return;
         end;
      end if;
      while Rest > 0 loop
         declare
            N   : constant Integer :=
              Integer'Min (Rest, Tedex_Ws.Max_Frame_Payload);
            Ch  : String (1 .. N);
            FL  : Natural;
            Last_Frag : constant Boolean := (N = Rest);
            Op  : constant Natural :=
              (if First_Frag then Opcode else 0);
         begin
            Ch := Data (First .. First + N - 1);
            if Masked then
               Tedex_Ws.Encode_Client_Frame
                 (Ch, Op, Next_Mask, Buf, FL, Fin => Last_Frag);
            else
               Tedex_Ws.Encode_Frame
                 (Ch, Op, Buf, FL, Fin => Last_Frag);
            end if;
            Send_All (Sock, To_Elements (Buf (1 .. FL)));
            First := First + N;
            Rest := Rest - N;
            First_Frag := False;
         end;
      end loop;
   end Ws_Send;

   function Read_Exact (Sock : Socket_Type;
                        N    : Natural;
                        Deadln : Ada.Calendar.Time) return String is
      use Ada.Calendar;
      Fd     : constant Interfaces.C.int := Sock_Fd (Sock);
      Buf    : String (1 .. Integer'Max (N, 1));
      Got    : Natural := 0;
      Last   : Stream_Element_Offset;
   begin
      if N = 0 then
         return "";
      end if;
      while Got < N loop
         declare
            Left : constant Duration := Deadln - Clock;
         begin
            if Left <= 0.0 then
               raise Net_Error with "timeout";
            end if;
            if not Wait_One (Fd, (if Left > 5.0 then 5.0 else Left)) then
               null;  --  idle slice elapsed; re-check deadline above
            else
               --  Never over-read: ask for exactly the missing bytes,
               --  otherwise pipelined frame bytes would be lost.
               declare
                  Want : constant Natural := N - Got;
                  Slot : Stream_Element_Array (1 .. Stream_Element_Offset (Want));
               begin
                  Receive_Socket (Sock, Slot, Last);
                  if Last < Slot'First then
                     raise Net_Error with "closed";
                  end if;
                  for I in Slot'First .. Last loop
                     Got := Got + 1;
                     Buf (Got) := Character'Val (Slot (I));
                  end loop;
               end;
            end if;
         end;
      end loop;
      return Buf (1 .. N);
   exception
      when Socket_Error =>
         raise Net_Error with "socket error";
   end Read_Exact;

   function Recv_Exact (Sock    : Socket_Type;
                        N       : Natural;
                        Timeout : Duration) return String is
      use Ada.Calendar;
   begin
      return Read_Exact (Sock, N, Clock + Timeout);
   end Recv_Exact;


   procedure Ws_Recv_Message (Sock    : Socket_Type;
                              Timeout : Duration := 3_600.0;
                              Payload : out Ada.Strings.Unbounded.Unbounded_String;
                              Masked_Replies : Boolean := False;
                              Masked_Expected : Boolean := True)
   is
      use Ada.Calendar;
      use Ada.Strings.Unbounded;
      Deadln  : constant Time := Clock + Timeout;
      Msg     : Unbounded_String := Null_Unbounded_String;
      Started : Boolean := False;
   begin
      Payload := Null_Unbounded_String;
      loop
         declare
            Hdr2 : constant String := Read_Exact (Sock, 2, Deadln);
            L7   : constant Natural :=
              Character'Pos (Hdr2 (Hdr2'Last)) mod 128;
            Ext  : constant Natural :=
              (if L7 < 126 then 0 elsif L7 = 126 then 2 else 8);
            Need : constant Natural :=
              2 + Ext + (if Masked_Expected then 4 else 0);
            Rest : constant String :=
              Read_Exact (Sock, Need - 2, Deadln);
            Full : constant String := Hdr2 & Rest;
            H    : Tedex_Ws.Frame_Header;
            Ok   : Boolean;
         begin
            Tedex_Ws.Decode_Header (Full, H, Ok, Masked_Expected);
            if not Ok then
               raise Net_Error with "bad frame";
            end if;
            declare
               Pay  : String := Read_Exact (Sock, H.Pay_Len, Deadln);
            begin
               if Masked_Expected then
                  declare
                     Msk : constant String (1 .. 4) :=
                       Full (Full'Last - 3 .. Full'Last);
                  begin
                     if Pay'Length > 0 then
                        Tedex_Ws.Xor_Mask (Pay, Msk);
                     end if;
                  end;
               end if;
               case H.Opcode is
                  when 8 =>
                     begin
                        Ws_Send (Sock, Pay (Pay'First .. Pay'First - 1), 8,
                                 Masked_Replies);
                     exception
                        when Net_Error => null;
                     end;
                     raise Net_Error with "closed";
                  when 9 =>
                     Ws_Send (Sock, Pay, 10, Masked_Replies);
                  when 10 =>
                     Pong_Track.Note;
                  when 0 =>
                     if not Started then
                        raise Net_Error with "unexpected continuation";
                     end if;
                     if Length (Msg) > Tedex_Ws.Msg_Cap - Pay'Length then
                        raise Net_Error with "message too big";
                     end if;
                     Append (Msg, Pay);
                     if H.Fin then
                        Payload := Msg;
                        return;
                     end if;
                  when 1 | 2 =>
                     if Started then
                        raise Net_Error with "interleaved message";
                     end if;
                     Started := True;
                     Msg := To_Unbounded_String (Pay);
                     if H.Fin then
                        Payload := Msg;
                        return;
                     end if;
                  when others =>
                     raise Net_Error with "bad opcode";
               end case;
            end;
         end;
      end loop;
   end Ws_Recv_Message;

   procedure Ws_Send_Line (Sock   : Socket_Type;
                           S      : String;
                           Masked : Boolean := False) is
   begin
      Ws_Send (Sock, S, 2, Masked);
   end Ws_Send_Line;

   procedure Ws_Recv_Line (Sock    : Socket_Type;
                           Timeout : Duration := 3_600.0;
                           Masked_Replies : Boolean := False;
                           Masked_Expected : Boolean := True;
                           Line : out Ada.Strings.Unbounded.Unbounded_String) is
   begin
      Ws_Recv_Message (Sock, Timeout, Line, Masked_Replies, Masked_Expected);
   end Ws_Recv_Line;

   procedure Ws_Splice (S1 : Socket_Type; S1_Ws : Boolean;
                        S2 : Socket_Type; S2_Ws : Boolean) is

      protected Done_Flag is
         procedure Set;
         function Done return Boolean;
      private
         D : Boolean := False;
      end Done_Flag;

      protected body Done_Flag is
         procedure Set is
         begin
            D := True;
         end Set;
         function Done return Boolean is (D);
      end Done_Flag;

      procedure Net_Send (To : Socket_Type; To_Ws : Boolean; Data : String) is
      begin
         if To_Ws then
            Ws_Send (To, Data, 2);
         else
            Send_All (Sock => To, Data => To_Elements (Data));
         end if;
      end Net_Send;

      function Net_Recv (From : Socket_Type; From_Ws : Boolean;
                         Timeout : Duration)
        return Ada.Strings.Unbounded.Unbounded_String
      is
         use Ada.Strings.Unbounded;
         P : Unbounded_String;
      begin
         if From_Ws then
            Ws_Recv_Message (From, Timeout, P);
            return P;
         else
            declare
               Chunk  : Stream_Element_Array (1 .. 32_768);
               Last   : Stream_Element_Offset;
            begin
               if not Wait_One (Sock_Fd (From), Timeout) then
                  raise Net_Error with "timeout";
               end if;
               Receive_Socket (From, Chunk, Last);
               if Last < Chunk'First then
                  raise Net_Error with "closed";
               end if;
               return To_Unbounded_String
                 (Tedex_Net_Pure.To_String (Chunk (Chunk'First .. Last)));
            exception
               when Socket_Error =>
                  raise Net_Error with "socket error";
            end;
         end if;
      end Net_Recv;

      procedure Half_Close (To : Socket_Type; To_Ws : Boolean) is
      begin
         if To_Ws then
            begin
               Ws_Send (To, "", 8);
            exception
               when Net_Error => null;
            end;
         else
            begin
               Shutdown_Socket (To, Shut_Write);
            exception
               when Socket_Error => null;
            end;
         end if;
      end Half_Close;

      procedure Kick_Both is
      begin
         --  Wake the surviving pump at once: without this it can sleep
         --  up to 30 s in a WS read while the session is already dead
         --  (stale attach => "device busy" ghosts).
         begin
            Shutdown_Socket (S1, Shut_Read_Write);
         exception
            when Socket_Error => null;
         end;
         begin
            Shutdown_Socket (S2, Shut_Read_Write);
         exception
            when Socket_Error => null;
         end;
      end Kick_Both;

      type Pump_Job is record
         From, To       : Socket_Type;
         From_Ws, To_Ws : Boolean;
      end record;

      type Pump_Job_Ptr is access Pump_Job;

      task type Pump (Job : Pump_Job_Ptr);

      task body Pump is
         use Ada.Strings.Unbounded;
      begin
         loop
            exit when Done_Flag.Done;
            begin
               declare
                  M : constant Unbounded_String :=
                    Net_Recv (Job.From, Job.From_Ws,
                              (if Job.From_Ws then 30.0 else 1.0));
               begin
                  Net_Send (Job.To, Job.To_Ws, To_String (M));
               end;
            exception
               when E : Net_Error =>
                  if Ada.Exceptions.Exception_Message (E) = "timeout" then
                     if Job.From_Ws then
                        begin
                           Ws_Send (Job.From, "", 9);
                        exception
                           when Net_Error =>
                              Done_Flag.Set;
                              Kick_Both;
                              exit;
                        end;
                     end if;
                     --  raw idle timeout: just loop again (checks Done)
                  else
                     Half_Close (Job.To, Job.To_Ws);
                     Done_Flag.Set;
                     Kick_Both;
                     exit;
                  end if;
               when Socket_Error =>
                  Half_Close (Job.To, Job.To_Ws);
                  Done_Flag.Set;
                  Kick_Both;
                  exit;
            end;
         end loop;
      end Pump;

      P1 : Pump (new Pump_Job'(From => S1, From_Ws => S1_Ws,
                                 To   => S2, To_Ws   => S2_Ws));
      P2 : Pump (new Pump_Job'(From => S2, From_Ws => S2_Ws,
                                 To   => S1, To_Ws   => S1_Ws));

   begin
      null;
   exception
      when others =>
         Done_Flag.Set;
   end Ws_Splice;

   procedure Ws_Client_Handshake (Sock       : Socket_Type;
                                  Host, Path, Key : String) is
      Req : constant String :=
        "GET " & Path & " HTTP/1.1" & CRLF
        & "Host: " & Host & CRLF
        & "Upgrade: websocket" & CRLF
        & "Connection: Upgrade" & CRLF
        & "Sec-WebSocket-Key: " & Key & CRLF
        & "Sec-WebSocket-Version: 13" & CRLF & CRLF;
      Want : constant String := Tedex_Ws.Accept_Key (Key);
   begin
      Send_All (Sock, To_Elements (Req));
      declare
         Resp : constant String := Read_Until_Blank (Sock, 8192, 15.0);
      begin
         --  101/accept-key validation is proved in Tedex_Util
         --  (same verdicts, same messages as the inline version).
         case Tedex_Util.Check_Handshake (Resp, Want) is
            when Tedex_Util.Hs_Ok =>
               null;
            when Tedex_Util.Hs_Bad_Status =>
               raise Net_Error with "handshake rejected";
            when Tedex_Util.Hs_Bad_Key =>
               raise Net_Error with "bad accept key";
         end case;
      end;
   end Ws_Client_Handshake;

end Tedex_Net;
