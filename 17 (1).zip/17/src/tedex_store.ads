--  Account record plus parsing/serialization of DB lines.
--  Fully in SPARK. DB file format per line:  name:salt$hash:disabled:limit
with Tedex_Crypto;
with Tedex_Protocol;

package Tedex_Store with SPARK_Mode is

   Max_Account_Line : constant := 256;
   Max_Limit        : constant := 10_000;
   Field_Cap        : constant := 128;
   --  Field width cap of the legacy flat-file splitter (mirrors the
   --  historical Unbounded-based Split2 in Tedex_DB, now retired).

   type Account is record
      Name     : String (1 .. Tedex_Protocol.Max_Name) := [others => ' '];
      Name_Len : Natural range 0 .. Tedex_Protocol.Max_Name := 0;
      Hash     : String (1 .. Tedex_Crypto.Stored_Len) := [others => ' '];
      Disabled : Boolean := False;
      Limit    : Natural range 1 .. Max_Limit := 10;
   end record;

   --  Parse one "name:hash:0|1:limit" line. Ok is False on any shape error.
   --  Boundary obligation: caller must normalize Line to First = 1.
   procedure Parse_Account_Line (Line : String;
                                 Acc  : out Account;
                                 Ok   : out Boolean)
     with Pre => Line'First = 1 and Line'Length <= Max_Account_Line,
          Global => null,
          Depends => ((Acc, Ok) => Line);

   function Format_Account_Line (Acc : Account) return String
     with Post => Format_Account_Line'Result'Length <= Max_Account_Line
                  and Format_Account_Line'Result'First = 1,
          Global => null,
          Depends => (Format_Account_Line'Result => Acc);

   --  Split "user:dev[:rest]" at the first two colons. Mirrors the
   --  retired Unbounded Split2 point-for-point: False when there is no
   --  colon or a capped field overflows 128; one colon yields F2 = tail
   --  with LR = 0; empty fields are allowed. Token/shape policy stays
   --  with the caller (the '%' line keeps its secret verbatim).
   --  Buffers F1/F2 hold 128 chars each; Rt must fit the whole line.
   procedure Parse_Migrate_Fields (Line : String;
                                   F1   : out String; L1 : out Natural;
                                   F2   : out String; L2 : out Natural;
                                   Rt   : out String; LR : out Natural;
                                   Ok   : out Boolean; Two : out Boolean)
     with Pre  => Line'First >= 1 and Line'Last < Integer'Last
                  and Line'Length <= Max_Account_Line
                  and F1'First = 1 and F1'Length >= Field_Cap
                  and F2'First = 1 and F2'Length >= Field_Cap
                  and Rt'First = 1 and Rt'Length >= Line'Length,
          Post => L1 <= Field_Cap and L2 <= Field_Cap
                  and LR <= Line'Length
                  and (if not Ok then L1 = 0 and L2 = 0 and LR = 0
                                      and not Two)
                  and (if Ok and Two then
                         L1 + L2 + LR + 2 = Line'Length)
                  and (if Ok and not Two then
                         LR = 0 and L1 + L2 + 1 = Line'Length),
          Global => null,
          Depends => ((L1, L2, LR, Ok, Two) => Line,
                      F1 =>+ Line, F2 =>+ Line, Rt =>+ Line);

end Tedex_Store;
