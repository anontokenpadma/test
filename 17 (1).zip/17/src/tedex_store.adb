package body Tedex_Store with SPARK_Mode is

   procedure Parse_Account_Line (Line : String;
                                 Acc  : out Account;
                                 Ok   : out Boolean) is
      subtype Field_No is Integer range 1 .. 4;
      F_Data : array (Field_No) of String (1 .. 128) :=
        [others => [others => ' ']];
      F_Len  : array (Field_No) of Natural range 0 .. 128 := [others => 0];
      NF   : Integer range 0 .. 4 := 0;
      In_F : Boolean := False;
   begin
      Acc := (Name     => [others => ' '], Name_Len => 0,
              Hash     => [others => ' '],
              Disabled => False, Limit => 10);
      Ok := False;
      for I in 1 .. Line'Length loop
         pragma Loop_Invariant (NF <= 4);
         pragma Loop_Invariant (if In_F then NF in 1 .. 4);
         if Line (I) = ':' then
            In_F := False;
         elsif not In_F then
            if NF = 4 then
               return;
            end if;
            NF := NF + 1;
            In_F := True;
            F_Len (NF) := 1;
            F_Data (NF) (1) := Line (I);
         else
            if F_Len (NF) = 128 then
               return;
            end if;
            F_Len (NF) := F_Len (NF) + 1;
            F_Data (NF) (F_Len (NF)) := Line (I);
         end if;
      end loop;
      if NF /= 4 then
         return;
      end if;
      --  name: nonempty, bounded, safe charset
      if F_Len (1) not in 1 .. Tedex_Protocol.Max_Name then
         return;
      end if;
      for I in 1 .. F_Len (1) loop
         pragma Loop_Invariant
           (for all J in 1 .. I - 1 =>
              F_Data (1) (J) in 'a' .. 'z' or F_Data (1) (J) in 'A' .. 'Z'
              or F_Data (1) (J) in '0' .. '9' or F_Data (1) (J) = '_'
              or F_Data (1) (J) = '-' or F_Data (1) (J) = '.');
         declare
            C : constant Character := F_Data (1) (I);
         begin
            if not (C in 'a' .. 'z' or C in 'A' .. 'Z'
                    or C in '0' .. '9' or C = '_' or C = '-' or C = '.')
            then
               return;
            end if;
         end;
      end loop;
      Acc.Name_Len := F_Len (1);
      Acc.Name (1 .. Acc.Name_Len) := F_Data (1) (1 .. F_Len (1));
      --  hash: must be a well-shaped "salt$hash"
      if F_Len (2) /= Tedex_Crypto.Stored_Len then
         return;
      end if;
      declare
         H : constant String (1 .. Tedex_Crypto.Stored_Len) :=
           F_Data (2) (1 .. Tedex_Crypto.Stored_Len);
         Salt : Tedex_Crypto.Salt_String;
         HH   : Tedex_Crypto.Hash_String;
         HOk  : Boolean;
      begin
         Tedex_Crypto.Split_Stored (H, Salt, HH, HOk);
         if not HOk then
            return;
         end if;
         Acc.Hash := Salt & "$" & HH;
      end;
      --  disabled flag: exactly "0" or "1"
      if F_Len (3) /= 1 then
         return;
      end if;
      if F_Data (3) (1) = '1' then
         Acc.Disabled := True;
      elsif F_Data (3) (1) /= '0' then
         return;
      end if;
      --  limit: decimal 1 .. 10000
      if F_Len (4) not in 1 .. 6 then
         return;
      end if;
      declare
         V : Natural := 0;
      begin
         for I in 1 .. F_Len (4) loop
            pragma Loop_Invariant (V <= 10_000);
            declare
               C : constant Character := F_Data (4) (I);
               D : Natural;
            begin
               if C not in '0' .. '9' then
                  return;
               end if;
               D := Character'Pos (C) - Character'Pos ('0');
               if V > 1000 then
                  return;
               end if;
               V := V * 10 + D;
               if V > 10_000 then
                  return;
               end if;
            end;
         end loop;
         if V < 1 then
            return;
         end if;
         Acc.Limit := V;
      end;
      Ok := True;
   end Parse_Account_Line;

   function Format_Account_Line (Acc : Account) return String is
     (Acc.Name (1 .. Acc.Name_Len) & ":" & Acc.Hash & ":"
      & (if Acc.Disabled then "1" else "0") & ":"
      & Tedex_Protocol.Nat_Image (Acc.Limit));

   procedure Parse_Migrate_Fields (Line : String;
                                   F1   : out String; L1 : out Natural;
                                   F2   : out String; L2 : out Natural;
                                   Rt   : out String; LR : out Natural;
                                   Ok   : out Boolean; Two : out Boolean) is
      P1 : Integer := 0;
      P2 : Integer := 0;
      C  : Integer := Line'First;
   begin
      F1 := [others => ' '];
      F2 := [others => ' '];
      Rt := [others => ' '];
      L1 := 0;
      L2 := 0;
      LR := 0;
      Ok := False;
      Two := False;
      while C <= Line'Last loop
         pragma Loop_Invariant (C in Line'First .. Line'Last + 1);
         pragma Loop_Variant (Increases => C);
         if Line (C) = ':' then
            P1 := C;
            exit;
         end if;
         C := C + 1;
      end loop;
      if P1 = 0 then
         return;
      end if;
      L1 := P1 - Line'First;
      if L1 > Field_Cap then
         L1 := 0;
         return;
      end if;
      if L1 > 0 then
         F1 (1 .. L1) := Line (Line'First .. P1 - 1);
      end if;
      C := P1 + 1;
      while C <= Line'Last loop
         pragma Loop_Invariant (C in P1 + 1 .. Line'Last + 1);
         pragma Loop_Variant (Increases => C);
         if Line (C) = ':' then
            P2 := C;
            exit;
         end if;
         C := C + 1;
      end loop;
      if P2 = 0 then
         L2 := Line'Last - P1;
         if L2 > Field_Cap then
            L1 := 0;
            L2 := 0;
            return;
         end if;
         if L2 > 0 then
            F2 (1 .. L2) := Line (P1 + 1 .. Line'Last);
         end if;
         Ok := True;
         return;
      end if;
      L2 := P2 - P1 - 1;
      if L2 > Field_Cap then
         L1 := 0;
         L2 := 0;
         return;
      end if;
      if L2 > 0 then
         F2 (1 .. L2) := Line (P1 + 1 .. P2 - 1);
      end if;
      LR := Line'Last - P2;
      if LR > 0 then
         Rt (1 .. LR) := Line (P2 + 1 .. Line'Last);
      end if;
      Two := True;
      Ok := True;
   end Parse_Migrate_Fields;

end Tedex_Store;
