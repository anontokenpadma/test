Require Import VST.floyd.proofauto.
Check @semax.
