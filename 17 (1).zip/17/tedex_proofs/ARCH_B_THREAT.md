# Tedex B — Architecture / Trim bug / Threat model (reconstructed 2026-10-07)

Nguồn duy nhất: Tedex.zip (43 files, 10456 dòng: wc -l src/*.ad* src/*.c tests/*.adb).
Mọi claim dưới đây trích file:dòng thật, đã grep kiểm chứng.

## 1. Kiến trúc (protocol/util/net_pure/sha/sha1/b64/crypto/ws/tls/term/time/shell/echo/store/db/net/server/client/admin/C/tests)

| Lớp | File | Vai trò |
|---|---|---|
| protocol | src/tedex_protocol.ads/adb (178/434 dòng) | Parser lệnh, Max_Dev=64 (ads:7), Backoff_Secs (adb:420-432) |
| util | src/tedex_util.ads/adb (291/500) | Auth_Verdict (adb:387-401, ads:175-186), Jittered_Backoff, Should_Forward_Resize (adb:408-414), Tail_Blank |
| net_pure | src/tedex_net_pure.ads/adb (97/123) | Logic thuần, SPARK_Mode On |
| sha/sha1/b64 | src/tedex_sha.adb (247), sha1.adb (137), b64.adb (36) + ads | Hash, SPARK On |
| crypto | src/tedex_crypto.ads/adb (63/76) | Hash_Password (adb:6), Secure_Equal (adb:17), SPARK On |
| ws | src/tedex_ws.ads/adb (224/201) | WebSocket framing |
| tls | src/tedex_tls.ads (57) | WSS spec |
| term | src/tedex_term.ads (33) | Terminal spec |
| time | src/tedex_time.ads/adb (31/24) | Thời gian |
| shell | src/tedex_shell.ads/adb (52/105) | Spawn shell, SPARK On |
| echo | src/tedex_echo.ads/adb (26/34) | Common_Prefix, Bracket_Pre (B1/B2 ESC[?2004l/h), SPARK Off có rationale |
| store | src/tedex_store.ads/adb (65/205) | Account record, SPARK On |
| db | src/tedex_db.ads/adb (75/940) | Load/Find, Verify_Key (adb:872-938), SPARK Off |
| net | src/tedex_net.ads/adb (103/826) | Socket, SPARK On (ads:9) |
| server | src/server.adb (1346) | Registry protected object (Devs/Mgrs/Atts/Gones/Next_Seq), Handle_Device/Manager/Connection, Do_Attach_Splice, Poller |
| client | src/client.adb (2434) | Device + manager legs, Get_Cmd_Alive Silent>=4 |
| admin | src/admin.adb (330) | add/create-key |
| C | src/termhelp.c (197), tlswrap.c (414) | term_attach/read_line/raw/nonblock/read_chunk, tls_open/reap/pty_poll/set_size/close, fd_read_timeout/write_all |
| tests | tests/echo_vectors.adb (145), sha_vectors.adb (83), fuzz_parsers.adb (276) | Decide vectors, SHA vectors, fuzz |

SPARK: hầu hết ads SPARK_Mode On; Off chỉ echo/db (boundary + DB IO).

## 2. v11 server.adb: Trim_User oldest-first + Count_Attached + Last_Dropped

diff 11.zip vs Tedex.zip (gốc) trên src/server.adb:

- Spec: +`function Count_Attached (U) return Natural` (v11:102), `Trim_User (U, Keep, Dropped, Last_Dropped: out Unbounded_String)` (v11:107-108).
- Body: +`Count_Attached` đếm Atts (v11:236-246).
- Trim_User v11: N = Devs + Atts cùng user; Best_Seq := Natural'Last; chọn `Seq < Best_Seq` = OLDEST idle; `Last_Dropped := Devs(Best_Ix).Id`; comment: live shells count toward quota nhưng chỉ evict idle (never kill live shell, grandfather + block new ở AUTH); evict oldest vì same-name supersede giữ slot age, evict newest sẽ flap mỗi persist reconnect.
- AUTH: `Count_Dev + Count_Attached >= Limit` (v11:~1130).
- Poller trim gọi bản 4 tham số, log Last_Dropped.

## 3. BUG THẬT vs false positive đã rút

- BUG THẬT: Trim_User gốc (Tedex.zip server.adb:331-362): `Best_Seq := 0`, chọn `Seq > Best_Seq` = NEWEST. Đây là đuổi mới nhất — sai policy oldest-first của v11, gây flap persist reconnect. Đã đối chiếu diff trực tiếp.
- False positive đã rút: All_Users (server.adb:364-396) chỉ duyệt Devs + Mgrs, không duyệt Atts. Đây là đúng-thiết-kế (danh sách user, không phải attached sessions; attached đã có List_Attached:216-224), không phải bug.

## 4. Threat model: key lộ không cướp live session (3 cơ chế)

1. Manager leg không bao giờ dùng key: server.adb:1060-1075 chỉ tra password, `Key_Ok` chỉ lookup khi `not Pass_Ok and Req.Kind = Auth_Device`; Auth_Verdict với Is_Device=False cưỡng bức key vô hiệu (AuthVerdict.v: manager_never_uses_key).
2. Device leg vẫn cần Take_Dev + Mark_Attached + Wait_Handler_Gone: Do_Attach (788-) Take_Dev → Mark_Attached → Wait_Handler_Gone → Account_Still_Active → Do_Attach_Splice mới SHELL_START/ATTACHED; kẻ có key không chen vào splice đang sống.
3. Supersede an toàn: Reg_Dev trả Replaced socket cũ để caller đóng ngoài protected object; Unreg_Dev chỉ xóa khi entry vẫn trỏ đúng Sock (server.adb:84-94 comment), task stale không xóa live re-registration.

Đuổi-cũ an toàn hơn đuổi-mới: evict oldest tránh flap persist (v11 comment), không giết shell sống (grandfather), quota tính cả live.
